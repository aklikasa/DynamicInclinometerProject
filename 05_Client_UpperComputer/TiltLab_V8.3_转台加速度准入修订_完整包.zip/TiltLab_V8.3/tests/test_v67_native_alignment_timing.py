"""V6.7: protocol wire frame, read-only axis checks, lag diagnostic.
No live hardware or motor commands are executed in these tests.
"""
import json
import math
import struct
from pathlib import Path
import numpy as np
import pytest
from fastapi.testclient import TestClient
from app.rs422_feedback import parse_status_frame,FrameStreamParser,ReadOnlyFeedback422
from app.axis_static import StaticThreePoint
from app.dynamic_experiment import analyze_tracking,analyze_time_shift
from app.main import app


def make_frame(byte_order='<',counter=127,angle=4.75):
    p=bytearray(55);p[:5]=b'\xaa\x55\x37\x01\xa0';p[-1]=0xFE
    struct.pack_into(byte_order+'I',p,5,counter)
    for ix,x in enumerate([2026,11,14,9,10,11,145]):struct.pack_into(byte_order+'h',p,9+2*ix,x)
    for i,(status,position,speed) in enumerate(((2,0.,0.),(0,0.,0.),(5,angle,-1.25))):
        off=23+10*i
        struct.pack_into(byte_order+'Hff',p,off,status,position,speed)
    p[53]=sum(p[2:53])&255
    return bytes(p)


def test_wire_frame_parsed_directly_from_manual_layout():
    p=parse_status_frame(make_frame())
    assert p['counter']==127 and p['outer_status_raw']==5
    assert abs(p['outer_position_deg']-4.75)<1e-6
    assert abs(p['outer_speed_dps']+1.25)<1e-6
    assert p['device_datetime']=='2026-11-14T09:10:11.145'
    assert p['checksum_valid']
    q=parse_status_frame(make_frame('>',counter=2,angle=-5),byte_order='big')
    assert q['counter']==2 and q['outer_position_deg']==-5
    corrupted=bytearray(make_frame());corrupted[45]^=1
    with pytest.raises(ValueError,match='checksum'):parse_status_frame(bytes(corrupted))


def test_wire_stream_reassembles_split_and_ignores_garbage():
    parser=FrameStreamParser()
    f1=make_frame(counter=50);f2=make_frame(counter=51)
    assert parser.feed(b'\x01\x02'+f1[:21])==[]
    out=parser.feed(f1[21:]+b'junk'+f2)
    assert [x['counter'] for x in out]==[50,51]
    assert parser.feed(b'')==[]


def test_native_second_port_rejects_ddl_same_port_before_serial_open():
    class Table:connected=True;port=7
    r=ReadOnlyFeedback422(Path('/tmp/unused'),Table())
    with pytest.raises(ValueError,match='独立'):r.start('COM7')
    assert not r.running


def test_three_points_are_measured_encoder_not_nominal():
    obj=StaticThreePoint(None,None,Path('/tmp/unused'))
    obj.points={-3:{'outer_actual_deg':-2.94,'poses':{'cal':{'complementary':{'roll':-2.94,'pitch':-.1}}}},
        0:{'outer_actual_deg':.01,'poses':{'cal':{'complementary':{'roll':0,'pitch':0}}}},
        3:{'outer_actual_deg':3.03,'poses':{'cal':{'complementary':{'roll':3.03,'pitch':.1}}}}}
    r=obj.status()['analysis'];assert r['ready']
    assert math.isclose(r['measured_outer_span_deg'],5.97,abs_tol=.001)
    assert math.isclose(r['algorithms']['cal_complementary']['target_gain'],1,abs_tol=.001)
    assert 1<r['algorithms']['cal_complementary']['apparent_2d_cross_axis_deg']<2.5
    with pytest.raises(ValueError,match='确认'):obj.capture(0,confirmed=False)


def synthetic_lag(delay=.05):
    freq=.3;amp=5;start=3.;cycles=8;end=start+cycles/freq
    times=np.arange(0.,end+1.5,.04)
    def ref(t):return amp*np.sin(2*np.pi*freq*np.maximum(0,t-start))*(np.asarray(t)>=start)
    table=[{'pc_mid_ns':int(t*1e9),'axis_2_pos':float(ref(t))} for t in times]
    imu_t=np.arange(0.,end+1.5,.006)
    imu=[]
    for i,t in enumerate(imu_t):
        r={'host_est_ns':int(t*1e9),'pc_observed_ns':int(t*1e9),'device_t_s':float(t)}
        angle=float(ref(t-delay))
        for ch in ('raw','cal'):
            for algo in ('accel','complementary','kalman','mahony','adaptive','madgwick','gyro'):
                r[f'{ch}_{algo}_roll']=angle
        imu.append(r)
    return table,imu,int(start*1e9),int(end*1e9)


def test_time_shift_analysis_has_nonoverwritten_official_rmse():
    table,imu,start,end=synthetic_lag()
    r=analyze_tracking(table,imu,2,'roll',1,5,.3,start,end)
    assert r['valid']
    lag=r['time_shift_diagnostics']
    assert lag['available'],lag
    assert -80<lag['shift_reference_by_ms']<-20
    assert lag['test_raw_rmse_deg']>lag['test_shifted_rmse_deg']*2
    assert lag['correction_applied_to_official_rmse'] is False
    assert any('diagnostic_shifted_errors' in x for x in r['chart'])
    assert r['comparison'][0]['relative_tracking_rmse_deg']>0.15
    assert r['certified_dynamic_accuracy'] is False


def test_api_alignment_no_motion_and_native_disconnected_status():
    with TestClient(app) as c:
        assert c.get('/api/turntable/native/status').json()['running'] is False
        assert c.get('/api/axis-static/status').json()['read_only'] is True
        assert c.post('/api/axis-static/capture',json={'point':0,'confirmed':False}).status_code==400
        assert c.post('/api/axis-static/reset',json={'direction':'pitch'}).status_code==200
        assert c.get('/api/axis-static/status').json()['direction']=='pitch'
        c.post('/api/axis-static/reset',json={'direction':'roll'})
