import csv
import json
import time
from pathlib import Path
import pytest
from app.table_monitor import TableMonitor

class FakeTable:
    def __init__(self):
        self.connected=True
        self.reads=0
        self.motion_calls=0
    def read_status(self):
        self.reads+=1
        def axis(a):
            return {'position_deg':1.25+a/10+self.reads*.001,'speed_dps':0.01,
                    'mode':2,'enabled':True,'zeroed':True,'healthy':True,
                    'in_place':True,'upper_limit':False,'lower_limit':False,
                    'driver_fault':False,'over_speed':False}
        return {'connected':True,'axes':{'0':axis(0),'2':axis(2)},'time_monotonic_ns':time.monotonic_ns()}
    def move(self,*args):self.motion_calls+=1;raise AssertionError('unexpected move')
    def sway(self,*args):self.motion_calls+=1;raise AssertionError('unexpected sway')
    def stop(self,*args):self.motion_calls+=1;raise AssertionError('unexpected stop')

class FakeEngine:
    import threading
    lock=threading.RLock()
    source='offline'
    running=False
    connected=False
    latest=None

def test_reject_bad_interval_and_unconnected(tmp_path):
    t=FakeTable();m=TableMonitor(t,FakeEngine(),tmp_path)
    for x in (0,49,1001,'100',True):
        with pytest.raises(ValueError):m.start(x)
    t.connected=False
    with pytest.raises(ValueError,match='连接'):m.start(100)

def test_real_feedback_csv_no_motion(tmp_path):
    t=FakeTable();m=TableMonitor(t,FakeEngine(),tmp_path)
    r=m.start(50)
    assert r['state']=='recording'
    time.sleep(.22)
    result=m.stop()
    assert result['state']=='stopped'
    assert result['count']>=3
    assert not result['running']
    assert t.motion_calls==0
    f=tmp_path/result['file']
    assert f.exists()
    with f.open('r',encoding='utf-8-sig',newline='') as handle:
        rows=list(csv.DictReader(handle))
    assert len(rows)==result['count']
    assert float(rows[0]['axis_0_position_deg'])>1.2
    assert float(rows[0]['axis_2_position_deg'])>1.4
    assert rows[0]['pc_monotonic_ns'] and rows[0]['pc_utc']
    assert rows[0]['imu_roll_raw_deg']==''
    meta=json.loads(f.with_suffix('.json').read_text(encoding='utf-8'))
    assert meta['motion_commands_sent'] is False
    assert 'NOT' in meta['timestamp_accuracy']

def test_status_and_restarts(tmp_path):
    t=FakeTable();m=TableMonitor(t,FakeEngine(),tmp_path)
    m.start(50)
    with pytest.raises(ValueError,match='正在运行'):m.start(50)
    time.sleep(.13)
    status=m.status()
    assert status['latest']['axes']['0']['enabled'] is True
    assert status['recent'] and status['measured_rate_hz']>0
    first=m.stop()['file']
    m.start(50)
    time.sleep(.06)
    second=m.stop()['file']
    assert first!=second

def test_disconnect_fails_closed(tmp_path):
    t=FakeTable();m=TableMonitor(t,FakeEngine(),tmp_path)
    m.start(50)
    time.sleep(.075)
    t.connected=False
    time.sleep(.10)
    result=m.status()
    assert result['state']=='failed'
    assert '断开' in result['error']
    m.stop()
    assert (tmp_path/result['file']).exists()

def test_monitor_api_requires_real_table(monkeypatch):
    from fastapi.testclient import TestClient
    import app.main as main
    dummy=FakeTable();dummy.connected=False
    monkeypatch.setattr(main.TABLE_MONITOR,'table',dummy)
    with TestClient(main.app) as c:
        x=c.get('/api/turntable/monitor/status')
        assert x.status_code==200 and x.json()['running'] is False
        x=c.post('/api/turntable/monitor/start',json={'interval_ms':100})
        assert x.status_code==400
    main.TABLE_MONITOR.table=main.TABLE
