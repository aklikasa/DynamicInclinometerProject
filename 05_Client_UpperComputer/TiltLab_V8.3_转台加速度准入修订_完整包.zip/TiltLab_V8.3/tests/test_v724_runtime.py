"""V7.24 no-hardware regressions: safety latching and UI throttling only."""
import json
import queue
import time
from pathlib import Path
from types import SimpleNamespace

import pytest
from app.engine import Workstation
from app.auto_dynamic import AutoDynamicWorkflow, IMUWatchdogError
from app.static_accuracy import StaticBeforeDynamic
from app.table_prepare import TablePreparation
from test_v66_dual_axis import FakeTable, FakeEngine, _complete
from test_v720_deferred_reports import FakeDeferred
from tools.check_live_health import observe


def test_ui_history_decimation_does_not_mutate_history():
    engine=Workstation()
    engine.history.extend({'seq':i} for i in range(1,23))
    engine.history_seq=22
    full,last=engine.stream_history(0)
    sparse,cursor=engine.stream_history(0,4)
    assert [x['seq'] for x in full]==list(range(1,23))
    assert [x['seq'] for x in sparse]==[4,8,12,16,20,22]
    assert last==cursor==22 and len(engine.history)==22
    assert engine.stream_history(cursor)==([],22)


def test_stall_on_final_sample_still_latches_500ms(monkeypatch):
    engine=Workstation()
    engine._queue=queue.Queue()
    engine._acq_done.set()
    engine.running=True
    engine.connected=True
    current=time.monotonic_ns()
    engine._queue.put([({'batch_id':17,'batch_index':15},current,current)])
    def process(*args,**kwargs):
        time.sleep(.52)
    monkeypatch.setattr(engine,'process',process)
    engine._fusion_loop()
    assert '500ms' in engine._pipeline_error
    assert not engine.connected and not engine.running
    assert engine._fault_perf['peak_ms']['process']>=500
    assert engine._fault_perf['batch_id']==17


def test_static_reposition_keeps_original_samples_and_order():
    engine=Workstation()
    engine.recent.extend({'sequence':i,'gyro_cal':[float(i),0.,0.]}
                         for i in range(1,10))
    static=StaticBeforeDynamic(None,engine,Path('.'))
    static._collect_mount_gyro=True
    assert static._collect_moving_samples(6)==9
    assert static._mount_gyro_moving==[[7.,0.,0.],[8.,0.,0.],[9.,0.,0.]]
    assert static._collect_moving_samples(9)==9
    assert len(static._mount_gyro_moving)==3


def test_static_speed_is_independent_and_validated(tmp_path,monkeypatch):
    w=AutoDynamicWorkflow(None,None,None,SimpleNamespace(dir=tmp_path))
    w.plan={'zero_speed_dps':2.,'static_position_speed_dps':3.,
            'static_limit_deg':.1,'amplitude_deg':5.}
    seen=[]
    def fake(*args,**kwargs):
        seen.append(args[3])
        return 'static.json',{'mount_axis_precheck':{'pass_for_dynamic':True}}
    monkeypatch.setattr(w.static_precheck,'run',fake)
    _,_,meta=w._capture_static_with_axis_retry('roll',0,1,None)
    assert seen==[3.] and meta['attempts']==1 and w.plan['zero_speed_dps']==2.
    with pytest.raises(ValueError,match='静态定位速度'):
        w.start(2,'both',1,5,.3,10,2,True,'xy_sequential',True,
                static_position_speed_dps=4.)


def test_watchdog_after_completed_roll_keeps_roll_and_blocks_pitch(tmp_path,monkeypatch):
    class Partial(FakeDeferred):
        def finalize_deferred_reports(self):
            assert len(self.deferred_reports)==1
            assert ('stop',) in self.table.cmds
            self.finalized=True
            result={}
            for name in self.deferred_reports:
                p=self.dir/name
                data=json.loads(p.read_text());data['state']='completed'
                p.write_text(json.dumps(data))
                result[name]={'state':'completed','error':''}
            return result
    table=FakeTable();engine=FakeEngine()
    dynamic=Partial(tmp_path,table)
    auto=AutoDynamicWorkflow(table,engine,TablePreparation(table),dynamic)
    position=auto._position
    def blocked(axis,target):
        if axis==0 and target==90:
            raise IMUWatchdogError('倾角仪数据中断，停止运动')
        return position(axis,target)
    monkeypatch.setattr(auto,'_position',blocked)
    auto.start(2,'both',1,5,.2,15,2,True,'xy_sequential',True)
    _complete(auto,engine,timeout=12)
    assert auto.state=='stopped_or_failed'
    assert auto.stopped_verified and dynamic.finalized
    assert len(auto.stages)==1 and auto.stages[0]['output']=='roll'
    assert auto.report_file=='roll_DYNAMIC.json'
    assert not any(cmd[0]=='sway_stage' and cmd[1]=='pitch' for cmd in table.cmds)


def test_health_observer_is_read_only_and_detects_failure(tmp_path):
    fake_time=[0.];count=[0]
    def clock():return fake_time[0]
    def sleep(x):fake_time[0]+=x
    def fetch():
        count[0]+=100
        return {'running':True,'connected':True,'source':'serial',
                'cal_status':'matched','uid':'DUT','count':count[0],
                'pipeline':{'mode':'realtime',
                    'acquired_samples':count[0],'raw_written_samples':count[0],
                    'queued_batches':0,'max_processing_age_ms':22.,
                    'watchdog':{'transport_alive':True,'pipeline_error':'',
                        'child_receipt_age_ms':10.,'fusion_receipt_age_ms':12.}}}
    result,prefix=observe(seconds=1,interval=.5,folder=tmp_path,
                          fetch=fetch,monotonic=clock,sleep=sleep)
    assert result['state']=='observed_pass' and result['poll_count']==3
    assert prefix.with_suffix('.csv').exists() and prefix.with_suffix('.json').exists()
    def broken():
        r=fetch();r['pipeline']['watchdog']['pipeline_error']='500ms stall';return r
    result,_=observe(seconds=1,interval=.5,folder=tmp_path,
                     fetch=broken,monotonic=clock,sleep=sleep)
    assert result['state']=='failed' and '500ms' in result['reason']
    # It never calls a table, serial link or POST endpoint.
