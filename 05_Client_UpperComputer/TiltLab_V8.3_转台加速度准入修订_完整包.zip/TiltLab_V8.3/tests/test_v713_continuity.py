import csv,io,json,math,zipfile
from dataclasses import asdict
import pytest
from app.fusion import Params,create_filter
from app.continuity_v713 import advance
from app.engine import Workstation
from app.acquisition_v712 import BatchClock
from app.diagnostic_bundle import make_bundle
from app.continuity_diagnostics import gap_summary
from app.replay_v712 import replay_missing

@pytest.mark.parametrize('name',['adaptive','mahony','madgwick','gyro','lever3d'])
def test_gap_bridge_no_acc_jump_and_hard_reset(name):
    p=Params();f=create_filter(name,p);f,_,_=advance(name,f,p,True,[0,0,1],[10,0,0],0.)
    f,o,act=advance(name,f,p,True,[0,1,0],[10,0,0],.12)
    assert act=='gyro_bridge' and o['roll']==pytest.approx(1.2,abs=1e-7)
    f,o,act=advance(name,f,p,True,[0,1,0],[10,0,0],.401)
    assert act=='reset' and o['roll']==pytest.approx(90,abs=1e-7)

def test_gap_uses_previous_endpoint_and_keeps_mahony_bias():
    p=Params();f=create_filter('adaptive',p);f,_,_=advance('adaptive',f,p,True,[0,0,1],[0,0,0],0.)
    f.bias=[math.radians(.2),0,0]
    f,o,act=advance('adaptive',f,p,True,[0,1,0],[20,0,0],.1)
    assert o['roll']==pytest.approx(1.02,abs=1e-7) and f.bias[0]==pytest.approx(math.radians(.2))

def test_live_flags_and_latched_degraded_status():
    e=Workstation();e.pipeline_mode='realtime';e.source='serial';e.active='adaptive';e.cal=None
    for t,g in [(0,0),(.1,20),(.101,20)]:
        e.process(dict(t=t,acc=[0,0,1],gyro=[g,0,0],device_t_original=t),int(1e9+t*1e9),int(1e9+t*1e9))
        if t==.1:assert e.latest['gap_bridge'] and not e.latest['gap_reset'] and e.latest['raw']['roll']==pytest.approx(1.)
    p=e.pipeline_status();assert p['gap_resets']==0 and p['long_gap_bridges']==1 and p['continuity_degraded_since_connect']

def test_replay_uses_original_step_for_each_filter():
    rows=[]
    for i in range(2):
        r={'fusion_dt_s':0,'imu_dt_s':.1 if i else 0,'gap_action':'reset' if i else 'normal','cal_adaptive_roll':123,'gap_reset':1 if i else 0}
        for ch in ('raw','cal'):
            r.update({f'{ch}_acc_{k}_g':v for k,v in zip('xyz',[0,0,1])});r.update({f'{ch}_gyro_{k}_dps':v for k,v in zip('xyz',[20*i,0,0])})
        rows.append(r)
    result,_=replay_missing(rows,asdict(Params()),None,'adaptive');assert result[1]['cal_gyro_roll']==pytest.approx(1.) and result[1]['cal_adaptive_roll']==123

def test_bundle_exact_excerpt_and_calibration_snapshot(tmp_path):
    reports=tmp_path/'reports';records=tmp_path/'records';reports.mkdir();records.mkdir();name='test_DYNAMIC.json'
    for n in ['test_imu.csv','test_table.csv']:(reports/n).write_text('x\n1\n')
    with zipfile.ZipFile(reports/'cal.zip','w') as z:z.writestr('DTS123_ACC_AMBIENT.json','{}')
    for n in ['raw.csv','poll.csv']:(records/n).write_text('poll_id,value\n1,1\n2,2\n3,3\n4,4\n5,5\n')
    (reports/name).write_text(json.dumps({'kind':'REAL_2TD600_SINE_DIAGNOSTIC','raw_file_imu':'test_imu.csv','raw_file_table':'test_table.csv','calibration_snapshot_file':'cal.zip','pipeline_start':{'poll_count':3},'pipeline_end':{'poll_count':4,'raw_file':'raw.csv','poll_file':'poll.csv'}}))
    with zipfile.ZipFile(io.BytesIO(make_bundle(reports,records,name))) as z:
        assert 'DTS123_ACC_AMBIENT.json' in z.namelist();assert 'test_imu.csv' in z.namelist()
        d=list(csv.DictReader(io.StringIO(z.read('test_DYNAMIC_raw_link_excerpt.csv').decode('utf-8-sig'))));assert [r['poll_id'] for r in d]==['2','3','4']
    with pytest.raises(ValueError):make_bundle(reports,records,'../test_DYNAMIC.json')

def test_gap_events_preserve_motion_flag():
    r=[dict(imu_dt_s=0,host_est_ns=100,pc_observed_ns=100,device_t_s=0),dict(imu_dt_s=.1,host_est_ns=100_000_100,pc_observed_ns=100_000_100,device_t_s=.1,gap_action='gyro_bridge',poll_id=3)]
    s=gap_summary(r,100,200_000_100);assert s['motion_steps_over_50ms']==1 and s['largest_gap_events'][0]['action']=='gyro_bridge'
