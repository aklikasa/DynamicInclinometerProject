"""No hardware access: optional diagnosis, file isolation, fault gating."""
import json,time
from pathlib import Path
import pytest
from app.auto_dynamic import AutoDynamicWorkflow
from app.auto_research_report import run_postprocess
from app.main import OneClickArgs
from app.table_prepare import TablePreparation
from test_v66_dual_axis import FakeTable,FakeEngine,_complete
from test_v720_deferred_reports import FakeDeferred


def test_request_and_checkbox():
    assert OneClickArgs().research_diagnostics is False
    assert OneClickArgs(research_diagnostics=True).research_diagnostics is True
    root=Path(__file__).resolve().parents[1]
    assert 'id="auto-research-diagnostics" type="checkbox" checked' in (root/'web/index.html').read_text()
    assert "research_diagnostics:$('auto-research-diagnostics').checked" in (root/'web/app.js').read_text()

@pytest.mark.parametrize('enabled',[False,True])
def test_child_diagnosis_option_and_no_input_changes(tmp_path,enabled):
    path=tmp_path/'one.json';path.write_text(json.dumps({'kind':'REAL_2TD600_SINE_DIAGNOSTIC','plan':{'output':'roll'}}));before=path.read_bytes()
    stages=[{'report_file':path.name,'output':'roll','inner_target_deg':0}]
    r=run_postprocess(tmp_path,stages,{},'combined.json','diag' if enabled else None)
    assert path.read_bytes()==before and r['report_file']==path.name
    assert r['diagnosis']['state']==('failed' if enabled else 'not_requested')
    assert (tmp_path/'diag.zip').exists()==enabled
    assert not (tmp_path/'combined.json').exists()


def test_post_stop_diagnosis_failure_does_not_mark_motion_failed(tmp_path):
    t=FakeTable();e=FakeEngine();d=FakeDeferred(tmp_path,t);a=AutoDynamicWorkflow(t,e,TablePreparation(t),d)
    a.start(2,'both',1,5,.2,15,2,True,'xy_sequential',True,research_diagnostics=True);_complete(a,e,timeout=15)
    assert a.state=='completed',a.error
    assert a.motion_completed and a.report_completed and a.stopped_verified
    assert a.diagnosis['state']=='failed' # fake captures lack CSV; report remains valid for simulation
    assert (tmp_path/a.diagnosis['zip_file']).exists()
    assert len(json.loads((tmp_path/a.report_file).read_text())['tests'])==2
    assert t.cmds.index(('inner_stage',0,2))>t.cmds.index(('sway_stage','pitch',90))


def test_pipeline_fault_at_report_end_keeps_report_and_blocks_restart(tmp_path,monkeypatch):
    t=FakeTable();e=FakeEngine();d=FakeDeferred(tmp_path,t);a=AutoDynamicWorkflow(t,e,TablePreparation(t),d)
    health={'pipeline_error':''};e.link_watchdog_status=lambda:dict(health)
    original=a._create_joint_report
    def end_fault(stages):
        name=original(stages);health['pipeline_error']='queue delay > 500ms';return name
    monkeypatch.setattr(a,'_create_joint_report',end_fault)
    a.start(2,'both',1,5,.2,15,2,True,'xy_sequential',True);_complete(a,e,timeout=15)
    assert a.state=='stopped_or_failed' and a.motion_completed and a.report_completed
    assert a.stopped_verified and (tmp_path/a.report_file).is_file()
    with pytest.raises(ValueError,match='实时采集异常'):a.start(2,'both',1,5,.2,15,2,True,'xy_sequential',True)


def test_failed_gate_does_not_diagnose_or_move_pitch(tmp_path):
    t=FakeTable();e=FakeEngine();d=FakeDeferred(tmp_path,t,fail=True);a=AutoDynamicWorkflow(t,e,TablePreparation(t),d)
    a.start(2,'both',1,5,.2,15,2,True,'xy_sequential',True,research_diagnostics=True);_complete(a,e)
    assert a.state=='analysis_invalid' and a.diagnosis['state']=='not_completed'
    assert not any(c[:2]==('sway_stage','pitch') for c in t.cmds)
