import csv,json,math,os,time,multiprocessing as mp
from dataclasses import replace,asdict
import pytest
from app.fusion import Params,create_filter
from app.continuity_v713 import advance
from app.dynamic_experiment import _report_process, _read_closed_csv, IMU_COLS,TABLE_COLS
from app.engine import Workstation


def test_anchor3d_raw_and_zero_equal_anchor_with_bias():
    p=Params();f=create_filter('gyro_anchor',p);z=create_filter('gyro_anchor3d',p);r=create_filter('gyro_anchor3d',replace(p,lever3_z_cm=19.51),False)
    for i in range(1200):
        a=[0.,0.,1.];g=[.065+math.sin(i)*.01,0.,0.]
        for n in range(1):
            f,o,_=advance('gyro_anchor',f,p,True,a,g,.002)
            z,oz,_=advance('gyro_anchor3d',z,p,True,a,g,.002)
            r,orr,_=advance('gyro_anchor3d',r,p,False,a,g,.002)
        assert oz['roll']==pytest.approx(o['roll'],abs=1e-12)
        assert orr['roll']==pytest.approx(o['roll'],abs=1e-12)
    assert o['stationary_bias_ready'] and o['gyro_bias_dps'][0]==pytest.approx(.065,abs=.001)


def test_anchor3d_gap_preserves_bias_not_acc_correction():
    p=Params(lever3_z_cm=19.51);f=create_filter('gyro_anchor3d',p)
    for i in range(1000):f,o,_=advance('gyro_anchor3d',f,p,True,[0,0,1],[.065,0,0],.002)
    assert o['stationary_bias_ready'] and o['lever_compensation_ready']
    prev=o['roll'];f,o,action=advance('gyro_anchor3d',f,p,True,[0,1,0],[10.065,0,0],.1)
    assert action=='gyro_bridge';assert o['roll']-prev==pytest.approx(.5,abs=1e-6)
    assert o['stationary_bias_ready'] and not o['stationary_detected'] and not o['lever_compensation_ready']
    assert o['imu_gaps_over_50ms']==1
    f,o,action=advance('gyro_anchor3d',f,p,True,[0,0,1],[0,0,0],.5)
    assert action=='reset' and not o['stationary_bias_ready']


def test_candidate_session_clear():
    w=Workstation();w.params=Params(lever3_z_cm=19.51);w.active='gyro_anchor3d';w.clear_lever3d()
    assert w.active=='gyro_anchor' and w.params.lever3_z_cm==0


def test_closed_csv_flags_and_ns_exact(tmp_path):
    p=tmp_path/'x.csv';p.write_text('host_est_ns,gap_bridge,gap_reset,alignment_active\n123456789012345678,False,0,1\n')
    r=next(_read_closed_csv(p));assert r=={'host_est_ns':123456789012345678,'gap_bridge':0,'gap_reset':0,'alignment_active':1}


def test_report_spawn_incomplete_capture_retains_safety_and_csv(tmp_path):
    imu=tmp_path/'imu.csv';table=tmp_path/'table.csv';out=tmp_path/'test_DYNAMIC.json'
    for path,fields in ((imu,IMU_COLS),(table,TABLE_COLS)):
        with path.open('w',newline='') as f:csv.DictWriter(f,fieldnames=fields).writeheader()
    d={'kind':'REAL_2TD600_SINE_DIAGNOSTIC','uid':'MOCK','plan':{'axis':2,'output':'roll','amplitude_deg':5,'frequency_hz':.3,'cycles':10,'sign':1},'imu_samples':0,'table_samples':0,'fusion_parameters_used':asdict(Params()),'imu_algorithm_at_start':'gyro_anchor3d','state':'invalid','stopped_verified':False,'error':'mock failure','certified_dynamic_accuracy':False}
    proc=mp.get_context('spawn').Process(target=_report_process,args=(str(out),str(imu),str(table),d,None,{},False,False,'mock failure','test_DYNAMIC'))
    proc.start();proc.join(12)
    try:
        assert proc.exitcode==0
        r=json.loads(out.read_text());assert r['report_worker_pid']!=os.getpid() and r['report_compute_mode']=='isolated_spawn_process'
        assert not r['stopped_verified'] and r['state']=='invalid' and not r['certified_dynamic_accuracy']
    finally:
        if proc.is_alive():proc.terminate();proc.join()
        proc.close()


def test_explicit_candidate_application_precedes_table_connection():
    from pathlib import Path
    root=Path(__file__).resolve().parents[1]
    html=(root/'web/index.html').read_text();js=(root/'web/app.js').read_text()
    assert 'id="anchor3d-auto-ack"' in html
    assert 'id="anchor3d-auto-ack" checked' not in html
    part=js.split('async function ensureAutoConnections',1)[1].split('async function refreshAutoTest',1)[0]
    assert part.index('/api/lever-identify/research-z')<part.index('/api/turntable/connect')
    assert 'stationary_bias_ready' in part and 'lever_compensation_ready' in part


def test_watchdog_rejects_old_raw_receipt_even_with_fresh_fusion_update(tmp_path):
    from types import SimpleNamespace
    from app.auto_dynamic import AutoDynamicWorkflow
    e=SimpleNamespace(running=True,connected=True,source='serial',last_wall=time.time(),link_watchdog_status=lambda:{'child_receipt_age_ms':751.,'fusion_receipt_age_ms':20.})
    t=SimpleNamespace(connected=True);w=AutoDynamicWorkflow(t,e,None,SimpleNamespace(dir=tmp_path));w.heartbeat_ns=time.monotonic_ns()
    with pytest.raises(RuntimeError,match='倾角仪数据中断'):w._watch()
