import json, math, time
from pathlib import Path
import numpy as np
import pytest
from app.pre_research import assess
from app.engine import Workstation
from app.research_optimizer import replay,CONFIGS
from app.auto_dynamic import AutoDynamicWorkflow
from app.table_prepare import TablePreparation
from app.main import OneClickArgs
from test_v66_dual_axis import FakeTable,FakeEngine,_complete
from test_v720_deferred_reports import FakeDeferred


def samples(seconds=3,rate=200):
    return [dict(sequence=i+1,host_est_ns=100000000000+i*int(1e9/rate),acc_cal=[.0002,0,1.],gyro_cal=[.004,-.006,.002]) for i in range(seconds*rate+1)]


def test_stationary_assessment_and_gates():
    data=samples();r=assess(data,3)
    assert r['state']=='passed' and r['gyro_bias_dps']==pytest.approx([.004,-.006,.002])
    with pytest.raises(ValueError,match='连续'):assess(data[:300]+data[301:],3)
    data[250]['gyro_cal']=[3,0,0]
    with pytest.raises(ValueError,match='质量'):assess(data,3)


def test_research_seed_and_release():
    e=Workstation();e.active='gyro_anchor';e.cal_status='matched';e.latest={'sequence':100,'processing_age_ms':1.,'gyro_cal':[.004,-.006,.002],'acc_cal':[0,0,1.]}
    e.seed_research_gyro_anchor([0,0,1],[.004,-.006,.002],100)
    f=e.pipes['gyro_anchor'][1];assert f.research_bias_locked and f.bias_ready
    for i in range(1000):f.update([0,0,1],[.02,0,0],.002)
    assert f.bias==[.004,-.006,.002]
    e.release_research_bias();assert not f.research_bias_locked
    with pytest.raises(ValueError,match='过期'):e.seed_research_gyro_anchor([0,0,1],[0,0,0],-1000)


@pytest.mark.parametrize('cfg',CONFIGS)
def test_replay_prefix_causality(cfg):
    family,n,t,d=cfg;a=[[0,0,1.]]*600;g=[[.004,.002,0.]]*400+[[0,1,0.]]*200;dt=[0.]+[.005]*599
    v,_=replay(a,g,dt,n,t,family,d);w,_=replay(a[:450],g[:450],dt[:450],n,t,family,d)
    assert np.isfinite(v).all() and np.array_equal(v[:450],w)


def test_options_and_static_failure(tmp_path,monkeypatch):
    t=FakeTable();e=FakeEngine();e.pipeline_mode='realtime';e.active='gyro_anchor';e.params=type('P',(),{'lever_z_cm':0.})()
    d=FakeDeferred(tmp_path,t);a=AutoDynamicWorkflow(t,e,TablePreparation(t),d)
    assert not OneClickArgs().pre_research
    with pytest.raises(ValueError,match='离线寻优'):a.start(2,'both',1,5,.2,15,2,True,'xy_sequential',True,research_optimize=True)
    def fail(*args):raise RuntimeError('静止诊断失败')
    monkeypatch.setattr('app.pre_research.capture',fail)
    a.start(2,'both',1,5,.2,15,2,True,'xy_sequential',True,pre_research=True,research_diagnostics=True,research_optimize=True);_complete(a,e,timeout=15)
    assert a.state=='stopped_or_failed' and not any(c[0]=='sway_stage' for c in t.cmds)
    assert a.optimization['state']=='not_completed'


def test_each_axis_initializes_then_moves_and_optimizer_failure_is_nonfatal(tmp_path,monkeypatch):
    t=FakeTable();e=FakeEngine();e.pipeline_mode='realtime';e.active='gyro_anchor';e.params=type('P',(),{'lever_z_cm':0.})()
    d=FakeDeferred(tmp_path,t);a=AutoDynamicWorkflow(t,e,TablePreparation(t),d)
    def capture(w,output,inner,seconds):
        t.cmds.append(('pre',output));w.pre_research_results.append({'output':output,'state':'passed','seed_applied':True})
    monkeypatch.setattr('app.pre_research.capture',capture)
    a.start(2,'both',1,5,.2,15,2,True,'xy_sequential',True,pre_research=True,research_diagnostics=True,research_optimize=True);_complete(a,e,timeout=20)
    assert a.state=='completed',a.error
    assert t.cmds.index(('pre','roll'))<t.cmds.index(('sway_stage','roll',0))<t.cmds.index(('pre','pitch'))<t.cmds.index(('sway_stage','pitch',90))
    assert a.motion_completed and a.report_completed and a.optimization['state']=='failed' # fake lacks CSV
    assert len(json.loads((tmp_path/a.report_file).read_text())['pre_research_results'])==2


def test_capture_stationary_csv_and_seed(tmp_path,monkeypatch):
    from types import SimpleNamespace
    from threading import RLock
    from collections import deque
    from app.pre_research import capture
    from test_v66_dual_axis import status
    tick=[0.];sequence=[0];seed=[]
    e=SimpleNamespace(uid='TEST',lock=RLock(),latest={'sequence':0},recent=deque(maxlen=3000),seed_research_gyro_anchor=lambda a,b,s:seed.append((a,b,s)))
    def wait(h):
        tick[0]+=h
        for _ in range(10):
            sequence[0]+=1;r=dict(sequence=sequence[0],host_est_ns=100000000000+sequence[0]*5000000,acc_cal=[0.,0.,1.],gyro_cal=[.004,-.006,.002],calibration_state='matched',static_alignment_active=False)
            e.recent.append(r);e.latest=r
        return False
    monkeypatch.setattr('app.pre_research.time',SimpleNamespace(monotonic=lambda:tick[0]))
    w=SimpleNamespace(engine=e,dynamic=SimpleNamespace(dir=tmp_path),table=SimpleNamespace(read_status=lambda:status(0,0)),_watch=lambda:None,lock=RLock(),cancel=SimpleNamespace(wait=wait),plan={'sign':1,'pitch_sign':1,'static_before_dynamic':True,'static_stop_on_fail':True,'static_limit_deg':.1},pre_research_progress=None,pre_research_results=[])
    r=capture(w,'roll',0,3)
    assert r['seed_applied'] and seed and len(w.pre_research_results)==1
    assert (tmp_path/r['raw_csv']).is_file() and json.loads((tmp_path/r['json_file']).read_text())['state']=='passed'
