"""Regression tests for 0/360-degree encoder wrap, no real DLL calls."""
import math, time
import numpy as np
from app.angles import angle_delta_deg, zero_distance_deg, unwrap_encoder_deg
from app.table_prepare import TablePreparation
from app.dynamic_experiment import _ok_axes, analyze_tracking, ALGORITHMS

def axes(position0=360.0,position2=0.0):
    def one(pos):
        return dict(position_deg=pos,speed_dps=0.0,mode=2,enabled=True,
                    zeroed=True,healthy=True,in_place=True,upper_limit=False,
                    lower_limit=False,driver_fault=False,over_speed=False)
    return {'axes':{'0':one(position0),'2':one(position2)}}

class FakeTable:
    def __init__(self):
        self.connected=True
        self.a=axes()['axes']
        self.cmds=[]
    def read_status(self):
        return {'axes':{k:dict(v) for k,v in self.a.items()}}
    def enable_axis(self,axis):self.cmds.append(('enable',axis));self.a[str(axis)]['enabled']=True
    def find_zero(self,axis,speed,accel):
        self.cmds.append(('find_zero',axis));self.a[str(axis)]['zeroed']=True
        self.a[str(axis)]['position_deg']=0
    def move(self,axis,pos,speed):self.cmds.append(('move',axis,pos,speed));self.a[str(axis)]['position_deg']=pos
    def stop(self):self.cmds.append(('stop',))
    def stopped_verified(self,timeout=5):return True

def test_encoder_zero_is_modular():
    assert zero_distance_deg(360)==0
    assert zero_distance_deg(-360)==0
    assert zero_distance_deg(720)==0
    assert abs(angle_delta_deg(.02,359.98)-.04)<1e-9
    assert abs(angle_delta_deg(359.98,0)+.02)<1e-9

def test_auto_prepare_already_at_360_does_not_move():
    t=FakeTable(); p=TablePreparation(t)
    pre=p.preflight()
    assert pre['movement_plan'][0]['estimated_travel_deg']==0
    p.start(pre['token'],True,zero_speed_dps=2)
    p.thread.join(4)
    assert p.verified and p.state=='ready',p.error
    assert not [c for c in t.cmds if c[0] in ('move','find_zero')]

def test_dynamic_preflight_accepts_360():
    assert _ok_axes(axes(),0)['0']['position_deg']==360.
    assert _ok_axes(axes(359.98,0),0)
    import pytest
    with pytest.raises(ValueError):
        _ok_axes(axes(359,0),0)

def test_seam_unwrap_preserves_small_movement():
    raw=[359.9,359.95,360.0,.03,.08,359.98]
    continuous=unwrap_encoder_deg(raw)
    assert np.max(np.abs(np.diff(continuous)))<.2
    assert np.max(continuous)-np.min(continuous)<.3

def test_sine_analysis_reference_does_not_jump_360():
    # Real-style near-zero reference, raw encoder wraps through 360->0.
    amp=1.;freq=.05;tstart=12.;tend=72.
    tr=[];im=[]
    for t in np.arange(10.,73.,.1):
        a=amp*math.sin(2*math.pi*freq*(t-tstart)) if t>=tstart else 0.
        raw=(360+a)%360
        tr.append({'pc_mid_ns':int(t*1e9),'axis_0_pos':raw})
    for t in np.arange(10.,73.,.02):
        a=amp*math.sin(2*math.pi*freq*(t-tstart)) if t>=tstart else 0.
        row={'host_est_ns':int(t*1e9)}
        for ch in ('raw','cal'):
            for algo in ALGORITHMS:row[f'{ch}_{algo}_roll']=a
        im.append(row)
    result=analyze_tracking(tr,im,0,'roll',1,amp,freq,int(tstart*1e9),int(tend*1e9))
    assert result['valid'],result.get('reason')
    assert result['comparison'][0]['relative_tracking_rmse_deg']<.01
    assert max(abs(r['reference_deg']) for r in result['chart'])<1.1
