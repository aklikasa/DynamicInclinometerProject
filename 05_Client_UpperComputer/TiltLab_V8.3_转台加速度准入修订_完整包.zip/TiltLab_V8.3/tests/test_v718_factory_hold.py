"""Offline mocked hardware tests; never connects a physical turntable."""
import ctypes,json,math,threading,time
from pathlib import Path
from types import SimpleNamespace
import pytest
from app.factory_table_bridge import FactoryBridge,FactoryDLLProxy,POSES,OUTER_POSES
from app import automatic_factory as mod
from app.factory_recovery import prepare

class FakeTable:
    connected=True;port=2
    def __init__(self):self.lock=threading.RLock();self.calls=[];self.enabled=True;self.fault=False;self.speed=0.;self.stop_ok=True
    def read_status(self):
        return {'axes':{str(a):{'enabled':self.enabled,'zeroed':True,'healthy':True,'position_deg':0.,'speed_dps':self.speed,'driver_fault':self.fault,'upper_limit':False,'lower_limit':False,'over_speed':False} for a in (0,2)}}
    def _int(self,name,a):return 1 if name in ('GetAxisEnable','GetAxisFindZero','GetAxisNormal') else 0
    def _float(self,name,a):return 0.
    def _call(self,name,argtypes,restype,*args):self.calls.append((name,*args));return 1
    def stop(self):self.calls.append(('stop',));self.speed=0.
    def stopped_verified(self,timeout=20):self.calls.append(('verify',));return self.stop_ok
    def disconnect(self):pytest.fail('must not disconnect table')
    def disable_axis(self,a):pytest.fail('must not disable axis')

@pytest.fixture
def bridge():
    t=FakeTable();alive=[True];b=FactoryBridge(t,lambda:alive[0],[1,2,5,1.5,3.5]);p=FactoryDLLProxy(b.endpoint)
    try:yield t,b,p,alive
    finally:p.close();b.close()

def test_real_loopback_proxy_allowlist(bridge):
    t,b,p,_=bridge
    assert p.GetPosition(0)==0
    assert p.SetAxisPosition(0,315,2)==1
    assert p.SetAxisVelocity(2,-3.5,1)==1
    assert p.SetAxisStop(2)==1
    for name in ('SetAxisDisable','SetAllAxisDisable','ClosePort','OpenPort','SetAxisFindZero','SetAxisEnable','SetAxisSway'):
        with pytest.raises(AttributeError):getattr(p,name)
        with pytest.raises(ValueError):b.dispatch(name,[0])
    assert t.calls==[('SetAxisPosition',0,315.,2.),('SetAxisVelocity',2,-3.5,1.),('SetAxisStop',2)]

@pytest.mark.parametrize('name,args',[('SetAxisPosition',[0,999,2]),('SetAxisPosition',[2,315,3]),('SetAxisPosition',[0,1,2]),('SetAxisVelocity',[0,20,1]),('SetAxisVelocity',[1,1,1]),('SetAxisVelocity',[2,1,2]),('SetAxisVelocity',[2,math.nan,1])])
def test_reject_outside_original_process(bridge,name,args):
    t,b,_,_=bridge
    with pytest.raises(ValueError):b.dispatch(name,args)
    assert not t.calls

@pytest.mark.parametrize('condition',['fault','disabled','overspeed','cancel','revoke'])
def test_fault_cancel_no_more_motion(bridge,condition):
    t,b,p,alive=bridge
    if condition=='fault':t.fault=True
    if condition=='disabled':t.enabled=False
    if condition=='overspeed':t.speed=11.
    if condition=='cancel':alive[0]=False
    if condition=='revoke':b.revoke()
    with pytest.raises(RuntimeError):p.SetAxisPosition(0,90,2)
    assert not t.calls
    assert p.SetAxisStop(0)==1


def test_allowlist_matches_original_r10():
    import sys
    root=Path(__file__).resolve().parents[1]/'r10_ambient';sys.path.insert(0,str(root))
    try:
        from production_calibration import acc_fit_steps,acc_verify_steps,gyro_fit_steps,gyro_verify_steps,load_profile
        prof=load_profile(str(root));steps=acc_fit_steps()+acc_verify_steps()+gyro_fit_steps(prof)+gyro_verify_steps(prof)
        assert {s['inner_deg'] for s in steps}==POSES
        assert {s['outer_deg'] for s in steps}==OUTER_POSES
    finally:sys.path.remove(str(root))

class FakeProc:
    returncode=0
    def poll(self):return self.returncode

def setup_supervisor(tmp_path,monkeypatch,success=True):
    calls=[];table=FakeTable()
    class E:
        running=True;connected=True;_pipeline_error='';error='';pipeline_mode='research'
        @property
        def latest(self):return {'cal':{'stationary_bias_ready':True},'pc_observed_ns':time.monotonic_ns()}
        def stop(self):calls.append('imu_stop');self.running=False;self.connected=False
        def set_pipeline_mode(self,mode):assert not self.running;self.pipeline_mode=mode
        def pipeline_status(self):return {'mode':self.pipeline_mode,'error':self._pipeline_error}
        def start(self,*args):calls.append('imu_start');self.running=True;self.connected=True
    class A:
        running=False
        def start(self,*args):calls.append('resume')
    class L:
        def disconnect(self):pytest.fail('must not disconnect')
        def connect(self,*args,**kwargs):pytest.fail('must not reconnect table')
    obj=mod.AutomaticFactory(E(),table,L(),A(),tmp_path);obj.job=tmp_path;obj.active=True;obj.last_heartbeat=time.monotonic()
    cfg={'imu_port':'COM3','imu_baud':1500000,'imu_address':1,'table_port':4}
    plan={'axis':2,'output':'roll','requested_roll_sign':1,'amplitude_deg':5,'frequency_hz':.3,'cycles':5,'zero_speed_dps':2,'mounting_mode':'x_outer','fixture_confirmed':True,'requested_pitch_sign':1,'static_limit_deg':.1,'pre_sway_axis_check':True}
    (tmp_path/'production_quality_profile.json').write_text(json.dumps({'rates':{'fit_dps':[1,2,5],'verify_dps':[1.5,3.5]}}))
    def popen(*args,**kwargs):
        calls.append('worker')
        ep=json.loads((tmp_path/'worker_request.json').read_text())['bridge'];p=FactoryDLLProxy(ep)
        assert p.SetAxisPosition(0,90,2)==1;p.close()
        (tmp_path/'worker_result.json').write_text(json.dumps({'success':success,'imu_released':True,'message':'quality failed'}));return FakeProc()
    monkeypatch.setattr(mod.subprocess,'Popen',popen)
    def load(*args):calls.append('load');return {'state':'loaded','loaded_files':['a','g']}
    monkeypatch.setattr(mod,'import_pair',load)
    return obj,cfg,plan,calls,table

def test_recovery_loads_before_resume(tmp_path,monkeypatch):
    obj,cfg,plan,calls,table=setup_supervisor(tmp_path,monkeypatch)
    obj._run({},cfg,plan,tmp_path/'worker.py')
    assert calls==['imu_stop','worker','imu_start','load','resume']
    assert obj.status()['state']=='resumed' and not obj.active
    assert obj.engine.pipeline_mode=='realtime'
    assert not (tmp_path/'heartbeat').exists()
    assert json.loads((tmp_path/'supervisor_status.json').read_text())['running'] is False
    assert table.enabled

def test_independent_does_not_resume(tmp_path,monkeypatch):
    obj,cfg,_,calls,table=setup_supervisor(tmp_path,monkeypatch)
    obj._run({},cfg,None,tmp_path/'worker.py')
    assert calls==['imu_stop','worker','imu_start','load']
    assert obj.status()['state']=='completed' and table.enabled

def test_failed_quality_does_not_load_or_resume(tmp_path,monkeypatch):
    obj,cfg,plan,calls,table=setup_supervisor(tmp_path,monkeypatch,False)
    obj._run({},cfg,plan,tmp_path/'worker.py')
    assert calls==['imu_stop','worker','imu_start']
    assert obj.status()['state']=='failed' and table.enabled

def test_cancel_before_transfer(tmp_path,monkeypatch):
    obj,cfg,plan,calls,table=setup_supervisor(tmp_path,monkeypatch);obj.abort()
    obj._run({},cfg,plan,tmp_path/'worker.py')
    assert calls==[] and obj.status()['state']=='failed' and table.enabled

def test_unverified_stop_no_worker(tmp_path,monkeypatch):
    obj,cfg,plan,calls,table=setup_supervisor(tmp_path,monkeypatch);table.stop_ok=False
    obj._run({},cfg,plan,tmp_path/'worker.py')
    assert calls==[] and obj.status()['state']=='unsafe_stop' and obj.safety_latched


def test_ui_independent_and_recovery_visible():
    root=Path(__file__).resolve().parents[1];js=(root/'web/app.js').read_text();html=(root/'web/index.html').read_text();src=(root/'app/auto_dynamic.py').read_text()
    assert 'id="factory-standalone"' in html and 'id="factory-safety"' in html
    assert 'manual:!!manual' in js and 'r.run_manifest_file||r.started_at||r.error' in js
    assert js.index('refreshFactoryHandoff(r).catch') < js.index("txt('auto-progress',autoRunning")
    assert 'disable_after_owned_calibration(' not in src
    assert 'holding_results=results' in src
