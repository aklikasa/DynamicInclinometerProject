import struct
import pytest
from app.devices import R10Device,DeviceError,crc16

class FakeSerial:
    def __init__(self, reply):
        self.reply=reply;self.sent=[];self.closed=False
    def reset_input_buffer(self):pass
    def write(self,data):self.sent.append(data);return len(data)
    def read(self,n):return self.reply[:n]
    def close(self):self.closed=True

def reply_frame(addr,n):
    data=struct.pack('>'+str(n)+'H',*list(range(n)))
    body=bytes([addr,3,2*n])+data
    return body+struct.pack('<H',crc16(body))

def test_r10_104_request_and_response():
    d=R10Device('COM1');d.serial=FakeSerial(reply_frame(1,104))
    r=d.read(1000,104)
    assert d.serial.sent[0].hex(' ').upper()=='01 03 03 E8 00 68 C4 54'
    assert len(r)==104 and r[99]==99 and d.last_rx_length==213

def test_wrong_address_timeout_has_tx_rx_trace():
    d=R10Device('COM1',address=2);d.serial=FakeSerial(b'')
    with pytest.raises(DeviceError,match='Modbus响应超时') as ex:d.read(1000,104)
    assert '02 03 03 E8 00 68 C4 67' in str(ex.value)
    assert 'RX(0/213)' in str(ex.value)

def test_modbus_error_crc():
    d=R10Device('COM1');bad=reply_frame(1,104)[:-1]+bytes([0])
    d.serial=FakeSerial(bad)
    with pytest.raises(DeviceError,match='CRC'):d.read(1000,104)

def test_exception_frame_is_visible():
    d=R10Device('COM1');body=bytes([1,0x83,2]);d.serial=FakeSerial(body+struct.pack('<H',crc16(body)))
    with pytest.raises(DeviceError,match='异常码 2'):d.read(1000,104)

def test_uid_read_request():
    d=R10Device('COM1');d.serial=FakeSerial(reply_frame(1,6))
    d.read(3000,6)
    assert d.serial.sent[0].hex(' ').upper()=='01 03 0B B8 00 06 47 C9'
