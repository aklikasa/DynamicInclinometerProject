"""Multi-algorithm chart output is built from SAME IMU trace; no fake points."""
import math
import numpy as np
from app.dynamic_experiment import analyze_tracking,ALGORITHMS

def test_all_cal_and_raw_series_have_true_corresponding_error():
    f=0.05;A=2.;start=12.;end=72.
    table=[];imu=[]
    for t in np.arange(10.,73.,.10):
        ref=A*math.sin(2*math.pi*f*(t-start)) if t>=start else 0.
        table.append({'pc_mid_ns':round(t*1e9),'axis_0_pos':ref})
    for t in np.arange(10.,73.,.02):
        ref=A*math.sin(2*math.pi*f*(t-start)) if t>=start else 0.
        item={'host_est_ns':round(t*1e9)}
        for ch in ('raw','cal'):
            for algo in ALGORITHMS:
                item[f'{ch}_{algo}_roll']=ref+(0.02 if ch=='cal' else .25)*math.sin(2*math.pi*.1*t) if t>=start else 0.
        imu.append(item)
    report=analyze_tracking(table,imu,0,'roll',1,A,f,round(start*1e9),round(end*1e9))
    assert report['valid'],report.get('reason')
    assert len(report['comparison'])==2*len(ALGORITHMS)
    assert len(report['chart'])<=560
    r=report['chart'][50]
    assert len(r['angles'])==2*len(ALGORITHMS)
    assert len(r['errors'])==2*len(ALGORITHMS)
    for key,y in r['angles'].items():
        assert abs((y-r['reference_deg'])-r['errors'][key])<.000003
    assert not report['certified_dynamic_accuracy']

def test_invalid_returns_no_unfounded_curves():
    report=analyze_tracking([],[],0,'pitch',1,2,.05,0,0)
    assert not report['valid']
    assert not report.get('chart')
