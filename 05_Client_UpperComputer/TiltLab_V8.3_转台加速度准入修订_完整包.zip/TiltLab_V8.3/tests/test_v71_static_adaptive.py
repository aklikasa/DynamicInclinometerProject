"""No physical motion. Validates train/holdout alignment, safety gate and adaptive fusion."""
import json,math,time
from pathlib import Path
import numpy as np
import pytest
from app.fusion import Params,Madgwick,create_filter,FILTERS
from app.static_alignment import fit_static_alignment,align_pose
from app.static_accuracy import STATIC_STEPS
from app.auto_dynamic import AutoDynamicWorkflow
from app.table_prepare import TablePreparation
from tests.test_v66_dual_axis import FakeTable,FakeEngine,FakeDynamic,_complete


def static_report(direction='roll',uid='TEST-001',calmode='ambient',a=None,b=None,hysteresis=.005):
    if a is None:a=[[1.03,.025],[-.02,.99]]
    if b is None:b=[2.2,-.8]
    items=[]
    for i,angle in enumerate(STATIC_STEPS):
        r=[angle,0.] if direction=='roll' else [0.,angle]
        measured=[b[j]+sum(a[j][k]*r[k] for k in range(2)) + (hysteresis if i>=7 else 0) for j in range(2)]
        items.append({'actual_outer_deg':angle,'target_deg':angle,'travel':'out' if i<=6 else 'back',
                      'angles':{'cal':{'accel':{'roll':measured[0],'pitch':measured[1]},
                                        'madgwick':{'roll':measured[0]+.001,'pitch':measured[1]-.001},
                                        'adaptive_lever':{'roll':measured[0]+.001,'pitch':measured[1]-.001}}}})
    return {'uid':uid,'calibration_mode':calmode,'output':direction,'analysis':{'reference_sign':1},'items':items}


def test_auto_alignment_removes_small_angle_mount_offsets_on_heldout_only():
    reports=[static_report('roll'),static_report('pitch')]
    model=fit_static_alignment(reports,'TEST-001','ambient','adaptive_lever',.1)
    assert model['valid'] and model['active_statically_pass'],model
    assert abs(model['effective_roll_zero_offset_deg']-2.2)<.005
    assert abs(model['effective_pitch_zero_offset_deg']+.8)<.005
    assert model['validation_active_before']['max_abs_deg']>2
    assert model['validation_active_after']['max_abs_deg']<.015
    assert model['applied'] is False
    original={'roll':2.2+1.03*3+.025*2,'pitch':-.8-.02*3+.99*2,'yaw':8.0}
    corrected=align_pose(original,model)
    assert corrected['roll']==pytest.approx(3,abs=1e-5)
    assert corrected['pitch']==pytest.approx(2,abs=1e-5)
    assert original['roll']!=corrected['roll']
    assert len(corrected['q'])==4


def test_alignment_rejects_sign_flip_UID_mismatch_and_wrong_fixture():
    original=[static_report('roll'),static_report('pitch')]
    assert not fit_static_alignment(original,'OTHER','ambient','madgwick')['valid']
    assert not fit_static_alignment(original[:1],'TEST-001','ambient','madgwick')['valid']
    assert not fit_static_alignment(original,'TEST-001','thermal','madgwick')['valid']
    reversed_sign=[static_report('roll',a=[[-1,0],[0,1]]),static_report('pitch',a=[[-1,0],[0,1]])]
    assert not fit_static_alignment(reversed_sign,'TEST-001','ambient','madgwick')['valid']


def test_alignment_rejects_reverse_hysteresis_that_makes_it_unreliable():
    original=[static_report('roll',hysteresis=.6),static_report('pitch',hysteresis=.6)]
    r=fit_static_alignment(original,'TEST-001','ambient','madgwick',.1)
    assert r['valid'] and not r['active_statically_pass']
    assert r['validation_active_after']['max_abs_deg']>.1


def test_new_adaptive_filter_is_causal_and_leaves_old_madgwick_unchanged():
    p=Params(lever_z_cm=0).validate()
    orig=Madgwick(p);direct=create_filter('madgwick',p)
    adap=create_filter('adaptive_lever',p)
    out=None
    for t in np.arange(0,4,.005):
        r=.07*math.sin(2*math.pi*.3*t)
        a=[0.,math.sin(r),math.cos(r)]
        gyro=[.07*2*math.pi*.3*math.cos(2*math.pi*.3*t)*180/math.pi,0.,0.]
        c=orig.update(a,gyro,.005)
        d=direct.update(a,gyro,.005)
        assert c['roll']==d['roll']
        out=adap.update(a,gyro,.005)
        assert 0 < out['beta_eff']<=p.beta
        assert 0<out['trust']<=1
        assert all(math.isfinite(v) for v in (out['roll'],out['pitch'],out['beta_eff']))
    assert 'adaptive_lever' in FILTERS


def test_factory_calibration_pose_preserved_in_engine_process():
    from app.engine import Workstation
    w=Workstation()
    # No arbitrary applying to raw-only or wrong UID.
    with pytest.raises(ValueError):w.install_static_alignment({'valid':True,'uid':'OTHER','calibration_mode':'ambient'})
    assert w.static_alignment is None
    w.process({'t':1,'acc':[0.,0.,1.], 'gyro':[0.,0.,0.]})
    assert w.latest['cal'] is None and w.latest['cal_factory'] is None


def test_automation_static_both_before_any_sway_and_refuses_bad_holdout(tmp_path):
    t=FakeTable();e=FakeEngine();e.active='madgwick'
    d=FakeDynamic(tmp_path,t);p=TablePreparation(t)
    a=AutoDynamicWorkflow(t,e,p,d)
    calls=[]
    def fake_static(output,inner,sign,speed,limit,watcher,progress,span_deg=5.):
        watcher();calls.append((output,inner))
        report=static_report(output)
        report.update(analysis={'reference_sign':1,'chosen_algorithm':'madgwick','pass_for_chosen_algorithm':False,'algorithm_metrics':{'cal_madgwick':{'static_max_abs_deg':3.}}})
        filename=output+'_STATIC.json'
        (tmp_path/filename).write_text(json.dumps(report),encoding='utf-8')
        return filename,report
    a.static_precheck.run=fake_static
    a.start(2,'both',1,5,.3,10,2,True,'xy_sequential',True,
            static_before_dynamic=True,static_limit_deg=.1,static_stop_on_fail=True,auto_static_align=True)
    _complete(a,e)
    # Fake engine doesn't expose install_static_alignment: the candidate is
    # fitted/validated but cannot be applied; production engine does.
    assert calls==[('roll',0),('pitch',90)]
    assert a.alignment_result['valid']
    assert a.state=='completed',a.error
    assert t.cmds.index(('inner_stage',90,2))<t.cmds.index(('sway_stage','roll',0))
    assert a.alignment_file and (tmp_path/a.alignment_file).exists()


def test_automation_bad_hysteresis_blocks_dynamic_and_persists_reason(tmp_path):
    t=FakeTable();e=FakeEngine();e.active='madgwick';d=FakeDynamic(tmp_path,t);p=TablePreparation(t)
    a=AutoDynamicWorkflow(t,e,p,d)
    def bad_static(output,inner,sign,speed,limit,watcher,progress,span_deg=5.):
        watcher();report=static_report(output,hysteresis=.7)
        report['analysis'].update(chosen_algorithm='madgwick',pass_for_chosen_algorithm=False)
        filename=output+'_STATIC.json';(tmp_path/filename).write_text(json.dumps(report),encoding='utf-8')
        return filename,report
    a.static_precheck.run=bad_static
    a.start(2,'both',1,5,.3,10,2,True,'xy_sequential',True,
            static_before_dynamic=True,static_limit_deg=.1,static_stop_on_fail=True,auto_static_align=True)
    _complete(a,e)
    assert a.state=='stopped_or_failed'
    assert not any(c[0]=='sway_stage' for c in t.cmds)
    # Reverse-traversal inconsistency is rejected during polarity precheck,
    # before the 2D installation fit; saved static HTML remains available.
    assert a.polarity_checks and not a.polarity_checks[0]['valid']
    assert a.alignment_file is None
    assert a.run_manifest_html_file
    assert (tmp_path/a.run_manifest_html_file).exists()


def test_automatic_alignment_requires_dual_axis():
    a=AutoDynamicWorkflow(None,None,None,None)
    with pytest.raises(ValueError,match='Roll\\+Pitch'):
        a.start(2,'roll',1,5,.3,10,2,True,'x_outer',False,static_before_dynamic=True,auto_static_align=True)


def test_live_engine_keeps_factory_angles_when_session_alignment_applied():
    from app.engine import Workstation
    from app.calibration import Cal
    w=Workstation();w.active='madgwick';w.uid='TEST-001';w.source='serial';w.connected=True;w.cal_mode='ambient';w.cal_status='matched'
    ident=Cal([0.,0.,0.],[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]],'TEST_ONLY')
    w.cal={'acc':ident,'gyro':ident,'files':['synthetic']}
    candidate=fit_static_alignment([static_report('roll'),static_report('pitch')],w.uid,w.cal_mode,'madgwick',.1)
    w.install_static_alignment(candidate)
    w.process({'t':1,'acc':[0.,0.,1.], 'gyro':[0.,0.,0.], 'temp':25})
    latest=w.latest
    assert latest['static_alignment_active']
    assert latest['outputs']['madgwick']['cal_factory']['roll']==pytest.approx(0)
    assert latest['outputs']['madgwick']['cal']['roll']==pytest.approx(-2.15,abs=.15)
    assert latest['outputs']['madgwick']['raw']['roll']==pytest.approx(0)
    assert w.status()['static_alignment']['applied'] is True
    w.clear_static_alignment()
    w.process({'t':1.01,'acc':[0.,0.,1.], 'gyro':[0.,0.,0.], 'temp':25})
    assert latest['static_alignment_active'] is True and w.latest['static_alignment_active'] is False
    assert w.latest['outputs']['madgwick']['cal']['roll']==pytest.approx(0)
