import math
import numpy as np
import pytest
from app.fusion import Params,Madgwick,create_filter,FILTERS


def _sample(t):
    w=2*math.pi*.3
    roll=math.radians(5)*math.sin(w*t)
    gyro_x=5*w*math.cos(w*t)
    angular_acc=math.radians(5)*w*w*-math.sin(w*t)
    r=.22
    acc_y=math.sin(roll)-angular_acc*r/9.80665
    acc_z=math.cos(roll)
    return [0.,acc_y,acc_z],[gyro_x,0.,0.]


def test_eighth_algorithm_is_selectable_and_default_correction_disabled():
    assert 'leverarm' in FILTERS
    params=Params();assert params.lever_z_cm==0
    a=create_filter('leverarm',params)
    b=Madgwick(params)
    for t in np.arange(0,3,.004):
        acc,gyro=_sample(t)
        x=a.update(acc,gyro,.004)
        y=b.update(acc,gyro,.004)
        assert x['roll']==y['roll']
        assert x['pitch']==y['pitch']


def test_raw_uncalibrated_branch_must_not_apply_product_p_geometry():
    p=Params(lever_z_cm=22)
    raw=create_filter('leverarm',p,calibrated=False)
    mad=Madgwick(p)
    for t in np.arange(0,2,.004):
        a,g=_sample(t)
        assert raw.update(a,g,.004)['roll']==mad.update(a,g,.004)['roll']


def test_physical_roll_sinusoid_improves_using_measured_lever_arm():
    p0=Params(lever_z_cm=0)
    p1=Params(lever_z_cm=22)
    f0=create_filter('leverarm',p0)
    f1=create_filter('leverarm',p1)
    t=np.arange(0,16,.004)
    err0=[];err1=[]
    for time in t:
        a,g=_sample(time)
        actual=5*math.sin(2*math.pi*.3*time)
        r0=f0.update(a,g,.004)['roll']
        r1=f1.update(a,g,.004)['roll']
        if time>5:
            err0.append((r0-actual)**2)
            err1.append((r1-actual)**2)
    assert np.sqrt(np.mean(err1)) < np.sqrt(np.mean(err0))*.65


def test_invalid_compensation_params_are_rejected():
    for k,v in [('lever_z_cm',100),('lever_z_cm',float('nan')),('lever_tau_s',0),('lever_tau_s',.5)]:
        with pytest.raises(ValueError):Params(**{k:v}).validate()


def test_motion_control_unmodified_and_report_includes_eighth_curve():
    from app.dynamic_experiment import ALGORITHMS,IMU_COLS
    assert set(ALGORITHMS)==set(FILTERS) and "lever3d" in ALGORITHMS
    assert 'cal_leverarm_roll' in IMU_COLS and 'raw_leverarm_pitch' in IMU_COLS
    from pathlib import Path
    root=Path(__file__).resolve().parents[1]
    code=(root/'app/turntable.py').read_text(encoding='utf-8')
    assert 'SetAxisSway' in code
    html=(root/'web/index.html').read_text(encoding='utf-8')
    js=(root/'web/app.js').read_text(encoding='utf-8')
    assert 'btn-lever-example' in html
    assert 'leverarm' in js
    assert "startsWith('8.1.')" in js
