"""Safety-focused source and unit regression for v7.6; no motor commands."""
from pathlib import Path
from types import SimpleNamespace
from bs4 import BeautifulSoup
import pytest

from app.auto_dynamic import AutoDynamicWorkflow


class StaticProbe:
    def __init__(self, checks):
        self.checks=list(checks)
        self.speeds=[]
    def run(self, out, inner, sign, speed, limit, watch, progress, span_deg):
        self.speeds.append(speed)
        return f"attempt{len(self.speeds)}.json", {'mount_axis_precheck':self.checks.pop(0)}


def owner(checks, speed=2):
    # Deliberately bypass real hardware initialization.
    flow=AutoDynamicWorkflow.__new__(AutoDynamicWorkflow)
    import threading
    flow.lock=threading.RLock()
    flow.state='static_alignment_calibration'
    flow.mount_recovery=None
    flow.plan={'zero_speed_dps':speed,'static_limit_deg':.1,'amplitude_deg':5}
    flow.static_precheck=StaticProbe(checks)
    flow._watch=lambda: None
    return flow


def test_weak_signal_is_recollected_once_without_relaxing_gate(monkeypatch):
    from app import auto_dynamic
    monkeypatch.setattr(auto_dynamic.DIAG,'record',lambda *args,**kwargs:None)
    x=owner([
        {'output':'roll','pass_for_dynamic':False,'reason':'运动角速度信噪比不足，不能证明装夹对齐'},
        {'output':'roll','pass_for_dynamic':True,'reason':'安装轴方向预检通过'}])
    name,data,info=x._capture_static_with_axis_retry('roll',0,1,lambda *_:None)
    assert x.static_precheck.speeds==[2,3]
    assert name=='attempt2.json' and data['mount_axis_precheck']['pass_for_dynamic']
    assert info['attempts']==2 and info['initial_report_file']=='attempt1.json'
    assert x.mount_recovery['state']=='rechecking_signal'


def test_hard_axis_misalignment_never_triggers_retry(monkeypatch):
    from app import auto_dynamic
    monkeypatch.setattr(auto_dynamic.DIAG,'record',lambda *args,**kwargs:None)
    x=owner([{'output':'roll','pass_for_dynamic':False,
              'reason':'安装轴偏差超过预检阈值；检查机械装夹'}])
    name,data,info=x._capture_static_with_axis_retry('roll',0,1,None)
    assert info['attempts']==1 and x.static_precheck.speeds==[2]
    assert not data['mount_axis_precheck']['pass_for_dynamic']


def test_no_retry_above_authorized_three_dps(monkeypatch):
    x=owner([{'output':'pitch','pass_for_dynamic':False,
              'reason':'运动角速度信噪比不足，不能证明装夹对齐'}],speed=5)
    _,_,info=x._capture_static_with_axis_retry('pitch',90,1,None)
    assert info['attempts']==1 and x.static_precheck.speeds==[3]


def test_all_experiment_modules_are_accordion_boxes_and_actions_keep_accessibility():
    root=Path(__file__).resolve().parents[1]
    doc=BeautifulSoup((root/'web/index.html').read_text(encoding='utf-8'),'html.parser')
    page=doc.find(id='page-experiments')
    for name in ['exp-device','exp-parameters','exp-static','exp-oneclick','exp-results']:
        box=page.find(id=name)
        assert box is not None and box.name=='details' and box.find('summary',recursive=False)
    for name in ['v58-connect-table','v58-close-table']:
        b=page.find(id=name)
        assert b.name=='button' and b.get('aria-label') and b.find('svg')
    assert page.find(id='auto-mount-recovery-result')
    assert page.find(id='auto-stop') and page.find(id='v58-global-stop')
    assert (root/'web/experiment-v76.css').is_file()
