"""Simulated API and DLL wiring: 10°/s default with retained axis safety."""
from pathlib import Path
import threading
from fastapi.testclient import TestClient
from app import main
from app.manual_axis_control import GuardedManualAxis
from app.native_axis_console_v727 import NativeAxisConsole
from app.turntable import Table2TD600
from app.motion_profile_v728 import position_limits, position_speed_max, velocity_speed_max
import pytest
import time

BASE=Path(__file__).resolve().parents[1]

class DummyTable:
    connected=True
    def __init__(self):self.commands=[];self.positions={0:0.,2:0.};self.lock=threading.RLock()
    def read_status(self):
        return {'time_monotonic_ns':time.monotonic_ns(),'axes':{str(a):{
            'position_deg':self.positions[a],'speed_dps':0.,'enabled':True,
            'healthy':True,'zeroed':True,'driver_fault':False,'upper_limit':False,
            'lower_limit':False,'over_speed':False,'mode':0,'in_place':True}
            for a in (0,2)}}
    def move_inner_manual(self,target,speed):self.commands.append(('inner_position',target,speed));self.positions[0]=target
    def move(self,axis,target,speed):self.commands.append(('position',axis,target,speed));self.positions[axis]=target
    def velocity(self,axis,speed,accel):self.commands.append(('velocity',axis,speed,accel))
    def stop(self):self.commands.append(('dual_stop',))
    def stopped_verified(self,timeout=20):return True


def test_default_10_is_present_in_both_axis_position_and_velocity_fields():
    html=(BASE/'web/index.html').read_text('utf8')
    js=(BASE/'web/turntable-native-v727.js').read_text('utf8')
    for a in (0,2):
        assert f'id="tt25-velocity-{a}" type="number" value="10"' in html
    assert 'id="tt27-vspeed-${a}" value="10"' in js
    assert 'id="tt27-vtime-${a}" value="1"' in js
    assert main.ManualPreflightArgs(axis=2,target_deg=1).speed_dps==10
    assert main.NativeAxisCommandArgs(axis=2,mode='velocity').speed_dps==10


def test_configured_axis_envelopes_and_10_speed_from_single_profile():
    assert position_limits(0)==(0.,90.)
    assert position_limits(2)==(-20.,20.)
    assert position_speed_max()==10
    assert velocity_speed_max()==10


def test_10_dps_position_command_reaches_simulated_table_and_stops():
    t=DummyTable();c=GuardedManualAxis(t,lambda:False)
    plan=c.preflight(2,5,10)
    c.start(plan['token'],True)
    c.thread.join(3)
    assert ('position',2,5.,10.) in t.commands
    assert ('dual_stop',) in t.commands
    assert c.stopped_verified is True


def test_10_dps_velocity_command_reaches_simulated_table_and_stops():
    t=DummyTable();c=NativeAxisConsole(t,lambda:False)
    c.start(2,'velocity',speed=10.,accel=1.,duration=.5)
    c.thread.join(3)
    assert ('velocity',2,10.,1.) in t.commands
    assert ('dual_stop',) in t.commands
    assert c.stopped_verified is True


def test_driver_adapter_sends_10_not_rejected_by_old_5_cap(monkeypatch):
    t=Table2TD600();t.connected=True
    calls=[]
    monkeypatch.setattr(t,'_ensure',lambda axis:{'enabled':True,'zeroed':True})
    monkeypatch.setattr(t,'_call',lambda name,argtypes,restype,*args:calls.append((name,args)) or 1)
    t.move(2,5,10)
    t.velocity(2,10,1)
    assert ('SetAxisPosition',(2,5.0,10.0)) in calls
    assert ('SetAxisVelocity',(2,10.0,1.0)) in calls


def test_v729_manual_motion_has_no_old_artificial_limits():
    t=DummyTable();c=GuardedManualAxis(t,lambda:False)
    for axis,target,speed,mode in [(0,-800,10,'relative'),(0,360,10,'absolute'),
                                   (2,720,11,'relative'),(2,-800,50,'absolute')]:
        result=c.preflight(axis,target,speed,mode)
        assert result['target_deg']==target and result['position_mode']==mode
    for axis,target,speed,mode in [(2,0,0,'absolute'),(2,1,float('nan'),'absolute'),
                                   (2,1,10,'unsupported'),(2,0,10,'relative')]:
        with pytest.raises(ValueError):c.preflight(axis,target,speed,mode)
    assert not t.commands


def test_v729_velocity_speed_not_capped_at_10_in_manual_console():
    t=DummyTable();n=NativeAxisConsole(t,lambda:False)
    n.start(2,'velocity',speed=11.,accel=1.,duration=.5)
    n.thread.join(3)
    assert ('velocity',2,11.,1.) in t.commands
    assert ('dual_stop',) in t.commands
