"""Regression: short 0.3Hz dynamic test must survive a mid-test host clock reset.
All traces are synthetic, never used as purported real hardware measurements.
"""
import math
import numpy as np
from app.dynamic_experiment import recover_imu_timebase,analyze_tracking,ALGORITHMS


def _samples(*, reception_jitter_s=0.0, host_jump=True):
    amp=5.;freq=.3;motion=12.;end=22.;first=10.
    table=[];imu=[]
    def ref(t):return amp*math.sin(2*math.pi*freq*(t-motion)) if t>=motion else 0.
    for t in np.arange(first,end+1.8,.08):
        table.append({'pc_mid_ns':int(t*1e9),'axis_2_pos':ref(t)})
    for j,begin in enumerate(np.arange(first,end+1.5,.04)):
        end_device=begin+15*.0012
        jitter=-reception_jitter_s if j==150 else 0.
        observed=int((end_device+jitter)*1e9)
        for k in range(16):
            t=begin+k*.0012
            # jump *back* between packets, while the median offset stays < 500ms
            host_t=t+(.23 if t<16. else -.29) if host_jump else t
            row={'host_est_ns':int(host_t*1e9),'pc_observed_ns':observed,
                 'device_t_s':t}
            for ch in ('raw','cal'):
                for a in ALGORITHMS:row[f'{ch}_{a}_roll']=ref(t)
            imu.append(row)
    return table,imu,int(motion*1e9),int(end*1e9)


def test_mid_experiment_anchor_reset_no_longer_fails():
    table,imu,start,end=_samples()
    host=np.asarray([x['host_est_ns'] for x in imu])
    assert np.any(np.diff(host)<=0)
    ts,info=recover_imu_timebase(imu,table[0]['pc_mid_ns'],table[-1]['pc_mid_ns'])
    assert np.all(np.diff(ts)>0)
    assert info['host_nonmonotonic_steps']>=1
    assert info['recovered']
    assert info['time_source']=='pc_fifo_reception_backprojection'
    result=analyze_tracking(table,imu,2,'roll',1,5.,.3,start,end)
    assert result['valid'],result.get('reason')
    assert result['comparison'][0]['relative_tracking_rmse_deg']<.03
    assert result['certified_dynamic_accuracy'] is False


def test_small_fifo_receipt_jitter_is_marked_and_bounded():
    table,imu,start,end=_samples(reception_jitter_s=.027)
    ts,info=recover_imu_timebase(imu,table[0]['pc_mid_ns'],table[-1]['pc_mid_ns'])
    assert info['recovered']
    assert info['pc_batch_seam_repairs']>=1
    assert 0<info['pc_batch_max_shift_ms']<=50
    assert np.all(np.diff(ts)>0)
    result=analyze_tracking(table,imu,2,'roll',1,5.,.3,start,end)
    assert result['valid'],result.get('reason')
    assert result['clock_diagnostics']['pc_batch_seam_repairs']>=1


def test_large_fifo_receipt_overlap_must_not_be_silently_repaired():
    table,imu,start,end=_samples(reception_jitter_s=.13)
    ts,info=recover_imu_timebase(imu,table[0]['pc_mid_ns'],table[-1]['pc_mid_ns'])
    assert info['recovered'] is False
    assert info['pc_receipt_backward_steps']>=1
    assert 'PC接收时钟发生倒退' in info['clock_warning']
    result=analyze_tracking(table,imu,2,'roll',1,5.,.3,start,end)
    assert not result['valid']
    assert result['clock_diagnostics']['host_nonmonotonic_steps']>=1
    assert '时间轴/采样检查' in result['reason']


def test_normal_host_time_untouched():
    table,imu,start,end=_samples(host_jump=False)
    ts,info=recover_imu_timebase(imu,table[0]['pc_mid_ns'],table[-1]['pc_mid_ns'])
    assert info['time_source']=='session_host_estimate'
    assert info['recovered'] is False
    assert np.max(np.abs(ts-np.asarray([r['host_est_ns']/1e9 for r in imu])))==0
