"""Manual relative multi-turn operator controls: no actual motor on CI."""
from pathlib import Path
import math
import time
import pytest
from fastapi.testclient import TestClient
from app import main
from app.turntable import Table2TD600, TableError
from app.manual_axis_control import GuardedManualAxis
from app.angles import angle_delta_deg

BASE=Path(__file__).resolve().parents[1]

def test_real_vendor_dll_has_mentioned_relative_export():
    # Portable PE name check; binary is supplied by the user's R10 project.
    blob=(BASE/'drivers/2TD600.dll').read_bytes()
    assert b'SetAxisOpposition' in blob
    assert b'SetAxisPosition' in blob


def test_operator_manual_dll_passes_unwrapped_signed_degrees(monkeypatch):
    device=Table2TD600();device.connected=True
    calls=[]
    monkeypatch.setattr(device,'_ensure',lambda axis:{'enabled':True,'zeroed':True})
    monkeypatch.setattr(device,'_call',lambda name,argtypes,restype,*args:calls.append((name,args)) or 1)
    device.manual_position(2,-800,10,'relative')
    device.manual_position(0,720,50,'relative')
    device.manual_position(0,360,50,'absolute')
    device.manual_position(2,-800,50,'absolute')
    assert calls == [
        ('SetAxisOpposition',(2,-800.,10.)),
        ('SetAxisOpposition',(0,720.,50.)),
        ('SetAxisPosition',(0,360.,50.)),
        ('SetAxisPosition',(2,-800.,50.)),
    ]
    assert angle_delta_deg(360,0)==0
    assert angle_delta_deg(-800,-80)==0


def test_controller_rejection_does_not_count_as_success(monkeypatch):
    device=Table2TD600();device.connected=True
    monkeypatch.setattr(device,'_ensure',lambda axis:{'enabled':True,'zeroed':True})
    monkeypatch.setattr(device,'_call',lambda *args:0)
    with pytest.raises(TableError,match='未被厂家控制器接受'):
        device.manual_position(2,-800,10,'relative')


def test_manual_invalid_number_or_mode_is_rejected(monkeypatch):
    d=Table2TD600();d.connected=True
    monkeypatch.setattr(d,'_ensure',lambda axis:{'enabled':True,'zeroed':True})
    calls=[]
    monkeypatch.setattr(d,'_call',lambda *args:calls.append(args) or 1)
    for mode,angle,speed in [('relative',float('nan'),10),('relative',-800,0),('absolute',0,float('inf')),('foo',-800,10)]:
        with pytest.raises(TableError):d.manual_position(2,angle,speed,mode)
    assert calls==[]


def test_ui_includes_mode_selectors_for_both_axes_without_numeric_caps():
    html=(BASE/'web/index.html').read_text('utf8')
    js=(BASE/'web/integrated-console-v725.js').read_text('utf8')
    for axis in (0,2):
        assert f'id="tt29-mode-{axis}"' in html
        assert f'id="tt25-velocity-{axis}" type="number" value="10"' in html
        assert f'<option value="relative">相对位移（可多圈）</option>' in html
    assert 'position_mode:$(`tt29-mode-${axis}`).value' in js
    assert 'manual/command' in js


def test_endpoint_forwards_relative_mode_and_speed(monkeypatch):
    payload={}
    def fake_preflight(axis,target,speed,position_mode):
        payload.update(axis=axis,target=target,speed=speed,position_mode=position_mode)
        return {'token':'test-token'}
    monkeypatch.setattr(main.MANUAL,'preflight',fake_preflight)
    monkeypatch.setattr(main.MANUAL,'start',lambda token,confirmed:{'running':True,'position_mode':payload['position_mode']})
    client=TestClient(main.app)
    response=client.post('/api/turntable/manual/command',json={'axis':2,'target_deg':-800,'speed_dps':50,'position_mode':'relative'})
    assert response.status_code==200,response.text
    assert payload=={'axis':2,'target':-800.,'speed':50.,'position_mode':'relative'}


def test_legacy_auto_profile_is_not_loosely_removed():
    from app.motion_profile_v728 import position_limits,position_speed_max
    assert position_limits(0)==(0.,90.)
    assert position_limits(2)==(-20.,20.)
    assert position_speed_max()==10

class RelativeMultiTurnFake:
    """Emulates a modulo-360 encoder and a live relative-position DLL task."""
    connected=True
    def __init__(self, step=-50., count=16):
        self.commands=[];self.started=False;self.reads=0
        self.step=step;self.count=count;self.raw=0.0
    def manual_position(self,axis,target,speed,mode):
        self.commands.append((axis,target,speed,mode));self.started=True
    def read_status(self):
        if self.started:
            self.reads+=1
            if self.reads > 1 and self.reads <= self.count+1:
                self.raw=(self.raw+self.step)%360
        moving=self.started and 1 < self.reads <= self.count+1
        return {'time_monotonic_ns':time.monotonic_ns(), 'axes':{
            str(a):{'position_deg':self.raw if a==2 else 0.,
                    'speed_dps':(-500. if moving else 0.) if a==2 else 0.,
                    'enabled':True,'zeroed':True,'healthy':True,
                    'driver_fault':False,'upper_limit':False,'lower_limit':False,
                    'over_speed':False,'mode':8 if moving else 2,'in_place':not moving}
            for a in (0,2)}}
    def stop(self):self.commands.append('stop')
    def stopped_verified(self,timeout=20):return True


def test_relative_minus800_requires_actual_observed_two_plus_turns():
    fake=RelativeMultiTurnFake(-50,16)
    c=GuardedManualAxis(fake,lambda:False)
    plan=c.preflight(2,-800,500,'relative')
    c.start(plan['token'],True)
    c.thread.join(6)
    assert c.state=='relative_observed_complete',c.status()
    assert abs(c.observed_relative_travel_deg+800)<.01
    assert c.relative_travel_quality=='observed_unwrapped'
    assert c.stopped_verified is True
    assert (2,-800.,500.,'relative') in fake.commands
    assert 'stop' in fake.commands


def test_modulo_feedback_at_minus80_must_not_claim_minus800():
    fake=RelativeMultiTurnFake(-80,1)
    c=GuardedManualAxis(fake,lambda:False)
    plan=c.preflight(2,-800,500,'relative')
    c.start(plan['token'],True)
    c.thread.join(4)
    assert c.state=='failed',c.status()
    assert c.observed_relative_travel_deg != -800
    assert c.stopped_verified is True
    assert 'stop' in fake.commands
