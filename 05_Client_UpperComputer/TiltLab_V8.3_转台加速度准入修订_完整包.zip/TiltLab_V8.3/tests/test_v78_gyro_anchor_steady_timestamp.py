"""V7.8 research-only tests; no hardware claims or motion commands."""
import math
import numpy as np
import pytest
from app.fusion import Params, create_filter, FILTERS
from app.steady_state import find_sway_steady_start
from app.dynamic_experiment import imu_sample_quality
from app.engine import Workstation


@pytest.mark.parametrize('frequency', (.1, .3))
def test_gyro_anchor_stationary_bias_then_real_sine(frequency):
    p=Params();f=create_filter('gyro_anchor',p)
    out=None;estimated=[];actual=[]
    fs=208.;duration=26. if frequency>.2 else 34.
    for t in np.arange(0,duration,1/fs):
        if t<3.:
            angle=0.;rate=0.;second=0.
        else:
            phase=2*math.pi*frequency*(t-3.)
            angle=5*math.sin(phase)
            rate=5*2*math.pi*frequency*math.cos(phase)
            second=-math.radians(5)*(2*math.pi*frequency)**2*math.sin(phase)
        # 0.18m offset creates a false dynamic gravity direction.
        a=[0.,math.sin(math.radians(angle))-.18*second/9.80665,math.cos(math.radians(angle))]
        g=[rate+.042,0.,0.]
        out=f.update(a,g,1/fs)
        if t>11.:
            estimated.append(out['roll']);actual.append(angle)
    assert out['stationary_bias_ready']
    assert abs(out['gyro_bias_dps'][0]-.042)<.008
    x=np.asarray(estimated);y=np.asarray(actual)
    assert (np.ptp(x)/np.ptp(y))==pytest.approx(1,abs=.04)
    assert abs(float(np.mean(x-y)))<.24


def test_gyro_anchor_does_not_claim_missing_samples_are_real():
    f=create_filter('gyro_anchor',Params())
    for _ in range(250):f.update([0,0,1],[.035,0,0],.005)
    out=f.update([0,0,1],[.035,0,0],.12)
    assert out['imu_gaps_over_50ms']>=1
    assert out['latest_gap_s']==pytest.approx(.12)
    assert out['stationary_bias_ready'] is True


def test_encoder_steady_start_excludes_controller_ramp():
    start=4.;period=1/.3;end=start+10*period
    ts=np.arange(1,end+.1,.085)
    def actual(t):
        if t<start:return 0.
        cycle=(t-start)/period
        envelope=min(1.,max(.0,(cycle+.5)/3.0))
        return 5*envelope*math.sin(2*math.pi*.3*(t-start))
    ref=np.array([actual(t) for t in ts]);result=find_sway_steady_start(ts,ref,start,end,.3,5.)
    assert result['valid'],result
    assert result['steady_start_s']>start+3*period
    assert result['steady_start_s']<end-1*period


def test_imu_quality_is_diagnostic_not_fake_time_repair():
    rows=[{'device_t_s':t,'imu_nominal_odr_hz':208} for t in (0,.005,.01,.016,.070,.075)]
    d=imu_sample_quality(rows)
    assert d['available'] and d['seams_over_50ms']==1
    assert d['reported_odr_hz']==208
    assert d['recorded_average_hz']<208


def test_v78_is_selectable_and_does_not_modify_table_commands():
    assert 'gyro_anchor' in FILTERS
    w=Workstation();w.configure(algorithm='gyro_anchor')
    assert w.active=='gyro_anchor'
    from pathlib import Path
    p=Path(__file__).resolve().parents[1]
    assert 'SetAxisSway' not in (p/'app/gyro_anchor.py').read_text(encoding='utf8')
    assert 'SetAxisSway' in (p/'app/turntable.py').read_text(encoding='utf8')
