from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
def test_v48_material_stylesheet_loaded():
    html=(ROOT/"web"/"index.html").read_text(encoding="utf-8")
    css=(ROOT/"web"/"liquid-v48.css").read_text(encoding="utf-8")
    assert "/assets/liquid-v48.css" in html
    assert "backdrop-filter" in css
    assert ".btn.primary" in css
def test_v48_existing_business_element_ids_preserved():
    html=(ROOT/"web"/"index.html").read_text(encoding="utf-8")
    required=["btn-serial","serial-port","serial-baud","serial-address","cal-folder",
      "btn-folder","cal-current-path","uid-number","raw-roll","raw-pitch","cal-roll",
      "cal-pitch","m-roll","m-pitch","sensor-3d","live-chart","btn-real-test",
      "btn-record","btn-replay","btn-params","cal-matrix-diagnostics"]
    ids=set(re.findall(r'id="([^"]+)"',html))
    assert set(required)<=ids
    assert len(ids)==len(re.findall(r'id="([^"]+)"',html))
