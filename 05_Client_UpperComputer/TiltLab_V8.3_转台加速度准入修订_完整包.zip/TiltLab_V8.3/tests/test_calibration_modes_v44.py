"""R10 sample-schema-compatible fixtures, not measured customer data."""
import json,math
from pathlib import Path
import pytest
from app.calibration import scan,parse_file,apply,uid_to_serial
from app.engine import Workstation
from app.fusion import FILTERS

@pytest.fixture(autouse=True)
def isolated_user_settings(monkeypatch,tmp_path):
    import app.engine as engine_module
    monkeypatch.setattr(engine_module,'SETTINGS_FILE',tmp_path/'settings.json')

I=[[1,0,0],[0,1,0],[0,0,1]]
UID='0123456789ABCDEFFEDCBA98'
SN=uid_to_serial(bytes.fromhex(UID))

def make_ambient(root,sn=SN):
    root.mkdir(exist_ok=True,parents=True)
    for sensor in ('accel','gyro'):
        obj={
            'schema_version':3,'calibration_type':('accelerometer_production_ambient' if sensor=='accel' else 'gyroscope_production_ambient'),
            'device_serial':sn,'coordinate_frame':'转台圆盘公共机械坐标系 P','axis_model':'outer_x_inner_z',
            'quality_gate':{'metric_pass':True},'status':'PILOT_PASS_NOT_RELEASED',
            'raw_to_platform_matrix':I,
            **({'raw_accel_bias_g':[0.1,0.,0.]} if sensor=='accel' else {'raw_gyro_bias_dps':[.2,0.,0.]})}
        (root/f'{sn}_{sensor}_calibration.json').write_text(json.dumps(obj),encoding='utf-8')

def make_thermal(root,sn=SN):
    folder=root/sn;folder.mkdir(exist_ok=True,parents=True)
    for k in ('acc','gyro'):
        obj={'schema_version':3,'sensor':k,'id':'T0-B1',
             'selection_status':'INDEPENDENT_TEMPERATURE_IMPROVEMENT_CONFIRMED_RESEARCH_ONLY',
             'production_release':False,'temperature_input':{'id':'T0'},
             'fit_temperature_range_c':[0.,45.],
             'bias_coeff':[[0.1],[0.],[0.]],
             'forward_coeff':[[[1.],[0.],[0.]],[[0.],[1.],[0.]],[[0.],[0.],[1.]]],
             'axis_model':'outer_x_inner_z'}
        (folder/f'thermal_{k}_selected_candidate.json').write_text(json.dumps(obj),encoding='utf-8')

def test_ambient_legacy_r10_file_structure(tmp_path):
    make_ambient(tmp_path)
    matched=scan(tmp_path,SN,UID,mode='ambient')
    assert matched['status']=='matched', matched
    assert apply([.1,0,1],matched['acc'])==pytest.approx([0,0,1])
    assert matched['quality']['acc']=='PILOT_PASS_NOT_RELEASED'
    assert scan(tmp_path,'DTS000000',UID,mode='ambient')['status']=='missing'

def test_ambient_rejects_failed_gate_or_thermal_candidate(tmp_path):
    make_ambient(tmp_path)
    p=next(tmp_path.glob('*_accel_calibration.json'))
    obj=json.loads(p.read_text());obj['quality_gate']['metric_pass']=False;p.write_text(json.dumps(obj))
    assert scan(tmp_path,SN,UID)['status']=='invalid'
    assert scan(tmp_path,SN,UID,mode='thermal')['status']=='missing'  # no thermal candidates

def test_thermal_selected_candidate_with_temperature_boundary(tmp_path):
    make_thermal(tmp_path)
    matched=scan(tmp_path,SN,UID,mode='thermal')
    assert matched['status']=='matched',matched
    assert apply([0.1,0,1],matched['acc'],25)==pytest.approx([0.,0.,1.])
    with pytest.raises(ValueError,match='禁止外推'):
        apply([0,0,1],matched['acc'],55)

def test_full_temp_rejects_unverified_candidate(tmp_path):
    make_thermal(tmp_path)
    p=next(tmp_path.glob('*/thermal_acc_selected_candidate.json'))
    obj=json.loads(p.read_text());obj['selection_status']='HOLDOUT_NOT_IMPROVED_NO_APPROVAL';p.write_text(json.dumps(obj))
    assert scan(tmp_path,SN,UID,mode='thermal')['status']=='invalid'

def test_raw_always_runs_even_without_calibration(tmp_path):
    lab=Workstation();lab.source='serial';lab.uid=SN;lab.uid_hex=UID;lab.set_folder(str(tmp_path))
    assert lab.cal_status=='missing'
    for i in range(25):lab.process(dict(t=i*.01,acc=[0,0,1],gyro=[0,0,0],temp=25))
    x=lab.status()['latest']
    assert x['raw'] is not None and x['cal'] is None
    # In single-algorithm realtime mode only the chosen filter and accel run.
    assert set(x['outputs'])=={'accel',lab.active}

def test_ambient_dual_chains_and_mode_disable(tmp_path):
    make_ambient(tmp_path)
    lab=Workstation();lab.source='serial';lab.uid=SN;lab.uid_hex=UID
    result=lab.set_folder(str(tmp_path))
    assert result['status']=='matched'
    for i in range(30):lab.process(dict(t=i*.01,acc=[.1,0,1],gyro=[.2,0,0],temp=25))
    x=lab.status()['latest']
    assert x['raw'] and x['cal'] and x['acc_cal']==pytest.approx([0,0,1])
    lab.set_mode('none')
    lab.process(dict(t=.5,acc=[.1,0,1],gyro=[.2,0,0],temp=25))
    assert lab.status()['latest']['raw'] and lab.status()['latest']['cal'] is None

def test_thermal_outside_range_does_not_stop_raw(tmp_path):
    make_thermal(tmp_path)
    lab=Workstation();lab.source='serial';lab.uid=SN;lab.uid_hex=UID
    lab.cal_root=str(tmp_path)
    assert lab.set_mode('thermal')['status']=='matched'
    lab.process(dict(t=0.,acc=[.1,0,1],gyro=[.1,0,0],temp=25))
    assert lab.status()['latest']['cal'] is not None
    lab.process(dict(t=.01,acc=[.1,0,1],gyro=[.1,0,0],temp=51))
    x=lab.status()['latest']
    assert x['raw'] is not None and x['cal'] is None
    assert '禁止外推' in lab.status()['cal_runtime_error']
    lab.process(dict(t=.02,acc=[.1,0,1],gyro=[.1,0,0],temp=25))
    assert lab.status()['latest']['raw'] and lab.status()['latest']['cal']


def test_calibration_mode_and_offline_inspect_http(tmp_path,monkeypatch):
    from fastapi.testclient import TestClient
    import app.main as main
    import app.engine as engine_module
    # Global singleton should not modify the distribution's settings during tests.
    monkeypatch.setattr(engine_module,'SETTINGS_FILE',tmp_path/'settings.json')
    make_ambient(tmp_path)
    main.ENGINE.stop()
    main.ENGINE.cal_mode='ambient'
    with TestClient(main.app) as client:
        r=client.post('/api/calibration/inspect',json={'path':str(tmp_path),'serial':SN,'mode':'ambient'})
        assert r.status_code==200, r.text
        assert r.json()['status']=='matched' and r.json()['applied'] is False
        r=client.post('/api/calibration/mode',json={'mode':'none'})
        assert r.status_code==200 and r.json()['status']=='disabled'
        assert client.get('/api/status').json()['cal_mode']=='none'
        assert client.post('/api/calibration/mode',json={'mode':'unverified'}).status_code==400
        assert client.post('/api/calibration/inspect',json={'path':str(tmp_path),'serial':'OTHER'}).status_code==400
