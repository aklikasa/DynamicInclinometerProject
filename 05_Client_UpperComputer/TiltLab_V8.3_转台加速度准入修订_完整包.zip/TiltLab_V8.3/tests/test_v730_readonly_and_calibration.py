"""V7.30 read-only diagnostics and auto calibration readiness (no hardware commands)."""
from fastapi.testclient import TestClient
from app.main import app, FACTORY, ENGINE, TABLE


def test_v730_meta_and_diagnostics_work_without_hardware():
    with TestClient(app) as client:
        m=client.get('/api/meta')
        assert m.status_code==200 and m.json()['version']=='8.2.0'
        r=client.get('/api/pcb/link-diagnostics')
        assert r.status_code==200
        obj=r.json()
        assert obj['server_alive'] is True
        assert 'pcb_connected' in obj and 'watchdog' in obj
        assert 'WebSocket' in obj['note']


def test_auto_calibration_readiness_is_read_only(monkeypatch):
    def forbidden(*a,**kw):raise AssertionError('Preflight cannot perform a hardware read')
    monkeypatch.setattr(TABLE,'read_status',forbidden)
    monkeypatch.setattr(ENGINE,'start',forbidden)
    monkeypatch.setattr(FACTORY,'start',forbidden)
    r=FACTORY.readiness()
    assert r['ready_for_preflight'] is False
    assert r['blockers']
    with TestClient(app) as client:
        response=client.get('/api/calibration/factory-handoff/readiness')
        assert response.status_code==200
        assert isinstance(response.json()['blockers'],list)


def test_v730_ui_has_preflight_and_version_gate():
    from pathlib import Path
    root=Path(__file__).resolve().parents[1]
    html=(root/'web'/'index.html').read_text(encoding='utf-8')
    js=(root/'web'/'app.js').read_text(encoding='utf-8')
    assert 'id="factory-readiness-btn"' in html
    assert 'id="pcb-link-diag"' in html
    assert '/api/pcb/link-diagnostics' in js
    assert '/api/calibration/factory-handoff/readiness' in js
    assert "startsWith('8.2.')" in js


def test_v730_websocket_endpoint_does_not_touch_serial():
    with TestClient(app) as client:
        with client.websocket_connect('/ws') as ws:
            status=ws.receive_json()
            assert 'chart_delta' in status and 'running' in status
