"""V8.3: purely offline measured-encoder interval detection, no DLL or hardware."""
import math
import numpy as np
import pytest

from app.steady_state import find_sway_steady_start
from app.dynamic_experiment import limits
from app.sway_envelope import verify_sway_motion, SWAY_LIMITS


def signal(*,amp=2.,freq=.5,cycles=10.,ramp_cycles=2.,finish_cycles=1.,phase=.63):
    start=10.; end=start+cycles/freq; period=1/freq
    times=np.arange(start-1.,end+.05,.08)
    def value(t):
        cyc=max(0,(t-start)/period)
        if ramp_cycles>0 and cyc<=ramp_cycles: env=min(1.,cyc/ramp_cycles)
        elif finish_cycles>0 and cyc>cycles-finish_cycles: env=max(0.,(cycles-cyc)/finish_cycles)
        else:env=1.
        return amp*env*math.sin(2*math.pi*freq*(t-start)+phase)
    return times,np.array([value(t) for t in times]),start,end


def test_decaying_tail_not_called_stable():
    t,p,start,end=signal()
    r=find_sway_steady_start(t,p,start,end,.5,2.)
    assert r['valid'],r
    assert r['cycles_evaluated']>=1
    assert r['steady_start_s']>start+2/.5
    assert r['steady_end_s'] <end-0.5/.5, r
    assert r['trailing_unverified_s']>0.5/.5
    assert any(x['quality']=='ramping_or_non_sinusoidal' for x in r['cycle_amplitudes'])


def test_clean_steady_has_valid_interval():
    t,p,start,end=signal(ramp_cycles=0.,finish_cycles=0.)
    r=find_sway_steady_start(t,p,start,end,.5,2.)
    assert r['valid'],r
    assert r['steady_start_s']<r['steady_end_s']<=end
    assert r['cycles_evaluated']>2


def test_no_stable_cycles_returns_invalid():
    t,p,start,end=signal(ramp_cycles=11.,finish_cycles=0.)
    r=find_sway_steady_start(t,p,start,end,.5,2.)
    assert not r['valid']


def test_wrong_waveform_rejected():
    t,p,start,end=signal(ramp_cycles=0.,finish_cycles=0.)
    # Flat-topped waveform has almost the right swing but is not sinusoidal.
    p=2.*np.tanh(p*2.)/np.tanh(4.)
    r=find_sway_steady_start(t,p,start,end,.5,2.)
    assert not r['valid']


def test_unverified_angular_accel_still_fails_closed():
    assert SWAY_LIMITS['accel_dps2']>=0
    if not SWAY_LIMITS['rating_verified']:
        with pytest.raises(ValueError):limits(2.,.8,10)
    assert math.isclose((2*math.pi*.8)**2*2,50.5323745,rel_tol=1e-4)


def test_site_documentation_required_before_higher_rating(tmp_path,monkeypatch):
    import json
    import app.sway_envelope as envelope
    profile=tmp_path/'rating.json'
    monkeypatch.setattr(envelope,'PROFILE_PATH',profile)
    profile.write_text(json.dumps({'factory_sway_rating_verified':True,'factory_sway_model':'2TD-600',
                                   'factory_sway_serial':'ST123',
                                   'factory_sway_max_speed_dps':35,'factory_sway_max_accel_dps2':80}),encoding='utf8')
    assert envelope.rated_sway_limits()['rating_verified'] is False
    config=json.loads(profile.read_text())
    config['factory_sway_document']='厂商按本机负载确认文件编号 DOC-2026-003'
    profile.write_text(json.dumps(config),encoding='utf8')
    approved=envelope.rated_sway_limits()
    assert approved['rating_verified'] is True
    assert approved['accel_dps2']==80
