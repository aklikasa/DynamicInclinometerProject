"""Offline-only fake hardware regression for the V7.10 data-path split.

No vendor DLL, serial device, homing, or physical motion is used.
"""
import collections, csv, json, math, threading, time
from dataclasses import dataclass
from app.dynamic_experiment import DynamicExperiment, ALGORITHMS

@dataclass
class _Params:
    kp:float=2.0

class _FakeTable:
    connected=True
    last_stop_check={'verified':True}
    def __init__(self):self.motion=False;self.stop_called=0
    def read_status(self):
        phase=(time.monotonic()-self.start)*2*math.pi*0.3 if self.motion else 0
        pos=.2*math.sin(phase) if self.motion else 0.
        axis={'position_deg':pos,'speed_dps':0.,'mode':2,
              'driver_fault':False,'upper_limit':False,'lower_limit':False,
              'over_speed':False,'healthy':True,'enabled':True,'zeroed':True}
        inner=dict(axis,position_deg=90.)
        return {'axes':{'0':inner,'2':axis}}
    def sway(self,axis,amp,freq): self.motion=True;self.start=time.monotonic()
    def stop(self):self.stop_called+=1;self.motion=False
    def stopped_verified(self,timeout=20):return True

class _FakeEngine:
    def __init__(self):
        self.lock=threading.RLock();self.recent=collections.deque(maxlen=3000)
        self.counter=0;self.running=True;self.connected=True;self.source='serial'
        self.uid='MOCK';self.params=_Params();self.active='gyro';self.cal_mode='ambient'
        self.cal={'files':[]};self.cal_status='matched';self.latest={'cal':{'roll':0.,'pitch':0.}}
        self.last_wall=time.time();self.device=None;self.static_alignment=None
        self.keep_running=True
    def produce(self):
        while self.keep_running:
            stamp=time.monotonic_ns();self.last_wall=time.time()
            with self.lock:
                self.counter+=1
                self.recent.append({'sequence':self.counter,'t':self.counter/80,
                    'host_est_ns':stamp,'pc_observed_ns':stamp,'uid':'MOCK','temp':25,
                    'dt':.0125,'odr':80,'timestamp_quality':'mock',
                    'acc':[0,0,1],'acc_cal':[0,0,1],
                    'gyro':[0,0,0],'gyro_cal':[0,0,0],
                    'outputs':{k:{ch:{'roll':0.,'pitch':0.} for ch in ('raw','cal','cal_factory')} for k in ALGORITHMS}})
            time.sleep(.0125)

def test_fake_recording_drains_imu_thread_and_persists_timing_columns(tmp_path):
    table=_FakeTable();engine=_FakeEngine()
    trial=DynamicExperiment(table,engine,tmp_path)
    trial.uid='MOCK';trial.heartbeat_ns=time.monotonic_ns();trial.running=True
    worker=threading.Thread(target=engine.produce,daemon=True);worker.start()
    try:
        # Directly exercise the acquisition routine without commanding hardware.
        plan={'axis':2,'amplitude_deg':.2,'frequency_hz':.3,'duration_s':.35,
              'peak_speed_dps':.4,'output':'pitch','sign':-1,'cycles':2}
        trial._run(plan)
    finally:
        engine.keep_running=False;worker.join(timeout=2)
    assert table.stop_called==1
    assert trial.table_count>=20
    assert trial.imu_count>=20
    with open(tmp_path/trial.table_file,encoding='utf-8-sig',newline='') as f:
        lines=list(csv.DictReader(f))
    assert len(lines)==trial.table_count
    assert all(row.get('poll_lag_ms') not in (None,'') for row in lines)
    assert all(row.get('previous_table_csv_write_ms') not in (None,'') for row in lines)
    with open(tmp_path/trial.imu_file,encoding='utf-8-sig',newline='') as f:
        data=list(csv.DictReader(f))
    assert len(data)==trial.imu_count
    doc=json.loads((tmp_path/trial.report_file).read_text(encoding='utf8'))
    assert doc['feedback_loop_diagnostics']['imu_worker']['polls']>0
    assert doc['stopped_verified'] is True
    assert 'IMU后台采集失败' not in str(doc.get('error',''))
