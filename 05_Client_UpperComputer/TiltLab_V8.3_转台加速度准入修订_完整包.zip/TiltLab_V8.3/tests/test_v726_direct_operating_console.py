"""Offline-only safety and API checks for one-click console; no motor attached."""
from pathlib import Path
from fastapi.testclient import TestClient
from app import main
from app.manual_axis_control import GuardedManualAxis
from tests.test_v725_integrated_console import FakeTurntable

ROOT=Path(__file__).parents[1]

def test_direct_console_has_no_preflight_button_and_has_tabs():
    html=(ROOT/'web/index.html').read_text(encoding='utf-8')
    js=(ROOT/'web/integrated-console-v725.js').read_text(encoding='utf-8')
    tabs=(ROOT/'web/turntable-factory-v726.js').read_text(encoding='utf-8')
    assert 'turntable-factory-v726.css' in html and 'turntable-factory-v726.js' in html
    assert 'id="tt25-check-0"' not in html and 'id="tt25-check-2"' not in html and '② 确认后定位' not in html
    assert 'tt25-target-0' in html and '<select id="tt25-target-0">' not in html
    assert '/api/turntable/manual/command' in js
    assert all(x in tabs for x in ['转台控制','实时曲线','自动测试','数据分析','设备维护'])

def test_direct_one_request_prechecks_and_launches_no_fake_motor(monkeypatch):
    calls=[]
    def pre(axis,target,speed,position_mode):
        calls.append(('check',axis,target,speed,position_mode));return {'token':'local-fake'}
    def run(token,confirmed):
        calls.append(('start',token,confirmed));return {'running':True}
    monkeypatch.setattr(main.MANUAL,'preflight',pre)
    monkeypatch.setattr(main.MANUAL,'start',run)
    r=TestClient(main.app).post('/api/turntable/manual/command',json={'axis':2,'target_deg':3,'speed_dps':1})
    assert r.status_code==200 and r.json()['running']
    assert calls==[('check',2,3.0,1.0,'absolute'),('start','local-fake',True)]

def test_direct_command_rejects_unavailable_real_table():
    response=TestClient(main.app).post('/api/turntable/manual/command',json={'axis':2,'target_deg':2,'speed_dps':1})
    assert response.status_code==409

def test_inner_can_position_within_verified_test_arc():
    fake=FakeTurntable();man=GuardedManualAxis(fake,lambda:False)
    plan=man.preflight(0,45,1.5)
    assert not fake.moves
    man.start(plan['token'],True);man.thread.join(3)
    assert fake.moves==[(0,45.0,1.5)] and man.stopped_verified is True

def test_manual_operator_position_accepts_finite_angles_but_not_bad_values():
    fake=FakeTurntable();man=GuardedManualAxis(fake,lambda:False)
    for axis,targ,speed,mode in [(0,95,1,'absolute'),(2,21,1,'absolute'),
                                 (2,-800,10,'relative'),(2,1,11,'absolute')]:
        assert man.preflight(axis,targ,speed,mode)['target_deg']==targ
    for axis,targ,speed,mode in [(2,1,0,'absolute'),(2,float('inf'),1,'relative'),
                                 (2,1,1,'invalid')]:
        try:man.preflight(axis,targ,speed,mode)
        except ValueError:pass
        else:raise AssertionError('invalid input was not rejected')
    assert not fake.moves
