import math
import numpy as np
import pytest
from app.fusion import Params,create_filter
from app.absolute_accuracy import absolute_metrics,lever_status
from app.continuity_v713 import advance


def test_absolute_retains_zero_error_and_pitch_sign_and_wrap():
    t=np.arange(0.,5.,.02);encoder=-3*np.sin(t)+.023
    table=[{'pc_mid_ns':int(round(x*1e9)),'axis_2_pos':y%360} for x,y in zip(t,encoder)]
    imu=[{'host_est_ns':int(round(x*1e9)),'cal_factory_gyro_anchor_pitch':-y+.04} for x,y in zip(t,encoder)]
    def recover(rows,*_):return np.array([r['host_est_ns']/1e9 for r in rows]),{}
    out=absolute_metrics(table,imu,2,'pitch',-1,1_000_000_000,4_000_000_000,{'valid':True,'reference_steady_state':{'valid':True,'steady_start_s':2.}},['gyro_anchor'],recover)
    assert out['available'] and not out['certified_dynamic_accuracy']
    for m in out['comparison']:
        assert m['absolute_max_error_deg']==pytest.approx(.04,abs=1e-6)
        assert m['absolute_angle_rmse_deg']==pytest.approx(.04,abs=1e-6)
        assert m['signed_mean_error_deg']==pytest.approx(.04,abs=1e-6)
    assert out['scopes']['full_motion']['complete_reference_coverage']


def test_absolute_missing_reference_not_interpolated_and_no_fake_steady():
    t=np.arange(0.,4.,.01);table=[{'pc_mid_ns':int(round(x*1e9)),'axis_2_pos':0} for x in t if x<1 or x>2]
    imu=[{'host_est_ns':int(round(x*1e9)),'cal_factory_gyro_anchor_roll':.03 if x<1 or x>2 else 99.} for x in t]
    def recover(rows,*_):return np.array([r['host_est_ns']/1e9 for r in rows]),{}
    out=absolute_metrics(table,imu,2,'roll',1,0,3_900_000_000,{'valid':False},['gyro_anchor'],recover)
    assert out['scopes']['full_motion']['excluded_reference_samples']>90
    assert out['comparison'][0]['absolute_max_error_deg']==pytest.approx(.03)
    assert 'steady' not in out['scopes']


def test_new_observer_causal_and_exactly_independent_of_lever_params():
    p=Params();q=Params(lever_z_cm=19.51,lever3_z_cm=19.51,lever3_x_cm=5.)
    f=create_filter('gravity_observer',p);h=create_filter('gravity_observer',q)
    for i in range(2000):
        t=i*.002;angle=0. if t<2.5 else 4*math.sin(2*(t-2.5));rate=0 if t<2.5 else 8*math.cos(2*(t-2.5))
        a=[0,math.sin(math.radians(angle)),math.cos(math.radians(angle))];g=[rate+.05,0,0]
        f,o,_=advance('gravity_observer',f,p,True,a,g,.002);h,v,_=advance('gravity_observer',h,q,True,a,g,.002)
        assert o['q']==v['q'];assert o['lever_compensation_enabled'] is False
    assert o['stationary_bias_ready'] and o['motion_detected']
    assert lever_status('gravity_observer',{'lever_z_cm':19.51})=='no_lever'
    assert lever_status('gyro_anchor',{'lever_z_cm':19.51})=='research_lever_branch'
    assert lever_status('gyro_anchor3d',{})=='research_lever_branch'
