"""No physical hardware. Verify inverted Pitch reference and retained partial charts."""
import json
from pathlib import Path
import pytest
from app.auto_dynamic import AutoDynamicWorkflow
from app.table_prepare import TablePreparation
from app.reference_polarity import infer_static_polarity,update_static_polarity
from app.static_alignment import fit_static_alignment
from app.run_ledger_html import write_run_ledger_html
from tests.test_v66_dual_axis import FakeTable,FakeEngine,FakeDynamic,_complete
from tests.test_v71_static_adaptive import static_report

A=[[1.013,-.021],[.017,-1.008]]
B=[.025,-.012]

def test_detect_pitch_inverse_without_changing_motor_direction():
    roll=static_report('roll',a=A,b=B)
    pitch=static_report('pitch',a=A,b=B)
    for r in (roll,pitch):
        r['threshold_deg']=.1
        r['analysis']['chosen_algorithm']='madgwick'
    x=infer_static_polarity(roll,1,'madgwick');y=infer_static_polarity(pitch,1,'madgwick')
    assert x['valid'] and x['selected_sign']==1
    assert y['valid'] and y['selected_sign']==-1 and y['changed']
    old_error=float(pitch['items'][0]['angles']['cal']['madgwick']['pitch'])-pitch['items'][0]['actual_outer_deg']
    assert abs(old_error)>9.9
    update_static_polarity(pitch,1,-1,'madgwick')
    assert pitch['analysis']['reference_sign']==-1
    assert abs(pitch['items'][0]['current_signed_error_deg'])<.1
    model=fit_static_alignment([roll,pitch],'TEST-001','ambient','madgwick',.1)
    assert model['valid'] and model['active_statically_pass'],model
    assert model['validation_active_after']['max_abs_deg']<.1


def test_wrong_axis_and_bad_reverse_data_rejected():
    axis_bad=static_report('pitch',a=[[1,0],[-.02,0.1]],b=B)
    assert not infer_static_polarity(axis_bad,1,'madgwick')['valid']
    hyst=static_report('pitch',a=A,b=B,hysteresis=.65)
    assert not infer_static_polarity(hyst,1,'madgwick')['valid']
    conflicting=static_report('pitch',a=A,b=B)
    for step in conflicting['items']:
        step['angles']['cal']['madgwick']['pitch']*=-1
    assert not infer_static_polarity(conflicting,1,'madgwick')['valid']


def test_full_auto_after_pitch_polarity_flip_uses_negative_reference(tmp_path):
    t=FakeTable();e=FakeEngine();e.active='madgwick';e.pipeline_mode='realtime';d=FakeDynamic(tmp_path,t)
    a=AutoDynamicWorkflow(t,e,TablePreparation(t),d)
    def run_static(output,inner,sign,speed,limit,watcher,progress,span_deg=5.):
        watcher()
        r=static_report(output,a=A,b=B)
        r.update(kind='REAL_STATIC_BEFORE_DYNAMIC',threshold_deg=limit,static_span_deg=span_deg,
                 algorithm_at_start='madgwick',inner_target_deg=inner)
        r['analysis']['chosen_algorithm']='madgwick'
        name=f'{output}_STATIC_PRECHECK.json'
        (tmp_path/name).write_text(json.dumps(r),encoding='utf-8')
        return name,r
    a.static_precheck.run=run_static
    a.start(2,'both',1,5,.3,10,2,True,'xy_sequential',True,pitch_sign=1,
            static_before_dynamic=True,static_limit_deg=.1,static_stop_on_fail=True,
            auto_static_align=True)
    _complete(a,e)
    assert a.state=='completed',a.error
    assert a.plan['requested_pitch_sign']==1 and a.plan['pitch_sign']==-1
    assert a.plan['sign']==1
    assert a.polarity_checks[1]['changed']
    assert ('preflight','pitch',90,-1) in d.commands
    assert len([x for x in t.cmds if x[0]=='sway_stage'])==2
    assert a.run_manifest_file and a.run_manifest_html_file
    assert '<svg' in (tmp_path/a.run_manifest_html_file).read_text(encoding='utf-8')
    report=json.loads((tmp_path/'pitch_STATIC_PRECHECK.json').read_text(encoding='utf-8'))
    assert report['analysis']['reference_sign']==-1
    assert 'analysis_with_original_reference_sign' in report


def test_incomplete_auto_ledger_has_static_svg_and_failure_explanation(tmp_path):
    report=static_report('pitch',a=A,b=B)
    report.update(threshold_deg=.1,algorithm_at_start='madgwick')
    report['analysis']['chosen_algorithm']='madgwick'
    path=tmp_path/'PITCH_STATIC_PRECHECK.json'
    path.write_text(json.dumps(report),encoding='utf-8')
    data={'state':'stopped_or_failed','error':'静态参考方向未核对，动态未执行',
          'stopped_verified':True,'all_requested_stages_completed':False,
          'static_prechecks':[{'output':'pitch','report_file':path.name,'analysis':report['analysis']}],
          'completed_dynamic_stages':[]}
    filename=write_run_ledger_html(tmp_path,'AUTO_FULL_RUN.json',data)
    text=(tmp_path/filename).read_text(encoding='utf-8')
    assert '<svg' in text and '静态参考方向未核对' in text and 'PITCH · 静态14点' in text
    assert '动态结果' not in text
