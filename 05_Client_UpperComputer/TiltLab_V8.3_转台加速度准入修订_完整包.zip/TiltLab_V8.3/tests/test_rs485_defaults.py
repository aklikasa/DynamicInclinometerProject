from fastapi.testclient import TestClient
from app.main import app
from app.devices import R10Device

def test_default_rs485_settings():
    dev=R10Device('COM123')
    assert dev.address == 1 and dev.baudrate == 1500000
    with TestClient(app) as c:
        x=c.get('/api/meta').json()
        assert x['default_connection']['address']==1
        assert x['simulation_enabled'] is False
        assert c.post('/api/start',json={'source':'simulation'}).status_code==403
        assert c.post('/api/experiment',json={'id':'static'}).status_code==403
