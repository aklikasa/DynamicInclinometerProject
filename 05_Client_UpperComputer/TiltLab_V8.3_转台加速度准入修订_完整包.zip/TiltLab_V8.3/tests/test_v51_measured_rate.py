from app.engine import Workstation

def test_rate_fields_offline():
    w=Workstation()
    s=w.status()
    assert s["sample_rate_hz"]==0
    assert s["nominal_odr_hz"] is None

def test_nominal_odr_from_real_sample_field():
    w=Workstation()
    w.process({"t":1.0,"acc":[0,0,1],"gyro":[0,0,0],"temp":25.0,"odr":833})
    assert w.status()["nominal_odr_hz"]==833

def test_json_static_report_has_expected_sections():
    import json
    from pathlib import Path
    path=Path(__file__).resolve().parents[1]/"示例报告"/"DTS872028_30秒静态实测.json"
    r=json.loads(path.read_text(encoding="utf-8"))
    assert r["state"]=="completed"
    assert len(r["comparison"])==14
    assert r["reference_available"] is False
