"""Alignment and standalone-report regressions; synthetic traces never represent hardware measurements."""
import json, math
import numpy as np
from app.dynamic_experiment import analyze_axis_alignment, analyze_tracking, ALGORITHMS
from app.html_report import write_interactive_report


def _gyro_trace(target='roll', deviation_deg=2.0, z_deg=1.5):
    rng=np.random.default_rng(2026)
    # Axis direction is deliberately offset from the expected sensor X/Y axis.
    if target=='roll':
        u=np.array([math.cos(math.radians(deviation_deg))*math.cos(math.radians(z_deg)),
                    math.sin(math.radians(deviation_deg))*math.cos(math.radians(z_deg)),
                    math.sin(math.radians(z_deg))])
    else:
        u=np.array([math.sin(math.radians(deviation_deg))*math.cos(math.radians(z_deg)),
                    math.cos(math.radians(deviation_deg))*math.cos(math.radians(z_deg)),
                    math.sin(math.radians(z_deg))])
    rows=[]
    for t in np.arange(0,12,.005):
        rate=0. if t<2.15 else 2*math.pi*5*.3*math.cos(2*math.pi*.3*(t-2.15))
        g=np.array([.12,-.07,.04])+rate*u+rng.normal(0,.015,3)
        rows.append({'device_t_s':t,**{f'cal_gyro_{a}_dps':g[i] for i,a in enumerate('xyz')}})
    return rows


def test_roll_axis_alignment_recovers_x_axis_misalignment():
    result=analyze_axis_alignment(_gyro_trace('roll',2.0,1.5),'roll')
    assert result['valid'],result
    assert result['target_sensor_axis']=='X'
    assert abs(result['signed_xy_deviation_deg']-2.0)<.15
    assert abs(result['out_of_plane_deg']-1.5)<.15
    assert abs(result['misalignment_deg']-math.hypot(2.0,1.5))<.2
    assert result['gyro_axis_coherence']>.99


def test_pitch_axis_alignment_recovers_y_axis_misalignment():
    result=analyze_axis_alignment(_gyro_trace('pitch',-1.2,.8),'pitch')
    assert result['valid'],result
    assert result['target_sensor_axis']=='Y'
    assert abs(result['signed_xy_deviation_deg']+1.2)<.15
    assert abs(result['out_of_plane_deg']-.8)<.15


def test_alignment_fails_closed_when_gyro_vectors_are_missing():
    result=analyze_axis_alignment([{'device_t_s':i*.01} for i in range(500)],'roll')
    assert not result['valid']
    assert '三轴陀螺仪' in result['reason']


def test_tracking_report_contains_alignment_even_when_angle_metrics_invalid():
    rows=_gyro_trace('roll',1.0,0.0)
    result=analyze_tracking([],rows,2,'roll',1,5,.3,0,0)
    assert not result['valid']
    assert result['axis_alignment']['valid']


def test_interactive_html_report_is_standalone(tmp_path):
    report={'kind':'REAL_2TD600_SINE_DIAGNOSTIC','uid':'TEST','state':'completed',
            'plan':{'output':'roll','inner_target_deg':0,'amplitude_deg':5,'frequency_hz':.3,'cycles':10},
            'stopped_verified':True,'raw_file_table':'trace_table.csv','raw_file_imu':'trace_imu.csv',
            'analysis':{'valid':True,'comparison':[],'chart':[],
                        'axis_alignment':{'valid':True,'target_sensor_axis':'X','misalignment_deg':1.2,
                                          'signed_xy_deviation_deg':1.1,'out_of_plane_deg':.2,
                                          'estimated_outer_axis_sensor':[.999,.019,.003],
                                          'gyro_axis_coherence':.999,'cross_axis_ratio_pct':.2,
                                          'sample_count':1200,'interpretation':'小幅偏差'}}}
    path=tmp_path/'trace.json';path.write_text(json.dumps(report),encoding='utf-8')
    out=write_interactive_report(path)
    html=out.read_text(encoding='utf-8')
    assert out.exists()
    assert 'canvas' in html and 'IMU—转台外轴对齐诊断' in html
    assert 'trace_imu.csv' in html and 'const DATA=' in html
