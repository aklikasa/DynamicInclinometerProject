import math
import pytest
from bs4 import BeautifulSoup
from app.fusion import AccelOnly, Params, accel_tilt, FILTERS
from app.stability import StationaryEvaluation
from app.engine import Workstation


def sample(t):
    a=[.02,-.03,.999]
    output={name:{'raw':dict(roll=2.1,pitch=-1.4,yaw=0.),'cal':dict(roll=2.0,pitch=-1.5,yaw=0.)} for name in FILTERS}
    return {'t':t,'acc':a,'gyro':[0.005,0.009,0.04],'gyro_cal':[0.001,0.001,0.003],'outputs':output}


def test_unfiltered_accel_is_instantaneous_without_gyro_or_dt_state():
    algo=AccelOnly(Params())
    for a in ([0.,0.,1.],[.05,.1,.99],[-.11,.04,.93],[0.,0.,1.]):
        out=algo.update(a,[200.,80.,-150.],.2)
        expected=accel_tilt(a)
        assert out['roll']==pytest.approx(expected['roll'],abs=1.e-7)
        assert out['pitch']==pytest.approx(expected['pitch'],abs=1.e-7)
        assert out['yaw']==pytest.approx(0.)
    assert '无滤波' in FILTERS['accel'][0]


def test_custom_15_minute_record_does_not_auto_end_at_60_or_120s():
    test=StationaryEvaluation(900,'DTS872028','ambient',{})
    assert test.add(sample(0.)) is False
    assert test.add(sample(150.)) is False
    assert test.add(sample(899.)) is False
    assert test.add(sample(900.1)) is True
    assert test.state=='completed'


def test_manual_run_only_stops_explicitly():
    test=StationaryEvaluation(0,'DTS872028','ambient',{})
    assert test.add(sample(0)) is False
    assert test.add(sample(86401.)) is False
    assert test.state=='running'
    test.state='stopped'
    report=test.summary()
    assert report['duration_s']==0
    assert report['metrics']['raw']['accel']['roll']['n']==2


@pytest.mark.parametrize('duration',[float('nan'),float('inf'),-1,604801])
def test_invalid_duration_rejected(duration):
    with pytest.raises(ValueError):StationaryEvaluation(duration,'DTS872028','ambient',{})


def test_ui_custom_duration_manual_and_baseline():
    from pathlib import Path
    ui=(Path(__file__).resolve().parents[1]/'web/index.html').read_text(encoding='utf-8')
    s=BeautifulSoup(ui,'html.parser')
    inp=s.select_one('#stability-duration')
    assert inp.get('type')=='number'
    assert s.select_one('#stability-manual')['type']=='checkbox'
    assert s.select_one('#show-unfiltered')['type']=='checkbox'
    assert '无滤波' in s.select_one('.stability-panel').get_text()


def test_workstation_manual_start_with_real_source_pretend():
    lab=Workstation()
    lab.running=True;lab.connected=True;lab.source='serial';lab.uid='DTS872028'
    r=lab.start_stability(0)
    assert r['duration_s']==0
    assert r['state']=='running'
    lab.stop_stability()
