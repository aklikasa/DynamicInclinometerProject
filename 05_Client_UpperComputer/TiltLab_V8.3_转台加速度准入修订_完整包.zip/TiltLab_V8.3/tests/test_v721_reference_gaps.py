"""V7.2.1: reference gaps must not be silently filled or discard all of a run."""
import json, math
from pathlib import Path
import numpy as np
from app.dynamic_experiment import analyze_tracking, ALGORITHMS
from app.run_ledger_html import write_run_ledger_html

F=.3; AMP=5.; START=5.; END=START+10/F

def make_data(holes=(), put_imu_spike=False):
    ts=np.arange(2., END+1,.09)
    for a,b in holes:
        ts=ts[(ts<a)|(ts>b)]
    table=[{'pc_mid_ns':int(t*1e9),'axis_2_pos':AMP*math.sin(2*math.pi*F*(t-START)) if t>=START else 0} for t in ts]
    imu=[]
    for t in np.arange(2.,END+1.,.009):
        ang=AMP*math.sin(2*math.pi*F*(t-START)) if t>=START else 0.
        if put_imu_spike and 17<=t<17.47:ang+=15.
        row={'host_est_ns':int(t*1e9)}
        for channel in ('raw','cal'):
            for alg in ALGORITHMS:
                row[f'{channel}_{alg}_roll']=ang
        imu.append(row)
    return table,imu

def analyze(holes=(),spike=False):
    t,i=make_data(holes,spike)
    return analyze_tracking(t,i,2,'roll',1,AMP,F,int(START*1e9),int(END*1e9))

def test_normal_dense_reference_not_masked():
    r=analyze()
    assert r['valid']
    assert r['reference_gaps_masked'] is False
    assert r['reference_quality']['imu_stable_samples_excluded']==0

def test_single_455ms_gap_is_censored_and_bad_imu_measurements_do_not_leak():
    r=analyze([(17.,17.455)],True)
    assert r['valid'],r.get('reason')
    q=r['reference_quality']
    assert q['max_feedback_gap_ms']>400
    assert 0<q['stable_missing_reference_pct']<3
    assert q['imu_stable_samples_excluded']>0
    assert r['reference_gaps_masked']
    assert '研究性' in r['quality_warning']
    assert r['time_shift_diagnostics']['available'] is False
    # Any huge apparent angle inside the hole must not enter an RMSE calculation.
    first=next(x for x in r['comparison'] if x['channel']=='cal' and x['algorithm']=='madgwick')
    assert first['relative_tracking_rmse_deg']<.04
    assert any(x.get('missing_reference') for x in r['chart'])

def test_large_gap_is_rejected_and_quality_included():
    r=analyze([(17.,18.5)])
    assert r['valid'] is False
    assert r['reference_quality']['stable_missing_reference_pct']>3
    assert '原始CSV' in r['reason']

def test_multiple_medium_gaps_too_much_loss_rejected():
    r=analyze([(17.,17.55),(21.,21.55)])
    assert r['valid'] is False
    assert r['reference_quality']['stable_missing_reference_pct']>3

def test_aborted_stage_always_visible_in_auto_ledger(tmp_path):
    fname='ROLL_DYNAMIC.json'
    (tmp_path/fname).write_text(json.dumps({'error':'反馈缺口','raw_file_table':'raw_table.csv',
        'raw_file_imu':'raw_imu.csv','analysis':{'valid':False,'reason':'缺失',
            'reference_quality':{'max_feedback_gap_ms':455.0,'stable_coverage_pct':98.5}}},ensure_ascii=False),encoding='utf-8')
    ledger={'state':'stopped_or_failed','error':'ROLL动态分析未通过','stopped_verified':True,
            'last_dynamic_report_file':fname,'completed_dynamic_stages':[],'static_prechecks':[]}
    out=write_run_ledger_html(tmp_path,'AUTO_FULL_RUN.json',ledger)
    html=(tmp_path/out).read_text(encoding='utf-8')
    assert '未完成的动态阶段' in html
    assert 'ROLL_DYNAMIC.json' in html
    assert 'raw_table.csv' in html
    assert '98.5%' in html
