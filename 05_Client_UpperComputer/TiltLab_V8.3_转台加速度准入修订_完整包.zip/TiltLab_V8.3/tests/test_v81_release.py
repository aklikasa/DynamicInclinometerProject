"""V8.2 release regression checks that do not connect to devices."""
from pathlib import Path
import ast
import unittest

ROOT = Path(__file__).resolve().parents[1]

class V82Release(unittest.TestCase):
    def test_version_consistency(self):
        main=(ROOT/'app'/'main.py').read_text(encoding='utf-8')
        appjs=(ROOT/'web'/'app.js').read_text(encoding='utf-8')
        html=(ROOT/'web'/'index.html').read_text(encoding='utf-8')
        assert "version='8.2.0'" in main
        assert "'version':'8.2.0'" in main
        assert "startsWith('8.2.')" in appjs
        assert '/assets/app.js?v=8200' in html
        assert 'V8.2.0' in html

    def test_r10_ambient_does_not_require_plc(self):
        s=(ROOT/'app'/'automatic_factory.py').read_text(encoding='utf-8')
        tree=ast.parse(s)
        fn=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='readiness')
        excerpt=ast.get_source_segment(s,fn)
        assert "('snap7','PLC兼容模块')" not in excerpt
        assert "('PySide6','PySide6界面')" in excerpt
        assert 'stopped_verified' in s  # original motion safety protocol retained
        assert "subprocess.run([sys.executable,str(worker),'--check']" in s
        assert 'python-snap7' not in (ROOT/'requirements-r10.txt').read_text(encoding='utf-8')
        assert 'python-snap7' in (ROOT/'requirements-plc.txt').read_text(encoding='utf-8')

    def test_ui_fixes_still_present(self):
        js=(ROOT/'web'/'app.js').read_text(encoding='utf-8')
        html=(ROOT/'web'/'index.html').read_text(encoding='utf-8')
        assert 'function initGlassSelects(' not in js
        assert 'panel.open=true' not in js
        assert '<select id="serial-port"' in html
        assert '<select id="table-port"' in html

    def test_windows_batch_is_crlf_and_has_targets(self):
        for filename in ('INSTALL_DEPENDENCIES_DEBUG.cmd','START_TILT_LAB.bat','V8.1_只读检查环境.bat','V8.1_R10常温依赖预检.bat'):
            b=(ROOT/filename).read_bytes()
            assert b'\r\n' in b
            assert b'\n' not in b.replace(b'\r\n',b'')
        assert '--mode r10' in (ROOT/'V8.1_只读检查环境.bat').read_text(encoding='utf-8')
        assert '--mode r10' in (ROOT/'V8.1_R10常温依赖预检.bat').read_text(encoding='utf-8')
        bat=(ROOT/'INSTALL_DEPENDENCIES_DEBUG.cmd').read_text(encoding='utf-8')
        assert ':CREATE_VENV' in bat and 'goto CREATE_VENV' in bat
        assert 'install_v81.txt' in bat

    def test_v81_healthcheck_is_hardware_free(self):
        s=(ROOT/'tools'/'v81_healthcheck.py').read_text(encoding='utf-8')
        assert 'subprocess.' not in s  # safe no-worker-exec dependency audit
        assert 'engine.start(' not in s
        assert 'serial.Serial(' not in s
        ast.parse(s)
