"""V7.10 unit/contract tests. Fake VQF only checks our adapter, NOT upstream accuracy."""
import math
from pathlib import Path
import numpy as np
import pytest
from app import vqf_fusion
from app.fusion import Params
from app.auto_dynamic import is_completed_capture_with_invalid_analysis


class FakeOfficialVQF:
    def __init__(self, dt):
        self.dt=dt
        self.updates=[]
        self.pred=[]
        self.tau=None

    def setTauAcc(self, tau):self.tau=tau
    def updateGyr(self,omega):self.pred.append(np.asarray(omega).copy())
    def update(self,omega,gravity):self.updates.append((np.asarray(omega).copy(),np.asarray(gravity).copy()))
    def getQuat6D(self):return np.array([1.,0.,0.,0.])
    def getRestDetected(self):return True
    def getBiasEstimate(self):return np.array([.001,0.,0.]),.0004


def test_vqf_units_normal_updates_gap_prediction_are_distinct(monkeypatch):
    monkeypatch.setattr(vqf_fusion, 'OfficialVQF', FakeOfficialVQF)
    filt=vqf_fusion.VQF6D(Params(vqf_nominal_hz=833,vqf_tau_acc_s=3.))
    r1=filt.update([0,0,1],[10,0,0],1/833)
    r2=filt.update([0,0,1],[10,0,0],.031)
    assert len(filt.core.updates)==2
    assert filt.core.updates[0][0][0] == pytest.approx(10*math.pi/180)
    assert filt.core.updates[0][1][2] == pytest.approx(9.80665)
    assert filt.core.tau==3
    assert filt.core.dt==pytest.approx(1/833)
    assert 20<len(filt.core.pred)<29
    assert r2['model_prediction_only_steps']==len(filt.core.pred)
    assert r2['imu_gaps_over_threshold']==1
    assert r2['timing_warning'] is True
    assert r2['trust_available'] is False
    assert r2['gyro_bias_dps'][0]==pytest.approx(.001*180/math.pi,abs=1e-5)
    assert len(r2['q'])==4


def test_vqf_large_gap_never_silent_full_extrapolation(monkeypatch):
    monkeypatch.setattr(vqf_fusion,'OfficialVQF',FakeOfficialVQF)
    f=vqf_fusion.VQF6D(Params())
    f.update([0,0,1],[2,0,0],.0012)
    out=f.update([0,0,1],[2,0,0],.35)
    assert out['imu_gaps_over_threshold']>0
    assert out['unmodelled_gap_s']>.20
    assert 0<len(f.core.pred)<120
    assert len(f.core.updates)==2 # no fictitious accelerometer update


def test_vqf_measured_lever_is_off_by_default(monkeypatch):
    monkeypatch.setattr(vqf_fusion,'OfficialVQF',FakeOfficialVQF)
    f=vqf_fusion.VQF6D(Params(lever_z_cm=0),lever_compensate=True)
    out=f.update([0,0,1],[5,0,0],.005)
    assert out['lever_compensation_enabled'] is False
    assert f.core.updates[0][1][2] == pytest.approx(9.80665)
    f=vqf_fusion.VQF6D(Params(lever_z_cm=22),lever_compensate=True)
    f.update([0,0,1],[0,0,0],.005)
    out=f.update([0,0,1],[10,0,0],.005)
    assert out['lever_compensation_enabled'] is True
    assert f.core.updates[-1][1][1]!=pytest.approx(0)


def test_analysis_only_status_requires_genuine_verified_stop_and_report():
    data=dict(state='analysis_invalid',stopped_verified=True,report_file='a_DYNAMIC.json')
    assert is_completed_capture_with_invalid_analysis(data)
    for changes in (dict(stopped_verified=False),dict(stopped_verified=None),dict(report_file=None),dict(state='invalid'),dict(state='completed')):
        assert not is_completed_capture_with_invalid_analysis({**data,**changes})


def test_ui_version_and_real_filter_or_explicit_dependency():
    from app.fusion import FILTERS
    from app.main import app
    from fastapi.testclient import TestClient
    with TestClient(app) as client:
        r=client.get('/api/meta');assert r.json()['version'].startswith('8.3.')
    js=(Path(__file__).resolve().parents[1]/'web/app.js').read_text(encoding='utf8')
    assert "startsWith('8.3.')" in js
    assert 'vqf6d' in js and 'vqf_lever' in js and 'gyro_anchor' in js
    if vqf_fusion.VQF_AVAILABLE:
        assert 'vqf6d' in FILTERS and 'vqf_lever' in FILTERS
    else:
        assert 'vqf6d' not in FILTERS


def test_offline_vqf_utility_has_no_turntable_import_or_movement_command():
    p=Path(__file__).resolve().parents[1]/'tools/replay_v79.py'
    text=p.read_text(encoding='utf8')
    assert 'app.turntable' not in text and 'SetAxisSway' not in text
    assert 'no physical table import' in text
