import math
from pathlib import Path
import pytest
from app.dynamic_experiment import limits,DynamicExperiment
from app.auto_dynamic import AutoDynamicWorkflow
from app.turntable import Table2TD600,TableError
from app.main import OneClickArgs,DynamicArgs


def test_custom_sine_is_accepted():
    m=limits(5,0.3,3)
    assert m['duration_s']==10.0
    assert abs(m['peak_speed_dps']-9.4248)<.001
    assert abs(m['peak_accel_dps2']-17.7653)<.001

def test_truly_unsafe_sine_blocked():
    for params in ((30,.1,3),(10,.5,3),(5,1,3),(0,.1,3),(5,.3,1),(5,.001,3)):
        with pytest.raises(ValueError):limits(*params)

def test_x_y_are_explicit_fixture_modes():
    x=AutoDynamicWorkflow(None,None,None,None)
    assert x._check_inputs(2,'roll',1,5,.3,3,2,'x_outer',False)['duration_s']==10.0
    with pytest.raises(ValueError,match='不匹配'):
        x._check_inputs(2,'pitch',1,5,.3,3,2,'x_outer',True)
    with pytest.raises(ValueError,match='运动路径'):
        x._check_inputs(2,'pitch',1,5,.3,3,2,'y_inner_90',False)
    assert x._check_inputs(2,'pitch',1,5,.3,3,2,'y_inner_90',True)['duration_s']==10.0
    with pytest.raises(ValueError,match='外轴2'):
        x._check_inputs(0,'pitch',1,5,.3,3,2,'y_inner_90',True)

def test_dynamic_preflight_rejects_bad_fixture_before_status_read():
    x=DynamicExperiment(None,None,Path('.'))
    with pytest.raises(ValueError,match='Pitch'):
        x.preflight(2,'pitch',1,5,.3,3,'y_inner_90',False)
    with pytest.raises(ValueError,match='外轴2'):
        x.preflight(0,'pitch',1,5,.3,3,'y_inner_90',True)

def test_dll_sway_guard_matches_high_level_guard():
    # no physical DLL is called; tests check the same envelope numerically
    for amp,freq in ((5,.3),(2,.05),(10,.2)):
        m=limits(amp,freq,3)
        assert 2*math.pi*amp*freq<=20 and (2*math.pi*freq)**2*amp<=40
    with pytest.raises(ValueError):limits(5,.5,3)

def test_request_fields_allow_y_without_mapping_assumptions():
    args=OneClickArgs(axis=2,output='pitch',mounting_mode='y_inner_90',fixture_confirmed=True)
    assert args.fixture_confirmed and args.output=='pitch'
    args2=DynamicArgs(axis=2,output='pitch',mounting_mode='y_inner_90',fixture_confirmed=True)
    assert args2.mounting_mode=='y_inner_90'

def test_ui_includes_fixture_gate_and_error_curve():
    root=Path(__file__).resolve().parents[1]
    html=(root/'web/index.html').read_text()
    js=(root/'web/app.js').read_text()
    assert 'dyn-fixture-verified' in html and 'dyn-test-mode' in html
    assert 'dyn-error-chart' in js and '误差曲线' in js
    assert 'fixtureReady()' in js and "startsWith('8.3.')" in js
