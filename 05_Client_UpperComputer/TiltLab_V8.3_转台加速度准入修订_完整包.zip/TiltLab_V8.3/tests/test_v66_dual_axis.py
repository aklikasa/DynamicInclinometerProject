"""No live motion: strict tests of user-confirmed U-T geometry and sequencing."""
import json,time,threading,math
from pathlib import Path
import pytest
from app.auto_dynamic import AutoDynamicWorkflow
from app.dynamic_experiment import _ok_axes,DynamicExperiment
from app.table_prepare import TablePreparation
from app.turntable import Table2TD600,TableError
from app.main import OneClickArgs


def flags(angle, enabled=True):
    return dict(position_deg=angle,speed_dps=0.0,mode=2,enabled=enabled,zeroed=True,
                healthy=True,upper_limit=False,lower_limit=False,driver_fault=False,
                over_speed=False,in_place=True)


def status(inner=0,outer=0):
    return {'connected':True,'axes':{'0':flags(inner),'2':flags(outer)}}


def test_inner90_pitch_preflight_and_roll_stance():
    assert _ok_axes(status(0,0),2,inner_target_deg=0)
    assert _ok_axes(status(90,0),2,inner_target_deg=90)
    assert _ok_axes(status(450,360),2,inner_target_deg=90)
    with pytest.raises(ValueError,match='90'):_ok_axes(status(0,0),2,inner_target_deg=90)
    with pytest.raises(ValueError,match='0'):_ok_axes(status(90,0),2,inner_target_deg=0)
    with pytest.raises(ValueError):_ok_axes(status(90,1),2,inner_target_deg=90)


def test_contained_vendor_inner_position_only_0_or_90(monkeypatch):
    device=Table2TD600();device.connected=True
    st=status(0,0)
    monkeypatch.setattr(device,'read_status',lambda:st)
    cmds=[]
    monkeypatch.setattr(device,'_call',lambda name,types,ret,*args:(cmds.append((name,args)),1)[1])
    device.move_inner_test_orientation(90,2)
    assert cmds[-1][0]=='SetAxisPosition' and cmds[-1][1][0]==0 and cmds[-1][1][1]==90
    with pytest.raises(TableError):device.move_inner_test_orientation(80,2)
    st['axes']['2']['position_deg']=1.0
    with pytest.raises(TableError,match='外轴'):device.move_inner_test_orientation(90,2)
    assert len(cmds)==1


def test_three_modes_validate_before_touching_hardware():
    a=AutoDynamicWorkflow(None,None,None,None)
    for mode,output,ack in [('x_outer','roll',False),('y_inner_90','pitch',True),('xy_sequential','both',True)]:
        assert a._check_inputs(2,output,1,5,.3,3,2,mode,ack)['duration_s']==10
    with pytest.raises(ValueError):a._check_inputs(2,'both',1,5,.3,3,2,'xy_sequential',False)
    with pytest.raises(ValueError):a._check_inputs(0,'both',1,5,.3,3,2,'xy_sequential',True)
    with pytest.raises(ValueError):a._check_inputs(2,'pitch',1,5,.3,3,2,'x_outer',True)
    assert OneClickArgs(output='both',mounting_mode='xy_sequential',fixture_confirmed=True).pitch_sign==1


class FakeTable:
    def __init__(self):
        self.connected=True;self.a={0:flags(0,False),2:flags(0,False)};self.cmds=[]
    def read_status(self):
        return {'connected':True,'axes':{str(i):dict(x) for i,x in self.a.items()}}
    def enable_axis(self,a):self.cmds.append(('enable',a));self.a[a]['enabled']=True
    def find_zero(self,a,*args):self.cmds.append(('find_zero',a));self.a[a]['zeroed']=True
    def move(self,a,p,s):
        assert a==2 or p==0
        self.cmds.append(('move',a,p,s));self.a[a]['position_deg']=p
    def move_inner_test_orientation(self,p,s):
        assert abs(self.a[2]['position_deg'])<.1
        self.cmds.append(('inner_stage',p,s));self.a[0]['position_deg']=p
    def stop(self):self.cmds.append(('stop',))
    def stopped_verified(self,timeout=8):return True


class FakeEngine:
    def __init__(self):
        self.running=True;self.connected=True;self.source='serial';self.latest={'cal':{'roll':0}}
        self.cal_status='matched';self.cal={'files':[]};self.cal_mode='ambient'
        self.uid='TEST-001';self.last_wall=time.time();self.stability=None;self.record_fp=None


class FakeDynamic:
    def __init__(self,dir,table):
        self.dir=dir;self.table=table;self.running=False;self.state='idle';self.error='';self.report_file=None
        self.table_file=None;self.imu_file=None;self.commands=[];self.last_plan=None
    def preflight(self,axis,output,sign,amp,freq,cycles,mounting_mode='x_outer',fixture_confirmed=False):
        target=0 if output=='roll' else 90
        assert _ok_axes(self.table.read_status(),axis,inner_target_deg=target)
        self.last_plan=(output,target)
        self.commands.append(('preflight',output,target,sign))
        return {'token':'yes'}
    def start(self,token,ack):
        assert token=='yes' and ack
        output,target=self.last_plan
        self.commands.append(('start',output,target))
        self.table.cmds.append(('sway_stage',output,target))
        self.running=True;self.state='swaying'
        def done():
            time.sleep(.06)
            self.report_file=f'{output}_DYNAMIC.json'
            self.table_file=f'{output}_table.csv'
            self.imu_file=f'{output}_imu.csv'
            (self.dir/self.report_file).write_text(json.dumps({'kind':'REAL_2TD600_SINE_DIAGNOSTIC','state':'completed','plan':{'output':output,'inner_target_deg':target},'analysis':{'valid':True,'chart':[],'comparison':[]}}),encoding='utf-8')
            self.state='completed';self.running=False
        threading.Thread(target=done,daemon=True).start()
    def heartbeat(self):pass
    def abort(self):self.state='invalid';self.running=False
    def status(self):
        return dict(running=self.running,state=self.state,error=self.error,report_file=self.report_file,
                    table_file=self.table_file,imu_file=self.imu_file,stopped_verified=True)


def _complete(auto,engine,timeout=8):
    end=time.monotonic()+timeout
    while auto.running and time.monotonic()<end:
        engine.last_wall=time.time()
        auto.heartbeat()
        time.sleep(.035)
    assert not auto.running,'fake timed out'


def test_joint_test_executes_roll_then_inner90_pitch_then_zeros(tmp_path):
    t=FakeTable();e=FakeEngine();d=FakeDynamic(tmp_path,t);p=TablePreparation(t)
    a=AutoDynamicWorkflow(t,e,p,d)
    a.start(2,'both',1,2,.05,3,2,True,'xy_sequential',True,pitch_sign=-1)
    _complete(a,e)
    assert a.state=='completed',a.error
    assert [(x['output'],x['inner_target_deg']) for x in a.stages]==[('roll',0),('pitch',90)]
    assert d.commands==[('preflight','roll',0,1),('start','roll',0),('preflight','pitch',90,-1),('start','pitch',90)]
    cmds=t.cmds
    assert ('inner_stage',90,2) in cmds and ('inner_stage',0,2) in cmds
    assert cmds.index(('inner_stage',90,2))>cmds.index(('sway_stage','roll',0))
    assert cmds.index(('inner_stage',0,2))>cmds.index(('sway_stage','pitch',90))
    assert t.a[0]['position_deg']==0 and t.a[2]['position_deg']==0
    report=json.loads((tmp_path/a.report_file).read_text(encoding='utf-8'))
    assert report['kind']=='REAL_2TD600_XY_SEQUENTIAL'
    assert [x['direction'] for x in report['tests']]==['roll','pitch']
    assert report['certified_dynamic_accuracy'] is False


def test_inner_motion_never_issued_without_outer_at_zero(tmp_path):
    t=FakeTable();t.a[0]['enabled']=True;t.a[2]['enabled']=True;t.a[2]['position_deg']=2.0
    e=FakeEngine();d=FakeDynamic(tmp_path,t);prep=TablePreparation(t);a=AutoDynamicWorkflow(t,e,prep,d)
    a.plan={'zero_speed_dps':2.0};a.heartbeat_ns=time.monotonic_ns()
    with pytest.raises(RuntimeError,match='外轴未回0°'):a._position(0,90)
    assert not any(x[0]=='inner_stage' for x in t.cmds)


def test_frontend_offers_three_real_modes():
    root=Path(__file__).resolve().parents[1]
    html=(root/'web/index.html').read_text(encoding='utf-8')
    js=(root/'web/app.js').read_text(encoding='utf-8')
    for mode in ('x_outer','y_inner_90','xy_sequential'):assert f'value="{mode}"' in html
    assert 'dyn-dual-report-nav' in html and 'showAutoReport' in js
    assert "startsWith('8.2.')" in js
