"""Full 7.0 workflow tests use fake devices only. Never actuate real hardware."""
import json,time
from pathlib import Path
import pytest
from app.auto_dynamic import AutoDynamicWorkflow
from app.table_prepare import TablePreparation
from tests.test_v66_dual_axis import FakeTable,FakeEngine,FakeDynamic,_complete


def _fake_static(job, folder, fail=False):
    calls=[]
    def execute(output,inner,sign,speed,limit,watcher,progress,span_deg=5.):
        watcher()
        assert inner==(0 if output=='roll' else 90)
        assert job.table.a[2]['position_deg']==0
        assert speed<=3
        assert span_deg==5
        calls.append((output,inner))
        for i,point in enumerate([-5,-3,-1,0,1,3,5,3,1,0,-1,-3,-5,0],1):
            progress(i,14,point)
        filename=f'{output}_STATIC_PRECHECK.json'
        passed=not fail
        report={'kind':'REAL_STATIC_BEFORE_DYNAMIC',
                'analysis':{'valid':True,'chosen_algorithm':'madgwick',
                            'pass_for_chosen_algorithm':passed,
                            'reason':('静态通过' if passed else '静态最大误差超出研发阈值'),
                            'algorithm_metrics':{'cal_madgwick':{'static_rmse_deg':.035,
                                  'static_max_abs_deg':.055 if passed else .5}}}}
        (folder/filename).write_text(json.dumps(report,ensure_ascii=False),encoding='utf-8')
        return filename,report
    job.static_precheck.run=execute
    return calls


def test_one_click_xy_performs_static_then_dynamic_and_writes_ledger(tmp_path):
    t=FakeTable();e=FakeEngine();e.pipeline_mode='realtime';d=FakeDynamic(tmp_path,t);p=TablePreparation(t)
    a=AutoDynamicWorkflow(t,e,p,d)
    calls=_fake_static(a,tmp_path)
    a.start(2,'both',1,5,.3,10,2,True,'xy_sequential',True,
            static_before_dynamic=True,static_limit_deg=.1,static_stop_on_fail=True)
    _complete(a,e)
    assert a.state=='completed',a.error
    assert calls==[('roll',0),('pitch',90)]
    assert len(a.static_reports)==2
    assert [x[1] for x in d.commands if x[0]=='start']==['roll','pitch']
    assert t.cmds.index(('inner_stage',90,2))>t.cmds.index(('sway_stage','roll',0))
    assert t.cmds.index(('inner_stage',0,2))>t.cmds.index(('sway_stage','pitch',90))
    assert a.run_manifest_file
    ledger=json.loads((tmp_path/a.run_manifest_file).read_text(encoding='utf-8'))
    assert ledger['all_requested_stages_completed'] and ledger['stopped_verified'] is True
    assert len(ledger['static_prechecks'])==2 and len(ledger['completed_dynamic_stages'])==2
    assert ledger['certified_dynamic_accuracy'] is False
    report=json.loads((tmp_path/a.report_file).read_text(encoding='utf-8'))
    assert len(report['static_prechecks'])==2 and len(report['tests'])==2


def test_static_failure_creates_ledger_and_never_commands_sway(tmp_path):
    t=FakeTable();e=FakeEngine();e.pipeline_mode='realtime';d=FakeDynamic(tmp_path,t);p=TablePreparation(t)
    a=AutoDynamicWorkflow(t,e,p,d)
    calls=_fake_static(a,tmp_path,fail=True)
    a.start(2,'both',1,5,.3,10,2,True,'xy_sequential',True,
            static_before_dynamic=True,static_limit_deg=.1,static_stop_on_fail=True)
    _complete(a,e)
    assert a.state=='stopped_or_failed'
    assert calls==[('roll',0)]
    assert not any(x[0]=='sway_stage' for x in t.cmds)
    assert a.run_manifest_file
    report=json.loads((tmp_path/a.run_manifest_file).read_text(encoding='utf-8'))
    assert report['all_requested_stages_completed'] is False
    assert report['static_report_files']==['roll_STATIC_PRECHECK.json']
    assert not report['completed_dynamic_stages']
    assert '静态' in report['error']


def test_one_click_ui_is_first_and_all_angles_automatic():
    root=Path(__file__).resolve().parents[1]
    html=(root/'web/index.html').read_text(encoding='utf-8')
    js=(root/'web/app.js').read_text(encoding='utf-8')
    assert html.index('id="dynamic-test"')<html.index('id="static-axis-test"')
    assert '<option value="xy_sequential" selected>' in html
    assert 'id="auto-static-before" type="checkbox"/' in html
    assert 'id="auto-static-stop" type="checkbox" checked' in html
    assert 'id="auto-flow-steps"' in html and 'id="auto-manifest-container"' in html
    assert 'ensureAutoConnections()' in js and 'static_before_dynamic' in js
    assert 'auto-start' in js and '/api/auto-dynamic/start' in js
    assert "startsWith('8.2.')" in js
    assert 'fixtureReady()' in js


def test_no_automatic_servo_disable_or_emergency_override():
    root=Path(__file__).resolve().parents[1]
    code=(root/'app/auto_dynamic.py').read_text(encoding='utf-8')
    assert 'disable_axis(' not in code
    assert 'self.table.stopped_verified(timeout=20)' in code
    assert 'static_stop_on_fail' in code
    assert 'self._position(2,0)' in code
