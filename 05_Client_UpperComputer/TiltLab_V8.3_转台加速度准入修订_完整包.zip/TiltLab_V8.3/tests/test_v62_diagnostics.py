"""Regression tests for field diagnostics. No motion, COM port or real DLL used."""
import json
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from app.table_diagnostics import TableDiagnostics,DIAG
from app.table_prepare import TablePreparation
from app.turntable import Table2TD600,TableError
from app.main import app

def test_jsonl_diagnostic_file(tmp_path):
    d=TableDiagnostics(tmp_path)
    d.record('command','SetAxisEnable returned 1',axis=0)
    d.snapshot('status',{'connected':True,'axes':{'0':{'position_deg':0,'speed_dps':0,'enabled':False,'zeroed':False,'healthy':False}}})
    info=d.recent()
    assert len(info['events'])==2
    assert info['events'][-1]['details']['axes']['0']['enabled'] is False
    logfile=tmp_path/info['log_file']
    assert logfile.is_file()
    rows=[json.loads(x) for x in logfile.read_text(encoding='utf-8').splitlines()]
    assert rows[0]['stage']=='command' and rows[1]['stage']=='status'

def test_ready_failure_identifies_individual_flags():
    r=TablePreparation._readiness_reasons({'position_deg':0,'speed_dps':0,'mode':2,'enabled':False,'zeroed':False,'healthy':False})
    assert '使能位=0' in r and '找零位=0' in r and '正常状态位=0' in r
    r=TablePreparation._readiness_reasons({'position_deg':360,'speed_dps':0,'mode':2,'enabled':True,'zeroed':True,'healthy':True})
    assert r==[]

def test_vendor_invalid_feedback_not_treated_as_true():
    t=Table2TD600();t.connected=True;t.port=7
    t._int=lambda name,axis: (-1 if name=='GetAxisEnable' else 0)
    t._float=lambda name,axis: 0.0
    with pytest.raises(TableError,match='异常值'):
        t.read_status()

def test_no_motion_diagnostic_endpoint():
    DIAG.record('test','单元测试诊断记录')
    with TestClient(app) as client:
        r=client.get('/api/turntable/diagnostics?limit=3')
        assert r.status_code==200 and r.json()['events'][-1]['stage']=='test'
        r=client.get('/api/turntable/diagnostics/download')
        assert r.status_code==200 and '单元测试诊断记录' in r.text

def test_frontend_checks_correct_version():
    web=Path(__file__).resolve().parents[1]/'web'
    code=(web/'app.js').read_text(encoding='utf-8')
    assert "startsWith('8.1.')" in code
    assert "startsWith('6.0')" not in code
    html=(web/'index.html').read_text(encoding='utf-8')
    assert 'tt-diag-list' in html and 'V7.16' in html


def test_disconnected_automatic_start_records_diagnostic():
    from app.main import AUTO_TEST
    assert AUTO_TEST.running is False
    with TestClient(app) as client:
        result=client.post('/api/auto-dynamic/start',json={'axis':2,'output':'roll','sign':1,'amplitude_deg':0.5,'frequency_hz':0.02,'cycles':3,'zero_speed_dps':2.0,'acknowledged':True})
        assert result.status_code==400
        events=client.get('/api/turntable/diagnostics?limit=10').json()['events']
        assert any(x['stage']=='auto_preconditions_failed' for x in events)
