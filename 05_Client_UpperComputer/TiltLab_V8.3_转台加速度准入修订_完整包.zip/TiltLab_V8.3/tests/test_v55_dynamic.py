"""Guarded real-motion workflow tests; fake turntable NEVER touches real hardware."""
import csv,json,math,threading,time
from pathlib import Path
from dataclasses import dataclass
import numpy as np
import pytest
from app.dynamic_experiment import DynamicExperiment,limits,_ok_axes,analyze_tracking,ALGORITHMS
from app.fusion import Params

class FakeTable:
    def __init__(self):
        self.connected=True;self.mode=2;self.pos=0.;self.speed=0.;self.motion=[]
        self.engine=None
    def read_status(self):
        if self.engine:self.engine.last_wall=time.time()  # emulate continuing IMU updates
        def axis(a):
            return {'position_deg':self.pos if a==2 else 0.,'speed_dps':self.speed if a==2 else 0.,
             'mode':self.mode if a==2 else 2,'enabled':True,'zeroed':True,'healthy':True,
             'in_place':self.mode!=5,'upper_limit':False,'lower_limit':False,
             'driver_fault':False,'over_speed':False}
        return {'connected':True,'axes':{'0':axis(0),'2':axis(2)}}
    def sway(self,axis,a,f):
        self.motion.append(('sway',axis,a,f));self.mode=5
    def stop(self):
        self.motion.append(('stop',));self.mode=2;self.speed=0
    def stopped_verified(self,timeout=8):return self.mode==2

class FakeEngine:
    def __init__(self):
        self.lock=threading.RLock();self.running=True;self.connected=True;self.source='serial';self.cal_status='matched';self.cal_mode='ambient'
        self.uid='DTS872028';self.latest={'cal':{'roll':0,'pitch':0}};self.last_wall=time.time();self.stability=None
        self.params=Params();self.cal={'files':['ACC.json','GYRO.json']};self.active='adaptive';self.counter=0;self.recent=[]

def test_guard_bounds():
    assert limits(2,.05,3)['duration_s']==60
    for values in [(21,.05,3),(2,.9,3),(2,.05,0),(5,.5,9)]:
        with pytest.raises(ValueError):limits(*values)

def test_preflight_no_motion_and_nonce(tmp_path):
    t=FakeTable();e=FakeEngine();t.engine=e
    x=DynamicExperiment(t,e,tmp_path)
    first=x.preflight(2,'roll',1,2.,.05,3)
    assert first['ready'] and first['token']
    assert t.motion==[]
    with pytest.raises(ValueError,match='现场'):
        x.start(first['token'],False)
    with pytest.raises(ValueError,match='安全预检查'):
        x.start('invalid-token',True)
    t.pos=.7
    with pytest.raises(ValueError):x.preflight(2,'roll',1,2.,.05,3)

def test_sway_stop_and_invalid_report_without_imu(tmp_path):
    t=FakeTable();e=FakeEngine();t.engine=e
    x=DynamicExperiment(t,e,tmp_path)
    first=x.preflight(2,'roll',1,.5,.05,3)
    # Shorten duration ONLY in fake-hardware test, never runtime hardware limits.
    x.plan['duration_s']=.3
    status=x.start(first['token'],True)
    assert status['running']
    x.thread.join(5)
    assert not x.running
    assert [r[0] for r in t.motion].count('sway')==1
    assert t.motion[-1][0]=='stop'
    assert x.stopped_verified is True
    report=json.loads((tmp_path/x.report_file).read_text(encoding='utf-8'))
    assert report['state']=='invalid'  # never call a data-free run validated
    assert report['certified_dynamic_accuracy'] is False
    assert report['motion_commands_sent']
    assert (tmp_path/x.table_file).exists() and (tmp_path/x.imu_file).exists()

def test_synthetic_analysis_is_diagnostic_not_certified():
    # Construct two clocks already aligned for a non-hardware numerical test.
    f=.05;am=2.;base=10.;start=12.;end=72.
    tr=[];ir=[]
    for t in np.arange(base,73,.10):
        v=am*math.sin(2*math.pi*f*(t-start)) if t>=start else 0.
        tr.append({'pc_mid_ns':int(t*1e9),'axis_0_pos':v})
    for i,t in enumerate(np.arange(base,73,.02)):
        v=am*math.sin(2*math.pi*f*(t-start)) if t>=start else 0.
        row={'host_est_ns':int(t*1e9)}
        for ch in ('raw','cal'):
            for algo in ALGORITHMS:row[f'{ch}_{algo}_roll']=v
        ir.append(row)
    result=analyze_tracking(tr,ir,0,'roll',1,am,f,int(start*1e9),int(end*1e9))
    assert result['valid']
    assert result['certified_dynamic_accuracy'] is False
    assert result['comparison'][0]['relative_tracking_rmse_deg']<0.01
    assert abs(result['comparison'][0]['amplitude_ratio']-1)<.01
    assert result['chart']

def test_incomplete_reference_is_rejected():
    assert not analyze_tracking([],[],0,'roll',1,2,.05,0,0)['valid']

def test_dynamic_api_does_not_start_without_hardware():
    from fastapi.testclient import TestClient
    from app.main import app
    with TestClient(app) as client:
        r=client.post('/api/dynamic/preflight',json={'axis':2,'output':'roll','sign':1,'amplitude_deg':2,'frequency_hz':.05,'cycles':3})
        assert r.status_code==400
        s=client.get('/api/dynamic/status').json()
        assert s['running'] is False
        assert '时间戳' in s['timing_warning']

def test_watchdog_heartbeat_and_other_axis_fail_closed(tmp_path):
    t=FakeTable();e=FakeEngine();t.engine=e
    x=DynamicExperiment(t,e,tmp_path)
    x.heartbeat_ns=time.monotonic_ns()-7_000_000_000
    with pytest.raises(RuntimeError,match='心跳'):
        x._watch(e.uid,__import__('dataclasses').asdict(e.params),2,0)
    x.heartbeat_ns=time.monotonic_ns()
    t.pos=4.5
    with pytest.raises(RuntimeError,match='运动轴'):
        x._watch(e.uid,__import__('dataclasses').asdict(e.params),2,0)

def test_token_expired(tmp_path):
    t=FakeTable();e=FakeEngine();t.engine=e
    x=DynamicExperiment(t,e,tmp_path)
    p=x.preflight(2,'roll',1,2,.05,3)
    x.token_until=time.monotonic()-1
    with pytest.raises(ValueError,match='过期'):
        x.start(p['token'],True)
    assert t.motion==[]
