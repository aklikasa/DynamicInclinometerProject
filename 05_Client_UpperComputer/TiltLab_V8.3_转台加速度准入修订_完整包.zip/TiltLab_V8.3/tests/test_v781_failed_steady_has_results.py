"""Regression: failed steady-state gate must still return genuine diagnostic curves.

The preview is not a qualified accuracy evaluation and cannot enable more motion.
"""
import math
import numpy as np
from app.dynamic_experiment import analyze_tracking
from app.html_report import _TEMPLATE


def make_rows(cycles=3, freq=.3, amp=5.0, with_gap=False):
    motion_start_ns=int(100.0*1e9)
    motion_end_ns=int((100.0+cycles/freq)*1e9)
    ts=np.arange(97.8,100.0+cycles/freq+.2,.1)
    if with_gap:
        ts=ts[(ts<104.1)|(ts>104.7)]
    def turn(t):
        if t<100:return 0.
        wave=math.sin(2*math.pi*freq*(t-100))
        # For three cycles controller ramp never reaches two full qualifying cycles.
        envelope=min(1.,max(0.,(t-100)/(4/freq)))
        return amp*envelope*wave
    table=[{'pc_mid_ns':int(t*1e9),'axis_2_pos':turn(t)} for t in ts]
    imut=np.arange(97.85,100.0+cycles/freq,.02)
    imu=[]
    for i,t in enumerate(imut):
        angle=turn(t)
        row={'host_est_ns':int(t*1e9),'pc_observed_ns':int(t*1e9),
             'device_t_s':t-90.,'imu_nominal_odr_hz':208,'alignment_active':0,
             'cal_gyro_roll':angle,'cal_accel_roll':angle*1.08,
             'cal_adaptive_roll':angle*1.06,'cal_gyro_anchor_roll':angle}
        imu.append(row)
    return table,imu,motion_start_ns,motion_end_ns


def test_insufficient_stable_cycles_still_have_real_preview():
    table,imu,a,b=make_rows()
    result=analyze_tracking(table,imu,2,'roll',1,5.,.3,a,b)
    assert result['valid'] is False
    assert result['diagnostic_preview_only'] is True
    assert len(result['chart'])>100
    assert len(result['chart'][0]['angles'])>0
    assert result['comparison']==[]
    assert result['certified_dynamic_accuracy'] is False
    assert '未识别' in result['reason']
    assert 'gyro_anchor' in ' '.join(result['preview_algorithm_keys'])


def test_gap_does_not_get_cross_interpolated_in_preview():
    table,imu,a,b=make_rows(with_gap=True)
    result=analyze_tracking(table,imu,2,'roll',1,5.,.3,a,b)
    assert result['diagnostic_preview_only'] is True
    assert result['reference_gaps_masked'] is True
    assert result['preview_reference_samples_excluded']>0
    assert any(x.get('missing_reference') for x in result['chart'])
    assert result['comparison']==[]


def test_html_has_chart_fallback_for_invalid_steady():
    assert 'previewKeys' in _TEMPLATE
    assert 'diagnostic_preview_only' in _TEMPLATE
