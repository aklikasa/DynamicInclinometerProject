"""Offline tests: no actual DLL call, no physical turntable motion."""
from copy import deepcopy
from types import SimpleNamespace
import pytest
from app.table_connection_lifecycle import TableConnectionLifecycle
from app import table_connection_lifecycle


def fixture(monkeypatch, initial=(False,False),moving=False):
    events=[]
    flags={0:bool(initial[0]),2:bool(initial[1])}
    speeds={0:0.,2:(.2 if moving else 0.)}
    positions={0:0.,2:0.}
    faults={0:False,2:False}
    table=SimpleNamespace(connected=False)
    def status():
        return {'connected':table.connected,'axes':{str(a):{
            'enabled':flags[a], 'healthy':flags[a], 'zeroed':True,
            'mode':2, 'position_deg':positions[a], 'speed_dps':speeds[a],
            'driver_fault':faults[a], 'upper_limit':False,
            'lower_limit':False, 'over_speed':False} for a in (0,2)}}
    def connect(p,b):
        events.append(('connect',p,b));table.connected=True
    def enable(a):
        events.append(('enable',a));flags[a]=True
    def stop():
        events.append(('stop',));speeds[0]=speeds[2]=0.
    def stopped_verified(timeout=20):
        events.append(('verify',timeout));return table.stop_success
    def disable(a):
        if table.disable_failure_axis==a:raise RuntimeError('断使能反馈未确认')
        events.append(('disable',a));flags[a]=False
    def close():
        events.append(('close',));table.connected=False
    table.connect=connect;table.read_status=status;table.enable_axis=enable
    table.stop=stop;table.stopped_verified=stopped_verified
    table.disable_axis=disable;table.disconnect=close
    table.stop_success=True
    manager=SimpleNamespace(in_progress=False)
    manager._sample_stop=lambda axis,seconds: {'axes':deepcopy(status()['axes'])}
    def disable_checked(axis):
        if table.disable_failure_axis==axis:raise RuntimeError('断使能反馈未确认')
        if flags[axis]:disable(axis);return {'axis':axis,'confirmed_disabled':True,'command_sent':True}
        return {'axis':axis,'confirmed_disabled':True,'command_sent':False}
    table.disable_failure_axis=None
    manager._disable_checked=disable_checked
    busy={'value':False}
    lifecycle=TableConnectionLifecycle(table,manager,lambda:busy['value'])
    monkeypatch.setattr(table_connection_lifecycle.time,'sleep',lambda _:None)
    return lifecycle,table,flags,events,busy,faults,speeds


def test_connection_automatically_enables_both_axes_in_r10_order(monkeypatch):
    lc,t,flags,e,*_=fixture(monkeypatch)
    r=lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    assert r['auto_enabled_confirmed'] is True
    assert e[:3]==[('connect',4,115200),('enable',0),('enable',2)]
    assert flags=={0:True,2:True}
    assert ('stop',) not in e and ('close',) not in e


def test_connection_skips_already_enabled_axis(monkeypatch):
    lc,_,flags,e,*_=fixture(monkeypatch,initial=(True,False))
    lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    assert ('enable',0) not in e and ('enable',2) in e


def test_no_connect_without_one_time_load_safety_ack(monkeypatch):
    lc,t,_,e,*_=fixture(monkeypatch)
    with pytest.raises(RuntimeError,match='机械支撑'):
        lc.connect(4,115200,operator_confirmed=True,load_secured=False)
    assert not t.connected and not e


def test_disconnect_stop_verify_disable_close_in_order(monkeypatch):
    lc,t,flags,e,*_=fixture(monkeypatch)
    lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    r=lc.disconnect()
    assert not t.connected and r['disabled_verified']
    assert e.index(('stop',))<e.index(('verify',20))<e.index(('disable',0))<e.index(('disable',2))<e.index(('close',))
    assert flags=={0:False,2:False}


def test_disconnect_denies_failed_physical_stop_and_preserves_holding(monkeypatch):
    lc,t,flags,e,*_=fixture(monkeypatch)
    lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    t.stop_success=False
    with pytest.raises(RuntimeError,match='物理停车确认'):
        lc.disconnect()
    assert t.connected and flags=={0:True,2:True} and ('close',) not in e
    assert not any(x[0]=='disable' for x in e)


def test_disconnect_denies_if_other_task_busy(monkeypatch):
    lc,t,flags,e,busy,*_=fixture(monkeypatch)
    lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    busy['value']=True
    with pytest.raises(RuntimeError,match='任务'):
        lc.disconnect()
    assert t.connected and ('stop',) not in e and ('close',) not in e


def test_disconnect_failure_does_not_close_on_partial_disable(monkeypatch):
    lc,t,flags,e,*_=fixture(monkeypatch)
    lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    t.disable_failure_axis=2
    with pytest.raises(RuntimeError,match='断使能反馈未确认'):
        lc.disconnect()
    assert t.connected and ('close',) not in e


def test_disconnect_without_enabled_axes_only_verifies_and_closes(monkeypatch):
    lc,t,flags,e,*_=fixture(monkeypatch)
    lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    flags.update({0:False,2:False})
    lc.disconnect()
    assert ('stop',) not in e and ('close',) in e


def test_connect_failure_leaves_open_com_and_authorization(monkeypatch):
    lc,t,flags,e,busy,faults,*_=fixture(monkeypatch)
    original=t.enable_axis
    def break_second(axis):
        if axis==2:raise RuntimeError('模拟轴2使能失败')
        original(axis)
    t.enable_axis=break_second
    with pytest.raises(RuntimeError,match='通信保留'):
        lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    assert t.connected and lc.consent_to_servo_off and flags[0]
    assert ('close',) not in e
    lc.disconnect()
    assert not t.connected


def test_no_silent_reconnect(monkeypatch):
    lc,t,flags,e,*_=fixture(monkeypatch)
    lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    with pytest.raises(RuntimeError,match='已经连接'):
        lc.connect(5,115200,operator_confirmed=True,load_secured=True)
    assert len([x for x in e if x[0]=='connect'])==1


def test_fault_prevents_connect_enable(monkeypatch):
    lc,t,flags,e,busy,faults,*_=fixture(monkeypatch)
    faults[2]=True
    with pytest.raises(RuntimeError,match='限位'):
        lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    assert not [x for x in e if x[0]=='enable']
    assert t.connected


def test_ui_uses_only_open_close_and_backend_auto_lifecycle():
    from pathlib import Path
    from app.main import app
    root=Path(__file__).resolve().parents[1]
    html=(root/'web/index.html').read_text(encoding='utf-8')
    js=(root/'web/app.js').read_text(encoding='utf-8')
    assert 'id="table-lifecycle-ack"' in html
    assert 'id="v58-connect-table"' in html
    assert 'id="v58-close-table"' in html
    # V7.6: icon-only power actions keep the exact same lifecycle route IDs,
    # but use accessible labels and different on/off SVG artwork.
    assert 'id="v58-connect-table" aria-label="打开转台并自动使能双轴"' in html
    assert 'id="v58-close-table" disabled aria-label="停车并关闭转台、断开双轴使能"' in html
    assert 'class="tt-power-switch"' in html
    assert '<details class="v60-advanced" hidden aria-hidden="true">' in html
    assert '<article class="panel glass table-connect-panel" hidden aria-hidden="true">' in html
    assert "$('v58-close-table').addEventListener('click'" in js
    assert 'async function closeTableSimple()' in js
    assert 'ensureAutoConnections(true)' in js
    routes={route.path for route in app.routes}
    assert '/api/turntable/disconnect' in routes and '/api/turntable/connect' in routes


def test_dual_disable_commands_are_adjacent_without_roundtrips(monkeypatch):
    lc,t,flags,events,*_=fixture(monkeypatch)
    lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    lc.disconnect()
    disable_indices=[i for i,e in enumerate(events) if e[0]=='disable']
    assert len(disable_indices)==2
    assert disable_indices[1]==disable_indices[0]+1

def test_in_progress_is_reset_after_both_lifecycle_actions(monkeypatch):
    lc,_,_,_,*_=fixture(monkeypatch)
    assert lc.in_progress is False
    lc.connect(4,115200,operator_confirmed=True,load_secured=True)
    assert lc.in_progress is False
    lc.disconnect()
    assert lc.in_progress is False
