"""V6.9 regression: static angle accuracy is a separate absolute metric;
servo disable only after independent stationary proof + operator acknowledgement.
All tests use fake hardware. No real DLL call or motion.
"""
import math, time, json
from pathlib import Path
from types import SimpleNamespace
import pytest
from app.static_accuracy import summarize_static,STATIC_STEPS
from app.disable_supervisor import DisableSupervisor
from app.auto_dynamic import AutoDynamicWorkflow
from app.main import OneClickArgs


def synthetic_static_rows(bias=.018,gain=1.009,reverse_shift=.01):
    rows=[]
    for i,angle in enumerate(STATIC_STEPS):
        travel='out' if i<=6 else 'back'
        measured=bias+gain*angle+(reverse_shift if travel=='back' else 0)
        rows.append({'target_deg':angle,'travel':travel,
          'actual_outer_deg':angle,'angles':{'cal':{'complementary':{'roll':measured,'pitch':angle*.008},
                                                         'accel':{'roll':measured+.01,'pitch':angle*.009}},
                                               'raw':{'complementary':{'roll':angle*.6,'pitch':angle*.8}}}})
    return rows


def test_static_absolute_metrics_are_not_auto_zeroed_or_scaled():
    data=summarize_static(synthetic_static_rows(),'roll',1,.10,'complementary')
    assert data['valid'] and data['pass_for_chosen_algorithm']
    m=data['algorithm_metrics']['cal_complementary']
    assert m['samples']==len(STATIC_STEPS)==14
    assert abs(m['observed_gain']-1.009)<.005
    assert .005<m['static_zero_bias_deg']<.04
    assert m['static_max_abs_deg']>=.018 # bias retained
    assert .008<m['hysteresis_max_deg']<.012
    assert .006<m['cross_axis_slope']<.01
    assert data['note'].startswith('原始静态绝对误差')


def test_static_can_block_dynamic_without_changing_algorithm():
    data=summarize_static(synthetic_static_rows(bias=.2),'roll',1,.10,'complementary')
    assert not data['pass_for_chosen_algorithm']
    assert data['chosen_static_max_abs_deg']>.10


def test_static_sign_reversal_is_not_silently_corrected():
    a=summarize_static(synthetic_static_rows(),'roll',-1,.10,'complementary')
    assert not a['pass_for_chosen_algorithm']
    assert a['algorithm_metrics']['cal_complementary']['static_max_abs_deg']>9


class FakeTable:
    connected=True
    def __init__(self, speed=0,mode=2,drift=0):
        self.speed=speed;self.mode=mode;self.drift=drift;self.reads=0;self.disabled=[];self.enabled={0:True,2:True}
    def read_status(self):
        self.reads+=1
        axes={}
        for i in (0,2):
            axes[str(i)]={'enabled':self.enabled[i],'position_deg':(self.reads*self.drift if i==2 else 0.0),
                'speed_dps':self.speed if i==2 else 0.,'mode':self.mode,'healthy':True,
                'driver_fault':False,'upper_limit':False,'lower_limit':False,'over_speed':False,
                'zeroed':True,'in_place':True}
        return {'axes':axes}
    def disable_axis(self,axis):
        self.disabled.append(axis);self.enabled[axis]=False


def test_servo_disable_is_two_stage_and_explicit(monkeypatch):
    from app import disable_supervisor as mod
    monkeypatch.setattr(mod.time,'sleep',lambda s:None)
    t=FakeTable();d=DisableSupervisor(t,lambda:False)
    preview=d.preflight(2)
    assert not t.disabled
    with pytest.raises(ValueError):d.disable(2,preview['token'],operator_confirmed=False,load_secured=True)
    # Confirmation consumes the token even on rejection.
    with pytest.raises(ValueError):d.disable(2,preview['token'],True,True)
    preview=d.preflight(2)
    answer=d.disable(2,preview['token'],True,True)
    assert answer['confirmed_disabled'] is True and t.disabled==[2]
    assert t.enabled[0] and not t.enabled[2]


def test_servo_disable_rejects_motion_and_bogus_velocity(monkeypatch):
    from app import disable_supervisor as mod
    monkeypatch.setattr(mod.time,'sleep',lambda s:None)
    for kw in ({'speed':-1.552},{'mode':5},{'drift':.025}):
        t=FakeTable(**kw);d=DisableSupervisor(t,lambda:False)
        with pytest.raises(ValueError):d.preflight(2)
        assert not t.disabled


def test_disable_refuses_running_tests(monkeypatch):
    t=FakeTable();d=DisableSupervisor(t,lambda:True)
    with pytest.raises(ValueError,match='自动任务'):d.preflight(2)


def test_new_args_opt_in_backward_compatible():
    p=OneClickArgs()
    assert p.static_before_dynamic is False
    c=OneClickArgs(static_before_dynamic=True,static_limit_deg=.1,static_stop_on_fail=True)
    assert c.static_stop_on_fail and c.static_limit_deg==.1


def test_web_exposes_accuracy_gate_and_manual_disable():
    root=Path(__file__).resolve().parents[1]
    html=(root/'web/index.html').read_text()
    js=(root/'web/app.js').read_text()
    for key in ('auto-static-before','auto-static-limit','auto-static-stop','auto-static-result',
                'disable-axis','disable-preview','disable-load','disable-execute'):
        assert key in html and key in js
    assert 'static_before_dynamic' in js and 'static_stop_on_fail' in js
    assert '/api/turntable/disable/preflight' in js
    assert 'startsWith(\'8.2.\')' in js


def test_automatic_run_stops_before_vendor_sway_after_failed_static(monkeypatch,tmp_path):
    """Full orchestrator integration with fake hardware; no real table commands."""
    from tests.test_v66_dual_axis import FakeTable,FakeEngine,FakeDynamic,_complete
    from app.table_prepare import TablePreparation
    t=FakeTable();e=FakeEngine();e.pipeline_mode='realtime';d=FakeDynamic(tmp_path,t);p=TablePreparation(t)
    flow=AutoDynamicWorkflow(t,e,p,d)
    def stub_static(output,inner,sign,speed,limit,watcher,progress,span_deg=5.):
        progress(14,14,0)
        name='FAILED_STATIC_PRECHECK.json'
        (tmp_path/name).write_text(json.dumps({'kind':'REAL_STATIC_BEFORE_DYNAMIC',
                'analysis':{'valid':True,'pass_for_chosen_algorithm':False,
                'reason':'静态最大绝对误差0.18°超过0.1°研发阈值'}}),encoding='utf-8')
        return name,json.loads((tmp_path/name).read_text())
    monkeypatch.setattr(flow.static_precheck,'run',stub_static)
    flow.start(2,'roll',1,5,.3,10,2,True,'x_outer',False,
               static_before_dynamic=True,static_limit_deg=.1,static_stop_on_fail=True)
    _complete(flow,e)
    assert flow.state=='stopped_or_failed'
    assert '静态未达到' in flow.error
    assert flow.static_reports==['FAILED_STATIC_PRECHECK.json']
    assert not d.commands # no dynamic preflight/start issued
    assert not any(cmd[0]=='sway_stage' for cmd in t.cmds)


def test_auto_can_continue_only_with_explicit_static_gate_override(monkeypatch,tmp_path):
    """Opting out is reflected in plan/report; not an implicit precision pass."""
    from tests.test_v66_dual_axis import FakeTable,FakeEngine,FakeDynamic,_complete
    from app.table_prepare import TablePreparation
    t=FakeTable();e=FakeEngine();e.pipeline_mode='realtime';d=FakeDynamic(tmp_path,t);p=TablePreparation(t)
    flow=AutoDynamicWorkflow(t,e,p,d)
    def static_stub(output,inner,sign,speed,limit,watcher,progress,span_deg=5.):
        name='STATIC_OVERRIDDEN.json'
        report={'kind':'REAL_STATIC_BEFORE_DYNAMIC','analysis':{'valid':True,'pass_for_chosen_algorithm':False,
                'reason':'静态误差超过研发阈值','chosen_static_max_abs_deg':.3}}
        (tmp_path/name).write_text(json.dumps(report),encoding='utf-8')
        return name,report
    monkeypatch.setattr(flow.static_precheck,'run',static_stub)
    flow.start(2,'roll',1,2,.05,3,2,True,'x_outer',False,
               static_before_dynamic=True,static_limit_deg=.1,static_stop_on_fail=False)
    _complete(flow,e)
    assert flow.state=='completed',flow.error
    assert d.commands[0][0]=='preflight'
    assert flow.plan['static_stop_on_fail'] is False
    assert flow.static_check_info[0]['analysis']['pass_for_chosen_algorithm'] is False
    final=json.loads((tmp_path/flow.report_file).read_text())
    assert final['static_before_dynamic']['report_file']=='STATIC_OVERRIDDEN.json'


def test_static_report_saved_and_points_scaled_without_unrequested_motion(tmp_path,monkeypatch):
    from app.static_accuracy import StaticBeforeDynamic
    from app.static_report_html import make_static_html
    class Engine:
        uid='TEST-001';active='complementary';cal_mode='ambient';cal_files=[]
    from tests.test_v69_static_first_disable import synthetic_static_rows
    e=Engine();job=StaticBeforeDynamic(object(),e,tmp_path)
    moves=[]
    monkeypatch.setattr(job,'_position_outer',lambda target,watcher,inner,speed:moves.append(target))
    monkeypatch.setattr(job,'_check',lambda *args:{'0':{'position_deg':0},'2':{'position_deg':0}})
    def sample(target,watcher,inner,output,sign,uid,active,travel):
        return {'target_deg':target,'travel':travel,'actual_outer_deg':target,
            'imu_sample_count':200,'encoder_spread_deg':.002,'current_signed_error_deg':.01,
            'angles':{'cal':{'complementary':{'roll':target+.01,'pitch':target*.006}}}}
    monkeypatch.setattr(job,'_sample',sample)
    progress=[]
    name,report=job.run('roll',0,1,2,.1,lambda:None,
                       progress=lambda step,total,target:progress.append(target),span_deg=2.)
    assert len(moves)==14 and len(progress)==14
    assert max(abs(v) for v in moves)==2.0 # explicit 2° run never commands +/-5°
    assert report['analysis']['pass_for_chosen_algorithm']
    assert (tmp_path/name).is_file()
    assert (tmp_path/report['interactive_html_file']).is_file()
    assert '静态角度精度验证' in (tmp_path/report['interactive_html_file']).read_text()


def test_small_amplitude_with_static_before_fails_before_motion():
    from app.auto_dynamic import AutoDynamicWorkflow
    job=AutoDynamicWorkflow(None,type('RealtimeEngine',(),{'pipeline_mode':'realtime'})(),None,None)
    with pytest.raises(ValueError,match='小于1°'):
        job.start(2,'roll',1,.5,.3,10,2,True,'x_outer',False,
                  static_before_dynamic=True)
