"""V7.25 GUI integration and guarded manual control, no actual motor DLL calls."""
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.manual_axis_control import GuardedManualAxis

ROOT = Path(__file__).parents[1]


class FakeTurntable:
    connected = True

    def __init__(self):
        self.pos = {0: 0.0, 2: 0.0}
        self.speed = {0: 0.0, 2: 0.0}
        self.enabled = True
        self.limit = False
        self.moves = []
        self.stops = 0
        self.confirm_stop = True

    def read_status(self):
        def one(a):
            return {'enabled': self.enabled, 'zeroed': True, 'healthy': True,
                    'driver_fault': False, 'upper_limit': self.limit,
                    'lower_limit': False, 'over_speed': False,
                    'position_deg': self.pos[a], 'speed_dps': self.speed[a],
                    'mode': 0, 'in_place': True}
        return {'connected': True, 'time_monotonic_ns': time.monotonic_ns(),
                'axes': {'0': one(0), '2': one(2)}}

    def move(self, axis, position, speed):
        self.moves.append((axis, position, speed))
        self.pos[axis] = position

    def move_inner_manual(self, target, speed):
        self.moves.append((0, target, speed))
        self.pos[0] = target

    def move_inner_test_orientation(self, target, speed):
        self.moves.append((0, target, speed))
        self.pos[0] = target

    def stop(self):
        self.stops += 1

    def stopped_verified(self, timeout=20):
        return self.confirm_stop


def test_backend_has_no_motion_from_status_and_preflight():
    client = TestClient(app)
    html = client.get('/').text
    assert 'page-turntable' in html and 'tt25-target-0' in html and 'tt25-target-2' in html
    assert 'integrated-console-v725.js' in html
    assert client.get('/api/turntable/manual/status').status_code == 200
    assert client.post('/api/turntable/manual/preflight', json={'axis': 2, 'target_deg': 3, 'speed_dps': 1}).status_code == 409


def test_manual_preflight_never_moves_and_start_needs_confirmation():
    fake = FakeTurntable()
    man = GuardedManualAxis(fake, lambda: False)
    plan = man.preflight(2, 3, 1)
    assert not fake.moves
    with pytest.raises(ValueError, match='确认'):
        man.start(plan['token'], False)
    assert not fake.moves
    man.start(plan['token'], True)
    man.thread.join(timeout=3)
    assert not man.running
    assert fake.moves == [(2, 3.0, 1.0)]
    assert fake.stops > 0
    assert man.stopped_verified is True


def test_manual_numeric_validity_and_healthy_feedback_are_required():
    fake = FakeTurntable()
    man = GuardedManualAxis(fake, lambda: False)
    for axis, target, speed in [(0,-1,1),(0,91,1),(2,21,1),(2,1,11),(2,1,0.05)]:
        assert man.preflight(axis,target,speed)['target_deg']==target
    for axis,target,speed in [(2,1,0),(2,1,float('nan')),(2,float('inf'),1)]:
        with pytest.raises(ValueError):man.preflight(axis,target,speed)
    fake.limit = True
    with pytest.raises(RuntimeError, match='限位'):
        man.preflight(2, 2, 1)
    fake.limit = False
    fake.enabled = False
    with pytest.raises(RuntimeError, match='找零'):
        man.preflight(2, 2, 1)
    assert not fake.moves


def test_manual_no_longer_forces_experiment_orientation_but_requires_stationary():
    fake = FakeTurntable()
    fake.pos[2] = 2
    man = GuardedManualAxis(fake, lambda: False)
    plan = man.preflight(0,90,1)
    assert plan['target_deg']==90
    fake.speed[2]=1
    with pytest.raises(RuntimeError, match='静止'):
        man.preflight(0,90,1)
    fake.speed[2]=0
    plan=man.preflight(0,90,1)
    man.start(plan['token'],True)
    man.thread.join(3)
    assert fake.moves==[(0,90.0,1.0)]
    assert man.stopped_verified

def test_occupied_or_stale_position_prevents_motion():
    fake = FakeTurntable()
    occupied = [True]
    man = GuardedManualAxis(fake, lambda: occupied[0])
    with pytest.raises(RuntimeError, match='禁止'):
        man.preflight(2, 3, 1)
    occupied[0] = False
    plan = man.preflight(2, 3, 1)
    fake.pos[0] = 1
    with pytest.raises(RuntimeError, match='改变'):
        man.start(plan['token'], True)
    assert not fake.moves


def test_unverified_stop_latches_all_future_motion():
    fake = FakeTurntable()
    fake.confirm_stop = False
    man = GuardedManualAxis(fake, lambda: False)
    plan = man.preflight(2, 1, .8)
    man.start(plan['token'], True)
    man.thread.join(timeout=3)
    assert man.safety_latched and man.stopped_verified is False
    with pytest.raises(RuntimeError, match='安全故障'):
        man.preflight(2, 2, 1)


def test_experiment_navigation_and_ui_files_present():
    html=(ROOT/'web'/'index.html').read_text(encoding='utf-8')
    js=(ROOT/'web'/'integrated-console-v725.js').read_text(encoding='utf-8')
    main=(ROOT/'app'/'main.py').read_text(encoding='utf-8')
    assert 'data-page="turntable"' in html
    assert 'exp25-workspace' in js and 'buildExperimentsFrame()' in js
    assert "detail.open=detail.id==='exp-device'" in js
    assert '/api/turntable/manual/heartbeat' in main and '/api/turntable/manual/heartbeat' in js
    assert 'pre_sway_axis_check' in main
    assert '500ms' in js
