import json,time,csv
from types import SimpleNamespace
import pytest
from app.auto_dynamic import AutoDynamicWorkflow
from app.dynamic_experiment import _analyze_tracking_core,_report_process
from app.table_prepare import TablePreparation
from test_v66_dual_axis import FakeTable,FakeEngine,FakeDynamic,_complete
from test_v710_partial_results import _case,START,END,F,AMP

def test_gate_same_quality_policy():
    for holes,expected in [((),True),(((17,17.6),(23,23.55),(29,29.6)),False)]:
        tab,imu=_case(holes)
        result=_analyze_tracking_core(tab,imu,2,'roll',1,AMP,F,int(START*1e9),int(END*1e9),gate_algorithm='gyro')
        assert result['valid'] is expected
        assert 'chart' not in result and 'comparison' not in result
    tab,imu=_case(())
    for r in imu:r.pop('cal_gyro_roll')
    assert not _analyze_tracking_core(tab,imu,2,'roll',1,AMP,F,int(START*1e9),int(END*1e9),gate_algorithm='gyro')['valid']

@pytest.mark.parametrize('gap',[False,True])
def test_gate_writes_pending_ledger_and_fails_closed(tmp_path,gap):
    tab,imu=_case(())
    for row in imu:row['imu_dt_s']=.013;row['gap_reset']=0
    if gap:imu[len(imu)//2]['imu_dt_s']=.1
    ip=tmp_path/'imu.csv';tp=tmp_path/'table.csv';out=tmp_path/'r.json'
    for p,rows in ((ip,imu),(tp,tab)):
        with p.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    result={'plan':{'axis':2,'output':'roll','sign':1,'amplitude_deg':AMP,'frequency_hz':F},'imu_samples':len(imu),'table_samples':len(tab),'fusion_parameters_used':{},'imu_algorithm_at_start':'gyro','motion_start_pc_monotonic_ns':int(START*1e9),'motion_end_pc_monotonic_ns':int(END*1e9),'stopped_verified':True}
    _report_process(str(out),str(ip),str(tp),result,None,{'ACC.json':b'{}'},True,True,'','r',True)
    r=json.loads(out.read_text());assert r['state']==('analysis_invalid' if gap else 'capture_complete')
    assert r['data_analysis_state']=='pending_offline_analysis' and not r['certified_dynamic_accuracy']
    assert not (tmp_path/'r_offline_replay.csv').exists() and (tmp_path/'r_calibration_snapshot.zip').exists()

class FakeDeferred(FakeDynamic):
    def __init__(self,*a,fail=False):super().__init__(*a);self.deferred_reports=[];self.fail=fail;self.finalized=False
    def start(self,token,ack,defer_report=False):
        assert defer_report is True and token=='yes' and ack
        out,target=self.last_plan;self.commands.append(('start',out,target));self.table.cmds.append(('sway_stage',out,target))
        self.report_file=f'{out}_DYNAMIC.json';self.table_file=f'{out}_table.csv';self.imu_file=f'{out}_imu.csv'
        self.state='analysis_invalid' if self.fail else 'capture_complete';self.error='quality gate failed' if self.fail else ''
        (self.dir/self.report_file).write_text(json.dumps({'kind':'REAL_2TD600_SINE_DIAGNOSTIC','state':self.state,'plan':{'output':out},'analysis':{}}))
        self.deferred_reports.append(self.report_file);self.running=False
    def finalize_deferred_reports(self):
        assert not self.running
        if not self.fail:
            assert self.table.a[0]['position_deg']==0 and self.table.a[2]['position_deg']==0
            assert len(self.deferred_reports)==2
            assert self.table.cmds.index(('inner_stage',0,2))>self.table.cmds.index(('sway_stage','pitch',90))
        self.finalized=True;result={}
        for name in self.deferred_reports:
            path=self.dir/name;r=json.loads(path.read_text());r['state']='analysis_invalid' if self.fail else 'completed';path.write_text(json.dumps(r));result[name]={'state':r['state'],'error':self.error}
        return result

@pytest.mark.parametrize('fail',[False,True])
def test_joint_motion_before_full_report_and_no_next_axis_on_invalid(tmp_path,fail):
    t=FakeTable();e=FakeEngine();d=FakeDeferred(tmp_path,t,fail=fail);a=AutoDynamicWorkflow(t,e,TablePreparation(t),d)
    a.start(2,'both',1,5,.2,15,2,True,'xy_sequential',True);_complete(a,e)
    assert d.finalized
    if fail:
        assert a.state=='analysis_invalid' and not any(c[0]=='sway_stage' and c[1]=='pitch' for c in t.cmds)
    else:
        assert a.state=='completed',a.error
        assert [s['output'] for s in a.stages]==['roll','pitch']
        assert all(s['data_analysis_state']=='available_research_only' for s in a.stages)
        assert len(json.loads((tmp_path/a.report_file).read_text())['tests'])==2

def test_pipeline_fault_immediately_blocks_motion(tmp_path):
    t=FakeTable();e=FakeEngine();e.link_watchdog_status=lambda:{'pipeline_error':'queue fault','child_receipt_age_ms':5.,'fusion_receipt_age_ms':20.}
    a=AutoDynamicWorkflow(t,e,None,SimpleNamespace(dir=tmp_path));a.heartbeat_ns=time.monotonic_ns()
    with pytest.raises(RuntimeError,match='倾角仪数据中断'):a._watch()
    assert not t.cmds
