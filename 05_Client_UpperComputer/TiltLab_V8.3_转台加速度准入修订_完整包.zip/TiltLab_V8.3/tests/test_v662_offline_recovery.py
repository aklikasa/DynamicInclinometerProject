"""Data-only recovery regressions: no connection to real hardware."""
import csv,json,math
from pathlib import Path
import pytest
from app.offline_recovery import recover_report
from app.turntable import Table2TD600
from tests.test_v67_timestamp_reset import _samples


def _write(tmp_path,invalid_time=False):
    table,imu,start,end=_samples()
    j=tmp_path/'RECOVER_DYNAMIC.json'
    js={'kind':'REAL_2TD600_SINE_DIAGNOSTIC','state':'invalid','stopped_verified':False,
        'uid':'TEST-001','motion_start_pc_monotonic_ns':start,'motion_end_pc_monotonic_ns':end,
        'plan':{'axis':2,'output':'roll','sign':1,'amplitude_deg':5.,'frequency_hz':.3,'cycles':3},
        'raw_file_table':'RECOVER_DYNAMIC_table.csv','raw_file_imu':'RECOVER_DYNAMIC_imu.csv'}
    if invalid_time:js['motion_end_pc_monotonic_ns']=start
    j.write_text(json.dumps(js),encoding='utf-8')
    for name,rows in [('RECOVER_DYNAMIC_table.csv',table),('RECOVER_DYNAMIC_imu.csv',imu)]:
        keys=list(rows[0]);p=tmp_path/name
        with p.open('w',newline='',encoding='utf-8-sig') as f:
            writer=csv.DictWriter(f,fieldnames=keys);writer.writeheader();writer.writerows(rows)
    return j


def test_successful_readonly_recovery_retains_stop_failure(tmp_path):
    path=_write(tmp_path)
    original=path.read_bytes()
    out,html,result=recover_report(path)
    assert path.read_bytes()==original
    assert result['analysis']['valid']
    assert result['original_stop_confirmed'] is False
    assert result['state']=='analysis_available_stop_unverified'
    assert result['certified_dynamic_accuracy'] is False
    assert result['analysis']['comparison'][0]['relative_tracking_rmse_deg']<.03
    assert out.exists() and html.exists()
    page=html.read_text(encoding='utf-8')
    assert '独立误差曲线' in page and '恢复分析' in page
    assert '不连接转台' in page


def test_recovery_does_not_invent_incomplete_motion(tmp_path):
    path=_write(tmp_path,invalid_time=True)
    with pytest.raises(ValueError,match='起止'):recover_report(path)
    assert not list(tmp_path.glob('*_OFFLINE_ANALYSIS.*'))


def test_stable_position_with_bogus_speed_is_not_verified(monkeypatch):
    t=Table2TD600();t.connected=True
    t.read_status=lambda:{'axes':{str(a):{'position_deg':0.,'speed_dps':-1.552 if a==2 else 0.,'mode':2,
                                   'in_place':True,'healthy':True,'driver_fault':False,'upper_limit':False,'lower_limit':False,
                                   'over_speed':False} for a in (0,2)}}
    assert not t.stopped_verified(timeout=.03)
    assert t.last_stop_check['verified'] is False
    assert t.last_stop_check['samples'][0]['axes']['2']['speed_dps']==-1.552
