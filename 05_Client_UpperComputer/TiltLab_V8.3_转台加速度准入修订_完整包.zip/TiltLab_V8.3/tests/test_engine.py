import json,math,time,csv
from pathlib import Path
import pytest
from app.fusion import Params,FILTERS,create_filter,euler_to_q,gravity_body,q_to_euler,integrate
from app.calibration import uid_to_serial,parse_file,apply,scan,Cal
from app.simulation import DemoDevice,DEMO_ACC,DEMO_GYRO
from app.analysis import run_experiment,calculate
from app.devices import crc16,R10Device,DeviceError
from app.engine import Workstation

def test_quaternion_and_filters():
    q=euler_to_q(22,-15,0)
    e=q_to_euler(q)
    assert abs(e['roll']-22)<1e-9 and abs(e['pitch']+15)<1e-9
    g=gravity_body(q)
    for name in FILTERS:
        f=create_filter(name,Params())
        out=None
        for i in range(600):out=f.update(g,[0,0,0],.005)
        assert math.isfinite(out['roll']) and math.isfinite(out['pitch']),name
        assert abs(out['roll']-22)<1 and abs(out['pitch']+15)<1,name

def test_gyro_integral_yaw():
    f=create_filter('gyro',Params())
    for i in range(200):out=f.update([0,0,1],[0,0,90],.005)
    assert abs(out['yaw']-90)<1

def test_cal_applies_inverse_synthetic_error():
    d=DemoDevice('hold')
    rows=d.next_batch(300)
    a=[apply(r['acc'],DEMO_ACC) for r in rows]
    assert abs(sum(v[2] for v in a)/len(a)-math.cos(math.radians(12))*math.cos(math.radians(4)))<.01

def test_r10_calibration_scan(tmp_path):
    uid=bytes.fromhex('0123456789abcdeffedcba98')
    sn=uid_to_serial(uid)
    assert sn.startswith('DTS')
    m=[[1,0,0],[0,1,0],[0,0,1]]
    a={'device_serial':sn,'uid_hex':uid.hex(),'raw_accel_bias_g':[.01,0,.02], 'raw_to_platform_matrix':m}
    g={'device_serial':sn,'uid_hex':uid.hex(),'raw_gyro_bias_dps':[.1,.2,.3], 'raw_to_platform_matrix':m}
    (tmp_path/f'{sn}_acc.json').write_text(json.dumps(a))
    (tmp_path/f'{sn}_gyro.json').write_text(json.dumps(g))
    result=scan(tmp_path,sn,uid.hex())
    assert result['status']=='matched'
    assert apply([.01,0,1.02],result['acc'])==pytest.approx([0,0,1])
    result2=scan(tmp_path,'DTS000000',uid.hex())
    assert result2['status']=='missing'
    (tmp_path/f'{sn}_acc_v2.json').write_text(json.dumps(a))
    assert scan(tmp_path,sn,uid.hex())['status']=='ambiguous'

def test_r10_crc():
    assert crc16(bytes.fromhex('01030000000a'))==0xCDC5

class FakeSerial:
    def __init__(self,port,baudrate,timeout,bytesize,parity,stopbits):
        self.is_open=True;self.response=b''
        self.calls=0
    def reset_input_buffer(self):pass
    def write(self,payload):
        import struct
        addr,count=struct.unpack('>HH',payload[2:6]);assert payload[0]==1
        self.calls+=1
        if addr==3000:
            values=list(struct.unpack('>6H',bytes.fromhex('0123456789abcdeffedcba98')))
        elif addr==1000:
            values=[0]*104
            values[0]=1;values[99]=0;values[98]=1000+self.calls*20;values[100]=2;values[101]=250;values[102]=833
            for i in range(16):values[33+i]=16384
        else:raise AssertionError(addr)
        blob=bytes([1,3,count*2])+struct.pack('>'+str(count)+'H',*values)
        self.response=blob+struct.pack('<H',crc16(blob))
    def read(self,n):
        b=self.response[:n];self.response=self.response[n:];return b
    def close(self):self.is_open=False

def test_r10_serial_parse(monkeypatch):
    import types,sys
    # stand-in serial module, separate from installed pyserial
    fake=types.SimpleNamespace(Serial=FakeSerial)
    monkeypatch.setitem(sys.modules,'serial',fake)
    d=R10Device('COM3',address=1);d.open()
    assert d.serial_no==uid_to_serial(bytes.fromhex('0123456789abcdeffedcba98'))
    b=d.next_batch()
    assert len(b)==16 and b[0]['t']<b[-1]['t']
    assert b[0]['acc'][2]==pytest.approx(16384*.061/1000)
    assert b[0]['odr']==833
    d.close()

def test_experiment_report_and_reference():
    result=run_experiment('static',Params(),fs=200)
    assert result['mode']=='SIMULATED' and len(result['rankings'])==len(FILTERS)
    assert result['rankings'][0]['roll_cal']['n']>0
    assert result['samples'] and result['chart']
    assert calculate([1,2],[1,2])['rmse']==0
    assert calculate([1],[1,2]) is None

def test_state_sim_record(tmp_path,monkeypatch):
    import app.engine as mod
    monkeypatch.setattr(mod,'RECORD_DIR',tmp_path)
    lab=Workstation()
    try:
        lab.start('simulation',mode='hold')
        lab.start_record()
        time.sleep(.18)
        status=lab.status()
        assert status['source']=='simulation' and status['count']>0
        assert status['latest']['cal'] is not None
        filename=lab.stop_record()
        assert filename and (tmp_path/filename).is_file()
        with (tmp_path/filename).open(encoding='utf-8-sig') as fp:
            rows=list(csv.DictReader(fp))
        assert len(rows)>0 and 'acc_cal_x_g' in rows[0]
        lab.configure('mahony',{'kp':1.5})
        assert lab.active=='mahony'
    finally:lab.stop()
