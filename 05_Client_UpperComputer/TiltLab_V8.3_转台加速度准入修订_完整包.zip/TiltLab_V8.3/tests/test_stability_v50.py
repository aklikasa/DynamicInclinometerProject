import math
import pytest
from app.engine import Workstation
from app.stability import StationaryEvaluation
from app.fusion import FILTERS


def sample(t, wobble=0.):
    out={name:{'raw':{'roll':10+wobble,'pitch':-3+wobble/2,'yaw':.02*t},
               'cal':{'roll':10+wobble/2,'pitch':-3+wobble/4,'yaw':.01*t}}
         for name in FILTERS}
    return {'t':t,'acc':[0,0,1], 'gyro':[.001,-.002,.02],
            'gyro_cal':[0,0,.005], 'outputs':out}


def test_stationary_stats_and_z_rate_report(tmp_path):
    test=StationaryEvaluation(10,'DTS872028','ambient',{'kp':2.3})
    for i in range(1001):
        test.add(sample(i*.01,.003*math.sin(i/20)))
    assert test.state=='running'
    test.add(sample(10.02))
    r=test.summary()
    assert r['state']=='completed' and r['reference_available'] is False
    assert r['inputs']['gyro_raw_z']['mean']==pytest.approx(.02)
    assert r['inputs']['gyro_cal_z']['mean']==pytest.approx(.005)
    assert r['metrics']['cal']['adaptive']['roll']['std'] < r['metrics']['raw']['adaptive']['roll']['std']
    assert r['metrics']['raw']['adaptive']['yaw']['drift_deg_per_min']==pytest.approx(1.2,abs=.01)
    name=test.save(tmp_path)
    assert (tmp_path/name).is_file()


def test_switch_algorithm_preserves_states_and_history():
    lab=Workstation()
    # No hardware needed to test the processing pipeline and selection semantics.
    lab.process({'t':1.00,'acc':[0,0,1], 'gyro':[0,0,.01]})
    for i in range(2,12):lab.process({'t':1.00+i*.01,'acc':[0,0,1], 'gyro':[0,0,.01]})
    prev=lab.pipes['mahony'][0]
    before=lab.history_seq
    lab.configure(algorithm='mahony')
    assert lab.pipes['mahony'][0] is prev
    assert lab.history_seq==before and len(lab.history)>0
    rows,last=lab.stream_history(-1)
    assert len(rows)>0 and 'curves' in rows[0]
    assert rows[0]['curves']['kalman']['raw']['roll'] is not None
    assert lab.stream_history(last)[0]==[]
    lab.configure(params={'kp':2.4})
    assert lab.pipes['mahony'][0] is not prev
    assert len(lab.history)==0


def test_stability_requires_real_device_and_ignores_filter_switch(tmp_path):
    lab=Workstation()
    with pytest.raises(ValueError,match='RS485'):lab.start_stability(10)
    lab.running=True;lab.connected=True;lab.source='serial';lab.uid='DTS872028'
    lab.start_stability(10)
    lab.configure(algorithm='gyro')
    with pytest.raises(ValueError,match='运行中'):lab.configure(params={'alpha':.95})
    lab.stop_stability()


def test_api_stability_and_websocket_stream():
    from fastapi.testclient import TestClient
    from app.main import app, ENGINE
    # No physical device: only read-only smoke tests, start explicitly rejected.
    with TestClient(app) as client:
        assert client.post('/api/stability/start',json={'duration_s':30}).status_code==400
        assert client.get('/api/stability/status').status_code==200
        assert client.get('/assets/research-v50.css').status_code==200
        with client.websocket_connect('/ws') as socket:
            message=socket.receive_json()
            assert 'chart_delta' in message and 'history_seq' in message
            assert message['algorithm'] in FILTERS
