"""Real deferred-to-offline transition, no fake table, no physical motion."""
import csv, json
from pathlib import Path
from app.dynamic_experiment import _report_process
from test_v710_partial_results import _case, START, END, AMP, F


def _write_csv(path, rows):
    with path.open('w', encoding='utf-8', newline='') as fp:
        writer = csv.DictWriter(fp, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _two_phase(tmp_path, *, corrupt_gate=False):
    table, imu = _case(())
    for row in imu:
        row['imu_dt_s'] = .013
        row['gap_reset'] = 0
    source = tmp_path/'case.json'
    table_file = tmp_path/'table.csv'
    imu_file = tmp_path/'imu.csv'
    _write_csv(table_file, table)
    _write_csv(imu_file, imu)
    metadata = {'state':'completed', 'error':'', 'kind':'REAL_2TD600_SINE_DIAGNOSTIC',
            'plan':{'axis':2,'output':'roll','sign':1,'amplitude_deg':AMP,'frequency_hz':F},
            'imu_samples':len(imu),'table_samples':len(table),
            'fusion_parameters_used':{},'imu_algorithm_at_start':'gyro',
            'motion_start_pc_monotonic_ns':int(START*1e9),
            'motion_end_pc_monotonic_ns':int(END*1e9),
            'stopped_verified':True,'pipeline_start':{'mode':'offline'},
            'certified_dynamic_accuracy':False}
    _report_process(str(source),str(imu_file),str(table_file),metadata,None,{},True,True,'','case',True)
    pending=json.loads(source.read_text(encoding='utf-8'))
    assert pending['state']=='capture_complete'
    if corrupt_gate:
        pending['deferred_capture_gate']['valid']=False
    _report_process(str(source),str(imu_file),str(table_file),pending,None,{},True,True,'','case',False)
    return json.loads(source.read_text(encoding='utf-8'))


def test_deferred_good_analysis_promotes_to_completed(tmp_path):
    r=_two_phase(tmp_path)
    assert r['state']=='completed', (r.get('error'),r.get('analysis',{}).get('reason'))
    assert r['error']==''
    assert r['analysis']['valid'] and r['deferred_capture_gate']['valid']
    assert r['stopped_verified'] and r['data_analysis_state']=='available_research_only'
    assert r['certified_dynamic_accuracy'] is False


def test_corrupt_deferred_gate_never_passes(tmp_path):
    r=_two_phase(tmp_path,corrupt_gate=True)
    assert r['state']=='analysis_invalid'
    assert r['data_analysis_state']=='invalid'
    assert r['error']
    assert r['certified_dynamic_accuracy'] is False


def test_repair_existing_completed_analysis_without_raw_change(tmp_path):
    from tools.repair_report_status_v7241 import repair_status
    r=_two_phase(tmp_path)
    assert r['state']=='completed'
    r['state']='capture_complete'  # the documented V7.24 bug
    r['motion_period_collected']=True
    r['motion_capture_state']='completed'
    source=tmp_path/'test_DYNAMIC.json'
    source.write_text(json.dumps(r,ensure_ascii=False),encoding='utf-8')
    before=source.read_bytes()
    out=repair_status(source)
    got=json.loads(out.read_text(encoding='utf-8'))
    assert got['state']=='completed'
    assert got['analysis']==r['analysis']
    assert source.read_bytes()==before
    assert got['certified_dynamic_accuracy'] is False


def test_repair_refuses_missing_stop_or_bad_analysis(tmp_path):
    from tools.repair_report_status_v7241 import repair_status
    r=_two_phase(tmp_path)
    r['state']='capture_complete'
    r['motion_period_collected']=True
    r['motion_capture_state']='completed'
    p=tmp_path/'test_DYNAMIC.json'
    r['stopped_verified']=False
    p.write_text(json.dumps(r),encoding='utf-8')
    import pytest
    with pytest.raises(ValueError,match='STOP'):repair_status(p)
    r['stopped_verified']=True
    r['analysis']['valid']=False
    p.write_text(json.dumps(r),encoding='utf-8')
    with pytest.raises(ValueError,match='精度分析'):repair_status(p)
