from pathlib import Path
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[1]

def test_49_real_layout_restructuring():
    s=BeautifulSoup((ROOT/'web/index.html').read_text(encoding='utf-8'),'html.parser')
    assert s.select_one('.global-dock #nav') is not None
    assert s.select_one('#page-dashboard .dashboard-composition .measurement-column .metric-grid') is not None
    assert s.select_one('#page-dashboard .dashboard-composition .measurement-column .graph-panel') is not None
    assert s.select_one('#page-dashboard .dashboard-composition .pose-panel #sensor-3d') is not None
    assert s.select_one('link[href^="/assets/workstation-v49.css"]') is not None

def test_controls_not_lost_in_visual_redesign():
    s=BeautifulSoup((ROOT/'web/index.html').read_text(encoding='utf-8'),'html.parser')
    for name in ['btn-serial','serial-port','serial-baud','serial-address','cal-folder','cal-inspect-sn','btn-inspect','btn-rescan','btn-real-test','btn-real-abort','btn-record','btn-replay','sensor-3d','live-chart']:
        assert len(s.select(f'#{name}'))==1, name
