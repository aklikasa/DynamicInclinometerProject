from pathlib import Path
import pytest
from app.auto_dynamic import AutoDynamicWorkflow
from app.dynamic_experiment import DynamicExperiment
from app.main import OneClickArgs,DynamicArgs

def test_api_defaults_to_outer_roll():
    assert OneClickArgs().axis == 2 and OneClickArgs().output == 'roll'
    assert DynamicArgs().axis == 2 and DynamicArgs().output == 'roll'

def test_inner_axis_rejected_before_motion():
    job = AutoDynamicWorkflow(None,None,None,None)
    with pytest.raises(ValueError,match='外轴2'):
        job._check_inputs(0,'roll',1,.5,.02,3,2.0)
    with pytest.raises(ValueError,match='不匹配'):
        job._check_inputs(2,'pitch',1,.5,.02,3,2.0)
    assert job._check_inputs(2,'roll',1,.5,.02,3,2.0)['peak_speed_dps'] > 0

def test_dynamic_preflight_rejects_axis_before_touching_hardware():
    trial = DynamicExperiment(None,None,Path('.'))
    with pytest.raises(ValueError,match='外轴2'):
        trial.preflight(0,'pitch',1,.5,.02,3)

def test_page_outer_axis_only():
    root=Path(__file__).resolve().parents[1]
    ui=(root/'web/index.html').read_text(encoding='utf-8')
    assert '外轴2 · 执行正弦摆动' in ui
    assert 'y_inner_90' in ui
    assert 'V7.24' in ui
    assert "startsWith('8.1.')" in (root/'web/app.js').read_text(encoding='utf-8')
