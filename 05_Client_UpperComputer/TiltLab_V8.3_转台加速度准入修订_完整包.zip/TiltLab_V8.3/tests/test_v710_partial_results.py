"""V7.10: quality failure must not hide actual measured research data.

These tests use *simulated* time series strictly to exercise the software gates.
They do not certify motion precision or test hardware safety.
"""
import math
import numpy as np
from app.dynamic_experiment import analyze_tracking, ALGORITHMS, TABLE_COLS

START = 5.0
F = .3
AMP = 5.0
END = START + 10/F

def _case(holes):
    ts=np.arange(2.,END+.2,.08)
    for a,b in holes:
        ts=ts[(ts<a)|(ts>b)]
    def angle(t):
        if t < START: return 0.0
        return AMP*math.sin(2*math.pi*F*(t-START))
    table=[{'pc_mid_ns':int(t*1e9),'axis_2_pos':angle(t)} for t in ts]
    imu=[]
    for t in np.arange(2.,END,.013):
        row={'host_est_ns':int(t*1e9),'pc_observed_ns':int(t*1e9),
             'device_t_s':t,'imu_nominal_odr_hz':208}
        for algo in ALGORITHMS:
            for channel in ('raw','cal'):
                row[f'{channel}_{algo}_roll']=angle(t)*(1.07 if algo=='adaptive' else 1.)
        imu.append(row)
    return table,imu

def test_partial_research_has_real_comparison_but_fails_full_coverage():
    table,imu=_case(((17,17.6),(23,23.55),(29,29.6)))
    result=analyze_tracking(table,imu,2,'roll',1,AMP,F,int(START*1e9),int(END*1e9))
    assert result['valid'] is False
    assert result['diagnostic_preview_only'] is True
    assert result['partial_research_only'] is True
    assert result['reference_quality']['stable_missing_reference_pct']>3
    assert result['reference_quality']['research_contiguous_segments_s']
    assert result['comparison'] and result['chart']
    assert any(row.get('missing_reference') for row in result['chart'])
    assert result['certified_dynamic_accuracy'] is False
    a=next(x for x in result['comparison'] if x['channel']=='cal' and x['algorithm']=='adaptive')
    g=next(x for x in result['comparison'] if x['channel']=='cal' and x['algorithm']=='gyro')
    assert 1.05 < a['amplitude_ratio'] < 1.09
    assert abs(g['amplitude_ratio']-1)<.03

def test_table_timing_columns_are_explicitly_previous_samples():
    for field in ('poll_lag_ms','feedback_interval_ms','previous_table_csv_write_ms','previous_loop_work_ms'):
        assert field in TABLE_COLS


def test_offline_html_warns_partial_rmse_and_vqf_optional():
    from app.offline_recovery import make_html
    doc=make_html({'kind':'2TD600_READ_ONLY_OFFLINE_RECOVERY','plan':{'output':'roll'},'analysis':{
        'valid':False,'partial_research_only':True,'comparison':[], 'chart':[]}, 'warning':'研究数据，非验收'})
    assert '局部片段可分析' in doc
    assert '整段精度无效' in doc
    assert "vqf6d" in doc
