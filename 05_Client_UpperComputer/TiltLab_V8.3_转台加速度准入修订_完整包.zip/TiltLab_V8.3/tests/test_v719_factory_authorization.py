"""Offline tests: no hardware or physical motor commands."""
import json, time
import pytest
from app.factory_table_bridge import FactoryAuthorization, FactoryBridge, FactoryDLLProxy
from test_v718_factory_hold import FakeTable, setup_supervisor

@pytest.mark.parametrize('failure',['cancel','revoke','token','server_close'])
def test_fail_closed_lease(failure):
    t=FakeTable();alive=[True];b=FactoryBridge(t,lambda:alive[0],[1,2,5]);closed=False
    try:
        ep=b.endpoint;probe=FactoryAuthorization(ep,interval=0)
        assert probe.cancelled() is False
        assert not t.calls
        if failure=='cancel':alive[0]=False
        if failure=='revoke':b.revoke()
        if failure=='token':probe.endpoint={**ep,'token':'wrong'}
        if failure=='server_close':b.close();closed=True
        assert probe.cancelled() is True
        alive[0]=True
        assert probe.cancelled() is True  # no renewed authorization after failure
        assert not t.calls
    finally:
        if not closed:b.close()

def test_browser_lease_not_renewed_by_worker(tmp_path,monkeypatch):
    obj,*_=setup_supervisor(tmp_path,monkeypatch)
    b=FactoryBridge(obj.table,obj._alive,[1]);probe=FactoryAuthorization(b.endpoint,interval=0)
    try:
        last=obj.last_heartbeat
        assert not probe.cancelled() and obj.last_heartbeat==last
        obj.last_heartbeat=time.monotonic()-6.01
        assert probe.cancelled()
    finally:b.close()

def test_reconnect_pipeline_failure_blocks_import_and_motion(tmp_path,monkeypatch):
    obj,cfg,plan,calls,table=setup_supervisor(tmp_path,monkeypatch)
    original=obj.engine.start
    def fail(*args):
        original(*args);obj.engine.running=False;obj.engine.connected=False;obj.engine._pipeline_error='融合队列延迟超过500ms'
    monkeypatch.setattr(obj.engine,'start',fail)
    obj._run({},cfg,plan,tmp_path/'worker.py')
    assert 'load' not in calls and 'resume' not in calls
    assert obj.status()['state']=='failed' and '500ms' in obj.status()['detail']
    assert table.enabled

def test_progress_partial_line_ignored(tmp_path,monkeypatch):
    obj,*_=setup_supervisor(tmp_path,monkeypatch)
    (tmp_path/'worker_progress.jsonl').write_bytes(b'{"state":"ready"}\n{"state":')
    assert obj.status()['worker']['state']=='ready'
