import json,time
from types import SimpleNamespace
from pathlib import Path
from app import automatic_factory as mod

class FakeProc:
    returncode=0
    def poll(self):return self.returncode

def setup(tmp_path,monkeypatch,success=True):
    calls=[]
    class E:
        latest={'cal':{'roll':0}}
        def stop(self):calls.append('imu_stop')
        def start(self,*args):calls.append('imu_start')
    class L:
        def disconnect(self):calls.append('table_close')
        def connect(self,*args,**kwargs):calls.append('table_connect')
    class A:
        def start(self,*args):calls.append('resume')
    obj=mod.AutomaticFactory(E(),None,L(),A(),tmp_path);obj.job=tmp_path;obj.active=True;obj.last_heartbeat=time.monotonic()
    cfg={'imu_port':'COM3','imu_baud':1500000,'imu_address':1,'table_port':4}
    plan={'axis':2,'output':'roll','requested_roll_sign':1,'amplitude_deg':5,'frequency_hz':.3,'cycles':5,'zero_speed_dps':2,'mounting_mode':'x_outer','fixture_confirmed':True,'requested_pitch_sign':1,'static_limit_deg':.1,'pre_sway_axis_check':True}
    def popen(*args,**kwargs):
        calls.append('worker');(tmp_path/'worker_result.json').write_text(json.dumps({'success':success,'safe_closed':True,'message':'quality failed'}));return FakeProc()
    monkeypatch.setattr(mod.subprocess,'Popen',popen)
    def load(*args):calls.append('load');return {'state':'loaded','loaded_files':['a','g']}
    monkeypatch.setattr(mod,'import_pair',load)
    return obj,cfg,plan,calls

def test_success_loads_before_resume(tmp_path,monkeypatch):
    obj,cfg,plan,calls=setup(tmp_path,monkeypatch)
    obj._run({},cfg,plan,tmp_path/'worker.py')
    assert calls==['table_close','imu_stop','worker','imu_start','load','table_connect','resume']
    assert obj.status()['state']=='resumed' and not obj.active

def test_failed_quality_never_loads_or_resumes(tmp_path,monkeypatch):
    obj,cfg,plan,calls=setup(tmp_path,monkeypatch,False)
    obj._run({},cfg,plan,tmp_path/'worker.py')
    assert calls==['table_close','imu_stop','worker']
    assert obj.status()['state']=='failed'

def test_cancel_before_transfer(tmp_path,monkeypatch):
    obj,cfg,plan,calls=setup(tmp_path,monkeypatch);obj.abort()
    obj._run({},cfg,plan,tmp_path/'worker.py')
    assert calls==[] and obj.status()['state']=='failed'
