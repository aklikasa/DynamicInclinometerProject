"""No-device regression checks for the V7.30.1 dropdown / accordion fixes."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
JS = (ROOT / 'web/app.js').read_text(encoding='utf-8')
HTML = (ROOT / 'web/index.html').read_text(encoding='utf-8')
CSS = (ROOT / 'web/ui-reliability-v7301.css').read_text(encoding='utf-8')

class UiRegressionTests(unittest.TestCase):
    def test_glass_selector_no_longer_replaces_native_select(self):
        self.assertNotIn('function initGlassSelects(', JS)
        self.assertNotIn("document.addEventListener('scroll',()=>closeGlassSelect(),true)", JS)
        self.assertNotIn('glass-select-native', JS)
        self.assertIn('appearance: auto;', CSS)
        self.assertIn('ui-reliability-v7301.css?v=8200', HTML)

    def test_port_selectors_remain_native_html(self):
        for port_id in ('v58-table-port', 'v58-imu-port', 'tt25-port', 'serial-port', 'table-port'):
            self.assertRegex(HTML, rf'<select\s+id="{port_id}"')
            self.assertTrue(any(port_id in (ROOT / "web" / name).read_text(encoding="utf-8") for name in ("app.js", "integrated-console-v725.js")))

    def test_recovery_does_not_force_exp_static_open_on_every_poll(self):
        self.assertIn('if(r.mount_recovery)', JS)
        self.assertIn("txt('auto-mount-recovery-result'", JS)
        self.assertNotIn('panel.open=true', JS)
        self.assertIn('id="exp-oneclick"', HTML)
        self.assertIn('id="exp-static"', HTML)

    def test_revisions_bust_cache(self):
        self.assertIn('/assets/app.js?v=8200', HTML)
        self.assertIn('V8.2.0', HTML)

if __name__ == '__main__':
    unittest.main()
