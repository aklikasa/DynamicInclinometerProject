import math
import numpy as np
from app.dynamic_experiment import recover_imu_timebase,analyze_tracking,ALGORITHMS

def test_101_second_stale_anchor_is_recovered_from_fifo_observation():
    base=10.; frequency=.05;amplitude=2.;motion=12.;end=72.
    tr=[];imu=[]
    for t in np.arange(base,73,.1):
        pos=amplitude*math.sin(2*math.pi*frequency*(t-motion)) if t>=motion else 0.
        tr.append({'pc_mid_ns':int(t*1e9),'axis_2_pos':pos})
    # Simulate batches of 16 IMU samples with common observation timestamp.
    for start in np.arange(base,73,.32):
        for offset in np.arange(16)*.02:
            t=start+offset
            val=amplitude*math.sin(2*math.pi*frequency*(t-motion)) if t>=motion else 0.
            # The PC observed time belongs to batch's LAST IMU sample.
            row={'host_est_ns':int((t+101.44)*1e9),'pc_observed_ns':int((start+.30)*1e9), 'device_t_s':t}
            for channel in ('cal','raw'):
                for algo in ALGORITHMS:row[f'{channel}_{algo}_roll']=val
            imu.append(row)
    ix,info=recover_imu_timebase(imu,int(base*1e9),int(end*1e9))
    assert info['recovered'] and abs(info['host_clock_error_median_s']-101.44)<.01
    assert info['time_source']=='pc_fifo_reception_backprojection'
    assert abs(ix[0]-base)<.001
    result=analyze_tracking(tr,imu,2,'roll',1,amplitude,frequency,int(motion*1e9),int(end*1e9))
    assert result['valid'],result.get('reason')
    assert result['clock_diagnostics']['recovered']
    assert result['comparison'][0]['relative_tracking_rmse_deg']<.01
    assert result['certified_dynamic_accuracy'] is False

def test_normal_timestamp_remains_unchanged():
    r=[]
    for j in range(3):
        obs=int((100+j*.020)*1e9)
        for k in range(16):
            t=99.98+j*.020+k*.001
            r.append({'host_est_ns':int(t*1e9),'pc_observed_ns':obs,'device_t_s':t})
    ix,info=recover_imu_timebase(r,int(99e9),int(101e9))
    assert not info['recovered']
    assert info['time_source']=='session_host_estimate'
