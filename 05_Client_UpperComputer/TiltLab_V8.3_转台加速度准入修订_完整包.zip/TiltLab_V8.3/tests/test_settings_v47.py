import json
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from app import engine as module
from app.main import app


def test_folder_saved_and_loaded_without_device(monkeypatch,tmp_path):
    cfg=tmp_path/'cfg'/'settings.json'
    monkeypatch.setattr(module,'SETTINGS_FILE',cfg)
    monkeypatch.setattr(module,'BUNDLED_SETTINGS_FILE',tmp_path/'empty-default.json')
    library=tmp_path/'calibration'; library.mkdir()
    desk=module.Workstation()
    assert desk.cal_root==''
    res=desk.set_folder(str(library),'local')
    assert res['status']=='uid_missing'
    assert desk.cal_root==str(library.resolve())
    assert json.loads(cfg.read_text(encoding='utf8'))['calibration_folder']==str(library.resolve())
    desk2=module.Workstation()
    assert desk2.cal_root==str(library.resolve())
    assert desk2.cal_source=='local'
    assert not desk2.running


def test_bad_source_rejected_without_changing_configuration(monkeypatch,tmp_path):
    monkeypatch.setattr(module,'SETTINGS_FILE',tmp_path/'config.json')
    monkeypatch.setattr(module,'BUNDLED_SETTINGS_FILE',tmp_path/'fallback.json')
    desk=module.Workstation()
    with pytest.raises(ValueError, match='只支持'):
        desk.set_folder(str(tmp_path),'http')
    assert desk.cal_root==''


def test_settings_route_is_non_sensitive_and_offline():
    c=TestClient(app)
    r=c.get('/api/settings')
    assert r.status_code==200
    assert r.json()['calibration_source'] in ('local','shared')
    assert r.json()['supported_sources']==['local','shared']
