import json
from types import SimpleNamespace
import threading
import pytest
from app.calibration import scan
from app.factory_recovery import prepare,import_pair,digest

UID='DTS672516';HEX='1234567890abcdef12345678'

def make_pair(base,bias=0.,uid=UID):
    base.mkdir(exist_ok=True,parents=True)
    for s in ('acc','gyro'):
        d={'device_serial':uid,'uid_hex':HEX,'sensor':s,'bias':[bias,0.,0.],'matrix':[[1,0,0],[0,1,0],[0,0,1]]}
        (base/f'{uid}_{s.upper()}_AMBIENT.json').write_text(json.dumps(d))

class Engine:
    def __init__(self,base):
        self.lock=threading.RLock();self.cal_root=str(base);self.uid=UID;self.uid_hex=HEX;self.cal_mode='ambient';self.connected=True;self.running=True;self.source='serial';self.record_fp=None;self.stability=None;self.params=SimpleNamespace(lever_z_cm=5.);self.active='gyro_anchor3d';self.latest={};self.reloads=0;self.lookup_calibration()
    def lookup_calibration(self):
        self.reloads+=1;self.cal=scan(self.cal_root,self.uid,self.uid_hex);self.cal_status=self.cal['status'];return self.cal
    def clear_lever3d(self):pass
    def log(self,s):pass

@pytest.fixture
def setup(tmp_path):
    base=tmp_path/'original';make_pair(base);e=Engine(base)
    run={'running':False,'state':'stopped_or_failed','stopped_verified':True,'error':'ROLL静态未达到设定门槛','plan':{}}
    return e,run,tmp_path/'work'

def test_import_success(setup):
    e,run,work=setup;h=prepare(e,run,work);make_pair(__import__('pathlib').Path(h['stage_folder']),.001)
    out=import_pair(e,h)
    assert out['state']=='loaded' and e.cal['acc'].bias[0]==.001 and e.cal['gyro'].bias[0]==.001
    assert e.active=='gyro_anchor' and e.params.lever_z_cm==0 and e.latest is None
    assert all(digest(p['backup'])==p['old_sha256'] for p in h['pairs'])
    assert all(digest(p['target'])!=p['old_sha256'] for p in h['pairs'])

@pytest.mark.parametrize('mode',['missing','unchanged','wrong_uid','changed_original'])
def test_refuse_unverified_pair(setup,mode):
    from pathlib import Path
    e,run,work=setup;h=prepare(e,run,work);stage=Path(h['stage_folder'])
    if mode=='unchanged':make_pair(stage)
    if mode=='wrong_uid':make_pair(stage,.001,'DTS999999')
    if mode=='changed_original':make_pair(stage,.001);make_pair(Path(e.cal_root),.002)
    before=[digest(p['target']) for p in h['pairs']]
    with pytest.raises(ValueError):import_pair(e,h)
    assert before==[digest(p['target']) for p in h['pairs']]

def test_prepare_requires_stop_and_external_backup(setup):
    from pathlib import Path
    e,run,work=setup
    with pytest.raises(ValueError):prepare(e,{**run,'stopped_verified':False},work)
    with pytest.raises(ValueError):prepare(e,run,Path(e.cal_root)/'backup')
    with pytest.raises(ValueError):prepare(e,{**run,'error':'倾角仪数据中断'},work)

def test_rollback_on_reload_failure(setup):
    from pathlib import Path
    e,run,work=setup;h=prepare(e,run,work);make_pair(Path(h['stage_folder']),.001)
    old=e.lookup_calibration;calls=[0]
    def fail_once():
        calls[0]+=1
        if calls[0]==1:raise ValueError('test load failure')
        return old()
    e.lookup_calibration=fail_once
    with pytest.raises(ValueError):import_pair(e,h)
    assert all(digest(p['target'])==p['old_sha256'] for p in h['pairs'])
    assert e.cal['acc'].bias[0]==0.
