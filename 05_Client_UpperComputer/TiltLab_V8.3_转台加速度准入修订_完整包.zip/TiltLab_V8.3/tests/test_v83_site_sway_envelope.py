"""Offline checks for site evidence separation and non-bypass of conservative default."""
import json
import math
from pathlib import Path
import pytest
from app import sway_envelope as env


def setup_site(tmp_path,monkeypatch,**changes):
    sample={
        'factory_sway_model':'2TD-600',
        'site_sway_validation':{
            'approved':True,'risk_acknowledged':True,
            'device_serial':'2TD600-123','load_kg':8,
            'fixture_description':'8 kg test fixture with installed DUT',
            'test_record':'SITE-TEST-123456',
            'approver':'Qualified operator',
            'date':'2026-11-20',
            'approved_max_speed_dps':12,
            'approved_max_accel_dps2':55,
        }
    }
    sample['site_sway_validation'].update(changes)
    p=tmp_path/'profile.json'
    p.write_text(json.dumps(sample),encoding='utf8')
    monkeypatch.setattr(env,'PROFILE_PATH',p)
    return sample,p


def test_site_approved_acceleration_requires_auditable_evidence(tmp_path,monkeypatch):
    sample,p=setup_site(tmp_path,monkeypatch)
    got=env.rated_sway_limits()
    assert got['site_validation_recorded'] and got['accel_dps2']==55
    assert not got['rating_verified']
    assert got['evidence_type']=='site'
    monkeypatch.setattr(env,'SWAY_LIMITS',got)
    speed,accel=env.verify_sway_motion(2,.8)
    assert speed<12 and 50<accel<55

@pytest.mark.parametrize('change',[
    {'approved':False},{'risk_acknowledged':False},
    {'test_record':''},{'approver':''},{'device_serial':''},
    {'load_kg':None},{'load_kg':21},
    {'approved_max_speed_dps':61},{'approved_max_accel_dps2':float('nan')},
])
def test_missing_or_invalid_site_evidence_falls_back(tmp_path,monkeypatch,change):
    setup_site(tmp_path,monkeypatch,**change)
    lim=env.rated_sway_limits()
    assert lim['evidence_type']=='unverified'
    assert lim['accel_dps2']==40
    monkeypatch.setattr(env,'SWAY_LIMITS',lim)
    with pytest.raises(ValueError):env.verify_sway_motion(2,.8)


def test_vendor_rating_compatibility(tmp_path,monkeypatch):
    p=tmp_path/'legacy.json'
    p.write_text(json.dumps({'factory_sway_rating_verified':True,
        'factory_sway_model':'2TD-600',
        'factory_sway_serial':'SN1234',
        'factory_sway_document':'Manuf letter for current 8kg rig dated 2026-11-20',
        'factory_sway_max_speed_dps':15,
        'factory_sway_max_accel_dps2':60}),encoding='utf8')
    monkeypatch.setattr(env,'PROFILE_PATH',p)
    got=env.rated_sway_limits()
    assert got['rating_verified'] and got['accel_dps2']==60


def test_invalid_amplitudes_and_frequencies_are_rejected():
    for a,f in [(float('nan'),.5),(2,0),(2,float('inf')),(-1,.3)]:
        with pytest.raises(ValueError):env.verify_sway_motion(a,f)
