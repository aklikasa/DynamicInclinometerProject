import os,time,math,pytest
from dataclasses import replace
from app.acquisition_v714 import ProcessTransport
from app.fusion import Params,create_filter
from app.continuity_v713 import advance
from app.engine import Workstation

class ProcessFake:
    serial_no='MOCK';uid='MOCKHEX';dropped_batches=0
    def __init__(self,*args):self.n=0;self._pending_registers=None
    def open(self):pass
    def close(self):pass
    def next_batch(self):
        self.n+=1;time.sleep(.005)
        return [{'t':self.n*.02,'pid':os.getpid()}]
class BrokenFake(ProcessFake):
    def next_batch(self):raise RuntimeError('test serial failure')

def test_spawn_owns_transport_clock_and_stops():
    d=ProcessTransport(ProcessFake,'MOCK',1500000,1)
    try:
        d.open();d.begin.set();item=()
        deadline=time.monotonic()+2
        while not item and time.monotonic()<deadline:item=d.next_poll()
        batch,poll=item;assert batch[0]['pid']!=os.getpid()
        assert poll['received_pc_ns']>=poll['request_pc_ns'] and poll['accepted_samples']==1
        assert d.dropped_batches==0
        d.request_stop()
        while d.next_poll() is not None:pass
    finally:d.close()
    assert not d.proc.is_alive()

def test_spawn_propagates_error():
    d=ProcessTransport(BrokenFake,'MOCK',1500000,1)
    try:
        d.open();d.begin.set()
        with pytest.raises(RuntimeError,match='test serial failure'):
            for _ in range(40):d.next_poll()
    finally:d.close()
    assert not d.proc.is_alive()

def test_zero_and_raw_match_adaptive():
    p=Params();f=create_filter('adaptive',p);zero=create_filter('adaptive3d',p);raw=create_filter('adaptive3d',replace(p,lever3_z_cm=19.51),False)
    for i in range(100):
        a=[0,.01*math.sin(i/10),1];g=[1.,0,0]
        f,o,_=advance('adaptive',f,p,True,a,g,.0012)
        zero,z,_=advance('adaptive3d',zero,p,True,a,g,.0012)
        raw,r,_=advance('adaptive3d',raw,p,False,a,g,.0012)
        assert o['roll']==pytest.approx(z['roll'],abs=1e-12) and o['roll']==pytest.approx(r['roll'],abs=1e-12)

def test_adaptive3d_gap_stays_marked_and_research_clears():
    p=Params(lever3_z_cm=19.51);f=create_filter('adaptive3d',p)
    f,_,_=advance('adaptive3d',f,p,True,[0,0,1],[10,0,0],0)
    f,o,act=advance('adaptive3d',f,p,True,[0,1,0],[10,0,0],.12)
    assert act=='gyro_bridge' and o['roll']==pytest.approx(1.2) and not o['lever_compensation_ready']
    lab=Workstation();lab.active='adaptive3d';lab.params=p;lab.clear_lever3d();assert lab.active=='adaptive' and lab.params.lever3_z_cm==0

def test_research_endpoint_refuses_without_exact_device_files(monkeypatch):
    from app import main
    from fastapi.testclient import TestClient
    e=Workstation();e.source='serial';e.connected=e.running=True;e.uid='DTS672516';e.cal_status='matched';e.cal_mode='ambient';e.cal={'files':[]}
    monkeypatch.setattr(main,'ENGINE',e)
    c=TestClient(main.app)
    r=c.post('/api/lever-identify/research-z',json={'same_fixture_confirmed':True,'research_only_confirmed':True})
    assert r.status_code==400 and e.params.lever3_z_cm==0
