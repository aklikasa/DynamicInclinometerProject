"""V7.8 synthetic diagnostics only; results DO NOT imply real hardware accuracy."""
import math
import numpy as np
import pytest
from app.fusion import Params,create_filter,FILTERS
from app.dynamic_experiment import analyze_tracking, ALGORITHMS
from app.dynamic_diagnostics import diagnostic_reference_mask


def fixture_trace(f=.3, radius=.18, bias=.043, noise=.0015):
    rng=np.random.default_rng(4242)
    filters={k:create_filter(k,Params()) for k in ('adaptive','gyro','motion_guard')}
    errors={k:[] for k in filters}
    obj=None
    for t in np.arange(0,22.,.004):
        if t<3.: ang=rate=accel=0.
        else:
            w=2.*math.pi*f;angle=w*(t-3.)
            ang=5.*math.sin(angle);rate=5.*w*math.cos(angle)
            accel=-math.radians(5.)*w*w*math.sin(angle)
        a=[0.,math.sin(math.radians(ang))-radius*accel/9.80665,math.cos(math.radians(ang))]
        a=[v+rng.normal(0,noise) for v in a]
        g=[rate+bias+rng.normal(0,.012),rng.normal(0,.012),rng.normal(0,.012)]
        for key,fil in filters.items():
            obj=fil.update(a,g,.004)
            if t>6.:errors[key].append(obj['roll']-ang)
    return {name:float(np.sqrt(np.mean(np.square(e)))) for name,e in errors.items()},filters


@pytest.mark.parametrize('frequency',(.1,.3))
def test_motion_guard_synthetic_motion_acceleration_and_small_bias(frequency):
    errors,filters=fixture_trace(frequency)
    assert 'motion_guard' in FILTERS
    # Motion-acceleration suppression plus a stationary bias baseline should
    # improve this *controlled* synthetic experiment without time fitting.
    assert errors['motion_guard']<errors['adaptive']*.7,errors
    assert filters['motion_guard']._initial_bias_frozen
    assert abs(filters['motion_guard'].bias[0]-.043)<.02


def test_fixed_gap_exclusion_is_independent_of_time_shift():
    ts=np.arange(0.,30.1,.08)
    ts=ts[(ts<18.)|(ts>18.6)]
    t=np.arange(5.,29.,.009)
    keep=diagnostic_reference_mask(ts,t)
    assert np.any(keep)
    assert not np.any(keep[(t>=17.85)&(t<=18.88)])
    for shift in [-.25,0.,.25]:
        # Any candidate shift must be far from forbidden bracket.
        trial=t[keep]+shift
        right=np.clip(np.searchsorted(ts,trial,side='right'),1,len(ts)-1)
        assert np.max(ts[right]-ts[right-1])<.4


def synthetic_rows(holes=False):
    frequency=.3; start=4.;end=34.;amp=5.
    ts=np.arange(1.,end+1.,.09)
    if holes:ts=ts[(ts<18.)|(ts>18.52)]
    def angle(t):return amp*math.sin(2*math.pi*frequency*(t-start)) if t>=start else 0.
    table=[{'pc_mid_ns':int(t*1e9),'axis_2_pos':angle(t)} for t in ts]
    imu=[]
    for t in np.arange(1.,end,.008):
        row={'host_est_ns':int(t*1e9)}
        for ch in ('raw','cal'):
            for alg in ALGORITHMS:
                # Only adaptive/accel have an injected amplitude problem.
                amp_err=1.07 if alg in ('adaptive','accel') else 1.
                lag=.06 if alg != 'gyro' else .055
                row[f'{ch}_{alg}_roll']=amp_err*angle(t-lag)
        imu.append(row)
    return table,imu,int(start*1e9),int(end*1e9)


@pytest.mark.parametrize('holes',(False,True))
def test_new_root_cause_diagnostic_uses_holdout_and_never_applies_correction(holes):
    table,imu,start,end=synthetic_rows(holes)
    res=analyze_tracking(table,imu,2,'roll',1,5.,.3,start,end)
    assert res['valid'],res.get('reason')
    d=res['root_cause_diagnostics'];assert d['available'],d
    acc=next(x for x in d['components'] if x['algorithm']=='accel')
    assert abs(acc['amplitude_ratio']-1.07)<.012,acc
    assert acc['holdout_rmse_shift_only_deg']<acc['holdout_rmse_original_deg'],acc
    assert abs(acc['holdout_optimal_reference_shift_ms']+60)<25,acc
    assert acc['amplitude_or_gain_applied_to_imu'] is False
    assert d['hardware_synchronized'] is False and not d['certified_accuracy']
    assert d['reference_gaps_excluded']==int(holes)
    if holes:
        assert res['time_shift_diagnostics']['available'] is False
        assert d['available'] # strictly gap-excluded new diagnostic survives


def test_hardware_motion_command_files_are_unchanged():
    from pathlib import Path
    p=Path(__file__).resolve().parents[1]
    assert 'SetAxisSway' in (p/'app/turntable.py').read_text(encoding='utf-8')
    assert 'SetAxisSway' not in (p/'app/motion_guard.py').read_text(encoding='utf-8')
    assert 'motion_guard' in (p/'app/fusion.py').read_text(encoding='utf-8')
