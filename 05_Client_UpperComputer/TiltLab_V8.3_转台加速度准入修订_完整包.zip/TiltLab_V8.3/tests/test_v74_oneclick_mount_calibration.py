"""No vendor hardware is touched. Verify motion sequencing and fail-closed behavior."""
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import pytest
from app.auto_dynamic import AutoDynamicWorkflow
from app.disable_supervisor import DisableSupervisor
from app.mount_calibration_storage import store_verified_mount_alignment
from app import auto_dynamic


def candidate():
    return dict(valid=True,applied=False,uid='DTS672516',calibration_mode='ambient',
                active_statically_pass=True,gravity_statically_pass=True,
                matrix=[[1,0],[0,1]],bias_deg=[0,0],reason='留出集通过',
                validation_active_before={},validation_active_after={})


def setup_workflow(tmp_path,monkeypatch,alignment=None,axis_pass=True,stop_ok=True):
    calls=[]
    def status():return {'axes':{str(a):{'enabled':True,'healthy':True,'zeroed':True} for a in (0,2)}}
    table=SimpleNamespace(connected=True,read_status=status,stop=lambda:calls.append(('stop',)),
                          stopped_verified=lambda timeout=20:(calls.append(('verify_stop',timeout)) or stop_ok))
    engine=SimpleNamespace(uid='DTS672516',cal_mode='ambient',active='madgwick',
        cal={'files':['DTS672516_ACC_AMBIENT.json','DTS672516_GYRO_AMBIENT.json']},
        clear_static_alignment=lambda:calls.append(('clear',)),
        install_static_alignment=lambda c:calls.append(('install',)))
    prep=SimpleNamespace(running=False,preflight=lambda:{'token':'preflight-token'},
        start=lambda *a,**k:calls.append(('prepare',)),status=lambda:{'ready':True,'error':''})
    reports=tmp_path/'data'/'reports';reports.mkdir(parents=True,exist_ok=True)
    dynamic=SimpleNamespace(running=False,dir=reports)
    workflow=AutoDynamicWorkflow(table,engine,prep,dynamic)
    workflow.plan=dict(calibration_only=True,load_secured=True,zero_speed_dps=2.,
        mounting_mode='xy_sequential',pre_sway_axis_check=True,auto_static_align=True,sign=1,pitch_sign=1,
        static_limit_deg=.1,amplitude_deg=5,static_stop_on_fail=True)
    workflow.running=True;workflow.state='prechecking';workflow.started_at=1_763_500_000
    workflow.heartbeat_ns=0
    workflow._watch=lambda:None
    workflow._await=lambda subtask:None
    workflow._position=lambda axis,target:calls.append(('position',axis,target))
    workflow._validate_and_save_polarity=lambda data,file,sign: {'valid':True,'output':data['output'],'selected_sign':1}
    def run_static(direction,orientation,sign,speed,limit,watch,progress,span_deg):
        calls.append(('static',direction,orientation,span_deg))
        name=direction+'_STATIC_PRECHECK.json'
        return name,{'output':direction,'analysis':{},'mount_axis_precheck':{'pass_for_dynamic':axis_pass},'interactive_html_file':None}
    workflow.static_precheck.run=run_static
    monkeypatch.setattr(auto_dynamic,'fit_static_alignment',lambda *a,**k:dict(candidate() if alignment is None else alignment))
    supervisor=SimpleNamespace(disable_after_owned_calibration=lambda **k:(calls.append(('disable',k)) or
        [{'axis':2,'confirmed_disabled':True},{'axis':0,'confirmed_disabled':True}]))
    workflow.disable_supervisor=supervisor
    return workflow,calls,reports


def test_one_click_mount_success_uses_no_sway_and_saves(tmp_path,monkeypatch):
    workflow,calls,reports=setup_workflow(tmp_path,monkeypatch)
    workflow._run()
    assert workflow.state=='completed',workflow.error
    assert [c[1] for c in calls if c[0]=='static']==['roll','pitch']
    assert calls.index(('position',2,0))<calls.index(('position',0,90))
    assert calls.index(('stop',))<calls.index(('verify_stop',20))
    assert not any(c[0]=='disable' for c in calls)
    assert calls[-1][0]=='install'
    stored=tmp_path/'data'/'mount_calibrations'/workflow.mount_calibration_file
    assert stored.is_file()
    document=json.loads(stored.read_text(encoding='utf-8'))
    assert document['automatic_reuse_allowed'] is False
    assert document['servos_held_after_calibration'] is True
    assert document['disable_results']==[]
    assert document['factory_calibration_files']==['DTS672516_ACC_AMBIENT.json','DTS672516_GYRO_AMBIENT.json']
    assert (tmp_path/'data'/'mount_calibrations'/'DTS672516_ambient_LATEST_MOUNT_ALIGNMENT.json').is_file()
    ledger=json.loads((reports/workflow.run_manifest_file).read_text(encoding='utf-8'))
    assert ledger['kind']=='2TD600_MOUNT_CALIBRATION_LEDGER'
    assert ledger['mount_calibration_file']==workflow.mount_calibration_file
    assert not ledger['completed_dynamic_stages']


@pytest.mark.parametrize('override,axis_pass,stop_ok',[
    ({'valid':False},True,True),
    ({'gravity_statically_pass':False},True,True),
    ({},False,True),
    ({},True,False),
])
def test_invalid_mount_calibration_never_saves_or_disables(tmp_path,monkeypatch,override,axis_pass,stop_ok):
    c=candidate();c.update(override)
    workflow,calls,reports=setup_workflow(tmp_path,monkeypatch,c,axis_pass,stop_ok)
    workflow._run()
    assert workflow.state=='stopped_or_failed'
    assert not workflow.mount_calibration_file
    assert not any(c[0]=='disable' for c in calls)
    assert not any(c[0]=='install' for c in calls)
    assert not list((tmp_path/'data'/'mount_calibrations').glob('*.json')) if (tmp_path/'data'/'mount_calibrations').exists() else True


def test_stored_file_requires_verified_stop_and_disable(tmp_path):
    with pytest.raises(ValueError,match='未确认物理停车'):
        store_verified_mount_alignment(tmp_path,candidate(),uid='DTS672516',mode='ambient',
            factory_files=['a','b'],stop_confirmed=False,
            disable_results=[{'confirmed_disabled':True},{'confirmed_disabled':True}])
    assert not (tmp_path/'data'/'mount_calibrations').exists()


def test_safe_servo_disable_requires_both_acknowledgements():
    table=SimpleNamespace(connected=True)
    supervisor=DisableSupervisor(table,lambda:True)
    with pytest.raises(ValueError,match='独立支撑'):
        supervisor.disable_after_owned_calibration(operator_confirmed=True,load_secured=False,stop_confirmed=True)
    with pytest.raises(ValueError,match='真实两轴停车确认'):
        supervisor.disable_after_owned_calibration(operator_confirmed=True,load_secured=True,stop_confirmed=False)


def test_safe_servo_disable_refuses_movement(monkeypatch):
    calls=[]
    axes={str(a):dict(position_deg=0.,speed_dps=(.12 if a==2 else 0),mode=2,
              enabled=True,healthy=True,driver_fault=False,upper_limit=False,lower_limit=False,over_speed=False)
          for a in (0,2)}
    table=SimpleNamespace(connected=True,read_status=lambda:{'axes':axes},
                          disable_axis=lambda a:calls.append(a))
    supervisor=DisableSupervisor(table,lambda:True)
    with pytest.raises(ValueError,match='角速度非零'):
        supervisor.disable_after_owned_calibration(operator_confirmed=True,load_secured=True,stop_confirmed=True)
    assert not calls


def test_web_has_operator_gated_one_click_entrypoint():
    from app.main import app
    root=Path(__file__).resolve().parents[1]
    html=(root/'web/index.html').read_text(encoding='utf-8')
    js=(root/'web/app.js').read_text(encoding='utf-8')
    routes={r.path for r in app.routes}
    assert '/api/calibration/mount/start' in routes
    assert '/api/calibration/mount-file/{name}' in routes
    for token in ('mount-cal-start','mount-load-secured','cal-open-mount'):
        assert token in html and token in js
    assert '/api/calibration/mount/start' in js
    assert "startsWith('8.2.')" in js
