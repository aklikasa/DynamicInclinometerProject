import math,time,threading
import pytest
from app.auto_dynamic import AutoDynamicWorkflow
from app.table_prepare import TablePreparation
from app.dynamic_experiment import limits

class FakeTable:
 def __init__(self, p=39.):
  self.connected=True;self.cmds=[]
  self.a={i:dict(position_deg=p if i==0 else 17.,speed_dps=0,mode=2,enabled=False,zeroed=True,healthy=True,
                 in_place=True,upper_limit=False,lower_limit=False,driver_fault=False,over_speed=False) for i in (0,2)}
 def read_status(self):return {'connected':True,'axes':{str(i):dict(v) for i,v in self.a.items()}}
 def enable_axis(self,axis):self.cmds.append(('enable',axis));self.a[axis]['enabled']=True
 def move(self,axis,pos,speed):self.cmds.append(('move',axis,pos,speed));self.a[axis]['position_deg']=pos
 def find_zero(self,axis,speed,accel):self.cmds.append(('find_zero',axis));self.a[axis]['zeroed']=True;self.a[axis]['position_deg']=0
 def stop(self):self.cmds.append(('stop',))
 def stopped_verified(self,timeout=5):return True

class FakeEngine:
 def __init__(self):
  self.running=True;self.connected=True;self.source='serial';self.latest={'cal':{'roll':1}};self.cal_status='matched'
  self.cal_mode='ambient';self.cal={'mat':True};self.last_wall=time.time();self.stability=None;self.record_fp=None

class FakeDynamic:
 def __init__(self):
  self.running=False;self.state='idle';self.report_file=None;self.thread=None;self.commands=[]
 def status(self):return dict(running=self.running,state=self.state,error='',report_file=self.report_file,table_file='test_table.csv',imu_file='test_imu.csv',stopped_verified=True)
 def preflight(self,axis,output,sign,amp,freq,cycles,mounting_mode="x_outer",fixture_confirmed=False):
  self.commands.append(('preflight',axis,output,sign,amp,freq,cycles))
  return {'token':'dyn-token'}
 def start(self,token,ack):
  assert token=='dyn-token' and ack
  self.commands.append(('start',))
  self.running=True;self.state='swaying'
  def done():
   time.sleep(.1);self.state='completed';self.report_file='test_report.json';self.running=False
  self.thread=threading.Thread(target=done,daemon=True);self.thread.start()
 def heartbeat(self):return {'ok':True}
 def abort(self):self.running=False;self.state='invalid'

def test_adjustable_speed_not_hardcoded():
 t=FakeTable();prep=TablePreparation(t);tk=prep.preflight()['token']
 prep.start(tk,True,zero_speed_dps=3.5)
 prep.thread.join(8)
 assert prep.state=='ready',prep.error
 assert ('move',0,0,3.5) in t.cmds
 assert ('move',2,0,3.5) in t.cmds

@pytest.mark.parametrize('v',[0.0,0.1,5.01,float('nan'),float('inf')])
def test_invalid_zero_speed_rejected_before_motion(v):
 t=FakeTable();p=TablePreparation(t);token=p.preflight()['token']
 with pytest.raises(ValueError):p.start(token,True,zero_speed_dps=v)
 assert not t.cmds

def test_one_click_from_nonzero_completes():
 table=FakeTable(39.07);dynamic=FakeDynamic();prep=TablePreparation(table);engine=FakeEngine()
 auto=AutoDynamicWorkflow(table,engine,prep,dynamic)
 status=auto.start(2,'roll',1,.5,.02,3,4.0,True)
 assert status['running']
 end=time.time()+6
 while auto.running and time.time()<end:
  auto.heartbeat()
  engine.last_wall=time.time()
  time.sleep(.07)
 assert auto.state=='completed', auto.error
 assert auto.report_file=='test_report.json'
 assert ('enable',0) in table.cmds and ('enable',2) in table.cmds
 assert ('move',0,0.,4.0) in table.cmds
 assert ('move',2,0.,4.0) in table.cmds
 assert ('start',) in dynamic.commands

def test_no_ack_no_movement():
 table=FakeTable();auto=AutoDynamicWorkflow(table,FakeEngine(),TablePreparation(table),FakeDynamic())
 with pytest.raises(ValueError,match='现场'):auto.start(2,'roll',1,.5,.02,3,2,False)
 assert not table.cmds

def test_fault_no_movement():
 table=FakeTable();table.a[0]['driver_fault']=True
 auto=AutoDynamicWorkflow(table,FakeEngine(),TablePreparation(table),FakeDynamic())
 with pytest.raises(ValueError,match='故障'):auto.start(2,'roll',1,.5,.02,3,2,True)
 assert not table.cmds

def test_api_missing_hardware_rejected():
 from fastapi.testclient import TestClient
 from app.main import app
 with TestClient(app) as c:
  r=c.post('/api/auto-dynamic/start',json={'acknowledged':True,'zero_speed_dps':2.5,'amplitude_deg':2,'frequency_hz':.05,'cycles':3})
  assert r.status_code==400
  assert '连接' in r.json()['detail']
  v=c.get('/api/auto-dynamic/settings').json()
  assert .2 <=v['zero_speed_dps']<=5.
