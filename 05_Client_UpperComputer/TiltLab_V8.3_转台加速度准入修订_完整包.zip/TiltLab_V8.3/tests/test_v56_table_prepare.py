import time
import pytest
from app.table_prepare import TablePreparation

class FakeTable:
    def __init__(self,position0=.3,position2=-.2,zeroed=True,enabled=False):
        self.connected=True
        self.data={a: {'position_deg':p,'speed_dps':0.,'mode':2,'enabled':enabled,
             'zeroed':zeroed,'healthy':True,'in_place':True,'upper_limit':False,
             'lower_limit':False,'driver_fault':False,'over_speed':False}
             for a,p in [(0,position0),(2,position2)]}
        self.cmds=[]
    def read_status(self):return {'connected':self.connected,'axes':{str(a):dict(s) for a,s in self.data.items()}}
    def enable_axis(self,a):self.cmds.append(('enable',a));self.data[a]['enabled']=True
    def find_zero(self,a,speed,accel):
        self.cmds.append(('find_zero',a));self.data[a]['zeroed']=True;self.data[a]['position_deg']=0.
    def move(self,a,p,s):
        self.cmds.append(('move',a,p,s));self.data[a]['position_deg']=p
    def stop(self):self.cmds.append(('stop',))
    def stopped_verified(self,timeout=5):return True


def test_preflight_is_readonly_requires_confirmation():
    t=FakeTable();p=TablePreparation(t)
    r=p.preflight();assert r['token'] and t.cmds==[]
    with pytest.raises(ValueError,match='现场'):p.start(r['token'],False)
    assert t.cmds==[]


def test_enable_and_return_zero_both_axes():
    t=FakeTable();p=TablePreparation(t);r=p.preflight();p.start(r['token'],True)
    p.thread.join(10)
    assert not p.running and p.verified and p.state=='ready',p.error
    assert t.cmds[:2]==[('enable',0),('enable',2)]
    assert ('move',0,0.,2.0) in t.cmds and ('move',2,0.,2.0) in t.cmds
    assert all(abs(x['position_deg'])<.06 for x in t.data.values())


def test_unzeroed_sends_findzero_sequentially():
    t=FakeTable(zeroed=False);p=TablePreparation(t);r=p.preflight();p.start(r['token'],True)
    p.thread.join(10)
    assert p.verified,p.error
    assert [x for x in t.cmds if x[0]=='find_zero']==[('find_zero',2),('find_zero',0)]


def test_far_angle_can_preflight_without_moving():
    t=FakeTable(position0=39.,position2=17.)
    p=TablePreparation(t)
    r=p.preflight()
    assert r['axes']['0']['position_deg']==39.
    assert r['movement_plan'][0]['estimated_travel_deg']==39.
    assert not t.cmds


def test_fault_rejected_without_commands():
    t=FakeTable();t.data[0]['driver_fault']=True
    p=TablePreparation(t)
    with pytest.raises(ValueError,match='驱动故障'):p.preflight()
    assert not t.cmds


def test_expired_token_rejected():
    t=FakeTable();p=TablePreparation(t);r=p.preflight();p.valid_until=time.monotonic()-1
    with pytest.raises(ValueError,match='失效'):p.start(r['token'],True)
    assert t.cmds==[]


def test_failure_requests_stop():
    t=FakeTable();p=TablePreparation(t);r=p.preflight()
    def failure(a):raise RuntimeError('fake failure')
    t.enable_axis=failure
    p.start(r['token'],True);p.thread.join(5)
    assert p.state=='failed' and not p.verified
    assert ('stop',) in t.cmds


def test_api_requires_hardware():
    from fastapi.testclient import TestClient
    from app.main import app
    with TestClient(app) as c:
        res=c.post('/api/turntable/prepare/preflight')
        assert res.status_code==400
        assert '连接' in res.json()['detail']


def test_enable_only_independent_of_current_position():
    t=FakeTable(position0=39.07,position2=17.06,enabled=False)
    p=TablePreparation(t)
    token=p.preflight()['token']
    p.start(token,True,only_enable=True)
    p.thread.join(10)
    assert p.state=='enabled_only',p.error
    assert p.verified is False  # not homed / zero-position verified
    assert t.cmds==[('enable',0),('enable',2)]

def test_unhealthy_while_disabled_can_enable_then_verify():
    t=FakeTable(position0=39.,position2=17.,enabled=False)
    for x in t.data.values():x['healthy']=False
    def enabling(a):
        t.cmds.append(('enable',a))
        t.data[a]['enabled']=True
        t.data[a]['healthy']=True
    t.enable_axis=enabling
    p=TablePreparation(t)
    token=p.preflight()['token']
    p.start(token,True,only_enable=True)
    p.thread.join(10)
    assert p.state=='enabled_only',p.error

def test_far_zero_position_timeout_is_not_fixed_30s():
    t=FakeTable(position0=39.,position2=17.,enabled=False)
    p=TablePreparation(t)
    p.start(p.preflight()['token'],True)
    p.thread.join(15)
    assert p.verified,p.error
    assert ('move',0,0.,2.0) in t.cmds
