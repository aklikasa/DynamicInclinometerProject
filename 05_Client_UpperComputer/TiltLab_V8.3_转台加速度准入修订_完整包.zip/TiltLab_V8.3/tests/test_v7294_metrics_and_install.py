"""V7.29.4: offline numerical correctness and installer contract. No hardware I/O."""
import math
from pathlib import Path
import numpy as np
import pytest
from app.analysis import calculate
from app.dynamic_experiment import imu_sample_quality

ROOT=Path(__file__).resolve().parents[1]


def test_p95_matches_real_dynamic_linear_percentile():
    # The historical nearest-low-rank order statistic incorrectly returned 0.
    values=[0.]*19+[10.]
    result=calculate(values,[0.]*20)
    assert result['p95']==pytest.approx(float(np.percentile(np.abs(values),95)))
    assert result['p95']==pytest.approx(0.5)
    assert result['rmse']==pytest.approx(math.sqrt(5.))


def test_analysis_rejects_invalid_reference_samples_without_fake_score():
    assert calculate([1.,float('nan')],[0.,0.]) is None
    assert calculate([1.,2.],[0.,float('inf')]) is None
    assert calculate([1.,None],[0.,0.]) is None
    assert calculate([] ,[]) is None
    assert calculate([2.],[0.])['p95']==2.


def test_sampling_diagnostics_refuse_non_monotone_device_clock():
    rows=[{'device_t_s':t,'imu_nominal_odr_hz':833} for t in (0.,.0012,.0012,.0036)]
    out=imu_sample_quality(rows)
    assert out['available'] is False
    assert out['device_nonmonotonic_steps']==1
    assert '时间戳' in out['reason']


def test_sampling_diagnostics_normal_clock_is_unchanged():
    rows=[{'device_t_s':i/100.,'imu_nominal_odr_hz':100} for i in range(100)]
    out=imu_sample_quality(rows)
    assert out['available']
    assert out['recorded_average_hz']==100.
    assert out['nominal_sample_coverage_pct']==100.


def test_v730_installer_does_not_force_r10_on_core_startup():
    from tools import setup_v730 as installer
    core={r.name for r in installer.requirements('core')}
    r10={r.name for r in installer.requirements('r10')}
    assert 'fastapi' in core and 'websockets' in core
    assert 'PySide6' not in core and 'python-snap7' not in core
    assert {'openpyxl','xlsxwriter'}.issubset(r10)
    import sys
    if sys.platform=='win32':
        assert 'PySide6' in r10
        assert 'python-snap7' not in r10
        assert 'python-snap7' in {r.name for r in installer.requirements('plc')}


def test_v730_installer_skips_network_if_environment_ready(monkeypatch,tmp_path):
    from tools import setup_v730 as installer
    monkeypatch.setattr(installer,'audit',lambda mode,output: [])
    def forbidden(*a,**kw):raise AssertionError('Should never call pip/network when ready')
    monkeypatch.setattr(installer.subprocess,'Popen',forbidden)
    assert installer.main(['--mode','core','--log',str(tmp_path/'log.txt')]) == 0


def test_v730_installer_read_only_check_does_not_use_pip(monkeypatch,tmp_path):
    from tools import setup_v730 as installer
    fake=installer.Requirement('pyserial>=3.5,<4')
    monkeypatch.setattr(installer,'audit',lambda mode,output: [fake])
    def forbidden(*a,**kw):raise AssertionError('Check must not attempt install')
    monkeypatch.setattr(installer.subprocess,'Popen',forbidden)
    assert installer.main(['--check','--mode','core','--log',str(tmp_path/'log.txt')]) == 1


def test_v730_installer_has_bounded_retry_and_one_pip_process(monkeypatch,tmp_path):
    from tools import setup_v730 as installer
    fake=installer.Requirement('pyserial>=3.5,<4')
    calls=[]
    def audit(mode,output):return [fake] if not calls else []
    monkeypatch.setattr(installer,'audit',audit)
    class Pipe:
        stdout=['Collecting pyserial\n','Successfully installed pyserial\n']
        def __enter__(self):return self
        def __exit__(self,*args):return False
        def wait(self):return 0
    monkeypatch.setattr(installer.subprocess,'Popen',lambda cmd,**kw:(calls.append(cmd) or Pipe()))
    assert installer.main(['--mode','core','--log',str(tmp_path/'log.txt')])==0
    assert len(calls)==1
    assert '--timeout' in calls[0] and '25' in calls[0]
    assert '--retries' in calls[0] and '1' in calls[0]
    assert '--only-binary=:all:' in calls[0]


def test_v730_windows_scripts_have_crlf_and_valid_label_layout():
    import re
    for script in ('INSTALL_DEPENDENCIES_DEBUG.cmd','INSTALL_DEPENDENCIES.bat',
                   'INSTALL_DEPENDENCIES_MIRROR.bat','INSTALL_R10_CALIBRATION.bat',
                   'INSTALL_R10_CALIBRATION_MIRROR.bat','START_TILT_LAB.bat'):
        raw=(ROOT/script).read_bytes()
        assert b'\r\n' in raw and raw.replace(b'\r\n',b'').find(b'\n')==-1
        text=raw.decode('utf-8')
        assert not re.search(r'if not errorlevel 1 set .* & goto ',text),script
        labels=re.findall(r'^:([A-Z_]+)\s*$',text,re.M)
        assert len(labels)==len(set(labels))
        assert all(name in labels for name in re.findall(r'(?m)\bgoto ([A-Z_]+)\s*$',text))
