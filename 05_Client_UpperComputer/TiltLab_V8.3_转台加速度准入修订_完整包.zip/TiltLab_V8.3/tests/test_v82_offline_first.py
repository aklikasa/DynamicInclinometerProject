"""V8.2 offline-first tests; NO physical motor commands are issued."""
from dataclasses import asdict
from pathlib import Path
import math
from app.engine import Workstation
from app.replay_v712 import replay_missing
from app.fusion import Params, FILTERS
from app.sst810_plan import cases
from app import main


def test_offline_is_default_and_does_not_fuse_samples():
    ws=Workstation()
    assert ws.pipeline_mode=='offline'
    ws.source='serial'
    ws.process({'t':0.,'acc':[0,0,1.],'gyro':[0,0,0], 'temp':25.,'odr':833},host_est_ns=1000000000,observed_ns=1000000000)
    assert ws.latest['outputs']=={}
    assert ws.latest['cal'] is None
    assert ws.latest['raw'] is None
    assert ws.latest['gyro']==[0,0,0]
    assert ws.latest['acc']==[0,0,1]
    assert ws.latest['pc_observed_ns']==1000000000
    assert ws.counter==1


def test_optional_realtime_is_single_algorithm_only():
    ws=Workstation()
    ws.set_pipeline_mode('realtime')
    ws.source='serial'
    ws.process({'t':0.,'acc':[0,0,1.],'gyro':[0,0,0], 'temp':25.,'odr':833},host_est_ns=1000000000,observed_ns=1000000000)
    assert set(ws.latest['outputs'])=={ws.active,'accel'}
    assert ws.latest['raw'] is not None


def test_offline_replay_computes_all_algorithms_without_reference_data():
    rows=[]
    for k in range(3):
        row={'imu_dt_s':0.0012 if k else 0.,'gap_action':'offline_no_fusion','gap_reset':0,'alignment_active':0}
        for ch in ('raw','cal'):
            for name,unit,v in [('acc','g',(0.,0.,1.)),('gyro','dps',(0.,0.,0.))]:
                row.update({f'{ch}_{name}_{axis}_{unit}':v[i] for i,axis in enumerate('xyz')})
        rows.append(row)
    replayed,info=replay_missing(rows,asdict(Params()),None,None)
    assert not info['realtime_algorithms']
    assert set(info['offline_algorithms'])==set(FILTERS)
    assert 'cal_gyro_anchor_roll' in replayed[0]
    assert 'cal_accel_pitch' in replayed[0]
    assert 'cal_gyro_anchor_roll' not in rows[0]


def test_sst810_reference_cases_and_hardware_limit_are_not_silently_overridden():
    cs=cases()
    assert len(cs)==10
    assert [(r['amplitude_deg'],r['frequency_hz']) for r in cs]==[
        (1.,.3),(1.,.5),(1.,.8),(2.,.3),(2.,.5),(2.,.8),
        (3.,.3),(3.,.5),(4.,.1),(4.,.3)]
    blocked=[r for r in cs if not r['software_preflight_allowed']]
    assert len(blocked)==1 and blocked[0]['id']==6
    assert blocked[0]['peak_accel_dps2']>50
    assert math.isclose(cs[-2]['peak_accel_dps2'],(2*math.pi*.1)**2*4,rel_tol=1e-4)


def test_ui_static_precheck_off_and_mode_offline_by_default():
    html=(Path(main.ROOT)/'web'/'index.html').read_text(encoding='utf-8')
    assert 'id="auto-static-before" type="checkbox"/>' in html
    assert '<option value="offline" selected>' in html
    assert 'id="v82-live-chart"' in html
    assert 'id="sst810-case-rows"' not in html
    assert html.index('id="pipeline-mode"') < html.index('id="exp-device"')
    assert 'id="v82-auto-ready-hint"' in html


def test_readonly_endpoints_no_motor_commands(monkeypatch):
    monkeypatch.setattr(main.DYNAMIC_TEST,'running',False)
    monkeypatch.setattr(main.DYNAMIC_TEST,'latest_feedback',None)
    result=main.dynamic_live_snapshot()
    assert result['reference_angle_deg'] is None
    assert result['mode'] in ('offline','realtime','research')
    cases_result=main.dynamic_sst810_cases()
    assert len(cases_result['cases'])==10
