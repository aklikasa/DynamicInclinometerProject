"""V7.8.2: phase-independent gate and conservative missing-reference rules."""
import numpy as np
from app.steady_state import find_sway_steady_start


def make_signal(freq=.3,cycles=10,phase=.5,with_gap=False,late_ramp=False):
    start=100.;period=1/freq;end=start+cycles*period
    ts=np.arange(start-2.,end+.03,.10)
    if with_gap:
        # Realistic isolated 545 ms stale feedback that must never be filled.
        ts=ts[(ts<start+18.)|(ts>start+18.545)]
    def position(t):
        if t<start:return 0.
        c=(t-start)/period
        env=min(1.,max(0.,(c+.45)/(6 if late_ramp else 3)))
        return 5.*env*np.sin(2*np.pi*freq*(t-start)+phase)
    return ts,np.array([position(t) for t in ts]),start,end


def test_offset_phase_and_ramp_still_find_independent_steady_interval():
    ts,p,start,end=make_signal(phase=1.43)
    d=find_sway_steady_start(ts,p,start,end,.3,5.)
    assert d['valid'],d
    assert d['steady_start_s']>start+3/.3
    assert d['steady_start_s']<end-1/.3
    assert d['phase_offset_s']>=0


def test_isolated_545ms_gap_does_not_require_every_cycle_to_be_perfect():
    ts,p,start,end=make_signal(with_gap=True,phase=.78)
    d=find_sway_steady_start(ts,p,start,end,.3,5.)
    assert d['valid'],d
    # The gate detects motion without silently declaring sparse reference valid;
    # the downstream data-quality layer decides whether 3% loss is acceptable.
    assert d['stable_missing_reference_pct']>0


def test_real_amplitude_mismatch_must_not_be_approved():
    ts,p,start,end=make_signal()
    d=find_sway_steady_start(ts,p*.7,start,end,.3,5.)
    assert not d['valid']


def test_short_motion_cannot_claim_full_steady_state():
    ts,p,start,end=make_signal(cycles=2)
    d=find_sway_steady_start(ts,p,start,end,.3,5.)
    assert not d['valid']
