from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app, WEB


def test_integrated_version_and_no_cache():
    with TestClient(app) as c:
        meta=c.get('/api/meta').json()
        assert meta['version'].startswith('8.1.')
        html=c.get('/')
        assert html.status_code == 200
        assert 'no-store' in html.headers.get('cache-control','')
        for field in ('v58-table-port', 'v58-imu-port', 'prep-preflight', 'prep-start', 'prep-enable', 'dyn-preflight','dyn-start','dyn-stop'):
            assert f'id="{field}"' in html.text


def test_new_launcher_uses_independent_port():
    path=WEB.parent
    assert 'PORT=8877' in (path/'run.py').read_text(encoding='utf-8')
    assert '127.0.0.1:8877' in (path/'启动上位机.bat').read_text(encoding='utf-8-sig')
    assert 'TiltLab V8.1.0' in (WEB/'index.html').read_text(encoding='utf-8')


def test_without_hardware_no_motion_preflight_allowed():
    with TestClient(app) as c:
        p=c.post('/api/turntable/prepare/preflight')
        assert p.status_code==400
        d=c.post('/api/dynamic/preflight',json={'axis':0,'output':'roll','sign':1,'amplitude_deg':0.5,'frequency_hz':0.02,'cycles':3})
        assert d.status_code==400
        state=c.get('/api/dynamic/status').json()
        assert state['running'] is False
