"""Research-only numeric and API tests; no COM ports, turntable DLL motion, or hardware."""
import math
import numpy as np
from fastapi.testclient import TestClient

from app.mount_axis_precheck import diagnose_mount_axis
from app.main import app


def mock_gyro(output='roll', error_deg=.7, seed=72):
    rng=np.random.default_rng(seed)
    baseline=np.array([.02,-.03,.01])
    stationary=[]
    for j in range(14):
        stationary.append({'count':1000,'mean':(baseline+rng.normal(0,.003,3)).tolist(),
                           'std':[.06,.06,.06]})
    e=math.radians(error_deg)
    shaft=np.array([math.cos(e),math.sin(e),0.]) if output=='roll' else np.array([math.sin(e),math.cos(e),0.])
    signal=rng.uniform(-2.5,2.5,5000)
    moving=baseline+signal[:,None]*shaft[None,:]+rng.normal(0,.06,(len(signal),3))
    return stationary,moving.tolist()


def test_small_alignment_roll_passes():
    stationary,moving=mock_gyro('roll',.75)
    d=diagnose_mount_axis('roll',stationary,moving)
    assert d['valid'] and d['pass_for_dynamic'] and not d['correction_applied']
    assert abs(d['misalignment_deg']-.75)<.25
    assert d['expected_gyro_axis']=='X'


def test_pitch_axis_opposite_gyro_sign_passes():
    stationary,moving=mock_gyro('pitch',.4)
    base=np.array([.02,-.03,.01]);moving=(2*base-np.array(moving)).tolist()
    d=diagnose_mount_axis('pitch',stationary,moving)
    assert d['pass_for_dynamic'] and d['valid']
    assert abs(d['misalignment_deg']-.4)<.25
    assert d['expected_gyro_axis']=='Y'


def test_wrong_mount_axis_refused():
    stationary,moving=mock_gyro('roll',5.0)
    d=diagnose_mount_axis('roll',stationary,moving)
    assert d['valid'] and not d['pass_for_dynamic']
    assert d['misalignment_deg']>4.5


def test_uninformative_slow_movement_fails_closed():
    stationary,moving=mock_gyro('roll',.2)
    baseline=np.array([.02,-.03,.01]);rng=np.random.default_rng(15)
    moving=(baseline+rng.normal(0,.06,(len(moving),3))).tolist()
    d=diagnose_mount_axis('roll',stationary,moving)
    assert not d['pass_for_dynamic']
    assert not d['valid']


def test_factory_files_location_api_is_read_only():
    with TestClient(app) as c:
        d=c.get('/api/calibration/paths').json()
        assert 'settings_file' in d and 'fixture_report_folder' in d
        assert 'matched_factory_files' in d
        assert 'calibration_folder' in d


def test_static_measurement_collector_cleanup_on_error(tmp_path):
    from app.static_accuracy import StaticBeforeDynamic
    class BadTable:
        def read_status(self):raise RuntimeError('controller disconnect')
    class FakeEngine:
        uid='DTS000000';active='mahony';cal_mode='ambient'
        def __init__(self):
            import threading,collections
            self.lock=threading.RLock();self.recent=collections.deque(maxlen=3000);self.counter=0
    st=StaticBeforeDynamic(BadTable(),FakeEngine(),tmp_path)
    import pytest
    with pytest.raises(RuntimeError,match='controller disconnect'):
        st.run('roll',0,1,2,.1,lambda:None)
    assert not st._collect_mount_gyro and st._mount_gyro_moving==[]
