"""Synthetic physics and API gates. No real motion or devices."""
import csv, io, json, math
import numpy as np
import pytest
from app.lever_identification import identify,bundles,G
from app.fusion import Params,Madgwick,create_filter,FILTERS
from app.lever3d import RigidLever3D

R=np.array([.035,-.045,.195])
def csvbytes(fields,rows):
    f=io.StringIO();w=csv.writer(f);w.writerow(fields);w.writerows(rows);return f.getvalue().encode()
def sample(direction,f,tag='',gap=False):
    w=2*math.pi*f; end=7/f; a0=math.radians(5); t0=100.;t=np.arange(-3,end+.1,.01)
    if gap:t=t[(t<8)|(t>8.2)]
    angle=np.where(t>=0,a0*np.sin(w*t),0);vel=np.where(t>=0,a0*w*np.cos(w*t),0);acc=np.where(t>=0,-a0*w*w*np.sin(w*t),0)
    axis=np.array([1,0,0]) if direction=='roll' else np.array([0,1,0]);base=np.array([0,0,1]);grav=base*np.cos(angle[:,None])-np.cross(axis,base)*np.sin(angle[:,None]);om=vel[:,None]*axis;al=acc[:,None]*axis
    force=grav+(np.cross(al,R)+np.cross(om,np.cross(om,R)))/G
    name=f'{direction}_{f}_{tag}_DYNAMIC';tn=name+'_table.csv';an=name+'_imu.csv'
    table=csvbytes(['pc_mid_ns','axis_2_pos','axis_0_pos'],zip(((t+t0)*1e9).astype('int64'),np.rad2deg(angle),np.full(len(t),0 if direction=='roll' else 90)))
    imu=csvbytes(['host_est_ns','device_t_s','imu_nominal_odr_hz','uid']+[f'cal_acc_{j}_g' for j in 'xyz']+[f'cal_gyro_{j}_dps' for j in 'xyz'],[list(v) for v in zip(((t+t0)*1e9).astype('int64'),t,np.full(len(t),100.),['DTS000001']*len(t),*force.T,*np.rad2deg(om).T)])
    d={'kind':'REAL_2TD600_SINE_DIAGNOSTIC','uid':'DTS000001','calibration_mode':'ambient','calibration_files':['ACC.json','GYRO.json'],'plan':{'axis':2,'output':direction,'frequency_hz':f,'amplitude_deg':5,'cycles':7,'sign':1,'mounting_mode':'x_outer' if direction=='roll' else 'y_inner_90'},'raw_file_table':tn,'raw_file_imu':an,'motion_start_pc_monotonic_ns':int(t0*1e9),'motion_end_pc_monotonic_ns':int((t0+end)*1e9),'stopped_verified':True,'motion_period_collected':True,'analysis':{'clock_diagnostics':{'host_clock_error_p95_abs_s':0.}}}
    return name+'.json',d,table,imu

def test_single_axis_unobservable_and_no_apply():
    r=identify([sample('pitch',.3)])
    assert r['rank']==2 and r['candidate_cm'][1] is None
    assert r['candidate_cm'][2]==pytest.approx(19.5,abs=.15)
    assert not r['eligible_for_session_apply']

def test_joint_fit_independent_validation_recovers_geometry():
    train=[sample(d,f) for d in ('roll','pitch') for f in (.1,.2)]
    hold=[sample(d,.3) for d in ('roll','pitch')]
    r=identify(train,hold)
    assert r['rank']==3
    assert np.allclose(r['candidate_cm'],R*100,atol=.2),r
    assert r['eligible_for_session_apply'],r['reasons']
    for row in r['runs']:
        assert row['amplitude_error_after_deg'] < row['amplitude_error_before_deg']

def test_duplicate_and_gap_gate():
    b=sample('pitch',.3)
    with pytest.raises(ValueError,match='重复'):identify([b],[b])
    r=identify([sample('pitch',.3,gap=True)])
    assert not r['eligible_for_session_apply']
    assert any('间隔' in x for x in r['runs'][0]['issues'])

def test_zero_and_raw_identical_to_madgwick_and_gap_resets():
    p=Params(lever3_z_cm=19.5);raw=create_filter('lever3d',p,calibrated=False);m=Madgwick(p)
    zero=create_filter('lever3d',Params());m0=Madgwick(Params())
    for i in range(30):
        a=[.01,0,1];g=[0,1,0]
        assert raw.update(a,g,.01)['q']==m.update(a,g,.01)['q']
        assert zero.update(a,g,.01)['q']==m0.update(a,g,.01)['q']
    c=RigidLever3D(R)
    for i in range(60):c.update([0,0,1],[i*.1,0,0],.01)
    assert c.ready
    assert c.update([0,0,1],[1,0,0],.2)==(0.,0.,1.) and not c.ready and c.gaps==1

def test_api_rejects_unverified_application_and_direct_nonzero():
    from fastapi.testclient import TestClient
    from app.main import app
    c=TestClient(app)
    assert c.post('/api/lever-identify/apply',json={'profile_id':'invalid','same_fixture_confirmed':True}).status_code==400
    assert c.post('/api/config',json={'params':{'lever3_z_cm':19.5}}).status_code==400
    b=sample('pitch',.3);name,d,tb,ib=b
    r=c.post('/api/lever-identify/fit',files=[('files',(name,json.dumps(d).encode())),('files',(d['raw_file_table'],tb)),('files',(d['raw_file_imu'],ib))]);assert r.status_code==200,r.text
    assert not r.json()['eligible_for_session_apply']
    assert c.post('/api/lever-identify/apply',json={'profile_id':r.json()['profile_id'],'same_fixture_confirmed':True}).status_code==400


def test_verified_profile_applies_only_to_matching_session(monkeypatch,tmp_path):
    import app.main as main
    import app.engine as engine_module
    from fastapi.testclient import TestClient
    lab=engine_module.Workstation();lab.connected=True;lab.source='serial';lab.uid='DTS000001';lab.cal_status='matched';lab.cal={'files':['ACC.json','GYRO.json']}
    monkeypatch.setattr(main,'ENGINE',lab);monkeypatch.setattr(engine_module,'SETTINGS_FILE',tmp_path/'settings.json')
    profile={'profile_id':'test','eligible_for_session_apply':True,'uid':'DTS000001','calibration_mode':'ambient','calibration_files':['ACC.json','GYRO.json'],'candidate_cm':[3.5,-4.5,19.5]}
    monkeypatch.setattr(main,'LEVER_RESULT',profile)
    c=TestClient(main.app)
    assert c.post('/api/lever-identify/apply',json={'profile_id':'test','same_fixture_confirmed':False}).status_code==400
    lab.uid='wrong';assert c.post('/api/lever-identify/apply',json={'profile_id':'test','same_fixture_confirmed':True}).status_code==400
    lab.uid='DTS000001';r=c.post('/api/lever-identify/apply',json={'profile_id':'test','same_fixture_confirmed':True});assert r.status_code==200,r.text
    assert lab.params.lever3_z_cm==19.5 and lab.active=='lever3d'
    assert 'lever3_z_cm' not in json.loads((tmp_path/'settings.json').read_text())['params']
    lab.stop();assert lab.params.lever3_z_cm==0 and lab.active=='madgwick'
