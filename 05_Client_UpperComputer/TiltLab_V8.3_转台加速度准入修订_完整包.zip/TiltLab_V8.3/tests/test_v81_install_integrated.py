"""No-device checks that the default V8.1 installer includes ambient R10."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('setup_v730_installer', ROOT/'tools'/'setup_v730.py')
installer=importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)


class InstallIntegration(unittest.TestCase):
    def test_standard_shortcuts_install_core_and_r10(self):
        for path in ('INSTALL_DEPENDENCIES.bat','安装依赖.bat','安装依赖_窗口常驻.cmd',
                     'INSTALL_DEPENDENCIES_MIRROR.bat'):
            text=(ROOT/path).read_text(encoding='utf-8')
            self.assertIn('--mode r10',text,path)
        self.assertIn('--mode core',(ROOT/'INSTALL_CORE_ONLY.bat').read_text(encoding='utf-8'))

    def test_merged_r10_scope_has_gui_but_no_plc(self):
        files=installer.REQUIREMENT_FILES['r10']
        self.assertIn('requirements-core.txt', files)
        self.assertIn('requirements-r10.txt', files)
        self.assertNotIn('requirements-plc.txt', files)
        self.assertIn('PySide6', (ROOT/'requirements-r10.txt').read_text(encoding='utf-8'))
        self.assertNotIn('snap7', (ROOT/'requirements-r10.txt').read_text(encoding='utf-8'))

    def test_no_network_when_installed(self):
        with tempfile.TemporaryDirectory() as tmp, \
             patch.object(installer,'audit',return_value=[]), \
             patch.object(installer.subprocess,'Popen',side_effect=AssertionError('Network should not be used')):
            self.assertEqual(installer.main(['--mode','r10','--log',str(Path(tmp)/'audit.log')]),0)

    def test_real_r10_import_smoketest_required_before_success(self):
        text=(ROOT/'INSTALL_DEPENDENCIES_DEBUG.cmd').read_text(encoding='utf-8')
        self.assertIn('r10_dependency_smoketest.py',text)
        self.assertIn('r10_worker_check.txt',text)
        self.assertIn('if errorlevel 1 goto FAILED_R10',text)
        smoke=(ROOT/'tools/r10_dependency_smoketest.py').read_text(encoding='utf-8')
        self.assertIn('PySide6.QtWidgets',smoke)
        self.assertNotIn('CDLL(',smoke)
        self.assertNotIn('serial.Serial(',smoke)
        self.assertIn(':FAILED_R10',text)
        for line in text.splitlines():
            if line.strip().upper().startswith('GOTO '):
                target=line.strip()[5:].strip().upper()
                self.assertIn(':'+target, text.upper())

    def test_installer_windows_crlf(self):
        for name in ('安装依赖.bat','安装依赖_窗口常驻.cmd','INSTALL_DEPENDENCIES_DEBUG.cmd',
                     'INSTALL_DEPENDENCIES.bat','INSTALL_DEPENDENCIES_MIRROR.bat',
                     'INSTALL_CORE_ONLY.bat','V8.1_只读检查环境.bat'):
            data=(ROOT/name).read_bytes()
            self.assertTrue(data.count(b'\r\n')>0,name)
            self.assertNotIn(b'\n',data.replace(b'\r\n',b''),name)


if __name__=='__main__': unittest.main()
