"""No hardware, simulator-only tests for V7.27 native DLL controls."""
from pathlib import Path
import threading
import time
import pytest
from fastapi.testclient import TestClient
from app import main
from app.native_axis_console_v727 import NativeAxisConsole

BASE=Path(__file__).parents[1]

class FakeHardware:
    connected=True
    def __init__(self):
        self.commands=[]
        self.zeroed={0:True,2:True}
        self.enabled={0:True,2:True}
        self.position={0:0.,2:0.}
        self.stops=0
        self.lock=threading.RLock()
    def read_status(self):
        with self.lock:
            return {'time_monotonic_ns':time.monotonic_ns(), 'axes':{
                str(axis):{'healthy':True,'enabled':self.enabled[axis],
                  'zeroed':self.zeroed[axis], 'in_place':True,
                  'driver_fault':False,'upper_limit':False,'lower_limit':False,
                  'over_speed':False,'position_deg':self.position[axis],
                  'speed_dps':0.,'mode':0}
                for axis in (0,2)}}
    def enable_axis(self,axis):
        self.commands.append(('enable',axis));self.enabled[axis]=True
    def velocity(self,axis,speed,accel):self.commands.append(('velocity',axis,speed,accel))
    def sway(self,axis,amp,freq):self.commands.append(('sway',axis,amp,freq))
    def find_zero(self,axis,speed,accel):
        self.commands.append(('home',axis,speed,accel));self.zeroed[axis]=True
    def stop(self):self.stops+=1
    def stopped_verified(self,timeout=20):return True

def test_all_independent_axis_controls_are_really_wired():
    html=(BASE/'web/index.html').read_text('utf-8')
    js=(BASE/'web/turntable-native-v727.js').read_text('utf-8')
    assert 'turntable-native-v727.js' in html and 'turntable-native-v727.css' in html
    for label in ('使能','断使能','速度运动','正弦摇摆','机械找零','停止'):
        assert label in js
    for endpoint in ('/api/turntable/console/enable','/api/turntable/console/disable',
                     '/api/turntable/console/start','/api/turntable/console/stop-axis',
                     '/api/turntable/manual/command'):
        assert endpoint in js or endpoint=='/api/turntable/manual/command' and endpoint in (BASE/'web/integrated-console-v725.js').read_text('utf-8')
    assert 'SetAxisVelocity' in (BASE/'app/turntable.py').read_text('utf-8')

def test_vendor_speed_motion_calls_real_adapter_and_stops():
    t=FakeHardware();c=NativeAxisConsole(t,lambda:False)
    r=c.start(2,'velocity',speed=1.0,accel=.5,duration=.5)
    assert r['running']
    c.thread.join(3)
    assert ('velocity',2,1.,.5) in t.commands
    assert not c.running and c.stopped_verified is True
    assert t.stops>0

def test_vendor_sway_calls_adapter_and_stop():
    t=FakeHardware();c=NativeAxisConsole(t,lambda:False)
    c.start(2,'sway',amp=5.,freq=.3,duration=1.)
    c.thread.join(3)
    assert ('sway',2,5.,.3) in t.commands
    assert c.stopped_verified is True

def test_per_axis_home_calls_vendor_find_zero():
    t=FakeHardware();t.zeroed[0]=False
    c=NativeAxisConsole(t,lambda:False)
    c.start(0,'home',speed=.3,accel=.3,duration=7.)
    c.thread.join(3)
    assert ('home',0,.3,.3) in t.commands
    assert c.state=='finished' and c.stopped_verified is True

def test_invalid_and_unsupported_modes_do_not_reach_hardware():
    t=FakeHardware();c=NativeAxisConsole(t,lambda:False)
    bad=[(2,'velocity',{'speed':0,'accel':.5,'duration':3}),
         (2,'velocity',{'speed':float('inf'),'accel':.5,'duration':3}),
         (2,'velocity',{'speed':4,'accel':0,'duration':15}),
         (2,'velocity',{'speed':4,'accel':.5,'duration':16}),
         (2,'sway',{'amp':30.,'freq':.3,'duration':6}),
         (2,'home',{'speed':1.,'accel':1.,'duration':60})]
    for axis,mode,kwargs in bad:
        with pytest.raises(ValueError):c.start(axis,mode,**kwargs)
    assert not t.commands

def test_concurrent_task_and_missing_table_rejected():
    t=FakeHardware();c=NativeAxisConsole(t,lambda:True)
    with pytest.raises(ValueError):c.start(2,'sway',amp=5.,freq=.3,duration=2.)
    assert not t.commands
    c2=NativeAxisConsole(t,lambda:False)
    t.connected=False
    with pytest.raises(ValueError):c2.enable_axis(0)

def test_home_requires_live_heartbeat():
    t=FakeHardware();t.zeroed[0]=False
    # Never reports homed, so guard must STOP on heartbeat expiry.
    def fake_home(axis,speed,accel):t.commands.append(('home',axis,speed,accel))
    t.find_zero=fake_home
    c=NativeAxisConsole(t,lambda:False)
    c.start(0,'home',speed=.3,accel=.3,duration=9.)
    with c.lock:c.heartbeat_ns=time.monotonic_ns()-7_000_000_000
    c.thread.join(3)
    assert c.state=='failed' and c.stopped_verified is True and t.stops>0

def test_new_apis_refuse_hardware_without_connection():
    client=TestClient(main.app)
    assert client.get('/api/turntable/console/status').status_code==200
    assert client.post('/api/turntable/console/enable',json={'axis':0}).status_code==409
    assert client.post('/api/turntable/console/start',json={'axis':2,'mode':'velocity','speed_dps':1,'duration_s':3}).status_code==409
    assert client.post('/api/turntable/console/disable',json={'axis':0,'load_secured':False}).status_code in (400,409)

def test_console_start_is_one_click_and_never_sends_automatically_on_page_load(monkeypatch):
    calls=[]
    monkeypatch.setattr(main.CONSOLE,'start',lambda *a,**k: calls.append((a,k)) or {'running':True,'axis':a[0]})
    client=TestClient(main.app)
    assert not calls
    result=client.post('/api/turntable/console/start',json={'axis':2,'mode':'sway','amplitude_deg':5,'frequency_hz':.3,'duration_s':10})
    assert result.status_code==200 and calls[0][0]==(2,'sway')

def test_servo_disable_requires_independent_support():
    client=TestClient(main.app)
    response=client.post('/api/turntable/console/disable',json={'axis':0,'load_secured':False})
    assert response.status_code in (400,409)


def test_real_dll_velocity_signature_and_stop_axis_dispatch(monkeypatch):
    from app.turntable import Table2TD600
    table=Table2TD600()
    table.connected=True
    calls=[]
    monkeypatch.setattr(table,'_ensure',lambda axis:{'enabled':True,'zeroed':True})
    monkeypatch.setattr(table,'_call',lambda name,argtypes,restype,*args: calls.append((name,args)) or 1)
    table.velocity(2,-2.,1.)
    table.stop_axis(2)
    assert ('SetAxisVelocity',(2,-2.0,1.0)) in calls
    assert ('SetAxisStop',(2,)) in calls
