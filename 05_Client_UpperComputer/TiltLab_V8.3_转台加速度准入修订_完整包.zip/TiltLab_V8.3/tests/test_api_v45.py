import json
from fastapi.testclient import TestClient
from app.main import app


def test_calibration_inspect_endpoint_reports_matrix_numbers(tmp_path):
    uid='DTS872028'
    for kind,key in (('accel','raw_accel_bias_g'),('gyro','raw_gyro_bias_dps')):
        (tmp_path/f'{uid}_{kind}_calibration.json').write_text(json.dumps({
          'device_serial':uid,key:[0,0,0],
          'raw_to_platform_matrix':[[.1,0,0],[0,.1,0],[0,0,.1]]
        }))
    r=TestClient(app).post('/api/calibration/inspect',json={
       'path':str(tmp_path),'serial':uid,'mode':'ambient'})
    assert r.status_code==200,r.text
    body=r.json()
    assert body['status']=='matched'
    assert body['applied'] is False
    assert len(body['matrix_diagnostics'])==2


def test_index_includes_diagnostic_panel_and_light_theme():
    with TestClient(app) as client:
        html=client.get('/').text
        assert 'id="cal-matrix-diagnostics"' in html
        assert '/assets/clarity-v45.css' in html
        css=client.get('/assets/clarity-v45.css')
        assert css.status_code==200
        assert 'background:#f7f8f9' in css.text
