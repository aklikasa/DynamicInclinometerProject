import csv,json
from types import SimpleNamespace
from pathlib import Path
import numpy as np
import pytest
from app.pre_research import assess,continuity_details,StaticContinuityError,capture_with_retry
from app.research_optimizer import replay,verified_seed,time_variants
from test_v66_dual_axis import status,FakeTable,FakeEngine,_complete
from test_v720_deferred_reports import FakeDeferred
from app.auto_dynamic import AutoDynamicWorkflow
from app.table_prepare import TablePreparation


def rows(n=601):
    return [dict(sequence=i+1,host_est_ns=100_000_000_000+i*5_000_000,batch_id=i//16,batch_index=i%16,acc_cal=[.0002,0,1.],gyro_cal=[.004,-.006,.002]) for i in range(n)]

def seam_rows():
    r=rows()
    for v in r[16:]:v['host_est_ns']+=12_000_000
    return r

def gap_error():
    return StaticContinuityError(continuity_details(seam_rows()))


def test_gap_threshold_preserved_and_retryable_only_batch_boundary():
    r=seam_rows()
    with pytest.raises(StaticContinuityError) as e:assess(r,3)
    assert e.value.retryable and e.value.details['gaps_over_10ms']==1 and e.value.details['max_gap_ms']==17
    r[16]['batch_index']=1
    with pytest.raises(StaticContinuityError) as e:assess(r,3)
    assert not e.value.retryable
    r=seam_rows();r[200]['gyro_cal']=[4,0,0]
    with pytest.raises(ValueError,match='质量'):assess(r,3)
    r=seam_rows();r[16]['sequence']+=1
    with pytest.raises(StaticContinuityError) as e:assess(r,3)
    assert not e.value.retryable


def test_bounded_retry_and_watch(monkeypatch):
    w=SimpleNamespace(_watch=lambda:None,table=SimpleNamespace(read_status=lambda:status(90,0)))
    attempts=[]
    def capture(*args):
        attempts.append(w.pre_research_attempt)
        if len(attempts)<3:raise gap_error()
        return {'state':'passed'}
    monkeypatch.setattr('app.pre_research.capture',capture)
    assert capture_with_retry(w,'pitch',90,60)['state']=='passed' and attempts==[1,2,3]
    attempts.clear()
    def fail(*args):attempts.append(w.pre_research_attempt);raise gap_error()
    monkeypatch.setattr('app.pre_research.capture',fail)
    with pytest.raises(StaticContinuityError):capture_with_retry(w,'pitch',90,60)
    assert attempts==[1,2,3]
    attempts.clear();w._watch=lambda:(_ for _ in ()).throw(RuntimeError('watchdog'))
    with pytest.raises(RuntimeError,match='watchdog'):capture_with_retry(w,'pitch',90,60)
    assert attempts==[1]


def test_position_error_no_retry(monkeypatch):
    w=SimpleNamespace(_watch=lambda:None,table=SimpleNamespace(read_status=lambda:status(90,.2)))
    def fail(*args):raise gap_error()
    monkeypatch.setattr('app.pre_research.capture',fail)
    with pytest.raises(RuntimeError,match='位置异常'):capture_with_retry(w,'pitch',90,60)
    assert w.pre_research_attempt==1


def test_seed_verified_from_prior_samples(tmp_path):
    r=rows(6001);v=assess(r,30)
    stem='20261118_000000_000000_TEST_ROLL_PRE_RESEARCH';p=tmp_path/(stem+'.csv');j=tmp_path/(stem+'.json')
    with p.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['sequence','host_est_ns','batch_id','batch_index',*[f'cal_acc_{k}_g' for k in 'xyz'],*[f'cal_gyro_{k}_dps' for k in 'xyz']]);w.writerows([[x['sequence'],x['host_est_ns'],x['batch_id'],x['batch_index'],*x['acc_cal'],*x['gyro_cal']] for x in r])
    meta={**v,'seed_applied':True,'output':'roll','requested_s':30,'raw_csv':p.name,'json_file':j.name,'samples_captured':len(r)};j.write_text(json.dumps(meta))
    report={'uid':'TEST','plan':{'output':'roll'},'pre_research':meta};end=r[-1]['host_est_ns']
    seed,why=verified_seed(tmp_path,report,end+1_000_000,r[-1]['sequence']+1)
    assert seed and seed['gyro_bias_dps']==pytest.approx([.004,-.006,.002])
    a=[[0,0,1.]]*400;g=[[.004,-.006,.002]]*400;dt=[0.]+[.005]*399
    full,_=replay(a,g,dt,3,1.5,seed=seed);short,_=replay(a[:200],g[:200],dt[:200],3,1.5,seed=seed)
    assert np.array_equal(full[:200],short)
    assert verified_seed(tmp_path,report,end-1,6002)[0] is None
    meta['gyro_bias_dps']=[1,0,0];assert verified_seed(tmp_path,report,end+1,6002)[0] is None


def test_time_variants_keep_pc_default_and_positive():
    d={'device_t_s':np.arange(32)*.0013,'batch_id':np.repeat([1,2],16),'batch_index':np.tile(np.arange(16),2),'imu_nominal_odr_hz':np.full(32,833.)}
    dt=np.r_[0.,np.full(31,.0012)];v=time_variants(d,dt)
    assert v['mcu_batch_uniform'][16:]==pytest.approx([.0013]*16)
    assert v['nominal_odr'][1]==pytest.approx(1/833)
    assert dt[16]==.0012


def test_partial_report_after_failed_pitch_no_more_motion(tmp_path,monkeypatch):
    class PartialDeferred(FakeDeferred):
        def finalize_deferred_reports(self):
            assert len(self.deferred_reports)==1 and self.table.a[0]['position_deg']==90
            assert ('stop',) in self.table.cmds
            self.finalized=True;name=self.deferred_reports[0];p=self.dir/name;r=json.loads(p.read_text());r['state']='completed';p.write_text(json.dumps(r));return {name:{'state':'completed','error':''}}
    t=FakeTable();e=FakeEngine();e.pipeline_mode='realtime';e.active='gyro_anchor';e.params=SimpleNamespace(lever_z_cm=0.);d=PartialDeferred(tmp_path,t);w=AutoDynamicWorkflow(t,e,TablePreparation(t),d)
    attempts=[]
    def capture(w,out,inner,seconds):
        attempts.append((out,w.pre_research_attempt))
        if out=='pitch':raise gap_error()
        w.pre_research_results.append({'output':out,'state':'passed','seed_applied':True})
    monkeypatch.setattr('app.pre_research.capture',capture)
    w.start(2,'both',1,5,.2,15,2,True,'xy_sequential',True,pre_research=True,research_diagnostics=True,research_optimize=True);_complete(w,e,timeout=30)
    assert w.state=='stopped_or_failed' and w.stopped_verified and not w.motion_completed and not w.report_completed
    assert d.finalized and w.report_file=='roll_DYNAMIC.json' and len(w.stages)==1
    assert attempts==[('roll',1),('pitch',1),('pitch',2),('pitch',3)]
    assert not any(c[0]=='sway_stage' and c[1]=='pitch' for c in t.cmds)
