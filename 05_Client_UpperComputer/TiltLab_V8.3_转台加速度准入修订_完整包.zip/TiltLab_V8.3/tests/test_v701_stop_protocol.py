"""Vendor STOP acknowledgement is not motion stop. Replay real failure shape.

These tests use ONLY fake telemetry and a virtual monotonic clock. No DLL/COM
or physical device interaction is possible.
"""
from types import SimpleNamespace
import math
from pathlib import Path
from app import turntable as tt


class SimTime:
    def __init__(self):self.t=0.0
    def monotonic(self):return self.t
    def sleep(self,n):self.t+=n

class TableRecorder(tt.Table2TD600):
    def __init__(self,clock,freeze=False):
        super().__init__();self.clock=clock;self.freeze=freeze
        self.connected=True;self.stop_commands=0
    def stop(self):
        self.stop_commands+=1
    def read_status(self):
        t=self.clock.t
        if self.freeze:
            pos=0.0002;speed=-1.552;mode=2
        elif self.stop_commands==0:
            pos=5*math.sin(2*math.pi*.3*t);speed=9.425*math.cos(2*math.pi*.3*t);mode=20
        elif self.stop_commands==1:
            pos=5*math.sin(2*math.pi*.3*t);speed=9.425*math.cos(2*math.pi*.3*t);mode=20
        else:
            # Second STOP took effect: rapid deceleration, then stable.
            settle=t-self.retry_time
            if settle<.5:
                pos=.3*(.5-settle);speed=-.6;mode=20
            else:pos=.0001;speed=0.;mode=2
        def a(x,v,m):
            return dict(position_deg=x,speed_dps=v,mode=m,in_place=m==2,
                        healthy=True,driver_fault=False,upper_limit=False,over_speed=False)
        return {'axes':{'0':a(.05,0.,2),'2':a(pos,speed,mode)}}


def test_persistent_oscillation_reissues_one_vendor_stop_and_verifies(monkeypatch):
    clock=SimTime()
    monkeypatch.setattr(tt,'time',clock)
    dev=TableRecorder(clock)
    def stop():
        dev.stop_commands+=1
        if dev.stop_commands==2:dev.retry_time=clock.t
    dev.stop=stop
    dev.stop()  # First ordinary vendor STOP was already issued.
    assert dev.stopped_verified(timeout=20) is True
    assert dev.stop_commands==2
    assert dev.last_stop_check['stop_retries']==1
    assert dev.last_stop_check['verified']
    assert dev.last_stop_check['samples'][-1]['elapsed_s']<8


def test_stationary_encoder_with_stale_nonzero_vendor_speed_must_fail(monkeypatch):
    clock=SimTime();monkeypatch.setattr(tt,'time',clock)
    dev=TableRecorder(clock,freeze=True)
    dev.stop()
    assert dev.stopped_verified(timeout=20) is False
    assert dev.stop_commands==1, 'stale speed alone must not trigger another command'
    assert dev.last_stop_check['verified'] is False
    assert len(dev.last_stop_check['samples'])>100


def test_mode20_and_zero_speed_but_moving_encoder_is_not_stop(monkeypatch):
    clock=SimTime();monkeypatch.setattr(tt,'time',clock)
    class Moving(TableRecorder):
        def read_status(self):
            d=super().read_status()
            d['axes']['2']['speed_dps']=0.
            d['axes']['2']['mode']=20
            return d
    dev=Moving(clock)
    def stop():
        dev.stop_commands+=1
        if dev.stop_commands==2:dev.retry_time=clock.t
    dev.stop=stop
    dev.stop()
    assert dev.stopped_verified(timeout=20) is True
    assert dev.stop_commands==2, 'movement must cause retry even if mode20 and speed0'
    assert dev.last_stop_check['verified']
