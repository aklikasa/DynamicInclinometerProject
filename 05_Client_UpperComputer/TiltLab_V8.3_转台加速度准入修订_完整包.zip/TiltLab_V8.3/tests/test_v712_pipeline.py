import csv,time,threading
from dataclasses import asdict
from app.acquisition_v712 import BatchClock
from app.engine import Workstation
from app.fusion import Params
from app.replay_v712 import replay_missing
from app import engine as mod
from app import main
from fastapi.testclient import TestClient

def batch(t,odr=833):
    return [dict(t=t-(15-i)/odr,odr=odr,reported_odr=0,acc=[0,0,1],gyro=[0,0,0],temp=25) for i in range(16)]

def test_causal_clock_originals_and_batch_overlap():
    c=BatchClock();a=c.stamp(batch(100.),1_000_000_000);b=c.stamp(batch(100.018),1_018_000_000)
    assert len(a)==len(b)==16 and c.repairs==1
    assert a[-1][1]<b[0][1]
    assert a[-1][0]['device_t_original']==100.
    assert b[0][0]['batch_shift_ms']>0
    assert b[-1][0]['reported_odr']==0
    assert b[-1][0]['timestamp_quality'].endswith('NOT_SYNC')

class FakeDevice:
    serial_no='MOCK';uid='MOCKHEX';last_odr=833;dropped_batches=0
    def __init__(self,*a):self.i=0;self.closed=False;self._pending_registers=[]
    def open(self):pass
    def close(self):self.closed=True
    def next_batch(self):
        time.sleep(.02);self.i+=1
        return batch(100+self.i*.024)

def test_real_threads_preserve_raw_and_selected_outputs(tmp_path,monkeypatch):
    monkeypatch.setattr(mod,'R10Device',FakeDevice);monkeypatch.setattr(mod,'RECORD_DIR',tmp_path)
    lab=Workstation();lab.active='madgwick';lab.set_pipeline_mode('realtime')
    try:
        lab.start('serial',port='COMMOCK');time.sleep(.35)
        st=lab.status();assert st['running'] and st['count']>=100
        assert set(st['latest']['outputs'])=={'accel','madgwick'}
        assert st['pipeline']['acquired_samples']>=st['count']
        assert st['pipeline']['raw_file']
    finally:lab.stop()
    p=lab.pipeline_status();assert p['acquired_samples']==p['raw_written_samples']==p['fusion_count']
    with (tmp_path/p['raw_file']).open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
    assert len(rows)==p['acquired_samples'] and rows[-1]['reported_odr']=='0'
    assert all(int(a['host_est_ns'])<int(b['host_est_ns']) for a,b in zip(rows,rows[1:]))

def test_long_gap_resets_instead_of_integrating():
    lab=Workstation();lab.source='serial';lab.active='madgwick';lab.set_pipeline_mode('realtime');c=BatchClock()
    for row,ns,obs in c.stamp(batch(100),1_000_000_000):lab.process(row,ns,obs)
    row,ns,obs=c.stamp(batch(100.6),1_600_000_000)[0];lab.process(row,ns,obs)
    assert lab.latest['gap_reset'] and lab.latest['fusion_dt']==0 and lab.latest['original_dt']>.05

def test_offline_replay_does_not_overwrite_real_outputs_or_use_reference():
    row={'fusion_dt_s':.0012,'gap_reset':0,'cal_madgwick_roll':12.345,'raw_madgwick_roll':33.3,'cal_accel_pitch':.123,'alignment_active':0}
    for ch in ('raw','cal'):
        for k,u,v in [('acc','g',[0,0,1]),('gyro','dps',[0,0,0])]:
            row.update({f'{ch}_{k}_{j}_{u}':v[i] for i,j in enumerate('xyz')})
    rows=[dict(row,ref_deg=999),dict(row,ref_deg=-999)]
    out,info=replay_missing(rows,asdict(Params()),None,'madgwick')
    assert out[0]['cal_madgwick_roll']==12.345 and out[1]['raw_madgwick_roll']==33.3
    assert out[0]['cal_gyro_roll']==out[1]['cal_gyro_roll']==0
    assert 'cal_gyro_roll' not in rows[0] and 'madgwick' not in info['offline_algorithms']

def test_busy_browser_reads_cache_without_dll(monkeypatch):
    monkeypatch.setattr(main.TABLE,'connected',True)
    monkeypatch.setattr(main.TABLE,'cached_status',{'connected':True,'axes':{},'time_monotonic_ns':time.monotonic_ns()})
    monkeypatch.setattr(main.DYNAMIC_TEST,'running',True)
    def fail():raise AssertionError('browser must not call DLL')
    monkeypatch.setattr(main.TABLE,'read_status',fail)
    r=main.table_status(diagnose=True)
    assert r['display_cache_only'] and r['display_cache_age_ms']>=0
