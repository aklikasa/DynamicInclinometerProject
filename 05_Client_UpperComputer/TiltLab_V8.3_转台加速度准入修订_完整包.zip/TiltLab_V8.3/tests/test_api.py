import io,csv
from fastapi.testclient import TestClient
from app.main import app
from app.fusion import Params,FILTERS
from app.calibration import scan


def test_http_data_flow(tmp_path,monkeypatch):
    import app.main as main
    monkeypatch.setattr(main,'REPORT_DIR',tmp_path)
    with TestClient(app) as client:
        assert client.get('/').status_code==200
        assert client.get('/assets/app.js').status_code==200
        assert len(client.get('/api/meta').json()['algorithms'])==len(FILTERS)
        assert client.get('/api/turntable/status').json()['connected'] is False
        assert client.post('/api/hardware-test/start',json={'acknowledged':False}).status_code==400
        assert client.post('/api/experiment',json={'id':'sweep','fs':100}).status_code==403
        assert client.post('/api/start',json={'source':'simulation'}).status_code==403
        csvfile='t_s,acc_x_g,acc_y_g,acc_z_g,gyro_x_dps,gyro_y_dps,gyro_z_dps\n0,0,0,1,0,0,0\n0.01,0,0,1,0,0,0\n'
        r=client.post('/api/replay',files={'file':('original.csv',csvfile.encode(),'text/csv')})
        assert r.status_code==200 and r.json()['rows']==2
        assert r.json()['metrics'] is None


def test_calibration_rejects_no_folder(tmp_path):
    x=scan(tmp_path,'DTS123456','deadbeefdeadbeefdeadbeef')
    assert x['status']=='missing'
