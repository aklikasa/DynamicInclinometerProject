import json
import pytest
from pathlib import Path
from app.calibration import validate_matrix,parse_file,scan,apply

def test_matrix_small_determinant_is_not_singular():
    matrix=[[.1,0,0],[0,.1,0],[0,0,.1]]
    d=validate_matrix(matrix,'acc.json')
    assert d['determinant']==pytest.approx(.001)
    assert d['condition']==pytest.approx(1)

def test_singular_matrix_rejected_with_specific_diagnostics():
    with pytest.raises(ValueError,match='矩阵不可逆'):
        validate_matrix([[1,0,0],[0,1,0],[0,0,0]],'bad_gyro.json')

def test_high_condition_matrix_rejected():
    with pytest.raises(ValueError,match='条件数超过'):
        validate_matrix([[1,0,0],[0,1,0],[0,0,.0001]],'gyro.json')

def test_ambient_file_pair_and_diagnostics(tmp_path):
    uid='DTS872028'
    for kind, bkey in [('accel','raw_accel_bias_g'),('gyro','raw_gyro_bias_dps')]:
        path=tmp_path/f'{uid}_{kind}_calibration.json'
        path.write_text(json.dumps({'device_serial':uid,bkey:[0,0,0],
          'raw_to_platform_matrix':[[.1,0,0],[0,.1,0],[0,0,.1]]}),encoding='utf8')
    r=scan(tmp_path,serial=uid,mode='ambient')
    assert r['status']=='matched',r
    assert len(r['matrix_diagnostics'])==2
    assert apply([10,20,30],r['acc'])==pytest.approx([1,2,3])

def test_invalid_matrix_not_silent_missing(tmp_path):
    uid='DTS872028'
    path=tmp_path/f'{uid}_accel_calibration.json'
    path.write_text(json.dumps({'device_serial':uid,'raw_accel_bias_g':[0,0,0],
      'raw_to_platform_matrix':[[1,0,0],[0,1,0],[0,0,0]]}),encoding='utf8')
    r=scan(tmp_path,serial=uid,mode='ambient')
    assert r['status']=='invalid',r
    assert '不可逆' in r['detail']
    assert r['matrix_diagnostics'][0]['file']==path.name

def test_other_device_failed_calibration_does_not_poison_uid(tmp_path):
    (tmp_path/'DTS999999_accel_calibration.json').write_text(json.dumps({'device_serial':'DTS999999','raw_accel_bias_g':[0,0,0], 'raw_to_platform_matrix':[[0,0,0],[0,0,0],[0,0,0]]}))
    r=scan(tmp_path,serial='DTS872028',mode='ambient')
    assert r['status']=='missing', r
    assert not r['matrix_diagnostics']
