"""Read-only, post-stop sign verification; no device classes or motor commands."""
import math
from copy import deepcopy

from app.dynamic_reference_polarity import infer_dynamic_reference_polarity
from app.dynamic_experiment import recover_imu_timebase


def make_motion(output='pitch', polarity=-1, amplitude=2.0, frequency=0.3,
                duration=15.0, reverse_gyro=False):
    origin=2000000000000
    def angle(t):return amplitude*math.sin(2*math.pi*frequency*t)
    def omega(t):return amplitude*2*math.pi*frequency*math.cos(2*math.pi*frequency*t)
    table=[]
    for i in range(int(duration*12.5)+1):
        t=i/12.5
        table.append({'pc_mid_ns':origin+round(t*1e9),
                      'axis_2_pos':angle(t)%360})
    imu=[]
    for i in range(int(duration*200)+1):
        t=i/200
        imu.append({'host_est_ns':origin+round(t*1e9),
                    f'cal_accel_{output}':polarity*angle(t)*1.05+.02,
                    'cal_gyro_'+('x' if output=='roll' else 'y')+'_dps':
                    polarity*omega(t)*(-1 if reverse_gyro else 1),
                    'imu_timestamp_quality':'pc_receipt_nominal_odr_estimate_NOT_SYNC'})
    return table,imu,origin,origin+round(duration*1e9)


def test_pitch_inversion_uses_two_physical_channels():
    tab,imu,start,end=make_motion()
    before=(deepcopy(tab),deepcopy(imu))
    result=infer_dynamic_reference_polarity(tab,imu,2,'pitch',1,start,end,recover_imu_timebase)
    assert result['valid'] and result['selected_sign']==-1 and result['changed']
    assert result['channels']['calibrated_accel_tilt']['vote']==-1
    assert result['channels']['calibrated_gyro_rate']['vote']==-1
    assert (tab,imu)==before   # never edit captured CSV input


def test_roll_in_phase_keeps_sign():
    tab,imu,start,end=make_motion('roll',1)
    result=infer_dynamic_reference_polarity(tab,imu,2,'roll',1,start,end,recover_imu_timebase)
    assert result['valid'] and result['selected_sign']==1 and not result['changed']


def test_conflicting_sensor_evidence_cannot_force_flip():
    tab,imu,start,end=make_motion(reverse_gyro=True)
    result=infer_dynamic_reference_polarity(tab,imu,2,'pitch',1,start,end,recover_imu_timebase)
    assert not result['valid'] and result['selected_sign'] is None


def test_insufficient_actual_motion_rejected():
    tab,imu,start,end=make_motion(amplitude=.05)
    result=infer_dynamic_reference_polarity(tab,imu,2,'pitch',1,start,end,recover_imu_timebase)
    assert not result['valid']


def test_missing_gyro_rejected():
    tab,imu,start,end=make_motion()
    for row in imu:row['cal_gyro_y_dps']=''
    result=infer_dynamic_reference_polarity(tab,imu,2,'pitch',1,start,end,recover_imu_timebase)
    assert not result['valid'] and result['selected_sign'] is None
