"""Offline timestamp diagnostic: loads saved CSV/JSON only, never connects to hardware.
Usage (Windows, from extracted project root):
    python 时间戳只读诊断.py "data/reports/2026..._DYNAMIC.json"
"""
from pathlib import Path
import csv,json,sys
import numpy as np
from app.dynamic_experiment import recover_imu_timebase,analyze_tracking


def inspect(report_filename):
    report_path=Path(report_filename).expanduser().absolute()
    report=json.loads(report_path.read_text(encoding='utf-8-sig'))
    if report.get('kind')!='REAL_2TD600_SINE_DIAGNOSTIC':
        raise ValueError('请选择单轴 *_DYNAMIC.json 实验报告（不是联合汇总JSON）')
    def source_file(name):
        if not isinstance(name,str) or not name or Path(name).name!=name:
            raise ValueError('报告中CSV文件名不安全或为空')
        f=report_path.parent/name
        if not f.is_file():raise FileNotFoundError('缺少原始CSV：'+str(f))
        return f
    with source_file(report['raw_file_table']).open(encoding='utf-8-sig',newline='') as f:
        table=list(csv.DictReader(f))
    with source_file(report['raw_file_imu']).open(encoding='utf-8-sig',newline='') as f:
        imu=list(csv.DictReader(f))
    if not table or not imu:raise ValueError('转台或IMU CSV为空')
    table_time=np.asarray([int(r['pc_mid_ns']) for r in table],dtype=np.int64)
    imu_clock,info=recover_imu_timebase(imu,int(table_time[0]),int(table_time[-1]))
    diff=np.diff(table_time)
    output={'kind':'OFFLINE_CLOCK_DIAGNOSTIC','source_report':report_path.name,
            'original_state':report.get('state'),
            'table_rows':len(table),'imu_rows':len(imu),
            'table_nonmonotonic_steps':int(np.count_nonzero(diff<=0)),
            'table_max_gap_ms':round(float(max(diff,default=0))/1e6,2),
            'selected_imu_nonmonotonic_steps':int(np.count_nonzero(np.diff(imu_clock)<=0)),
            'clock_diagnostics':info,'research_only':True,'hardware_synchronized':False}
    plan=report.get('plan') or {}
    start=report.get('motion_start_pc_monotonic_ns')
    end=report.get('motion_end_pc_monotonic_ns')
    if start and end and start<end and plan.get('axis') in (0,2):
        output['reanalysis']=analyze_tracking(table,imu,plan['axis'],plan['output'],
            plan['sign'],plan['amplitude_deg'],plan['frequency_hz'],int(start),int(end))
    else:
        output['reanalysis_note']='旧版报告未保存准确运动起止单调时间；仅完成时间轴诊断，不猜测RMSE'
    dest=report_path.with_name(report_path.stem+'_CLOCK_DIAGNOSTIC.json')
    if dest.exists():
        raise FileExistsError('诊断输出文件已存在，为防止覆盖请先改名：'+str(dest))
    dest.write_text(json.dumps(output,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print('转台样本:',len(table),'IMU样本:',len(imu))
    print('转台异常时间间隔:',output['table_nonmonotonic_steps'])
    print('IMU原会话倒退:',info.get('host_nonmonotonic_steps','未知'))
    print('分析使用的IMU时间源:',info.get('time_source','未知'))
    print('PC-FIFO重建:',info.get('recovered',False))
    print('研究级诊断文件:',dest)
    if 'reanalysis' in output:print('离线重分析有效:',output['reanalysis'].get('valid'))
    return dest


if __name__=='__main__':
    if len(sys.argv)!=2:
        print('用法：python 时间戳只读诊断.py "data/reports/XXX_DYNAMIC.json"')
        sys.exit(2)
    try:inspect(sys.argv[1])
    except Exception as exc:
        print('诊断失败：',type(exc).__name__,str(exc));sys.exit(1)
