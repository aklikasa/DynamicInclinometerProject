﻿@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo 离线CSV回放：不连接转台、不加载厂家DLL、不发送任何运动指令。
set /p "REPORT=请将原始 *_DYNAMIC.json 拖入窗口后回车（或输入完整路径）："
set "REPORT=%REPORT:"=%"
if "%REPORT%"=="" goto END
python "离线算法对照_只读.py" "%REPORT%"
:END
pause
endlocal
