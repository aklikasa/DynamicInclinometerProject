@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title TiltLab V8.1 - PCB Workstation
if not exist "run.py" goto FAILED
set "PY_EXE="
set "PY_OPT="
if exist ".venv\Scripts\python.exe" (
  set "PY_EXE=%CD%\.venv\Scripts\python.exe"
  goto PY_READY
)
py -3.13 -c "import sys" >nul 2>&1
if not errorlevel 1 (
  set "PY_EXE=py"
  set "PY_OPT=-3.13"
  goto PY_READY
)
py -3.12 -c "import sys" >nul 2>&1
if not errorlevel 1 (
  set "PY_EXE=py"
  set "PY_OPT=-3.12"
  goto PY_READY
)
py -3.11 -c "import sys" >nul 2>&1
if not errorlevel 1 (
  set "PY_EXE=py"
  set "PY_OPT=-3.11"
  goto PY_READY
)
py -3.10 -c "import sys" >nul 2>&1
if not errorlevel 1 (
  set "PY_EXE=py"
  set "PY_OPT=-3.10"
  goto PY_READY
)
python -c "import sys" >nul 2>&1
if not errorlevel 1 (
  set "PY_EXE=python"
  goto PY_READY
)
goto FAILED
:PY_READY
echo [INFO] TiltLab V8.1 - local http://127.0.0.1:8877
echo [INFO] Python:
"%PY_EXE%" %PY_OPT% --version
"%PY_EXE%" %PY_OPT% "tools\setup_v730.py" --check --mode core
if errorlevel 1 (
  echo [ERROR] Core dependencies missing. Run INSTALL_DEPENDENCIES.bat.
  goto FAILED
)
"%PY_EXE%" %PY_OPT% -c "import struct;assert struct.calcsize('P')==8" >nul 2>&1
if errorlevel 1 (
  echo [ERROR] 64-bit Python required for the 2TD600.dll.
  goto FAILED
)
rem R10 is optional. Absence must NOT prevent PCB monitoring.
"%PY_EXE%" %PY_OPT% "tools\setup_v730.py" --check --mode r10 >nul 2>&1
if errorlevel 1 echo [INFO] Optional R10 calibration dependencies incomplete. For auto-calibration run INSTALL_DEPENDENCIES.bat (one-click PCB + R10).
echo [INFO] Keep this window open. Ctrl+C stops the server.
"%PY_EXE%" %PY_OPT% -u "run.py"
echo [INFO] Server exited with code %ERRORLEVEL%.
goto END
:FAILED
echo [FAILED] TiltLab could not start. The message above explains why.
:END
pause
endlocal
