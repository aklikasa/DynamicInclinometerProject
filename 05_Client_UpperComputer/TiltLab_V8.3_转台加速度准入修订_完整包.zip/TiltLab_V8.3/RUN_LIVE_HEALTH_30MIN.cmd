@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
echo V7.24 只读采集健康检查：请保持设备安全静止，先手动连接真实IMU。
echo 不连接或控制转台；不更改标定；不会启动运动。
if exist .venv\Scripts\python.exe (
  .venv\Scripts\python.exe tools\check_live_health.py --seconds 1800
  goto END
)
where py >nul 2>&1
if not errorlevel 1 (
  py -3.12 -c "import sys" >nul 2>&1 && (py -3.12 tools\check_live_health.py --seconds 1800 & goto END)
  py -3.11 -c "import sys" >nul 2>&1 && (py -3.11 tools\check_live_health.py --seconds 1800 & goto END)
  py -3 -c "import sys" >nul 2>&1 && (py -3 tools\check_live_health.py --seconds 1800 & goto END)
)
where python >nul 2>&1
if not errorlevel 1 (
  python tools\check_live_health.py --seconds 1800
  goto END
)
echo [ERROR] No Python found. Use INSTALL_DEPENDENCIES.bat before starting the health check.
:END
pause
endlocal
