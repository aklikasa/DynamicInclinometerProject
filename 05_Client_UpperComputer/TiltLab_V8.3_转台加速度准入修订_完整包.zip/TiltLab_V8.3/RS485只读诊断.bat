@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" "RS485只读诊断.py"
) else (
  py -3 "RS485只读诊断.py"
)
echo.
pause
