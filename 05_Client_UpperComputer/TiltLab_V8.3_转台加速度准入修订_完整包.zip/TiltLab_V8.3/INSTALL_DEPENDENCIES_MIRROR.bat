@echo off
cd /d "%~dp0"
echo This uses an OPTIONAL third-party package mirror.
choice /C YN /M "Use Tsinghua PyPI mirror for PCB + ambient R10 packages"
if errorlevel 2 exit /b 1
call "INSTALL_DEPENDENCIES_DEBUG.cmd" --mode r10 --mirror
exit /b %errorlevel%
