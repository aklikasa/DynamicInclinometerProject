TiltLab V7.29.3 — 安装诊断与 R10 自动标定依赖补全

针对 V7.29.2 安装脚本只显示「Core pip installation failed」的问题：
  1. 保留项目 .venv，按包安装并在屏幕显示 pip 原始报错和失败的包名。
  2. 补全 WebSocket 相关库，以及 R10 图形标定入口直接导入的 openpyxl 与 python-snap7。
  3. 旧温箱 PLC 代码使用 snap7.type.Areas 等历史 API，因此选用 python-snap7 1.3。
  4. uvicorn[standard] 如失败会尝试 uvicorn + websockets 的最小 WebSocket 安装。
  5. pytest 与 VQF 单独安装；失败会提示可选组件不可用，不会伪装成主程序安装成功。
  6. 日志从旧 install_v711.txt 改为 install_logs\install_v7293.txt。

使用：
  - 关闭所有旧的软件窗口及 Python 服务器；不要同时运行两个 TiltLab。
  - 备份旧文件夹；全量解压 ZIP 到新的文件夹。不要删除原始标定数据。
  - 运行 INSTALL_DEPENDENCIES.bat；它会复用本目录已有的 .venv。
  - 若失败，复制安装窗口标注的 [FAILED PACKAGE] 及附近的 pip 错误行，或者发送
      install_logs\install_v7293.txt
    也可以在项目目录 CMD 中执行：
      powershell -NoProfile -Command "Get-Content -LiteralPath '.\install_logs\install_v7293.txt' -Tail 60"
  - 若报连接超时、SSL、代理，且你明确信任清华镜像，可以单独运行
      INSTALL_DEPENDENCIES_MIRROR.bat
    它会先征求同意，不会自动切换第三方源。
  - 安装成功后运行 START_TILT_LAB.bat，先检查 PCB 在线状态、自动标定页面，
    未验证转台硬件前不要直接启动自动运动。

限制：日志未上传，无法判定此次 pip 首个失败包或是否为网络问题；
本版不修改自动标定算法、PCB 串口、转台限位与安全停车逻辑；Windows 实机尚待验证。
