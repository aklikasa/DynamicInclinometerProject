@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (set "PYEXE=%CD%\.venv\Scripts\python.exe") else (set "PYEXE=python")
echo Drag an IMU ZIP file, an existing data/reports directory or _DYNAMIC_imu.csv here:
set /p "INPUT_PATH=File or folder: "
"%PYEXE%" "tools\auto_timebase\diagnose.py" "%INPUT_PATH%" --out "data\timebase_diagnostic"
pause
