@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set "PY=python"
if exist ".venv\Scripts\python.exe" set "PY=.venv\Scripts\python.exe"
echo OFFLINE ONLY - No device connection. Close live application safely first.
set /p "REPORT=Drag pending dynamic JSON here and press Enter: "
"%PY%" tools\finalize_deferred_report.py "%REPORT:"=%" --optimize
pause
