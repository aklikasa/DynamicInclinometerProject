@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
echo V7.24.1 OFFLINE REPORT STATUS REPAIR - NO MOTION, NO COM, NO ORIGINAL OVERWRITE
echo Please close the live application safely. Drag your *_DYNAMIC.json to the prompt.
set "PY=python"
if exist ".venv\Scripts\python.exe" set "PY=.venv\Scripts\python.exe"
"%PY%" tools\repair_report_status_v7241.py
pause
