@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo [ERROR] No .venv found. Run INSTALL_DEPENDENCIES.bat to set up BOTH PCB and R10.
 goto DONE
)
".venv\Scripts\python.exe" -u "tools\v81_healthcheck.py" --mode r10
:DONE
pause
endlocal
