# -*- coding: utf-8 -*-
"""TiltLab V7.16 stationary temperature investigation. IMU read-only; no table."""
import argparse, csv, datetime, hashlib, json, math, multiprocessing, shutil, sys, time, traceback, zipfile
from pathlib import Path
from dataclasses import asdict
import os

ROOT=Path(__file__).resolve().parent
if not (ROOT/'app'/'devices.py').is_file():
    raise SystemExit('请将本脚本及启动CMD放在已解压的TiltLab V7.16根目录（run.py旁）。')
from app.devices import R10Device, list_ports
from app.calibration import scan, apply
from app.fusion import Params, accel_tilt, create_filter
from app.acquisition_v712 import BatchClock, POLL_FIELDS
from app.acquisition_v714 import ProcessTransport
from app.continuity_v713 import advance
import numpy as np

AXES='xyz'
VALUES=['temp_c']+[f'{p}_{a}' for p in ('acc_raw_g','gyro_raw_dps','acc_cal_g','gyro_cal_dps') for a in AXES]+['acc_raw_roll_deg','acc_raw_pitch_deg','acc_cal_roll_deg','acc_cal_pitch_deg','anchor_roll_deg','anchor_pitch_deg','bias_x_dps','bias_y_dps','bias_z_dps','acc_norm_g','gyro_norm_dps','bias_ready','stationary_detected','trust']
FIELDS=['seq','elapsed_receipt_s','sample_est_s','device_t_s','host_est_ns','pc_receipt_ns','batch_id','batch_index','poll_id','odr','reported_odr','fifo_state','batch_shift_ms','dt_est_s','ipc_ms','sample_age_ms','gap_action']+VALUES
STATS=['temp_c','acc_cal_roll_deg','acc_cal_pitch_deg','anchor_roll_deg','anchor_pitch_deg','acc_norm_g','gyro_norm_dps','bias_ready','stationary_detected']+[f'{p}_{a}' for p in ('acc_raw_g','gyro_raw_dps','acc_cal_g','gyro_cal_dps') for a in AXES]+['bias_x_dps','bias_y_dps','bias_z_dps']
AGG_FIELDS=['second','samples','gap_bridges','gap_resets']+[f'{k}_{stat}' for k in STATS for stat in ('mean','std','min','max')]


def utc():return datetime.datetime.now().astimezone().isoformat()
def save_json(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def settings():
    candidates=[Path(os.environ['LOCALAPPDATA'])/'TiltLab'/'settings.json'] if os.environ.get('LOCALAPPDATA') else []
    candidates.append(ROOT/'data'/'settings.json')
    for p in candidates:
        if p.is_file():return json.loads(p.read_text(encoding='utf-8-sig')),str(p)
    return {},None

def make_params(cfg):
    p=Params(**{k:v for k,v in cfg.get('params',{}).items() if k in Params.__dataclass_fields__})
    for k in ('lever_z_cm','lever3_x_cm','lever3_y_cm','lever3_z_cm'):setattr(p,k,0.)
    return p.validate()

class Recorder:
    def __init__(self,cal,p,origin,raw,seconds):
        self.cal=cal;self.p=p;self.origin=origin;self.raw=raw;self.seconds=seconds
        self.clock=BatchClock();self.filt=create_filter('gyro_anchor',p,calibrated=True)
        self.last=None;self.n=0;self.buf=[];self.sec=None;self.summaries=[];self.max_dt=0.;self.gaps10=0;self.gaps50=0;self.bridges=0;self.resets=0;self.age_max=0.;self.last_receipt=None
    def flush(self):
        if not self.buf:return
        a=np.asarray([v for v,_ in self.buf],float)
        row={'second':self.sec,'samples':len(a),'gap_bridges':sum(x=='gyro_bridge' for _,x in self.buf),'gap_resets':sum(x=='reset' for _,x in self.buf)}
        for k in STATS:
            x=a[:,VALUES.index(k)]
            for stat,val in [('mean',x.mean()),('std',x.std()),('min',x.min()),('max',x.max())]:row[f'{k}_{stat}']=float(val)
        self.seconds.writerow(row);self.summaries.append(row);self.buf=[]
    def consume(self,batch,poll,dequeued):
        observed=poll['received_pc_ns'];self.last_receipt=observed
        sec=max(0,int((observed-self.origin)/1e9))
        if self.sec!=sec:self.flush();self.sec=sec
        for s,ns,obs in self.clock.stamp(batch,observed):
            dt=0. if self.last is None else (ns-self.last)/1e9;self.last=ns
            self.max_dt=max(self.max_dt,dt);self.gaps10+=dt>.010;self.gaps50+=dt>.050
            a,g,t=s['acc'],s['gyro'],s['temp'];ca=apply(a,self.cal['acc'],t);cg=apply(g,self.cal['gyro'],t)
            self.filt,out,action=advance('gyro_anchor',self.filt,self.p,True,ca,cg,dt)
            self.bridges+=action=='gyro_bridge';self.resets+=action=='reset'
            ar=accel_tilt(a);ac=accel_tilt(ca)
            vals=[t,*a,*g,*ca,*cg,ar['roll'],ar['pitch'],ac['roll'],ac['pitch'],out['roll'],out['pitch'],*out['gyro_bias_dps'],math.sqrt(sum(x*x for x in ca)),math.sqrt(sum(x*x for x in cg)),int(out['stationary_bias_ready']),int(out['stationary_detected']),out['trust']]
            if not all(math.isfinite(x) for x in vals):raise RuntimeError('出现非有限数值，停止诊断，保留原始已记录数据')
            age=(time.monotonic_ns()-ns)/1e6;self.age_max=max(self.age_max,age);self.n+=1
            self.raw.writerow([self.n,(obs-self.origin)/1e9,s['t'],s['device_t_original'],ns,obs,s['batch_id'],s['batch_index'],poll['poll_id'],s['odr'],s['reported_odr'],s['fifo_state'],s['batch_shift_ms'],dt,(dequeued-obs)/1e6,age,action,*vals]);self.buf.append((vals,action))
    def summary(self):
        rows=self.summaries
        if not rows:return {}
        # Exclude startup first 10 seconds and questionable motion/gap seconds from trend fit only.
        eligible=[r for r in rows if r['second']>=10 and r['samples']>=100 and r['stationary_detected_mean']>=.95 and r['bias_ready_mean']>=.95 and not r['gap_bridges'] and not r['gap_resets']]
        report={'samples':self.n,'seconds_with_data':len(rows),'eligible_trend_seconds':len(eligible),'stationary_detected_fraction':sum(r['stationary_detected_mean']*r['samples'] for r in rows)/self.n,'mean_recorded_hz_approx':self.n/max(1.,rows[-1]['second']-rows[0]['second']+1),'max_estimated_dt_ms':self.max_dt*1000,'gaps_over_10ms':self.gaps10,'gaps_over_50ms':self.gaps50,'bridges':self.bridges,'resets':self.resets,'batch_clock_repairs':self.clock.repairs,'max_batch_shift_ms':self.clock.max_repair_ms,'max_estimated_sample_age_ms':self.age_max,'temperature_min_c':min(r['temp_c_min'] for r in rows),'temperature_max_c':max(r['temp_c_max'] for r in rows),'trend':{},'note':'仅静止诊断；无同步转台参考，不计算绝对精度。温度相关性不等于温漂因果关系。芯片温度不是环境温度。'}
        if not eligible:return report
        x=np.array([r['temp_c_mean'] for r in eligible]);span=float(np.ptp(x));report['eligible_temperature_span_c']=span
        first=[r for r in eligible if r['second']<eligible[0]['second']+60];last=[r for r in eligible if r['second']>eligible[-1]['second']-60]
        for key in ('temp_c','acc_cal_roll_deg','acc_cal_pitch_deg','anchor_roll_deg','anchor_pitch_deg','gyro_cal_dps_x','gyro_cal_dps_y','gyro_cal_dps_z','bias_x_dps','bias_y_dps','bias_z_dps','acc_cal_g_x','acc_cal_g_y','acc_cal_g_z'):
            y=np.array([r[key+'_mean'] for r in eligible]);f=float(np.mean([r[key+'_mean'] for r in first]));l=float(np.mean([r[key+'_mean'] for r in last]));d={'first_window_mean':f,'last_window_mean':l,'change':l-f,'min_second_mean':float(y.min()),'max_second_mean':float(y.max())}
            if key!='temp_c' and len(x)>=60 and span>=.5 and np.std(y)>1e-12:
                d.update(descriptive_slope_per_c=float(np.polyfit(x,y,1)[0]),pearson_r=float(np.corrcoef(x,y)[0,1]))
            report['trend'][key]=d
        report['trend_warning']='温差不足0.5℃或有效静止时间不足60秒时不拟合斜率；首尾窗口不足120秒可能重叠。单姿态不能辨识完整六轴温补。'
        return report


def main():
    ap=argparse.ArgumentParser(description='静止温漂诊断（仅IMU，默认30分钟）')
    ap.add_argument('--port');ap.add_argument('--baud',type=int,default=1500000);ap.add_argument('--address',type=int,default=1);ap.add_argument('--minutes',type=float);ap.add_argument('--cal-dir');ap.add_argument('--output',type=Path,default=ROOT/'data'/'thermal_diagnostics');args=ap.parse_args()
    cfg,settings_path=settings();p=make_params(cfg)
    print('TiltLab V7.16 静止温漂诊断 | 不控制转台、不归零、不修改标定')
    print('请先在原上位机确认转台安全停止、关闭转台连接，再退出上位机后台。保持IMU当前装夹及姿态。')
    print('转台必须由现场人员确保静止及安全；本程序不能验证或控制其状态。')
    if input('确认上述条件已满足，输入 YES 继续：').strip().upper()!='YES':return 1
    ports=list_ports();print('可用串口：');[print(' ',v['device'],v['label']) for v in ports]
    port=args.port or input('输入倾角仪COM口（不是转台COM口）：').strip().upper()
    if not port or port.upper() not in {v['device'].upper() for v in ports}:raise ValueError('未选择有效的已枚举IMU串口')
    if not 1<=args.address<=247 or args.baud<=0:raise ValueError('串口参数无效')
    default=cfg.get('calibration_folder') or r'E:\研发上位机\标定文件'
    folder=Path(args.cal_dir or input(f'常温标定目录（回车使用 {default}）：').strip().strip('"') or default)
    minutes=args.minutes if args.minutes is not None else float(input('记录分钟数（回车30）：').strip() or '30')
    if not math.isfinite(minutes) or not 0.1<=minutes<=180:raise ValueError('时长须在0.1～180分钟')
    args.output.mkdir(parents=True,exist_ok=True)
    # CSV full-rate records and ZIP both occupy disk until packaging finishes.
    needed=int(minutes*60*833*850+100_000_000)
    if shutil.disk_usage(args.output).free<needed:raise RuntimeError(f'磁盘空间不足，建议至少预留 {needed/1e9:.1f} GB')
    out=args.output/(datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_STATIC_TEMP_DIAG');out.mkdir()
    meta={'kind':'TILTLAB_V716_STATIC_TEMPERATURE_DIAGNOSTIC','state':'starting','started_at':utc(),'requested_minutes':minutes,'port':port,'baud':args.baud,'address':args.address,'settings_source':settings_path,'parameters':asdict(p),'reference':'none; operator verified stationary, zero pose not measured by script','temperature':'ASM330 die temperature from R10 protocol, not ambient','timestamp_note':'PC receive nominal ODR backprojection; not synchronized','operator_confirmed_stationary':True,'algorithm':'gyro_anchor','no_static_alignment':True,'no_thermal_compensation':True,'no_lever_compensation':True,'early_stop_note':'提前中止时仅保证已写入的数据；IPC中尚未处理的尾部数据可能未保存。'}
    save_json(out/'summary.json',meta)
    transport=None;rec=None;polls=0;last_dropped=None;failure=None;start=None
    try:
        transport=ProcessTransport(R10Device,port,args.baud,args.address);transport.open()
        meta.update(uid=transport.serial_no,uid_hex=transport.uid)
        if not transport.uid or transport.serial_no!='DTS672516':raise RuntimeError(f'设备身份不匹配（实际 {transport.serial_no}），本次只诊断 DTS672516；不使用其他设备标定')
        cal=scan(folder,transport.serial_no,transport.uid,'ambient')
        if cal['status']!='matched':raise RuntimeError(cal['detail'])
        copies=[];dest=out/'calibration';dest.mkdir()
        for f in dict.fromkeys(cal['files']):
            src=Path(f);dst=dest/src.name
            if dst.exists():raise RuntimeError('标定文件同名，拒绝覆盖')
            shutil.copyfile(src,dst);copies.append({'source':str(src),'name':dst.name,'sha256':digest(dst)})
        meta.update(calibration_files=copies,calibration_scan={k:v for k,v in cal.items() if k not in ('acc','gyro')},state='recording')
        save_json(out/'summary.json',meta)
        print('UID匹配成功：',transport.serial_no,'；常温标定文件：',cal['files'],flush=True)
        print('开始连续记录。保持静止，可安全调整空调；Ctrl+C提前结束并保存。',flush=True)
        with (out/'samples.csv').open('w',encoding='utf-8-sig',newline='',buffering=1024*1024) as rf,(out/'seconds.csv').open('w',encoding='utf-8-sig',newline='') as sf,(out/'polls.csv').open('w',encoding='utf-8-sig',newline='',buffering=256*1024) as pf:
            raw=csv.writer(rf);raw.writerow(FIELDS);sw=csv.DictWriter(sf,fieldnames=AGG_FIELDS);sw.writeheader();pw=csv.DictWriter(pf,fieldnames=POLL_FIELDS);pw.writeheader()
            start=time.monotonic_ns();rec=Recorder(cal,p,start,raw,sw);transport.begin.set();deadline=start+int(minutes*60*1e9);next_print=start;stop_requested=False;last_data=start
            try:
                while True:
                    now=time.monotonic_ns()
                    if now>=deadline and not stop_requested:transport.request_stop();stop_requested=True
                    item=transport.next_poll()
                    if item is None:
                        if not stop_requested:raise RuntimeError('采集进程提前停止')
                        break
                    if item:
                        batch,poll=item;dequeued=time.monotonic_ns();polls+=1;last_dropped=poll.get('reported_dropped_batches');pw.writerow({**poll,'parent_dequeue_pc_ns':dequeued,'ipc_delivery_ms':(dequeued-poll['received_pc_ns'])/1e6})
                        if batch:
                            last_data=dequeued;rec.consume(batch,poll,dequeued)
                    if not stop_requested and time.monotonic_ns()-last_data>5_000_000_000:raise RuntimeError('5秒无有效IMU数据')
                    if now>=next_print:
                        elapsed=(now-start)/1e9;print(f'{elapsed:.0f}/{minutes*60:.0f}s | {rec.n}点',end=' ',flush=True)
                        if rec.summaries:
                            v=rec.summaries[-1];print(f'温度 {v["temp_c_mean"]:.3f}℃ | ROLL {v["acc_cal_roll_deg_mean"]:+.4f}°（ACC） / {v["anchor_roll_deg_mean"]:+.4f}°（融合）',flush=True)
                        else:print('',flush=True)
                        rf.flush();sf.flush();pf.flush();next_print=now+10_000_000_000
                meta['state']='completed'
            except KeyboardInterrupt:
                meta['state']='operator_stopped_partial';transport.request_stop()
            finally:
                rec.flush();rf.flush();sf.flush();pf.flush()
    except KeyboardInterrupt:meta['state']='operator_stopped_partial'
    except Exception as exc:
        failure=f'{type(exc).__name__}: {exc}';meta['state']='failed_partial';(out/'error.txt').write_text(traceback.format_exc(),encoding='utf-8');print(failure,flush=True)
    finally:
        if transport is not None:
            try:transport.close()
            except Exception as exc:failure=f'{failure or ""}; close: {exc}';meta['state']='failed_partial'
        meta.update(finished_at=utc(),error=failure,polls=polls,reported_dropped_batches=last_dropped,elapsed_pc_s=(time.monotonic_ns()-start)/1e9 if start else 0,diagnostics=rec.summary() if rec else {})
        if meta['state']=='completed' and (not rec or not rec.n):meta['state']='failed_partial';meta['error']='无有效样本'
        save_json(out/'summary.json',meta)
        z=out.with_suffix('.zip')
        try:
            with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as zz:
                for f in sorted(out.rglob('*')):
                    if f.is_file():zz.write(f,f.relative_to(out))
            print('\n诊断状态：',meta['state'],'\n请发送完整ZIP：',z,flush=True)
        except Exception as exc:print('打包失败，原始文件仍保存在：',out,exc,flush=True);return 1
    return 0 if meta['state']=='completed' else 1

if __name__=='__main__':
    multiprocessing.freeze_support()
    try:sys.exit(main())
    except Exception:traceback.print_exc();sys.exit(1)
