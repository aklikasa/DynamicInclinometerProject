@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo [ERROR] No local Python environment. Please run INSTALL_DEPENDENCIES.bat first.
 goto DONE
)
".venv\Scripts\python.exe" -u "tools\v81_healthcheck.py" --mode r10
:DONE
pause
endlocal
