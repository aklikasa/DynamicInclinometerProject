@echo off
chcp 65001>nul
cd /d "%~dp0"
python "恢复已采集实验_只读.py"
if errorlevel 1 pause
