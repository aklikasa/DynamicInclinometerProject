/* V7.26 integrated factory-style 2TD-600 workspace; one DLL connection only. */
(()=>{'use strict';
  const $=id=>document.getElementById(id);
  const page=$('page-turntable');if(!page)return;
  const tabs=document.createElement('nav');tabs.className='tt26-tabs';tabs.setAttribute('aria-label','转台功能页签');
  const groups=[['operate','转台控制'],['monitor','实时曲线'],['test','自动测试'],['diagnose','数据分析'],['advanced','设备维护']];
  const slots={};
  for(const [key,title] of groups){
    const button=document.createElement('button');button.type='button';button.className='tt26-tab';button.textContent=title;button.dataset.tab=key;
    tabs.appendChild(button);
    const pane=document.createElement('div');pane.className='tt26-pane';pane.id='tt26-'+key;slots[key]=pane;
  }
  const heading=page.querySelector('.page-heading');heading.after(tabs);
  const toolbar=page.querySelector('.tt25-toolbar');const axis=page.querySelector('.tt25-axis-grid');
  const prepare=page.querySelector('.tt25-prepare');const diag=page.querySelector('.tt25-diagnostics');
  const note=page.querySelector('.tt25-bottom-note');
  slots.operate.append(toolbar,axis);
  slots.advanced.append(prepare);if(note)slots.advanced.append(note);
  slots.diagnose.append(diag);
  const currentMonitor=$('turntable-monitor');
  if(currentMonitor)slots.monitor.append(currentMonitor);
  else slots.monitor.innerHTML='<article class="panel glass"><h2>实时反馈记录</h2><p>请在实验模块启用转台反馈采集后查看曲线。</p></article>';
  slots.test.innerHTML='<article class="panel glass tt26-toolbox"><h2>自动测试与摇摆</h2><p>正弦摇摆仍调用TiltLab已有的真实实验任务，包含ROLL / PITCH、原始IMU记录和停车后算法诊断。</p><div class="tt25-actions"><button class="btn primary" id="tt26-open-auto">打开自动实验流程</button><button class="btn subtle" id="tt26-open-reports">查看实验数据</button></div></article>';
  for(const [key] of groups)page.appendChild(slots[key]);
  function activate(key){for(const b of tabs.children){const active=b.dataset.tab===key;b.classList.toggle('selected',active);b.setAttribute('aria-selected',String(active))}for(const [k,pane] of Object.entries(slots))pane.hidden=k!==key;}
  for(const b of tabs.children)b.onclick=()=>activate(b.dataset.tab);
  activate('operate');
  const navigate=(page)=>document.querySelector(`.nav-link[data-page="${page}"]`)?.click();
  $('tt26-open-auto').onclick=()=>navigate('experiments');
  $('tt26-open-reports').onclick=()=>navigate('records');
  // Move summary labels out of the main operating surface, not telemetry.
  page.querySelector('.tt25-alert')?.remove();
  page.querySelectorAll('.tt25-descriptor').forEach(x=>x.remove());
  const top=page.querySelector('.page-heading h1');if(top)top.textContent='双轴转台';
  const sub=page.querySelector('.page-heading p');if(sub)sub.textContent='连接、使能、定位、STOP、状态、实时曲线和实验分析 · 集中操作';
})();