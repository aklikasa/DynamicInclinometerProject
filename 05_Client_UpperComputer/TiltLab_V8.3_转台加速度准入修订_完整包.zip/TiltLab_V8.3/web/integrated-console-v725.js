/* V7.25 on-page 2TD-600 console + single-frame experiment accordion.
   Moves existing DOM nodes (and their bound event handlers); no duplicated motor transport.
   All commands use the backend's existing guarded vendor-DLL lifecycle/STOP,
   or the new fresh-token supervised manual-position controller. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const toText=(id,v)=>{const n=$(id);if(n)n.textContent=String(v)};
const fmt=(n,d=3)=>Number.isFinite(Number(n))?Number(n).toFixed(d):'—';
const normalAngle=n=>Number.isFinite(Number(n))?((Number(n)+180)%360+360)%360-180:NaN;
const safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(url,method='GET',data){let r=await fetch(url,{method,headers:data?{'Content-Type':'application/json'}:undefined,body:data?JSON.stringify(data):undefined});let j={};try{j=await r.json()}catch{}if(!r.ok)throw Error(j.detail||`请求失败 HTTP ${r.status}`);return j}
const busyAction=async(fn)=>{try{await fn()}catch(e){window.console.error(e);window.alert(e.message)}};
let manualTokens={0:null,2:null},prepToken=null,manualActive=false,prepActive=false,connected=false,lastMotionError='',lastStatus=null;
function toggleModule(module){
  for(const el of document.querySelectorAll('#exp25-workspace details.exp-module')){
    if(el!==module && el.open)el.open=false;
  }
}
function moduleWrapper(index,title,description,id,node){
  const d=document.createElement('details');d.id=id;d.className='exp-module exp25-extra';
  d.innerHTML=`<summary class="exp-module-header"><span class="exp-module-index">${safe(index)}</span><span><strong>${safe(title)}</strong><small>${safe(description)}</small></span><span class="exp-module-chevron" aria-hidden="true"></span></summary>`;
  if(node)d.appendChild(node);
  return d;
}
function buildExperimentsFrame(){
  const page=$('page-experiments');if(!page||$('exp25-workspace'))return;
  const heading=page.querySelector(':scope > .page-heading');const note=page.querySelector(':scope > .exp-note');
  const frame=document.createElement('section');frame.id='exp25-workspace';frame.className='exp25-workspace glass';
  frame.innerHTML='<header class="exp25-frame-head"><div><span class="tt25-label">EXPERIMENT WORKSPACE</span><h2>实验任务工作台</h2><p>一个工作区管理全部模块 · 点击模块标题展开具体操作，其他模块自动收起</p></div><div class="exp25-head-actions"><button type="button" class="btn subtle" id="exp25-collapse">全部收起</button><button type="button" class="btn subtle" id="exp25-console">转台控制台</button></div></header>';
  if(note)note.after(frame);else heading.after(frame);
  const device=$('exp-device');const dynamic=$('dynamic-test');
  frame.appendChild(device);frame.appendChild(dynamic);
  dynamic.querySelector(':scope > .panel-head')?.setAttribute('hidden','');
  // Keep inherited #dynamic-test and all original controls/ids/events intact.
  const extraAdvanced=Array.from(dynamic.querySelectorAll(':scope > details.v60-advanced'));
  // Leave legacy service controls in their existing hidden/guarded location.
  // Move only top-level ancillary panels into explicit accordion modules.
  const extras=[
    ['06','同次采样与算法诊断','原始IMU/陀螺/融合角度与转台相位对照；仅已完成实验','exp25-timebase',null],
    ['07','静态稳定性对照','无需转台运动：静止样本噪声、漂移、不同滤波算法','exp25-stability',$('stationary-evaluation')],
    ['08','转台反馈与数据质量','只读位置、速度、反馈间隔；不会自动定位','exp25-table-monitor',$('turntable-monitor')],
    ['09','手动静态与轴向研究','低速多点静态与三点轴向检查；实验用途','exp25-manual',null],
    ['10','历史结果与诊断工具','历史实验结果、独立反馈与维护功能','exp25-history',null],
  ];
  for(const [idx,title,sub,id,node] of extras){
    const d=moduleWrapper(idx,title,sub,id,node);
    if(id==='exp25-timebase'){
      const region=document.createElement('div');region.className='exp25-inline-diag';
      region.innerHTML='<p>对同一场ROLL/PITCH实验进行加速度直算、校准陀螺角速度和已记录融合通道的表观相位比较。结果只用于归因，不是±0.05°验收。</p><div class="tt25-actions"><button type="button" class="btn primary" id="exp25-diag-run">分析最新动态实验</button><button type="button" class="btn subtle" id="exp25-diag-console">进入转台操作台</button></div><div id="exp25-diag-result" class="tt25-diagnostic-output">无报告 · 需先完成实验、确认停车并归档动态数据。</div>';
      d.appendChild(region);
    }else if(id==='exp25-manual'){
      const manual=page.querySelector('.real-test-panel');if(manual)d.appendChild(manual);
      const optional=page.querySelector('.v70-extra-diagnostics');if(optional)d.appendChild(optional);
    }else if(id==='exp25-history'){
      const result=$('experiment-result');if(result)d.appendChild(result);
      for(const el of extraAdvanced)d.appendChild(el);
    }
    frame.appendChild(d);
  }
  const expCards=$('experiment-cards');if(expCards)frame.appendChild(expCards);
  const modules=frame.querySelectorAll('details.exp-module');
  for(const detail of modules){detail.open=detail.id==='exp-device';detail.addEventListener('toggle',()=>{if(detail.open)toggleModule(detail)});}
  $('exp25-collapse').onclick=()=>modules.forEach(x=>x.open=false);
  $('exp25-console').onclick=()=>navigate('turntable');
  $('exp25-diag-console').onclick=()=>navigate('turntable');
  $('exp25-diag-run').onclick=()=>busyAction(()=>diagnose(true));
}
function navigate(page){const n=document.querySelector(`.nav-link[data-page="${page}"]`);n?.click()}
function portValue(){const p=$('tt25-port').value;const m=/^COM(\d+)$/i.exec(p);if(!m)throw Error('请选择一个有效的转台COM口');return Number(m[1])}
async function refreshPorts(){const {ports=[]}=await api('/api/ports');const el=$('tt25-port'),v=el.value||$('v58-table-port')?.value||'';
 el.innerHTML='<option value="">选择COM端口</option>'+ports.map(p=>`<option value="${safe(p.device)}">${safe(p.device+' · '+p.label)}</option>`).join('');if(ports.some(p=>p.device===v))el.value=v;
}
function flag(x,k,name,alarm=false){let on=!!x[k],bad=alarm?on:!on;return `<span class="tt25-flag ${bad?'bad':'good'}">${safe(name)} ${on?'●':'○'}</span>`}
function showStatus(s){lastStatus=s;connected=!!s.connected;toText('tt25-link-state',connected?'已连接 · COM'+s.port:'未连接');
 const cache=!!s.display_cache_only,age=Number(s.display_cache_age_ms);
 toText('tt25-fresh',!connected?'尚未读取设备':cache?`任务运行中 · 状态缓存${Number.isFinite(age)?' '+age.toFixed(0)+' ms':''}（非安全依据）`:'真实DLL状态已读取');
 for(const axis of [0,2]){
   const x=s.axes?.[String(axis)];const missing=!x;
   toText(`tt25-pos-${axis}`,missing?'—':fmt(normalAngle(x.position_deg),4));toText(`tt25-speed-${axis}`,missing?'—':fmt(x.speed_dps,4));
   toText(`tt25-state-${axis}`,missing?'无反馈':(!x.enabled?'未使能':!x.zeroed?'未找零':!x.healthy?'异常':'设备已就绪'));
   $(`tt25-flags-${axis}`).innerHTML=missing?'<span>无法读取轴状态；不允许移动</span>':[
     flag(x,'enabled','使能'),flag(x,'zeroed','机械找零'),flag(x,'healthy','正常'),
     flag(x,'in_place','到位'),flag(x,'upper_limit','上限',true),flag(x,'lower_limit','下限',true),
     flag(x,'driver_fault','驱动故障',true),flag(x,'over_speed','超速',true)
   ].join('');
 }
 $('tt25-connect').disabled=connected;$('tt25-disconnect').disabled=!connected;
}
async function refreshStatus(){const status=await api('/api/turntable/status');showStatus(status);return status}
async function refreshTasks(){const [m,p,n]=await Promise.all([api('/api/turntable/manual/status'),api('/api/turntable/prepare/status'),api('/api/turntable/console/status')]);
 manualActive=!!m.running;prepActive=!!p.running;
 if(m.axis!==null){const axis=m.axis;
    toText(`tt25-action-${axis}`,m.running?`正在${m.position_mode==='relative'?'相对转动':'绝对定位'} ${m.target_deg}° · ${m.speed_dps}°/s`:m.error?`异常：${m.error}`:['at_target','relative_observed_complete'].includes(m.state)?(m.stopped_verified?'控制器停车及反馈已确认':'等待停车确认'):`状态：${m.state}`);
 }
 $('tt25-prep-start').disabled=manualActive||prepActive;
 if(p.running || p.error || p.state==='ready')toText('tt25-prep-status',p.running?'准备执行中：'+p.state:p.error?'准备失败：'+p.error:'准备状态：'+p.state);
 document.querySelectorAll('#page-turntable .tt25-actions button:not([data-tt25-stop])').forEach(btn=>{if(!btn.id.startsWith('tt25-check-')&&!btn.id.startsWith('tt25-go-'))return;
   if(manualActive||prepActive||n.running)btn.disabled=true;
   else if(btn.id.startsWith('tt25-check-'))btn.disabled=false;
   else btn.disabled=false;
 });
}
function invalidatePrecheck(axis){manualTokens[axis]=null;toText(`tt25-action-${axis}`,'目标已更新，可直接点击运行')}
async function preflight(axis){if(manualActive||prepActive)throw Error('当前有运动任务，请先等待完成或停车');
  manualTokens[axis]=null;$(`tt25-go-${axis}`).disabled=true;
  const target=Number($(`tt25-target-${axis}`).value),speed=Number($(`tt25-velocity-${axis}`).value);
  const r=await api('/api/turntable/manual/preflight','POST',{axis,target_deg:target,speed_dps:speed,position_mode:$(`tt29-mode-${axis}`).value});
  manualTokens[axis]=r.token;$(`tt25-go-${axis}`).disabled=false;
  toText(`tt25-action-${axis}`,`预检查通过：${fmt(r.from_deg)}° → ${fmt(r.target_deg)}°，速度${r.speed_dps}°/s；30秒内须现场确认`);
}
async function runPosition(axis){
  if(manualActive||prepActive)throw Error('转台有运动任务正在执行，请先停车');
  const target=Number($(`tt25-target-${axis}`).value),speed=Number($(`tt25-velocity-${axis}`).value);
  if(!Number.isFinite(target)||!Number.isFinite(speed)||$(`tt25-target-${axis}`).value.trim()===''||$(`tt25-velocity-${axis}`).value.trim()==='')throw Error('请输入有效的目标位置和目标速度');
  $(`tt25-go-${axis}`).disabled=true;toText(`tt25-action-${axis}`,'已请求定位，正在核查两轴状态并发送厂家命令…');
  try{const result=await api('/api/turntable/manual/command','POST',{axis,target_deg:target,speed_dps:speed,position_mode:$(`tt29-mode-${axis}`).value});
      manualActive=!!result.running;toText(`tt25-action-${axis}`,'定位运行中 · 关闭页面或链路异常将触发自动停车');
  }finally{if(!manualActive)$(`tt25-go-${axis}`).disabled=false;}
}
async function stopAxes(){manualTokens={0:null,2:null};prepToken=null;$('tt25-go-0').disabled=true;$('tt25-go-2').disabled=true;$('tt25-prep-start').disabled=true;
  const s=await api('/api/turntable/stop','POST');
  manualActive=false;prepActive=false;
  $('tt25-prep-start').disabled=false;
  toText('tt25-prep-status',s.stopped_verified?'双轴停车已获位置/速度反馈确认':'STOP未获确认！立即使用实体急停并现场核查');
  if(!s.stopped_verified)window.alert('危险：STOP未确认，请使用实体急停并联系设备负责人。');
  await refreshStatus();
}
async function prepPreflight(){if(manualActive||prepActive)throw Error('其他运动任务尚未结束');prepToken=null;$('tt25-prep-start').disabled=true;
  const r=await api('/api/turntable/prepare/preflight','POST');prepToken=r.token;$('tt25-prep-start').disabled=false;
  toText('tt25-prep-status','预检通过，计划：'+(r.movement_plan||[]).map(x=>`轴${x.axis} ${x.action}（当前位置${fmt(x.current_deg)}°）`).join('；')+'。30秒内须二次确认。');
}
async function prepRun(){
  if(manualActive||prepActive)throw Error('请先结束当前运动任务');
  const v=Number($('tt25-zero-speed').value);
  const r=await api('/api/turntable/prepare/command','POST',{zero_speed_dps:v});
  prepActive=!!r.running;toText('tt25-prep-status','机械找零 / 归零运行中：'+r.state);
}
async function health(){const h=await api('/api/timebase/health');
  const wd=h.pipeline?.watchdog||{};
  const text=`IMU ${h.connected?'已连接':'未连接'} · UID ${h.uid||'—'} · 收到约${fmt(h.sample_rate_hz,1)}样本/秒 · 当前算法 ${h.algorithm||'—'} · 标定 ${h.cal_status||'—'} · 500ms融合看门狗未被修改\n原始采样与转台仅PC时基估算；不得将PC同时接收等同硬件同步。`;
  toText('tt25-pipeline-health',text);
}
function diagnosticResultHtml(r){
 const parts=(r.results||[]).map(x=>{
  const alg=(x.algorithms||[]);
  return `<div class="tt25-diag-run"><h3>${safe(x.direction_inferred_from_inner_axis?.toUpperCase()||'未知轴')} · ${safe(x.file)}</h3><p>${x.valid?`编码器 ${fmt(x.encoder_frequency_hz,4)}Hz · ±${fmt(x.encoder_amp_deg,3)}° · 最大反馈间隔 ${fmt(x.encoder_gap_ms?.max,1)}ms`:'数据不足：'+safe(x.reason)}</p>${x.valid?`<div class="tt25-tablewrap"><table><thead><tr><th>同次数据通道</th><th>相对编码器表观滞后</th><th>额外滞后vs陀螺</th><th>幅值比</th></tr></thead><tbody><tr><td>校准陀螺角速度积分参考</td><td>${fmt(x.calibrated_gyro_integral_apparent_lag_ms,2)} ms</td><td>基线</td><td>—</td></tr>${alg.map(a=>`<tr><td>${safe(a.algorithm)} <small>${safe(a.execution_mode)}</small></td><td>${fmt(a.apparent_lag_vs_encoder_ms,2)} ms</td><td>${fmt(a.apparent_extra_lag_vs_gyro_integration_ms,2)} ms</td><td>${fmt(a.amplitude_ratio_to_encoder,3)}</td></tr>`).join('')}</tbody></table></div>`:''}</div>`;
 }).join('');
 const l=(name)=>`/api/timebase/diagnose/download/${encodeURIComponent(name)}`;
 return `<p><strong>只读分析完成</strong>：${safe(r.source)}。<b>这是相位研究，不是0.05°验收。</b></p><div class="tt25-actions"><a class="btn subtle" href="${l(r.report_txt)}">下载TXT</a><a class="btn subtle" href="${l(r.report_json)}">下载JSON</a></div>${parts}`;
}
async function diagnose(fromExperiment){
 if(fromExperiment)toText('exp25-diag-result','正在读取最新一组归档CSV，生成研究性算法对照…');
 else toText('tt25-diag-result','正在读取最新一组归档CSV，生成研究性算法对照…');
 const r=await api('/api/timebase/diagnose/latest','POST');const html=diagnosticResultHtml(r);
 if($('exp25-diag-result'))$('exp25-diag-result').innerHTML=html;
 if($('tt25-diag-result'))$('tt25-diag-result').innerHTML=html;
}
function bind(){
 buildExperimentsFrame();
 $('tt25-ports').onclick=()=>busyAction(refreshPorts);
 $('tt25-refresh').onclick=()=>busyAction(refreshStatus);
 $('tt25-connect').onclick=()=>busyAction(async()=>{if(!window.confirm('即将连接转台并立即使能双轴。请确认负载由合适的机械装置支撑，人员与线缆已避开运动区域，实体急停可用。继续？'))return;
   const r=await api('/api/turntable/connect','POST',{port:portValue(),baudrate:Number($('tt25-baud').value),operator_confirmed:true,load_secured:true});showStatus(r);
   const p=$('v58-table-port');if(p)p.value='COM'+r.port;
 });
 $('tt25-disconnect').onclick=()=>busyAction(async()=>{if(!window.confirm('关闭转台会取消双轴伺服保持力。已再次确认负载有独立机械支撑，停止后可安全断使能？'))return;
   await api('/api/turntable/disconnect','POST',{acknowledged:true,load_secured:true});await refreshStatus();
 });
 $('tt25-stop').onclick=()=>busyAction(stopAxes);
 document.querySelectorAll('[data-tt25-stop]').forEach(b=>b.onclick=()=>busyAction(stopAxes));
 for(const axis of [0,2]){
  $(`tt25-go-${axis}`).onclick=()=>busyAction(()=>runPosition(axis));
  for(const id of [`tt25-target-${axis}`,`tt25-velocity-${axis}`,`tt29-mode-${axis}`])$(id).addEventListener('input',()=>invalidatePrecheck(axis));
 }
 // Legacy preflight API is preserved, but the main console needs only one click.

 $('tt25-prep-start').onclick=()=>busyAction(prepRun);
 $('tt25-zero-speed').addEventListener('input',()=>{prepToken=null;$('tt25-prep-start').disabled=true});
 $('tt25-health').onclick=()=>busyAction(health);
 $('tt25-diagnose').onclick=()=>busyAction(()=>diagnose(false));
 $('tt25-open-experiment').onclick=()=>navigate('experiments');
 refreshPorts().catch(()=>{});refreshStatus().catch(()=>{});health().catch(()=>{});
 setInterval(()=>{
   if(manualActive)api('/api/turntable/manual/heartbeat','POST').catch(err=>{if(!/409/.test(err.message))window.console.warn('manual heartbeat',err)});
   if(prepActive)api('/api/turntable/prepare/heartbeat','POST').catch(()=>{});
 },1100);
 setInterval(()=>{
   if(!$('page-turntable').classList.contains('active')&&!manualActive&&!prepActive)return;
   refreshTasks().then(()=>refreshStatus()).catch(err=>toText('tt25-fresh','设备读取/任务状态失败：'+err.message));
 },1400);
}
bind();
})();
