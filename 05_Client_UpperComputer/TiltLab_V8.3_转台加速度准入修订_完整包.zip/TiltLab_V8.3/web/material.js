/* Presentation-only specular response, no changes to sensor data or device actions. */
(function () {
  if (!window.matchMedia || !window.matchMedia('(pointer:fine)').matches) return;
  document.addEventListener('pointermove', (event) => {
    const element = event.target.closest('.btn,.nav-link,.seg-control button,.algo-item');
    if (!element) return;
    const rect = element.getBoundingClientRect();
    element.style.setProperty('--glx', `${Math.max(0,Math.min(100,((event.clientX - rect.left) / rect.width)*100)).toFixed(1)}%`);
  }, {passive:true});
})();
