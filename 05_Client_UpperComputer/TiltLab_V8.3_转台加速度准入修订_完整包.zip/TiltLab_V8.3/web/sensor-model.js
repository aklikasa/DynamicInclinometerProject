/*
 * Connector-free industrial inclinometer model. Self-contained Canvas 3D renderer.
 * No CAD, CDN, images or external runtime dependencies. V4.6 UI-only change.
 * Sensor axes use right-handed X/Y/Z; view drag changes camera, not IMU attitude.
 */
(() => {
  'use strict';
  const canvas = document.getElementById('sensor-3d');
  if (!canvas) return;
  const ctx = canvas.getContext('2d', { alpha: true });
  if (!ctx) return;
  const PI = Math.PI, DEG = PI / 180;
  let W = 0, H = 0, scale = 1;
  let cameraAz = -0.88, cameraEl = 0.64, zoom = 1;
  let desired = [0, 0, 0], smooth = [0, 0, 0];
  let poseFrameCache = new WeakMap(), rotationMatrix = [1,0,0,0,1,0,0,0,1];
  let dragging = false, oldPointer = null, currentPointer = null;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const add = (a, b) => a.map((v, i) => v + b[i]);
  const sub = (a, b) => a.map((v, i) => v - b[i]);
  const scale3 = (a, k) => a.map(v => v * k);
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
  const norm = a => {const n=Math.hypot(...a)||1; return scale3(a, 1/n)};
  const rotX = (p, a) => [p[0], p[1]*Math.cos(a)-p[2]*Math.sin(a), p[1]*Math.sin(a)+p[2]*Math.cos(a)];
  const rotY = (p, a) => [p[0]*Math.cos(a)+p[2]*Math.sin(a),p[1],-p[0]*Math.sin(a)+p[2]*Math.cos(a)];
  const rotZ = (p, a) => [p[0]*Math.cos(a)-p[1]*Math.sin(a),p[0]*Math.sin(a)+p[1]*Math.cos(a),p[2]];
  // Recompute trigonometry once per render, not for every vertex of every face.
  function prepareRotation() {
    const a=smooth[0]*DEG,b=smooth[1]*DEG,c=smooth[2]*DEG;
    const sa=Math.sin(a),ca=Math.cos(a),sb=Math.sin(b),cb=Math.cos(b),sc=Math.sin(c),cc=Math.cos(c);
    rotationMatrix=[cc*cb, cc*sb*sa-sc*ca, cc*sb*ca+sc*sa,
                    sc*cb, sc*sb*sa+cc*ca, sc*sb*ca-cc*sa,
                    -sb,   cb*sa,             cb*ca];
  }
  function sensorRotation(p) {
    const m=rotationMatrix,x=p[0],y=p[1],z=p[2];
    return [m[0]*x+m[1]*y+m[2]*z,m[3]*x+m[4]*y+m[5]*z,m[6]*x+m[7]*y+m[8]*z];
  }
  function camBasis() {
    const c = [Math.cos(cameraAz)*Math.cos(cameraEl), Math.sin(cameraAz)*Math.cos(cameraEl), Math.sin(cameraEl)];
    const forward = scale3(c,-1);
    const right = norm(cross(forward,[0,0,1]));
    const up = norm(cross(right,forward));
    return {c,right,up};
  }
  let basis;
  function project(p) {
    const cached=poseFrameCache.get(p);
    if(cached)return cached;
    const q=sensorRotation(p);
    const v={x:W*.51+dot(q,basis.right)*scale,
             y:H*.515-dot(q,basis.up)*scale,depth:dot(q,basis.c),q};
    poseFrameCache.set(p,v);
    return v;
  }
  // Rounded rectangle sampled in the XY plane, mathematically symmetric.
  function contour(hx,hy,r,steps=6) {
    const pts=[];
    for (const [cx,cy,start] of [[hx-r,hy-r,0],[-hx+r,hy-r,PI/2],[-hx+r,-hy+r,PI],[hx-r,-hy+r,3*PI/2]]) {
      for(let i=0;i<=steps;i++){const a=start+PI*i/(2*steps);pts.push([cx+r*Math.cos(a),cy+r*Math.sin(a)])}
    }
    return pts;
  }
  function polyPath(ps) {ctx.beginPath();ps.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath()}
  const mat = {
    base:[168,173,172], wall:[185,188,185], top:[222,224,220], lid:[220,222,219],
    trim:[206,211,207], rim:[237,239,237], fin:[145,149,145], groove:[102,107,106]
  };
  const meshes=[];
  function face(v, color, kind='surface', extra={}) { meshes.push({v,color,kind,...extra}) }
  function shell(outline,zBot,zTop,topMat,sideMat,topKind='surface') {
    for(let i=0;i<outline.length;i++){
      const a=outline[i],b=outline[(i+1)%outline.length];
      face([[a[0],a[1],zBot],[b[0],b[1],zBot],[b[0],b[1],zTop],[a[0],a[1],zTop]],sideMat);
    }
    face(outline.map(p=>[...p,zTop]),topMat,topKind);
  }
  // The real-world reference is a blank, cast aluminium enclosure without a connector.
  const flange=contour(1.60,1.17,.18,6);
  const housing=contour(1.39,.985,.19,6);
  const cap=contour(1.34,.945,.18,6);
  const cover=contour(1.275,.892,.15,6);
  shell(flange,-.41,-.315,mat.base,mat.base);
  shell(housing,-.335,.215,mat.top,mat.wall);
  shell(cap,.205,.264,mat.rim,mat.trim);
  shell(cover,.255,.289,mat.lid,mat.trim,'brushed');
  // Sidewall fins: deep recess, edge highlight and elevated metal rib.
  for(let i=0;i<11;i++){
    const x=-1.13+i*.226;
    face([[x-.018,-.990,-.298],[x+.012,-.990,-.298],[x+.012,-.990,.136],[x-.018,-.990,.136]],mat.groove,'groove');
    face([[x+.013,-.996,-.286],[x+.045,-.996,-.286],[x+.045,-.996,.123],[x+.013,-.996,.123]],mat.fin,'fin');
  }
  for(let i=0;i<7;i++){
    const y=-.72+i*.24;
    face([[1.395,y-.014,-.292],[1.395,y+.008,-.292],[1.395,y+.008,.115],[1.395,y-.014,.115]],mat.groove,'groove');
    face([[1.401,y+.012,-.286],[1.401,y+.034,-.286],[1.401,y+.034,.108],[1.401,y+.012,.108]],mat.fin,'fin');
  }
  // Four horizontal mounting bosses and recessed fastening holes.
  for(let x of [-1.46,1.46])for(let y of [-1.055,1.055]){
    const ring=(radius,z,n=22)=>Array.from({length:n},(_,i)=>[x+radius*Math.cos(2*PI*i/n),y+radius*Math.sin(2*PI*i/n),z]);
    face(ring(.104,-.310),[185,188,185],'holeRing');
    face(ring(.073,-.307),[85,89,90],'hole');
    face(ring(.055,-.306),[57,63,63],'holeInner');
  }
  // Body/cover seam and hairline around top, with no brand lettering.
  const seams=[];
  for(const o of [cover,cap])for(let i=0;i<o.length;i++){
    const a=o[i],b=o[(i+1)%o.length];seams.push([a,b]);
  }
  function baseShade(rgb, luminosity) {
    return rgb.map(v=>clamp(v*luminosity,0,255)|0);
  }
  const rgb = a => `rgb(${a.map(Math.round).join(',')})`;
  function drawFace(mesh) {
    const q=mesh.v.map(project);
    if(q.length<3)return;
    const normal=norm(cross(sub(q[1].q,q[0].q),sub(q[2].q,q[0].q)));
    // Keep only faces oriented toward the camera; allows proper rear-side visibility.
    if(dot(normal,basis.c)<=.015)return;
    const l=clamp(.78+.22*dot(normal,norm([-.5,-.32,1.55])),.63,1.03);
    const color=baseShade(mesh.color,l);
    polyPath(q);
    // The face normal already provides metal illumination. A gradient for each
    // tiny side facet was expensive and visually redundant.
    if(mesh.kind==='brushed'){
      const g=ctx.createLinearGradient(W*.25,H*.18,W*.82,H*.85);
      g.addColorStop(0,rgb(color.map(v=>clamp(v+12,0,255))));
      g.addColorStop(.47,rgb(color));
      g.addColorStop(1,rgb(color.map(v=>clamp(v-10,0,255))));
      ctx.fillStyle=g;
    }else ctx.fillStyle=rgb(color);
    ctx.fill();
    if(['brushed','surface','holeRing'].includes(mesh.kind)){
      ctx.lineWidth=mesh.kind==='brushed'?.75:.65;
      ctx.strokeStyle=mesh.kind==='brushed'?'rgba(255,255,255,.92)':'rgba(255,255,255,.36)';ctx.stroke();
    }
    if(mesh.kind==='brushed'){
      ctx.save();polyPath(q);ctx.clip();ctx.lineWidth=.45;
      for(let j=0;j<14;j++){
        const t=j/13;
        ctx.strokeStyle=j%3?'rgba(84,89,89,.023)':'rgba(255,255,255,.13)';
        const yy=H*.14+t*H*.71;
        ctx.beginPath();ctx.moveTo(W*.14,yy);ctx.lineTo(W*.87,yy-H*.14);ctx.stroke();
      }
      ctx.restore();
    }
  }
  function drawArrow(a,b,color,name){
    const A=project(a), B=project(b),angle=Math.atan2(B.y-A.y,B.x-A.x);
    ctx.save();ctx.lineCap='round';ctx.lineJoin='round';
    ctx.shadowColor='rgba(255,255,255,.94)';ctx.shadowBlur=5;
    ctx.strokeStyle=color;ctx.fillStyle=color;ctx.lineWidth=2.7;
    ctx.beginPath();ctx.moveTo(A.x,A.y);ctx.lineTo(B.x,B.y);ctx.stroke();
    const len=10, spread=.49;
    ctx.beginPath();ctx.moveTo(B.x,B.y);
    ctx.lineTo(B.x-len*Math.cos(angle-spread),B.y-len*Math.sin(angle-spread));
    ctx.lineTo(B.x-len*Math.cos(angle+spread),B.y-len*Math.sin(angle+spread));ctx.closePath();ctx.fill();
    ctx.shadowBlur=0;ctx.font='700 12px -apple-system, Segoe UI, Arial';ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.lineWidth=3.5;ctx.strokeStyle='rgba(255,255,255,.94)';
    const tx=B.x+13*Math.cos(angle),ty=B.y+13*Math.sin(angle);
    ctx.strokeText(name,tx,ty);ctx.fillText(name,tx,ty);
    ctx.restore();
  }
  function draw(){
    if(!W||!H)return;
    ctx.clearRect(0,0,W,H);
    basis=camBasis();
    prepareRotation();
    poseFrameCache=new WeakMap();
    const sorted=meshes.map(m=>({m,z:m.v.reduce((a,p)=>a+project(p).depth,0)/m.v.length})).sort((a,b)=>a.z-b.z);
    for(const el of sorted)drawFace(el.m);
    // A small soft floor-shadow gives the enclosure weight without fake geometry.
    // XYZ markers are physically attached to the sensor's top face.
    const org=[0,0,.305];
    const c=project(org); ctx.fillStyle='#5c6764';ctx.beginPath();ctx.arc(c.x,c.y,3.5,0,2*PI);ctx.fill();
    drawArrow(org,[.77,0,.305],'#c74a43','X');
    drawArrow(org,[0,.76,.305],'#39a06c','Y');
    drawArrow(org,[0,0,.97],'#487dbb','Z');
  }
  function resize(){
    const box=canvas.getBoundingClientRect();
    if(box.width<20||box.height<20)return;
    W=box.width;H=box.height;
    const dpr=Math.min(1.5,window.devicePixelRatio||1);
    const wp=Math.max(1,Math.round(W*dpr)),hp=Math.max(1,Math.round(H*dpr));
    if(canvas.width!==wp||canvas.height!==hp){canvas.width=wp;canvas.height=hp;}
    ctx.setTransform(dpr,0,0,dpr,0,0);
    scale=Math.min(W/3.85,H/2.85)*zoom;
  }
  let lastPaint=0,lastTick=0,paintWindowStart=0,paintWindowCount=0,actualFps=0,poseDirty=true;
  function step(timestamp){
    // Presentation is independent of the 20Hz network transport, capped at
    // the display's natural refresh, with no synthetic sensor measurements.
    if(!lastTick)lastTick=timestamp-16.667;
    const elapsed=timestamp-lastTick;
    if(elapsed>=15){
      lastTick=timestamp;
      const dt=Math.min(.08,elapsed/1000);
      const blend=1-Math.exp(-dt/.055);
      let moving=dragging||poseDirty;
      for(let i=0;i<3;i++){
        const delta=(i===0||i===2)?((desired[i]-smooth[i]+540)%360)-180:desired[i]-smooth[i];
        if(Math.abs(delta)>.00015){smooth[i]+=delta*blend;moving=true;}
      }
      if(moving){
        if(canvas.getClientRects().length){draw();paintWindowCount++;}
        poseDirty=false;lastPaint=timestamp;
      }else if(timestamp-lastPaint>500){
        // No redraw while the sensor is stationary: saves CPU/GPU work.
        lastPaint=timestamp;
      }
      if(timestamp-paintWindowStart>=1000){
        actualFps=paintWindowCount*1000/(timestamp-paintWindowStart||1);
        paintWindowCount=0;paintWindowStart=timestamp;
      }
    }
    window.requestAnimationFrame(step);
  }
  function setAngles(roll,pitch,yaw){
    const vals=[roll,pitch,yaw];
    for(let i=0;i<3;i++)if(Number.isFinite(+vals[i]) && Math.abs(desired[i]-(+vals[i]))>1e-6){desired[i]=+vals[i];poseDirty=true;}
  }
  function dragStart(e){dragging=true;oldPointer=[e.clientX,e.clientY];currentPointer=e.pointerId;canvas.setPointerCapture?.(e.pointerId)}
  canvas.addEventListener('pointerdown',dragStart);
  canvas.addEventListener('pointermove',e=>{
    if(!dragging||currentPointer!==e.pointerId)return;
    cameraAz+=(e.clientX-oldPointer[0])*.009;
    cameraEl=clamp(cameraEl+(e.clientY-oldPointer[1])*.006,-.30,1.48);
    oldPointer=[e.clientX,e.clientY];poseDirty=true;
  });
  for(const evt of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(evt,()=>{dragging=false;currentPointer=null});
  canvas.addEventListener('wheel',e=>{e.preventDefault();zoom=clamp(zoom*(e.deltaY<0?1.09:.91),.65,1.6);poseDirty=true;},{passive:false});
  canvas.addEventListener('dblclick',()=>{cameraAz=-.88;cameraEl=.64;zoom=1;poseDirty=true});
  window.addEventListener('resize',()=>{resize();poseDirty=true});
  if(window.ResizeObserver) new ResizeObserver(()=>{resize();poseDirty=true}).observe(canvas);
  window.tiltSensorModel={setAngles, frameRate:()=>actualFps, reset:()=>{cameraAz=-.88;cameraEl=.64;zoom=1;poseDirty=true}, info:'无接口金属外壳；XYZ实时旋转；非精密CAD；优化投影与金属材质绘制'};
  resize();window.requestAnimationFrame(step);
})();
