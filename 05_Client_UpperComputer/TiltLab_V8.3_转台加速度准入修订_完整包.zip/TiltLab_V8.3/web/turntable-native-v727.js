/* V7.27 Full per-axis native DLL controls. No duplicated COM or motor transport. */
(()=>{'use strict';
const $=id=>document.getElementById(id),axes=[0,2];
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(url,post){const r=await fetch(url,{method:post?'POST':'GET',headers:post?{'Content-Type':'application/json'}:undefined,body:post?JSON.stringify(post):undefined});let j={};try{j=await r.json()}catch{}if(!r.ok)throw Error(j.detail||`HTTP ${r.status}`);return j;}
const number=(id)=>{const x=$(id);if(!x||!x.value.trim()||!Number.isFinite(Number(x.value)))throw Error('请填写有效数值：'+id);return Number(x.value)};
let nativeActive=false,nativeAxis=null,nativeMode=null,actionBusy=false;
function feedback(a,msg,fail=false){const p=$(`tt27-message-${a}`);if(p){p.textContent=msg;p.classList.toggle('tt27-error',!!fail)}}
const modeNames={velocity:'速度运动',sway:'正弦摇摆',home:'机械找零'};
function render(){
 for(const a of axes){
  const card=document.querySelector(`#page-turntable .tt25-axis[data-tt25-axis="${a}"]`);
  if(!card||$(`tt27-native-${a}`))continue;
  const position=card.querySelector('.tt25-motion');const buttons=card.querySelector('.tt25-actions');
  if(position){const t=document.createElement('h3');t.className='tt27-section-title';t.innerHTML='01 · 位置运动 <small>SetAxisPosition</small>';position.before(t)}
  const tools=document.createElement('section');tools.id=`tt27-native-${a}`;tools.className='tt27-native';
  tools.innerHTML=`
   <section class="tt27-op tt27-op-head"><h3>伺服与轴控制 <small>AXIS ${a}</small></h3>
    <div class="tt27-controls"><button type="button" class="btn primary" id="tt27-enable-${a}">使能</button><button type="button" class="btn subtle" id="tt27-disable-${a}">断使能</button><button type="button" class="btn tt25-stop" id="tt27-stop-${a}">停止${a===0?'内':'外'}轴</button></div>
    <label class="tt27-small-check"><input type="checkbox" id="tt27-load-${a}"> 断使能时负载已有独立支撑</label>
   </section>
   <section class="tt27-op"><h3>02 · 速度运动 <small>SetAxisVelocity</small></h3><div class="tt27-fields three">
      <label>角速度 °/s <input type="number" id="tt27-vspeed-${a}" value="10" step="0.1"></label>
      <label>角加速度 °/s² <input type="number" id="tt27-vaccel-${a}" value="1" step="0.1"></label>
      <label>持续秒数 <input type="number" id="tt27-vtime-${a}" value="1" step="0.5"></label>
    </div><button type="button" class="btn primary" id="tt27-velocity-${a}">启动速度运动</button></section>
   <section class="tt27-op"><h3>03 · 正弦摇摆 <small>SetAxisSway</small></h3><div class="tt27-fields three">
      <label>幅度 ±° <input type="number" id="tt27-amp-${a}" value="5" step="0.1"></label>
      <label>频率 Hz <input type="number" id="tt27-freq-${a}" value="0.3" step="0.01"></label>
      <label>持续秒数 <input type="number" id="tt27-stime-${a}" value="10" step="1"></label>
    </div><button type="button" class="btn primary" id="tt27-sway-${a}">启动独立摇摆</button></section>
   <section class="tt27-op"><h3>04 · 机械找零 <small>SetAxisFindZero</small></h3><div class="tt27-fields three">
      <label>找零速度 °/s <input type="number" id="tt27-hspeed-${a}" value="0.3" step="0.1"></label>
      <label>角加速度 °/s² <input type="number" id="tt27-haccel-${a}" value="0.3" step="0.1"></label>
      <label>超时秒数 <input type="number" id="tt27-htime-${a}" value="120" step="10"></label>
    </div><button type="button" class="btn subtle" id="tt27-home-${a}">机械找零（本轴）</button></section>
   <p class="tt27-message" id="tt27-message-${a}" role="status">等待设备连接</p>`;
  if(buttons)buttons.after(tools);else card.appendChild(tools);
  const servo=tools.querySelector('.tt27-op-head');
  if(servo)card.querySelector('.tt25-flags')?.after(servo);
  // Legacy position STOP is retained. The other controls use the same backend DLL.
 }
}
async function perform(axis,label,call){
 if(actionBusy)return;actionBusy=true;
 feedback(axis,`正在执行${label}…`);
 try{const value=await call();feedback(axis,`${label}：命令已受理${value?.running?'，正在实时监控':''}`);await poll()}catch(e){feedback(axis,e.message,true)}finally{actionBusy=false}
}
async function start(axis,mode){
 const opts={axis,mode};
 if(mode==='velocity')Object.assign(opts,{speed_dps:number(`tt27-vspeed-${axis}`),accel_dps2:number(`tt27-vaccel-${axis}`),duration_s:number(`tt27-vtime-${axis}`)});
 if(mode==='sway')Object.assign(opts,{amplitude_deg:number(`tt27-amp-${axis}`),frequency_hz:number(`tt27-freq-${axis}`),duration_s:number(`tt27-stime-${axis}`)});
 if(mode==='home')Object.assign(opts,{speed_dps:number(`tt27-hspeed-${axis}`),accel_dps2:number(`tt27-haccel-${axis}`),duration_s:number(`tt27-htime-${axis}`)});
 return api('/api/turntable/console/start',opts);
}
async function stop(axis){const s=await api('/api/turntable/console/stop-axis',{axis});
 feedback(axis,s.stopped_verified?'已发出STOP且获得双轴停止反馈':'STOP未确认，请立即现场检查',!s.stopped_verified);
 return s;
}
async function poll(){
 const [n,m,p]=await Promise.all([
   api('/api/turntable/console/status'),api('/api/turntable/manual/status'),api('/api/turntable/prepare/status')]);
 nativeActive=!!n.running;nativeAxis=n.axis;nativeMode=n.mode;
 const busy=n.running||m.running||p.running;
 for(const axis of axes){
  for(const mode of ['velocity','sway','home']){const btn=$(`tt27-${mode}-${axis}`);if(btn)btn.disabled=busy}
  const enable=$(`tt27-enable-${axis}`),disable=$(`tt27-disable-${axis}`);
  if(enable)enable.disabled=busy;if(disable)disable.disabled=busy;
 }
 if(n.axis!==null){
  const a=n.axis;
  if(n.running)feedback(a,`${modeNames[n.mode]||n.mode}运行中 · 监控反馈与心跳`);
  else if(n.error)feedback(a,`${modeNames[n.mode]||n.mode}：${n.error}`,true);
  else if(n.state==='finished')feedback(a,`${modeNames[n.mode]||n.mode}已完成 · ${n.stopped_verified?'停止已确认':'等待停车确认'}`);
 }
}
function bind(){render();for(const a of axes){
 $(`tt27-enable-${a}`).onclick=()=>perform(a,'使能',()=>api('/api/turntable/console/enable',{axis:a}));
 $(`tt27-disable-${a}`).onclick=()=>perform(a,'断使能',()=>api('/api/turntable/console/disable',{axis:a,load_secured:$(`tt27-load-${a}`).checked}));
 $(`tt27-stop-${a}`).onclick=()=>perform(a,'停止',()=>stop(a));
 for(const mode of ['velocity','sway','home'])$(`tt27-${mode}-${a}`).onclick=()=>perform(a,modeNames[mode],()=>start(a,mode));
 }
 setInterval(()=>{if(nativeActive)api('/api/turntable/console/heartbeat',{}).catch(e=>console.warn('转台持续运动心跳',e.message));},1100);
 setInterval(()=>{if(!document.getElementById('page-turntable')?.classList.contains('active')&&!nativeActive)return;
 poll().catch(e=>console.warn('转台操作状态刷新',e.message));},1300);
 poll().catch(()=>{});
}
bind();
})();
