(()=>{'use strict';
const $=id=>document.getElementById(id), all=s=>Array.from(document.querySelectorAll(s));
const ALGO_INFO={gravity_observer:['自适应重力观测器（V7.16无杆臂）','IMU因果重力残差门控、梯形积分、静止零偏估计；无杆臂'],gyro_anchor3d:['动态重力约束 + 三维杆臂（V7.15研究）','实时静止零偏估计与因果杆臂补偿；不依赖转台'],adaptive3d:['三维杆臂 + Adaptive（V7.15研究）','因果刚体加速度补偿后执行Adaptive Mahony；不依赖转台或运动频率，参数须验证'],lever3d:['三维杆臂补偿融合（V7.15实验）','自动辨识后，经独立验证及现场确认应用；因果三轴运动加速度补偿 + Madgwick，不使用转台角度'],accel:['加速度直算（无滤波）','直接使用每次加速度读数计算倾角；不做时间平滑'],gyro:['纯陀螺积分','短时跟踪 / 长期漂移'],complementary:['互补滤波','低频加计 + 高频陀螺'],mahony:['Mahony','四元数PI姿态校正'],adaptive:['自适应 Mahony','根据加速度可信度调整权重'],madgwick:['Madgwick','梯度下降式姿态估计'],kalman:['双轴 Kalman','两轴角度 / 零偏状态估计'],leverarm:['旋转附加加速度补偿（试验）','陀螺角加速度×IMU Z向偏移补偿后再执行Madgwick；需验证安装几何'],adaptive_lever:['自适应旋转补偿融合（研发）','基于运动创新残差与重力一致性动态调整β，静止估计陀螺零偏；Z向偏心补偿可选'],motion_guard:['运动干扰抑制（实验）','动态ACC抑制实验对照；需注意偏置与漂移'],gyro_anchor:['陀螺主导·动态重力约束（V7.8）','保留旧版陀螺主导与静止偏置估计对照'],vqf6d:['VQF-6D（论文基准）','作者官方VQF，无磁力计；零偏估计与重力低频修正。固定采样周期模型，存在固件批间缺口时只作研究对照'],vqf_lever:['VQF-6D + Z杆臂补偿','仅对已实测的Z向安装偏心补偿切向/向心加速度；默认距离为0']};
const PARAMS=[['kp','Mahony 比例反馈 Kp',0,10,.05],['ki','Mahony 积分反馈 Ki',0,1,.005],['alpha','互补滤波 α',.8,1,.001],['beta','Madgwick β',.001,.5,.001],['acc_threshold','加速度模长可信度阈值',.015,.6,.005],['kalman_r','Kalman 测量噪声 R',.005,1,.005],['lever_z_cm','Z向等效偏心距离（cm，带符号）',-50,50,1],['lever_tau_s','角速度导数平滑时间常数（s）',.02,.4,.01],['adaptive_beta_floor','自适应β最小比例',.01,1,.01],['adaptive_acc_innovation_gps','加速度创新阈值（g/s）',.02,1,.01],['vqf_nominal_hz','VQF标称IMU ODR（Hz，须与设备一致）',52,1667,1],['vqf_tau_acc_s','VQF重力校正时间常数（秒）',.3,30,.1]];
const DEFAULT={kp:2.3,ki:.035,alpha:.985,beta:.075,acc_threshold:.14,kalman_r:.15,lever_z_cm:0,lever_tau_s:.09,adaptive_beta_floor:.12,adaptive_acc_innovation_gps:.12,vqf_nominal_hz:833,vqf_tau_acc_s:3};
const state={active:'dashboard',axis:'roll',status:null,meta:null,params:{...DEFAULT},algo:'gyro_anchor',latestResult:null,history:[],replay:null,ws:null};
let toastTimer=null, lastFetch=0, chartPending=false, chartBounds={}; let lastUi=0;let chartPaints=[];
let pushWindowStart=0,pushWindowCount=0,pushRate=0,lastChartFrame=0,lastDataArrival=0;
let chartShownCache={seq:null,rows:[]}, chartViewportFrame=0;
const fmt=(x,n=2)=>Number.isFinite(x)?Number(x).toFixed(n):'—';
const encoderAngle=(x,n=3)=>{if(!Number.isFinite(x))return '—';const d=((Number(x)+180)%360+360)%360-180;return fmt(d,n)+'°'+(Math.abs(x-d)>.1?'（原始'+fmt(x,n)+'°）':'')};
const txt=(id,val)=>{const o=$(id);if(o&&o.textContent!==String(val))o.textContent=val};
const escapeHtml=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(message,error=false){let el=$('toast');el.textContent=message;el.className='toast show'+(error?' error':'');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.className='toast',3500)}
async function request(route,method='GET',data=null){const options={method};if(data){if(data instanceof FormData)options.body=data;else{options.headers={'Content-Type':'application/json'};options.body=JSON.stringify(data)}}const res=await fetch(route,options);let payload={};try{payload=await res.json()}catch{}if(!res.ok)throw Error(payload.detail||`服务器错误 ${res.status}`);return payload}
function execute(f){return async(...args)=>{try{await f(...args)}catch(e){toast(e.message,true);console.error(e)}}}
function setPage(page){state.active=page;all('.nav-link').forEach(el=>el.classList.toggle('active',el.dataset.page===page));all('.page').forEach(el=>el.classList.toggle('active',el.id==='page-'+page));const names={dashboard:'实时监测',algorithms:'融合算法',calibration:'标定管理',experiments:'自动化实验',turntable:'转台控制',records:'数据分析',settings:'设置'};txt('crumb',names[page]);if(page==='records')refreshFiles();if(page==='settings')refreshPorts();if(page==='dashboard')scheduleChart();if(page==='experiments'){refreshPorts().catch(()=>{});refreshWorkbenchTable().catch(()=>{});}if(page==='experiments'&&state.latestResult)drawExperiment();if(page==='experiments'&&state.stabilityReport)setTimeout(drawStabilityBars,80);if(page==='records'&&state.replay)drawReplay();scrollTo({top:0,behavior:'smooth'})}
function drawLine(canvas,rows,axis,keys,stable=false){if(!canvas)return;const dpr=Math.min(1.5,devicePixelRatio||1);const rect=canvas.getBoundingClientRect();const w=rect.width,h=rect.height;if(!w||!h)return;const pxw=Math.floor(w*dpr),pxh=Math.floor(h*dpr);if(canvas.width!==pxw||canvas.height!==pxh){canvas.width=pxw;canvas.height=pxh}const c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);
const margin={l:48,r:14,t:14,b:32},cw=w-margin.l-margin.r,ch=h-margin.t-margin.b;
let min=Infinity,max=-Infinity;for(const r of rows)for(const def of keys){const v=def.value(r,axis);if(Number.isFinite(v)){if(v<min)min=v;if(v>max)max=v}}
const hasVals=Number.isFinite(min);if(!hasVals){min=-10;max=10;}
 let pad=Math.max(.6,(max-min)*.16);min-=pad;max+=pad;
 if(stable && hasVals){const key=axis+'|'+state.algo;
   const prev=chartBounds[key];
   if(prev){const step=.15;min=min<prev.min?min:prev.min+(min-prev.min)*step;
     max=max>prev.max?max:prev.max+(max-prev.max)*step;}
   chartBounds[key]={min,max};
 }
const time1=rows.length?(stable?(state.chartViewportEnd||rows.at(-1).t):rows.at(-1).t):1,time0=stable?time1-10:(rows.length?rows[0].t:0),span=time1-time0||1;
const y=v=>margin.t+ch*(max-v)/(max-min),x=t=>margin.l+(t-time0)/span*cw;
c.font='10px Inter, Arial';c.strokeStyle='rgba(80,84,80,.11)';c.fillStyle='#989c98';c.lineWidth=1;
for(let i=0;i<=4;i++){const yy=margin.t+i*ch/4;c.beginPath();c.moveTo(margin.l,yy);c.lineTo(margin.l+cw,yy);c.stroke();c.textAlign='right';c.fillText(fmt(max-i*(max-min)/4,1)+'°',margin.l-8,yy+3)}
for(let i=0;i<=5;i++){const xx=margin.l+i*cw/5;c.fillStyle='#9b9d99';c.textAlign='center';c.fillText((stable?fmt(-10+i*10/5,0):fmt(time0+i*span/5,1))+'s',xx,h-11)}
if(!rows.length)return;
for(const def of keys){c.beginPath();let first=true;for(const r of rows){let val=def.value(r,axis);if(!Number.isFinite(val)||!Number.isFinite(r.t)){first=true;continue}let xx=x(r.t),yy=y(val);if(first){c.moveTo(xx,yy);first=false}else c.lineTo(xx,yy)}c.strokeStyle=def.color;c.lineWidth=def.weight||1.8;c.globalAlpha=def.opacity||1;c.setLineDash(def.dash||[]);c.stroke();c.globalAlpha=1;c.setLineDash([])}
}
const series=[{color:'#acb1ab',weight:1.65,value:(r,a)=>r.raw?.[a]},{color:'#292f2a',weight:2.5,value:(r,a)=>r.cal?.[a]},{color:'#be9674',weight:2,value:(r,a)=>r.ref?.[a],dash:[5,4]}];
const liveSeries=[
 {color:'#acb1ab',weight:1.65,value:(r,a)=>r.curves?.[state.algo]?.raw?.[a]??r.raw?.[a]},
 {color:'#292f2a',weight:2.5,value:(r,a)=>r.curves?.[state.algo]?.cal?.[a]??r.cal?.[a]},
 {color:'#be9674',weight:2,value:(r,a)=>r.ref?.[a],dash:[5,4]}];
function drawLive(){
 if(state.active!=='dashboard')return;
 const data=state.history;if(!data.length){drawLine($('live-chart'),[],state.axis,liveSeries);return}
 const last=data[data.length-1],end=last.t;
 if(chartShownCache.seq!==last.seq){
   chartShownCache={seq:last.seq,rows:data.filter(r=>r.t>=end-10.2)};
 }
 const shown=($('show-unfiltered')?.checked) ? [...liveSeries,{color:'#769987',weight:1.3,opacity:.85,dash:[3,3],value:(r,a)=>r.curves?.accel?.cal?.[a]??r.curves?.accel?.raw?.[a]}] : liveSeries;
 drawLine($('live-chart'),chartShownCache.rows,state.axis,shown,true);
}
function scheduleChart(){chartPending=true;}
function liveChartLoop(now){
 const dt=lastChartFrame?Math.min(.08,(now-lastChartFrame)/1000):1/60;
 if(state.active==='dashboard' && state.history.length){
   const recent=now-lastDataArrival<220;
   if((chartPending||recent) && now-lastChartFrame>=16){
     const sampleEnd=state.history[state.history.length-1].t;
     // Smooth the viewport only. Every curve vertex is still a real IMU sample.
     const lead=recent?Math.min(.045,(now-lastDataArrival)/1000):0;
     const target=sampleEnd+lead;
     if(!Number.isFinite(state.chartViewportEnd)||!state.chartViewportEnd||Math.abs(target-state.chartViewportEnd)>2){
       state.chartViewportEnd=target;
     }else{
       const k=1-Math.exp(-dt/.055);
       state.chartViewportEnd+=(target-state.chartViewportEnd)*k;
     }
     lastChartFrame=now;
     drawLive();chartPending=false;
     chartPaints.push(now);
     while(chartPaints.length&&chartPaints[0]<now-1000)chartPaints.shift();
   }
 }
 requestAnimationFrame(liveChartLoop);
}
function updateRatePanel(){
 const s=state.status||{};
 const p=s.pipeline;if(p){txt('pipeline-metrics',`${p.transport_mode==='isolated_process'?'独立采集进程':'未启动采集进程'} · IPC峰值 ${p.ipc_peak_polls??0} 次 · 原始采集 ${fmt(p.acquisition_hz,1)} Hz · 实时处理 ${fmt(s.sample_rate_hz,1)} Hz · 原始保存 ${p.raw_written_samples}/${p.acquired_samples} · 队列 ${p.queued_batches} 批 / 峰值 ${p.peak_queued_batches} · 收包后计算 ${fmt(p.latest_processing_age_ms??0,2)} ms · 估算样本年龄 ${fmt(p.latest_sample_age_ms??0,2)} ms ${p.continuity_degraded_since_connect?"· 本连接曾有长缺口，姿态为估计值":""} · 陀螺缺口预测 ${p.gap_bridges??0} 次 / 长缺口 ${p.long_gap_bridges??0} 次 / 重置 ${p.gap_resets} 次 · 最长串口读取 ${fmt(p.max_serial_read_ms??0,1)} ms · 最长轮询停顿 ${fmt(p.max_poll_idle_ms??0,1)} ms · ${p.error||'未硬件同步'}`);if($('pipeline-apply'))$('pipeline-apply').disabled=!!s.running;if($('pipeline-mode')){$('pipeline-mode').disabled=!!s.running;if(document.activeElement!==$('pipeline-mode'))$('pipeline-mode').value=p.mode||'offline';}}
 txt('rate-odr',Number.isFinite(Number(s.nominal_odr_hz))&&Number(s.nominal_odr_hz)>0?fmt(Number(s.nominal_odr_hz),0)+' Hz':'—');
 txt('rate-samples',s.running?fmt(Number(s.last_seen_s)>1?0:s.sample_rate_hz,0)+' Hz':'—');
 txt('rate-push',pushRate>0?fmt(pushRate,1)+' Hz':'—');
 txt('rate-chart',state.active==='dashboard'?(chartPaints.length+' FPS'):'—');
 txt('rate-pose',window.tiltSensorModel?.frameRate?fmt(window.tiltSensorModel.frameRate(),0)+' FPS':'—');
 txt('rate-age',s.running&&s.last_seen_s!=null?fmt(s.last_seen_s*1000,0)+' ms':'—');
 txt('chart-render-status',chartPaints.length+' FPS');
}
function appendChartDelta(delta){
 if(!Array.isArray(delta)||!delta.length)return;
 const last=state.history.length?state.history.at(-1).seq:-1;
 for(const row of delta)if(row.seq>last)state.history.push(row);
 if(state.history.length>1200)state.history=state.history.slice(-1200);
 $('live-empty').style.display=state.status?.pipeline?.mode==='offline'||!state.history.length?'flex':'none';lastDataArrival=performance.now();scheduleChart();
}

function showMetric(id,n,unit,precision=2){const el=$(id);if(el)el.innerHTML=Number.isFinite(n)?`${fmt(n,precision)}<small>${unit}</small>`:`—<small>${unit}</small>`}
function updateStatus(s){updateWorkbenchDevices(s);renderExperimentInputState(s);state.status=s;state.algo=s.algorithm;const active=s.running&&(s.source==='simulation'||s.source==='serial');let headline=s.source==='simulation'&&s.running?'SIMULATED':s.source==='serial'&&s.running?'HARDWARE':'OFFLINE';
const head=$('head-source');head.className='state-pill'+(headline==='SIMULATED'?' sim':headline==='HARDWARE'?' real':'');head.innerHTML=`<i></i> ${headline==='HARDWARE'?'已连接':headline==='SIMULATED'?'模拟':'未连接'}`;
txt('sidebar-status',headline==='HARDWARE'?'真实PCB在线':headline==='SIMULATED'?'模拟数据运行中':'设备未连接');txt('side-source',headline==='SIMULATED'?'数字孪生 / 非真实数据':headline==='HARDWARE'?(s.uid||'串口已打开'):'等待选择数据源');$('side-dot').className='status-dot '+(headline==='HARDWARE'?'':headline==='SIMULATED'?'blue':'gray');
const latest=s.latest,cal=latest?.cal,raw=latest?.raw;
if($('live-empty')){$('live-empty').textContent=s.pipeline?.mode==='offline'?'默认离线采集：六轴正常记录；停车后计算所有Roll/Pitch算法':'暂无角度数据，请连接RS485设备';$('live-empty').style.display=s.pipeline?.mode==='offline'||!state.history.length?'flex':'none';}
showMetric('m-roll',(cal||raw)?.roll,'°');showMetric('m-pitch',(cal||raw)?.pitch,'°');showMetric('m-temp',latest?.temp,'°C',1);
showMetric('m-count',s.count,'点',0);txt('m-roll-delta',cal&&raw?`Δ ${fmt(cal.roll-raw.roll,3)}°`:'—');txt('m-pitch-delta',cal&&raw?`Δ ${fmt(cal.pitch-raw.pitch,3)}°`:'—');txt('m-output-label',s.pipeline?.mode==='offline'?'离线采集 · 不计算角度':cal?(s.cal_mode==='thermal'?'全温补偿融合':'常温补偿融合'):'未标定融合');txt('m-output-label2',s.pipeline?.mode==='offline'?'离线采集 · 不计算角度':cal?(s.cal_mode==='thermal'?'全温补偿融合':'常温补偿融合'):'未标定融合');
txt('raw-roll',raw?fmt(raw.roll,3)+'°':'—');txt('raw-pitch',raw?fmt(raw.pitch,3)+'°':'—');txt('cal-roll',cal?fmt(cal.roll,3)+'°':'—');txt('cal-pitch',cal?fmt(cal.pitch,3)+'°':'—');txt('comp-label-roll',(s.cal_mode==='thermal'?'全温':s.cal_mode==='ambient'?'常温':'补偿已关闭')+' · ROLL');txt('comp-label-pitch',(s.cal_mode==='thermal'?'全温':s.cal_mode==='ambient'?'常温':'补偿已关闭')+' · PITCH');
txt('m-freq',s.running?`实测 ${fmt(s.sample_rate_hz,0)} 样本/秒`:'等待采集');txt('m-rec',s.recording?`录制 ${s.record_rows}点`:'未录制');
if(latest?.acc&&latest?.gyro){for(const [n,arr] of [['a',latest.acc],['g',latest.gyro]])if(arr){['x','y','z'].forEach((axis,i)=>txt(n+axis,fmt(arr[i],5)))}}
const pose=cal||raw;if(pose){txt('pose-roll',fmt(pose.roll)+'°');txt('pose-pitch',fmt(pose.pitch)+'°');txt('pose-yaw',fmt(pose.yaw)+'°');txt('pose-trust',cal?(cal.trust_available===false?'VQF内部':' '+fmt(cal.trust*100,0)+'%'):'—');window.tiltSensorModel?.setAngles(pose.roll,pose.pitch,pose.yaw)}
txt('chart-algo',s.pipeline?.mode==='offline'?'离线模式：停车后再融合':(ALGO_INFO[s.algorithm]||['自适应 Mahony'])[0]);txt('chart-cal-state',s.cal_status==='simulated'?'演示合成标定':s.cal_status==='matched'?(s.cal_mode==='thermal'?'全温研究模型已匹配':'常温标定已匹配'):s.cal_status==='disabled'?'补偿关闭':s.cal_runtime_error?'补偿暂停：'+s.cal_runtime_error:'无有效标定配对');txt('chart-time',fmt(latest?.t||0,2)+' s');
txt('health-device',active?'RS485 · 采集中':'未连接');
txt('health-calibration',!active?'等待连接':s.cal_runtime_error?'补偿暂停':s.cal_status==='matched'?(s.cal_mode==='thermal'?'全温补偿':'常温补偿'):'仅原始融合');
txt('health-algorithm',s.pipeline?.mode==='offline'?'离线原始六轴采集（无姿态计算）':(ALGO_INFO[s.algorithm]||['Mahony'])[0]);
txt('health-record',s.recording?'录制中 · '+s.record_rows+' 点':'未录制');
const hErr=$('health-error');const hText=s.error||s.cal_runtime_error||((active&&s.cal_mode!=='none'&&s.cal_status!=='matched')?s.cal_detail:'');hErr.hidden=!hText;hErr.textContent=hText||'';
txt('uid-number',s.uid||'—');txt('uid-full',s.uid_hex?'完整UID：'+s.uid_hex:'完整96-bit UID：尚未读取');
const matched=s.cal_status==='matched';const modeLabel=s.cal_mode==='thermal'?'全温补偿':s.cal_mode==='ambient'?'常温标定':'无补偿';
txt('cal-status-pill',matched?modeLabel+' · 配对成功':s.cal_status==='disabled'?'已关闭补偿':s.cal_status==='uid_missing'?'等待UID':s.cal_status==='ambiguous'?'存在版本冲突':s.cal_status==='incompatible'?'文件不兼容':s.cal_status==='invalid'?'文件校验失败':s.cal_status==='missing'?'文件不完整':'未匹配');
txt('cal-headline',s.cal_runtime_error?'实时补偿已暂停':matched?modeLabel+'已加载':s.cal_status==='disabled'?'原始融合运行中':modeLabel+'未能启用');
txt('cal-details',s.cal_runtime_error?s.cal_runtime_error:(s.cal_detail||'等待设备UID和标定文件。'));
txt('cal-files',s.cal_files?.length?s.cal_files.join('　/　'):'—');
txt('cal-errors',(s.cal_issues||[]).slice(0,4).join('；'));
const cds=s.cal_diagnostics||[];$('cal-matrix-diagnostics').innerHTML=cds.length?cds.map(d=>`<div class="matrix-diagnostic ${d.status==='valid'?'valid':'invalid'}"><strong>${escapeHtml(d.file||'')}</strong><span>${d.status==='valid'?`${escapeHtml((d.sensor||'').toUpperCase())} · 条件数 ${fmt(d.condition,3)} · 行列式 ${fmt(d.determinant,6)}`:escapeHtml(d.reason||'校验未通过')}</span></div>`).join(''):'';
if(!state.settingsDirty){$('cal-folder').value=s.cal_folder||'';$('cal-source-kind').value=s.cal_source||'local';}
txt('cal-current-path',s.cal_folder||'尚未配置（在设置中选择目录）');
txt('cal-save-status',state.settingsDirty?'修改尚未保存':s.cal_folder?'已保存 · 自动匹配':'未配置');
if(!state.settingsHydrated){state.settingsHydrated=true;updateLibraryHelp()}
all('[name="cal-mode"]').forEach(el=>{el.checked=el.value===s.cal_mode});
const events=s.events||[];if(state.active==='settings')$('events').innerHTML=events.length?events.map(e=>`<div class="event-entry"><time>${escapeHtml(e.time)}</time><span>${escapeHtml(e.message)}</span></div>`).join(''):'<p class="help">暂无事件</p>';
const out=latest?.outputs||{};if(state.active==='algorithms')$('algo-results').innerHTML=Object.entries(ALGO_INFO).map(([id,entry])=>{const v=out[id];return `<tr class="${id===s.algorithm?'current':''}"><td>${entry[0]}</td><td>${v?fmt(v.raw.roll,3)+'°':'—'}</td><td>${v?.cal?fmt(v.cal.roll,3)+'°':'—'}</td><td>${v?.cal?fmt(v.cal.pitch,3)+'°':'—'}</td><td>${v?.cal?(v.cal.trust_available===false?'VQF内部自适应':fmt(v.cal.trust*100,0)+'%'):'—'}</td><td>${v?.cal?.beta_eff!==undefined?fmt(v.cal.beta_eff,4):'—'}</td></tr>`}).join('');
if(s.error&&s.error!==updateStatus.previousError){toast('采集错误：'+s.error,true);updateStatus.previousError=s.error}
}
async function refreshStatus(history=false){const s=await request('/api/status'+(history?'?history=true':''));updateStatus(s);if(history){state.history=s.history||[];chartShownCache.seq=null;state.chartViewportEnd=null;$('live-empty').style.display=state.status?.pipeline?.mode==='offline'||!state.history.length?'flex':'none';drawLive()}}
async function begin(source,mode){const payload=source==='simulation'?{source,mode:mode||$('sim-mode').value}:{source:'serial',port:$('serial-port').value,baudrate:Number($('serial-baud').value),address:Number($('serial-address').value)};await request('/api/start','POST',payload);await refreshStatus(true);toast(source==='simulation'?'独立模拟数据源已启动（非真实测量）':'已连接真实PCB并开始采样')}
function updateWorkbenchDevices(s){
 if(!s)return;
 txt('v58-imu-status',s.connected&&s.running?'已连接 · '+(s.uid||'等待UID'):'未连接');
 txt('v58-cal-status',s.cal_status==='matched'?'标定补偿已匹配 · '+(s.cal_mode==='thermal'?'全温':'常温'):'标定状态：'+(s.cal_status||'未匹配'));
}
function updateWorkbenchTable(r){
 const axes=r.axes||{};
 const stale=r.display_cache_only&&(r.display_cache_age_ms==null||r.display_cache_age_ms>1000);
 const unknown=r.connected&&['0','2'].some(k=>!axes[k]);
 txt('v58-table-state',r.connected?(unknown?'DLL已打开，但两轴状态均未确认；请查看转台运行日志':(['0','2'].every(k=>axes[k]?.enabled)?'已连接 · 双轴已使能':(['0','2'].every(k=>axes[k]&&!axes[k].enabled)?'通信连接中 · 双轴已断使能':'通信已连接 · 双轴未全部使能'))):'转台未连接');
 if(r.display_cache_only){const el=$('v58-table-state');if(el)el.textContent+=(stale?' · 缓存过期，不能作为安全依据':' · 实验状态缓存 '+fmt(r.display_cache_age_ms,0)+'ms');}
 const open=$('v58-connect-table'),close=$('v58-close-table');
 if(open)open.disabled=!!r.connected||tableLifecycleWorking;
 if(close)close.disabled=!r.connected||tableLifecycleWorking;
 const power=$('tt-power-label');if(power)power.textContent=r.connected?('已打开 · '+(['0','2'].every(k=>axes[k]?.enabled)?'双轴已使能':'检查使能反馈')):'已关闭 / 未连接';
 const sw=document.querySelector('.tt-power-switch');if(sw)sw.dataset.connected=r.connected?'true':'false';
 $('v58-axes').innerHTML=r.connected?[0,2].map(ax=>{const x=axes[String(ax)];return !x?'<span>轴'+ax+'反馈缺失</span>':`<span class="v58-axis-item"><strong>${ax===0?'内轴':'外轴'} · ${encoderAngle(x.position_deg,3)}</strong> · ${fmt(x.speed_dps,3)}°/s · <em>${x.enabled?'已使能':'未使能'} / ${x.zeroed?'已找零':'未找零'} / ${x.healthy?'正常':(!x.enabled&&!x.zeroed?'状态未确认':'未正常')}</em></span>`}).join(''):'转台未连接。';
}
function connectionAuthorization(){
 if(!$('table-lifecycle-ack').checked)throw Error('连接前只需勾选一次：已确认现场监护和负载断使能后的机械支撑');
 return {operator_confirmed:true,load_secured:true};
}
let tableLifecycleWorking=false;
async function closeTableSimple(){
 if(!window.confirm('关闭转台将实际解除伺服保持力。只有在设备负责人已确认负载受到独立机械支撑、失去保持力不会转动时才可继续。否则取消，并按现场安全规程处理。'))return;
 txt('v58-table-state','正在停车、确认静止并解除双轴使能……');
 const result=await request('/api/turntable/disconnect','POST',{acknowledged:true,load_secured:true});
 $('table-lifecycle-ack').checked=false;
 updateTable({connected:false});
 toast(result.disabled_verified?'双轴已确认断使能，通信已关闭':'转台已关闭');
}
async function refreshWorkbenchTable(){
 try{updateWorkbenchTable(await request('/api/turntable/status'))}catch(e){txt('v58-table-state','反馈读取失败：'+e.message)}
}
function bindWorkbench(){
 $('v58-goto-imu').onclick=()=>setPage('settings');
 $('v58-connect-imu').addEventListener('click',execute(async()=>{
  const port=$('v58-imu-port').value;if(!/^COM\d+$/i.test(port))throw Error('请从下拉列表选择倾角仪COM口');
  const baudrate=Number($('v58-imu-baud').value),address=Number($('v58-imu-address').value);
  if(!Number.isInteger(address)||address<1||address>247)throw Error('从站地址必须是1–247');
  await request('/api/start','POST',{source:'serial',port,baudrate,address});
  $('serial-port').value=port;$('serial-baud').value=String(baudrate);$('serial-address').value=String(address);
  await refreshStatus(true);toast('真实PCB已连接，检查UID和标定是否已匹配');
 }));
 $('v58-refresh-ports').addEventListener('click',execute(refreshPorts));
 $('v58-connect-table').addEventListener('click',execute(async()=>{
   if(tableLifecycleWorking)return;
   tableLifecycleWorking=true;
   $('v58-connect-table').disabled=true;$('v58-close-table').disabled=true;
   try{
     const status=await request('/api/turntable/status');
     if(status.connected)throw Error('转台已经打开，请直接点击「关闭转台」');
     const port=$('v58-table-port').value;
     if(!/^COM\d+$/i.test(port))throw Error('请在下拉列表中选择实际转台COM口');
     const r=await request('/api/turntable/connect','POST',{port:Number(port.replace(/^COM/i,'')),baudrate:Number($('v58-table-baud').value),...connectionAuthorization()});
     $('table-port').value=port;$('table-baud').value=$('v58-table-baud').value;
     updateTable(r);toast('转台已打开：内轴0和外轴2均已自动使能');
   }finally{
     tableLifecycleWorking=false;
     try{await refreshWorkbenchTable()}catch(_){}
   }
 }));
 $('v58-close-table').addEventListener('click',execute(async()=>{
   if(tableLifecycleWorking)return;
   tableLifecycleWorking=true;
   $('v58-connect-table').disabled=true;$('v58-close-table').disabled=true;
   try{await closeTableSimple()}finally{
     tableLifecycleWorking=false;
     try{await refreshWorkbenchTable()}catch(_){}
   }
 }));
 $('v58-read-table').addEventListener('click',execute(async()=>{const r=await request('/api/turntable/status?diagnose=true');updateWorkbenchTable(r);updateTable(r)}));
 $('v58-global-stop').addEventListener('click',execute(async()=>{const r=await request('/api/turntable/stop','POST');toast(r.stopped_verified?'已请求停车，双轴已反馈停止':'停车尚未确认，请现场检查硬件急停',!r.stopped_verified);await refreshWorkbenchTable()}));
}
function updateTable(r){updateWorkbenchTable(r);txt('table-connect-badge',r.connected?'转台已连接':'未连接');if(!r.connected){txt('table-state','未连接实机转台');return}const a=r.axes||{};txt('table-state',Object.entries(a).map(([id,v])=>`轴${id}: ${encoderAngle(v.position_deg,3)} / ${fmt(v.speed_dps,3)}°/s · ${v.healthy?'正常':(!v.enabled&&!v.zeroed?'状态未确认':'未正常')} · ${v.enabled?'已使能':'未使能'} · ${v.zeroed?'已找零':'未找零'}`).join('　|　'))}
async function selectAlgorithm(name){
 await request('/api/config','POST',{algorithm:name});
 state.algo=name;buildAlgorithms();fillQuickSelector();drawLive();
 if(!$('quick-tuning').hidden)renderQuickParams();
 await refreshStatus(false);
 toast('已切换观察算法：'+ALGO_INFO[name][0]+'（滤波状态未重置）');
}
let factoryPrompted=null,factoryPolling=false,factoryStarting=false,factoryRunning=false;
async function refreshFactoryHandoff(r){
 if(factoryPolling)return;factoryPolling=true;
 try{
  const h=r.factory||await request('/api/calibration/factory-handoff');
  factoryRunning=!!h.running;
  const eligible=!r.running&&r.stopped_verified===true&&r.state==='stopped_or_failed'&&String(r.error||'').includes('静态未达到设定门槛')&&!r.plan?.calibration_only;
  const key=String(r.run_manifest_file||r.started_at||r.error);
  $('factory-prepare').hidden=!eligible;
  $('factory-prepare').disabled=!eligible||factoryRunning||factoryStarting||!!h.safety_latched;
  $('factory-standalone').disabled=!!r.running||factoryRunning||factoryStarting||!!h.safety_latched;
  $('factory-cancel').disabled=!factoryRunning;
  txt('factory-handoff-status',[eligible?'静态超差：已确认停车，可选择自动重新标定。':'',h.detail,h.worker?.detail,h.job?'标定记录及备份：'+h.job:'',h.loaded_files?'新标定文件：'+h.loaded_files.join('；'):'',h.final_pipeline?.error?'采集链路：'+h.final_pipeline.error:(h.reconnect_pipeline?'标定后采集模式：单算法实时＋ACC直算':''),h.diagnostic_zip?'小体积诊断包：'+h.diagnostic_zip:'',h.note].filter(Boolean).join('\n')||'待命：先连接IMU及已使能、已建立机械零点的转台。');
  if(eligible&&!factoryRunning&&!factoryStarting&&!h.safety_latched&&factoryPrompted!==key&&(!h.run_manifest_file||h.run_manifest_file!==r.run_manifest_file)){
    factoryPrompted=key;
    if(window.confirm('静态精度超差，已确认停车。是否准备重新进行ACC＋GYRO常温标定？\n尚未确认机械安全条件时不会执行任何运动。')){
      $('factory-handoff-panel').scrollIntoView({behavior:'smooth',block:'center'});
      if($('factory-safety').checked)await confirmFactory(false);
      else toast('请先由设备负责人核实独立机械支撑及全周路径，再勾选标定安全确认并点击确认重标定。');
    }
  }
 }catch(e){txt('factory-handoff-status','标定状态/启动失败：'+e.message)}finally{factoryPolling=false}
}
async function confirmFactory(manual){
 if(factoryStarting||factoryRunning)throw Error('已有标定任务');
 if(!$('factory-safety').checked)throw Error('未确认独立机械保护、全周运动路径和现场监护；禁止标定');
 if(!window.confirm((manual?'开始独立常温标定？':'重新标定并重新静态预检？')+'\n包含双轴全周运动和连续速率运动。双轴保持使能，但断电或驱动故障仍可能失去保持力。仅在独立机械保护已验证、线缆与急停安全且现场监护时确认。'))return;
 factoryStarting=true;
 try{await request('/api/calibration/factory-handoff/prepare','POST',{acknowledged:true,load_secured:true,manual:!!manual});factoryRunning=true;toast('R10自动标定任务已启动，保持页面及现场监护');}
 finally{factoryStarting=false}
}
let autoRunning=false,autoBusy=false,autoLastReport=null,autoConnecting=false,autoLastManifest=null;
const AUTO_PHASES={pre_research_static:'每轴摇摆前静止诊断／初始化',factory_calibration:'R10常温自动标定',idle:'尚未开始',prechecking:'正在确认转台和倾角仪数据',
 enabling_and_zeroing:'自动准备：根据状态使能、机械找零或回到0°',static_alignment_calibration:'静态14点 + 实测安装轴预检 + 对齐标定',auto_calibration_signal_retry:'预检速度信号不足，原授权角度内以3°/s重采',auto_mount_calibration_recovery:'预检未通过，继续双轴静态标定候选与反向独立验证（不摇摆）',validating_static_alignment:'核验静态对齐与安装轴诊断',static_accuracy_precheck:'正在自动逐点定位、停稳采样并校核静态误差',
 switching_orientation:'正在切换Roll/Pitch测试方向',positioning_axis_2_to_0:'外轴回到0°',positioning_axis_0_to_90:'内轴定位90°，准备Pitch测试',positioning_axis_0_to_0:'内轴回到0°',returning_to_zero:'双轴恢复0°',saving_report:'全部运动结束，正在统一离线回放及生成报告',preparing_test:'转台已就绪，正在核验动态测试参数',testing:'正在进行正弦跟踪实验并保存原始数据',
 disabling_servos:'已确认停车，正在按现场预授权断使能',saving_calibration:'自动保存本次安装标定参数',completed:'自动任务已完成（标定/动态依模式显示）',aborting:'正在停止运动',stopped_or_failed:'自动实验已中止'};
function updateFullFlow(r){
 const steps=['connect','prepare','roll-static','roll-dynamic','pitch-static','pitch-dynamic','report'];
 const mode=r.plan?.mounting_mode||$('dyn-test-mode').value;
 const hasPitch=mode!=='x_outer',hasRoll=mode!=='y_inner_90';
 const cur=r.current_stage?.output|| (hasRoll?'roll':'pitch');
 const inStatic=r.state==='static_accuracy_precheck';
 const stage=r.state;
 const current=(stage==='prechecking'||autoConnecting)?'connect':
     stage==='enabling_and_zeroing'?'prepare':
     inStatic?(cur==='pitch'?'pitch-static':'roll-static'):
     (stage==='testing'||stage==='preparing_test')?(cur==='pitch'?'pitch-dynamic':'roll-dynamic'):
     (stage.startsWith('positioning_')||stage==='switching_orientation')?(cur==='pitch'?'pitch-static':'roll-static'):
     (stage==='returning_to_zero'||stage==='saving_report'||stage==='completed'||(r.motion_completed&&r.report_completed))?'report':'connect';
 let reached=false;
 for(const name of steps){
   const el=$('auto-flow-steps')?.querySelector(`[data-phase="${name}"]`);if(!el)continue;
   const skipped=(!hasPitch&&name.startsWith('pitch-'))||(!hasRoll&&name.startsWith('roll-'));
   el.classList.toggle('active',name===current&&r.running&&!skipped);
   el.classList.toggle('done',(stage==='completed'||(r.motion_completed&&r.report_completed&&r.stopped_verified))&&!skipped||(!reached&&name!==current&&!skipped));
   el.classList.toggle('blocked',stage==='stopped_or_failed'&&name===current&&!(r.motion_completed&&r.report_completed&&r.stopped_verified));
   if(name===current)reached=true;
   if(skipped){el.classList.remove('active','done','blocked');el.title='当前模式不测试此方向';}
 }
 const n=r.static_progress;
 const location=n?`${n.direction==='roll'?'Roll':'Pitch'} 静态第 ${n.step}/${n.total} 点 · 自动定位外轴 ${Number(n.target_deg)>0?'+':''}${n.target_deg}°`:'';
 const summary=(r.state==='analysis_invalid'?r.error:r.error?(r.motion_completed&&r.report_completed&&r.stopped_verified?`运动、报告已完成；实时采集需人工恢复：${r.error}`:`已中止：${r.error}`):r.state==='completed'?'所有选定步骤已完成，已生成实验报告':
    autoConnecting?'正在检查/连接选择的COM口，校验UID及补偿文件……':
    r.running?(location||`${AUTO_PHASES[r.state]||r.state}；完成后自动进入下一个阶段，无需手动调角度。`):
    '一次启动后自动执行全部静态点和动态摇摆；遇到静态超差、限位或停车反馈异常将停止，禁止强行进入下一阶段。');
 txt('auto-full-progress',summary);
}
function validCalibratedSixAxis(imu){
 const sample=imu?.latest;
 const valid=(a)=>Array.isArray(a)&&a.length===3&&a.every(v=>typeof v==='number'&&Number.isFinite(v));
 return !!(imu?.running&&imu?.source==='serial'&&imu?.cal_status==='matched'&&
   !imu?.cal_runtime_error&&valid(sample?.acc_cal)&&valid(sample?.gyro_cal)&&
   Number.isFinite(imu?.last_seen_s)&&imu.last_seen_s<=0.75);
}
function validExperimentInput(imu,mountCalibration=false){
 if(!imu?.running||imu?.source!=='serial'||imu?.cal_status!=='matched'||imu?.cal_runtime_error)return false;
 const mode=imu?.pipeline?.mode||'realtime';
 // R10 installation calibration and single-algorithm realtime require a pose output.
 if(mode!=='offline'||mountCalibration)return !!imu.latest?.cal;
 return validCalibratedSixAxis(imu);
}
function renderExperimentInputState(imu){
 const el=$('v82-auto-ready-hint');if(!el)return;
 const offline=imu?.pipeline?.mode==='offline';
 if(!imu?.running){el.textContent='未连接 PCB：请先选择正确 COM 口；实验还需要确认转台和现场安全条件。';return;}
 if(imu?.cal_status!=='matched'){
  el.textContent='标定文件尚未匹配：'+(imu?.cal_detail||imu?.cal_status||'未知原因')+'。请检查设备 UID、常温 ACC/GYRO 文件和标定目录。';return;
 }
 if(imu?.cal_runtime_error){el.textContent='校正数据无效：'+imu.cal_runtime_error+'；禁止开始自动运动。';return;}
 if(!validExperimentInput(imu)){
  el.textContent=offline?'离线模式：正在等待连续有效的校正 ACC/GYRO 六轴样本；不要求实时 Roll/Pitch。':'实时模式：正在等待选定算法姿态输出；请保持设备静止。';return;
 }
 el.textContent=(offline?'离线校正六轴数据已就绪':'实时姿态输出已就绪')+'；开始实验前仍需验证转台、负载、限位和现场急停。';
}
async function ensureAutoConnections(mountCalibration=false){
 // Called only after the operator explicitly confirms the complete path.
 // Never infer an unknown COM port: only the currently chosen UI ports are used.
 let imu=await request('/api/status');let table=await request('/api/turntable/status');
 const imuPort=$('v58-imu-port').value,tablePort=$('v58-table-port').value;
 if(imu.running&&imu.source!=='serial')throw Error('当前运行的不是RS485实机；请先停止该数据源');
 if(!imu.running){
   if(!/^COM\d+$/i.test(imuPort))throw Error('请选择真实PCB串口（一次选择，之后无需单独点击连接）');
  txt('auto-status','正在连接真实倾角仪，读取UID并匹配标定文件……');
   await request('/api/start','POST',{source:'serial',port:imuPort,baudrate:Number($('v58-imu-baud').value),address:Number($('v58-imu-address').value)});
 }
 if(!mountCalibration&&imu.pipeline?.mode==='offline'&&$('anchor3d-auto-ack').checked)throw Error('离线采集不支持实时3D候选初始化：请取消专项候选勾选，或断开PCB后切换单算法实时模式');
 if(!mountCalibration&&$('anchor3d-auto-ack').checked){
   // Explicit operator request; apply before connecting or enabling turntable.
   let ready=false;
   for(let i=0;i<24;i++){
     imu=await request('/api/status');
     if(imu.running&&imu.cal_status==='matched'&&imu.latest?.cal){ready=true;break;}
     if(!imu.running||imu.error)throw Error('IMU未就绪，未开始自动实验');
     await new Promise(resolve=>setTimeout(resolve,250));
   }
   if(!ready)throw Error('请先确认常温标定有效，未开始自动实验');
   const p=imu.params||{};
   const applied=imu.algorithm==='gyro_anchor3d'&&p.lever3_x_cm===0&&p.lever3_y_cm===0&&Math.abs(p.lever3_z_cm-19.51)<1e-6;
   if(!applied){
     if(table.connected)throw Error('启用研究候选前，请先停车并安全关闭转台连接，再点击完整自动实验；未发送运动指令');
     imu=await request('/api/lever-identify/research-z','POST',{same_fixture_confirmed:true,research_only_confirmed:true});
     state.params={...DEFAULT,...imu.params};state.algo=imu.algorithm;buildSliders();buildAlgorithms();fillQuickSelector();updateStatus(imu);
   }
   txt('auto-status','重力约束3D已启用；请保持静止，等待零偏估计就绪……');
   let biasReady=false;
   for(let i=0;i<32;i++){
     imu=await request('/api/status');
     if(!imu.running||imu.error)throw Error('IMU数据中断，未开始自动实验');
     if(imu.algorithm==='gyro_anchor3d'&&imu.latest?.cal?.stationary_bias_ready&&imu.latest?.cal?.lever_compensation_ready){biasReady=true;break;}
     await new Promise(resolve=>setTimeout(resolve,250));
   }
   if(!biasReady)throw Error('重力约束零偏尚未就绪；请保持设备静止后再启动，未发送运动指令');
 }
 if(!mountCalibration&&imu.pipeline?.mode==='offline'){
   let ready=false;
   for(let i=0;i<24;i++){
     imu=await request('/api/status');
     if(validCalibratedSixAxis(imu)){ready=true;break;}
     if(!imu.running||imu.error)throw Error('IMU未正常采集：'+(imu.error||'连接已停止'));
     if(imu.cal_status&&imu.cal_status!=='matched'&&i>=3)throw Error('ACC/GYRO厂标定未匹配：'+(imu.cal_detail||imu.cal_status));
     if(imu.cal_runtime_error)throw Error('ACC/GYRO校正异常：'+imu.cal_runtime_error);
     await new Promise(resolve=>setTimeout(resolve,250));
   }
   if(!ready)throw Error('离线采集六轴数据尚未就绪：请查看标定目录、数据更新和串口状态；不要求实时Roll/Pitch');
 }
 if(!mountCalibration&&imu.pipeline?.mode!=='offline'&&!$('anchor3d-auto-ack').checked){
   let ready=false;
   for(let i=0;i<24;i++){imu=await request('/api/status');if(imu.running&&imu.cal_status==='matched'&&imu.latest?.cal){ready=true;break;}await new Promise(resolve=>setTimeout(resolve,250));}
   if(!ready)throw Error('厂标定未就绪，未开始自动实验');
   const p=imu.params||{},target=$('general-observer-select').value;
   if(imu.algorithm!==target||['lever_z_cm','lever3_x_cm','lever3_y_cm','lever3_z_cm'].some(k=>Math.abs(p[k]||0)>1e-10)){
     if(table.connected)throw Error('切换通用无杆臂算法前，请先安全停车并断开转台；未发送运动指令');
     imu=await request('/api/general-observer/prepare','POST',{algorithm:target});
     state.params={...DEFAULT,...imu.params};state.algo=imu.algorithm;buildSliders();buildAlgorithms();fillQuickSelector();updateStatus(imu);
   }
   let biasReady=false;
   for(let i=0;i<40;i++){imu=await request('/api/status');if(imu.algorithm===target&&imu.latest?.cal?.stationary_bias_ready){biasReady=true;break;}if(!imu.running||imu.error)throw Error('IMU数据中断，未发送运动指令');await new Promise(resolve=>setTimeout(resolve,250));}
   if(!biasReady)throw Error('无杆臂重力观测器零偏尚未就绪，请保持静止，未发送运动指令');
 }
 if(!table.connected){
   if(!/^COM\d+$/i.test(tablePort))throw Error('请选择真实转台串口（一次选择，之后无需单独点击连接）');
   const actualIMUPort=imu.running?(imu.port||imuPort):imuPort;
   if(String(actualIMUPort).toUpperCase()===String(tablePort).toUpperCase())throw Error('PCB与转台不能共用同一个COM口');
   txt('auto-status','正在连接2TD-600转台，并自动确认两轴使能……');
   const authorization=mountCalibration?{operator_confirmed:true,load_secured:!!$('mount-load-secured').checked}:connectionAuthorization();
   await request('/api/turntable/connect','POST',{port:Number(tablePort.replace(/^COM/i,'')),baudrate:Number($('v58-table-baud').value),...authorization});
 }
 // Give the real FIFO at least a chance to deliver calibrated samples.
 for(let i=0;i<24;i++){
   imu=await request('/api/status');
   if(validExperimentInput(imu,mountCalibration)){
     const tab=await request('/api/turntable/status');
     if(!tab.connected)throw Error('转台连接意外断开，未发送运动命令');
     updateTable(tab);updateStatus(imu);return;
   }
   if(!imu.running||imu.error)throw Error('IMU启动或采集失败：'+(imu.error||'已停止'));
   if(imu.cal_status&&imu.cal_status!=='matched'&&i>=3)throw Error('标定尚未成功匹配：'+(imu.cal_detail||imu.cal_status)+'；实验未运动');
   await new Promise(resolve=>setTimeout(resolve,250));
 }
 throw Error('真实IMU校正数据尚未就绪：'+(imu.cal_detail||imu.cal_runtime_error||imu.error||'请检查采样新鲜度与六轴标定')+'；未发送运动命令');
}
async function refreshAutoTest(){if(autoBusy)return;autoBusy=true;
 try{
  const r=await request('/api/auto-dynamic/status');autoRunning=!!r.running;
  // Factory polling is independent of experimental report rendering.
  refreshFactoryHandoff(r).catch(()=>{});
  const phase=AUTO_PHASES[r.state]||r.state;
  txt('auto-progress',autoRunning?'自动任务进行中':r.state==='completed'?(r.plan?.calibration_only?'安装标定完成':'动态实验完成'):r.state==='analysis_invalid'?'采集完成/精度无效':r.state==='stopped_or_failed'?(r.motion_completed&&r.report_completed&&r.stopped_verified?'实验已完成／采集故障':'已中止'):'待命');
  const mountMode=!!r.plan?.calibration_only;
  txt('mount-cal-status',mountMode?(r.error?'中止：'+r.error:(r.running?phase:r.state==='completed'?'安装标定完成，已确认双轴停车并保持使能':'待命')):'独立安装标定尚未启动');
  const mountBtn=$('mount-cal-start');if(mountBtn)mountBtn.disabled=autoRunning||autoConnecting||!$('auto-ack').checked||!$('mount-load-secured').checked;
  if(mountMode){let links=[];if(r.mount_calibration_file)links.push(`<a href="/api/calibration/mount-file/${encodeURIComponent(r.mount_calibration_file)}" download>下载本次合格安装标定JSON</a>`);if(r.run_manifest_html_file)links.push(`<a href="/api/file/reports/${encodeURIComponent(r.run_manifest_html_file)}" target="_blank">查看完整静态报告</a>`);if(r.run_manifest_file)links.push(`<a href="/api/file/reports/${encodeURIComponent(r.run_manifest_file)}" download>下载运行记录</a>`);$('mount-cal-files').innerHTML=links.join(' · ')}
  const stage=r.current_stage?` · ${r.current_stage.output==='roll'?'Roll':'Pitch'}（第${r.current_stage.number}/${r.current_stage.count}项，内轴${r.current_stage.inner_target_deg}°）`:'';
  const staticStep=r.static_progress?` · 静态第${r.static_progress.step}/${r.static_progress.total}点：外轴${r.static_progress.target_deg}°`:'';
  const diag=r.research_diagnosis||{};
  const ds={not_requested:'本次未启用',pending:'等待全部运动完成及停车',running:'正在独立进程中诊断',completed:'诊断完成',partial:'部分诊断成功',failed:'诊断失败（原始数据保留）',not_completed:'诊断未执行完毕（原始数据保留）'};
  $('auto-research-result').innerHTML=escapeHtml(ds[diag.state]||'等待实验')+(diag.error?' · '+escapeHtml(diag.error):'')+(diag.html_file?` · <a href="/api/file/reports/${encodeURIComponent(diag.html_file)}" target="_blank" rel="noopener">查看研发诊断HTML</a>`:'')+(diag.zip_file?` · <a href="/api/file/reports/${encodeURIComponent(diag.zip_file)}" download>下载诊断ZIP</a>`:'');
   const pr=r.pre_research_progress;const pres=r.pre_research_results||[];
  $('auto-pre-result').innerHTML=escapeHtml(pr?`${pr.output.toUpperCase()} 第${pr.attempt||1}/${pr.max_attempts||3}次：${pr.elapsed_s}/${pr.total_s}秒 · ${pr.samples}点`:pres.length?'静止诊断：'+pres.map(v=>v.output+' 第'+(v.attempt||1)+'次:'+v.state+(v.error?' '+v.error:'')).join('；'):'等待静止诊断')+(autoRunning?[]:pres).map(v=>v.json_file?` · <a href="/api/file/reports/${encodeURIComponent(v.json_file)}" download>${escapeHtml(v.output)} 静止JSON</a>${v.raw_csv?` · <a href="/api/file/reports/${encodeURIComponent(v.raw_csv)}" download>CSV</a>`:''}`:'').join('');
  const opt=r.optimization||{};$('auto-opt-result').innerHTML=escapeHtml(ds[opt.state]||'等待寻优')+(opt.error?' · '+escapeHtml(opt.error):'')+(opt.selected?' · 最佳本次候选 '+escapeHtml(String(opt.selected.worst_max_abs_deg.toFixed(6)))+'°（非验收）':'')+(opt.html_file?` · <a href="/api/file/reports/${encodeURIComponent(opt.html_file)}" target="_blank" rel="noopener">查看寻优HTML</a>`:'')+(opt.zip_file?` · <a href="/api/file/reports/${encodeURIComponent(opt.zip_file)}" download>下载寻优ZIP</a>`:'');
  txt('auto-status',r.error?`${phase}：${r.error}`:phase+stage+staticStep+(autoRunning?' · 请保持现场监护':'')+(r.completed_stages?.length?` · 已完成${r.completed_stages.length}项`:''));
  if(r.static_check_info?.length){
   $('auto-static-result').innerHTML=r.static_check_info.map(x=>{const a=x.analysis||{};const m=a.algorithm_metrics?.[`cal_${a.chosen_algorithm}`]||{};
   return `<div class="static-result-row"><strong>${x.output==='roll'?'Roll（内轴0°）':'Pitch（内轴90°）'}</strong><span>对齐前（仅厂标定）${escapeHtml(a.chosen_algorithm||'')}: 静态RMSE ${fmt(m.static_rmse_deg,4)}° · P95绝对误差 ${fmt(m.static_p95_abs_deg,4)}° · 最大误差 ${fmt(m.static_max_abs_deg,4)}° · 回程差 ${fmt(m.hysteresis_max_deg,4)}°</span><em>${a.pass_for_chosen_algorithm?'原始已达标':'原始未达标，检查补偿后验证'}</em><a href="/api/file/reports/${encodeURIComponent(x.report_file)}" download>静态JSON</a>${x.interactive_html_file?`<a href="/api/file/reports/${encodeURIComponent(x.interactive_html_file)}" download>静态互动HTML报告</a>`:''}</div>`}).join('');
  }else if(r.running){txt('auto-static-result',r.plan?.static_before_dynamic?'等待静态检查阶段':'已选择跳过静态前检；动态结果不能据此认定静态精度合格');}

  if(r.polarity_checks?.length){
   const decisions=r.polarity_checks.map(d=>`${d.output==='pitch'?'Pitch':'Roll'}：${d.valid?(d.selected_sign===-1?'反向（−）':'同向（+）'):'方向未能确认'}${d.changed?'（自动修正参考方向）':''}`).join('；');
   const text=`方向诊断 · ${decisions}。${r.polarity_checks.some(d=>!d.valid)?'方向不确定，已停止后续运动。':'仅修正角度比较参考，不改变电机运动。'}`;
   txt('auto-full-progress',text);
   for(const d of r.polarity_checks){if(d.valid){const fld=d.output==='pitch'?'dyn-pitch-sign':'dyn-sign';$(fld).value=String(d.selected_sign)}}
  }
  if(r.mount_axis_checks?.length){
    const checks=r.mount_axis_checks.map(a=>{
      const angle=Number.isFinite(a.misalignment_deg)?`${fmt(a.misalignment_deg,3)}°`:'无法可靠测定';
      return `${a.output==='roll'?'Roll/X':'Pitch/Y'} 安装轴偏角 ${angle}（${a.pass_for_dynamic?'通过':'未通过'}：${escapeHtml(a.reason||'')}）`;
    }).join('；');
    txt('auto-mount-axis-result','动态前安装轴检查：'+checks+'。仅诊断，不修改工厂标定。');
  }else if(r.running)txt('auto-mount-axis-result','等待静态低速定位采集陀螺仪转轴方向……');
  if(r.mount_recovery){
    const mr=r.mount_recovery;
    txt('auto-mount-recovery-result',`自动安装标定：${mr.state==='rechecking_signal'?'低速信号复测中':mr.state==='fitting_fixture_candidate'?'正在构建静态对齐候选':mr.state==='candidate_saved_dynamic_blocked'?'静态候选已保存，轴向证据不足，动态禁止':mr.state==='validated_applied'?'独立验证通过，已应用本次小角度安装补偿':mr.state}。${mr.reason||mr.note||''}`);
    // A status poll must never change the operator's open module.
    // On failed/recovery runs this field remains non-null indefinitely.
  } else if(r.running){txt('auto-mount-recovery-result','正常进行：未触发低信噪比恢复流程。');}
  const align=r.static_alignment;
  if(align){
   const pre=align.validation_active_before||{},post=align.validation_active_after||{};
   $('auto-alignment-result').innerHTML=`<b>${align.applied?'已应用本次实验对齐':align.valid?'拟合成功，正在等待安全确认':'不应用补偿'}</b> · ${escapeHtml(align.reason||'')}<div>Roll零偏估计 ${fmt(align.effective_roll_zero_offset_deg,4)}° · Pitch零偏估计 ${fmt(align.effective_pitch_zero_offset_deg,4)}° · 反向复测（当前算法）最大绝对误差 ${fmt(pre.max_abs_deg,4)}° → ${fmt(post.max_abs_deg,4)}°</div>${r.static_alignment_file?`<a href="/api/file/reports/${encodeURIComponent(r.static_alignment_file)}" download>下载原始/补偿对照与拟合参数JSON</a>`:''}`;
  }else if(r.running)$('auto-alignment-result').textContent='等待两轴静态测试与留出验证；未通过之前不启用任何安装补偿';
  $('auto-start').disabled=autoRunning||autoConnecting||!$('auto-ack').checked||!fixtureReady();
  $('auto-stop').disabled=!autoRunning;updateFullFlow(r);
  $('auto-zero-speed').disabled=autoRunning;for(const id of ['auto-static-speed','auto-static-before','auto-static-limit','auto-static-stop','auto-align-enable','auto-research-diagnostics','auto-pre-research','auto-pre-seconds','auto-research-optimize'])$(id).disabled=autoRunning;
  for(const id of ['dyn-test-mode','dyn-fixture-verified','dyn-sign','dyn-pitch-sign','dyn-amp','dyn-freq','dyn-cycles'])$(id).disabled=autoRunning||dynRunning;
  if(r.run_manifest_file&&r.run_manifest_file!==autoLastManifest){
    autoLastManifest=r.run_manifest_file;
    $('auto-manifest-container').hidden=false;
    $('auto-manifest-container').innerHTML=`<strong>${r.state==='completed'?'实验完成':r.state==='analysis_invalid'?'运动及停车完成；精度评价无效，原始文件已保留':'实验中止，已保留部分测量结果'}</strong> ${r.run_manifest_html_file?`<a href="/api/file/reports/${encodeURIComponent(r.run_manifest_html_file)}" target="_blank" rel="noopener">查看静态曲线 / 错误原因（HTML）</a>`:''} <a href="/api/file/reports/${encodeURIComponent(r.run_manifest_file)}" download>下载完整运行记录JSON</a>`;
  }
  if(!autoRunning&&r.report_file&&r.report_file!==autoLastReport){autoLastReport=r.report_file;await showAutoReport(r.report_file)}
 }catch(e){txt('auto-status','自动测试状态获取失败：'+e.message)}finally{autoBusy=false}
}
async function initAutoOptions(){try{
 const r=await request('/api/auto-dynamic/settings');$('auto-zero-speed').value=String(r.zero_speed_dps||2);
 }catch(e){console.warn('回零速度设置读取失败',e)}
}
function bindAutoTest(){
 $('factory-readiness-btn').onclick=execute(async()=>{const r=await request('/api/calibration/factory-handoff/readiness');const items=r.blockers?.length?r.blockers.map(x=>'• '+x).join('\n'):'软件层基础条件已满足；仍需现场独立核验机械保护与实际停车。';txt('factory-readiness-output',(r.ready_for_preflight?'基础预检通过：':'基础预检未通过：')+'\n'+items);});
 $('factory-prepare').onclick=execute(async()=>{await confirmFactory(false);await refreshAutoTest()});
 $('factory-standalone').onclick=execute(async()=>{await confirmFactory(true);await refreshAutoTest()});
 $('factory-cancel').onclick=execute(async()=>{if(window.confirm('中止自动标定并请求停车？')){await request('/api/calibration/factory-handoff/cancel','POST',{acknowledged:true});await refreshAutoTest()}});

 const syncAutoAlign=()=>{
   const eligible=$('dyn-test-mode').value==='xy_sequential'&&$('auto-static-before').checked;
   if(!eligible){$('auto-align-enable').checked=false;$('auto-align-enable').disabled=true;}
   else if(!autoRunning){$('auto-align-enable').disabled=false;}
 };
 $('dyn-test-mode').addEventListener('change',syncAutoAlign);
 $('auto-static-before').addEventListener('change',()=>{syncAutoAlign();updateDynamicPlan();});
 syncAutoAlign();
 $('auto-ack').addEventListener('change',()=>{$('auto-start').disabled=autoRunning||!$('auto-ack').checked||!fixtureReady();$('mount-cal-start').disabled=autoRunning||autoConnecting||!$('auto-ack').checked||!$('mount-load-secured').checked});
 $('mount-load-secured').addEventListener('change',()=>{$('mount-cal-start').disabled=autoRunning||autoConnecting||!$('auto-ack').checked||!$('mount-load-secured').checked});
 $('cal-open-mount').addEventListener('click',()=>{setPage('experiments');$('mount-cal-start').scrollIntoView({behavior:'smooth',block:'center'})});
 $('mount-cal-start').addEventListener('click',execute(async()=>{
   if(autoRunning||autoConnecting)throw Error('已有转台自动任务，禁止重复启动');
   if(!$('auto-ack').checked||!$('mount-load-secured').checked)throw Error('需要现场确认全程运动安全，以及断使能后负载有独立支撑');
   const speed=Number($('auto-zero-speed').value),limit=Number($('auto-static-limit').value);
   if(!Number.isFinite(speed)||speed<.2||speed>5)throw Error('普通回零速度需为0.2–5°/s');
   if(!Number.isFinite(limit)||limit<.01||limit>5)throw Error('静态独立验证阈值需为0.01–5°');
   autoConnecting=true;$('mount-cal-start').disabled=true;
   try{await ensureAutoConnections(true);
     if(!$('auto-ack').checked||!$('mount-load-secured').checked)throw Error('现场安全确认被取消，未发送运动命令');
     await request('/api/calibration/mount/start','POST',{zero_speed_dps:speed,static_limit_deg:limit,sign:Number($('dyn-sign').value),pitch_sign:Number($('dyn-pitch-sign').value),acknowledged:true,fixture_confirmed:true,load_secured:true});
     autoRunning=true;toast('安装标定已启动：双轴静态检查、自动回0°、停车确认、保持使能并保存结果');
     await refreshAutoTest();
   }finally{autoConnecting=false}
 }));
 $('auto-zero-speed').addEventListener('change',execute(async()=>{
   if(autoRunning)throw Error('实验运行中不能修改回零速度');
   const value=Number($('auto-zero-speed').value);
   if(!Number.isFinite(value)||value<.2||value>5)throw Error('普通回0°速度应为0.2–5°/s');
   await request('/api/auto-dynamic/settings','POST',{zero_speed_dps:value});
   toast('普通回零速度已保存为 '+value+'°/s');
 }));
 $('auto-research-diagnostics').addEventListener('change',()=>{if(!$('auto-research-diagnostics').checked)$('auto-research-optimize').checked=false;});
 $('auto-research-optimize').addEventListener('change',()=>{if($('auto-research-optimize').checked)$('auto-research-diagnostics').checked=true;});
 $('auto-start').addEventListener('click',execute(async()=>{
   if(autoRunning||autoConnecting)throw Error('完整自动实验已经在执行');
   if(!$('auto-ack').checked)throw Error('请先确认现场工装、两轴全行程、人员安全和实体急停');
   const speed=Number($('auto-zero-speed').value);
   if(!Number.isFinite(speed)||speed<.2||speed>5)throw Error('普通回零速度应设置为0.2–5°/s');
   if(!fixtureReady())throw Error('请确认内轴0°到90°完整路径、机械和线缆安全');
   const staticLimit=Number($('auto-static-limit').value);
   if(!Number.isFinite(staticLimit)||staticLimit<.01||staticLimit>5)throw Error('静态检查门槛须在0.01°～5°');
   const args={...dynamicValues(),zero_speed_dps:speed,acknowledged:true,
      static_position_speed_dps:$('auto-static-speed').value?Number($('auto-static-speed').value):null,static_before_dynamic:$('auto-static-before').checked,
      static_limit_deg:staticLimit,static_stop_on_fail:$('auto-static-stop').checked,auto_static_align:$('anchor3d-auto-ack').checked&&$('auto-align-enable').checked,
      pre_sway_axis_check:$('auto-static-before').checked,research_diagnostics:$('auto-research-diagnostics').checked,pre_research:$('auto-pre-research').checked,pre_research_seconds:Number($('auto-pre-seconds').value),research_optimize:$('auto-research-optimize').checked};
   if(args.research_optimize&&!args.research_diagnostics)throw Error('离线寻优须启用实验后研发诊断');
   if((args.pre_research||args.research_optimize)&&args.auto_static_align)throw Error('研发闭环不允许现场经验对齐');
   if(args.pre_research&&$('anchor3d-auto-ack').checked)throw Error('静止初始化仅支持无杆臂Gyro Anchor');
   // Check motion bounds before attaching any device, no covert settings changes.
   if(args.auto_static_align&&(!args.static_before_dynamic||args.mounting_mode!=='xy_sequential'))throw Error('静态自动对齐要求启用静态检查并选择Roll+Pitch联合模式，或取消自动对齐');
   if(args.static_before_dynamic&&args.amplitude_deg<1)throw Error('14点静态前检需要幅度至少±1°，本次尚未连接/运动');
   autoConnecting=true;$('auto-start').disabled=true;
   try{
     await ensureAutoConnections();
     if(!$('auto-ack').checked)throw Error('现场确认已取消，自动运动未开始');
     txt('auto-status','两台实机已连接，UID/标定已验证。正在自动使能并按需要回零……');
     await request('/api/auto-dynamic/start','POST',args);autoRunning=true;
     toast('自动实验已启动：'+(args.static_before_dynamic?'静态检查→':'')+'原始采集→停车→离线报告，全程现场监护');
     await refreshAutoTest();
   }finally{autoConnecting=false;}
 }));
 $('auto-stop').addEventListener('click',execute(async()=>{
   await request('/api/auto-dynamic/abort','POST');
   toast('已发送停车请求，请确认真实转台停止；实体急停仍可用',true);
   await refreshAutoTest();
 }));
}
let prepToken=null,prepRunning=false,prepBusy=false;
async function refreshPreparation(){if(prepBusy)return;prepBusy=true;
 try{const r=await request('/api/turntable/prepare/status');prepRunning=!!r.running;
  const labels={idle:'未准备',checked:'已预检查',enabling:'正在使能',enabled_only:'双轴已使能（未执行回零）',verifying:'核验零位',ready:'双轴就绪',failed:'准备失败'};
  const label=labels[r.state]||r.state.replace('enabling_','使能轴').replace('finding_zero_','机械找零轴').replace('moving_zero_','回零定位轴');
  txt('prep-badge',label);txt('prep-status',r.error?'准备失败：'+r.error:r.running?label+'，请保持现场监护与硬件急停可用':r.ready?'双轴已确认使能、找零、定位至0°并停止，可进行动态实验预检查':'尚未准备；须先完成现场安全确认');
  $('prep-preflight').disabled=prepRunning;$('prep-start').disabled=prepRunning||!prepToken||!$('prep-ack').checked;$('prep-enable').disabled=prepRunning||!prepToken||!$('prep-ack').checked;
  $('prep-abort').disabled=!prepRunning;
 }catch(e){txt('prep-status','转台准备状态读取失败：'+e.message)}finally{prepBusy=false}
}
// Two-stage, operator-gated, vendor-native SetAxisDisable. Never on experiment stop.
let disableToken=null;
function bindDisableMaintenance(){
 const reset=()=>{disableToken=null;$('disable-execute').disabled=true};
 $('disable-axis').addEventListener('change',()=>{reset();$('disable-load').checked=false;$('disable-operator').checked=false;txt('disable-feedback','轴已切换，请重新只读预检查')});
 for(const id of ['disable-load','disable-operator'])$(id).addEventListener('change',()=>{$('disable-execute').disabled=!(disableToken&&$('disable-load').checked&&$('disable-operator').checked)});
 $('disable-preview').addEventListener('click',execute(async()=>{
  reset();const axis=Number($('disable-axis').value);
  const r=await request('/api/turntable/disable/preflight','POST',{axis});disableToken=r.token;
  txt('disable-feedback',`轴${axis}已通过只读静止预检查。确认失去保持力后工装仍安全，才能继续。30秒内有效。`);
  $('disable-execute').disabled=!($('disable-load').checked&&$('disable-operator').checked);
 }));
 $('disable-execute').addEventListener('click',execute(async()=>{
  if(!disableToken||!$('disable-load').checked||!$('disable-operator').checked)throw Error('请重新预检查并双重确认机械支撑与现场安全');
  const token=disableToken,axis=Number($('disable-axis').value);reset();
  const r=await request('/api/turntable/disable/confirm','POST',{axis,token,operator_confirmed:true,load_secured:true});
  txt('disable-feedback',r.confirmed_disabled?`轴${axis}DLL已反馈取消使能。负载仍须现场核查。`:'断使能结果未确认，请现场检查');
  $('disable-load').checked=false;$('disable-operator').checked=false;
  await refreshWorkbenchTable();
 }));
}
function bindPreparation(){bindDisableMaintenance();
 $('prep-ack').addEventListener('change',()=>{$('prep-start').disabled=!prepToken||!$('prep-ack').checked||prepRunning;$('prep-enable').disabled=!prepToken||!$('prep-ack').checked||prepRunning});
 $('prep-preflight').addEventListener('click',execute(async()=>{prepToken=null;const r=await request('/api/turntable/prepare/preflight','POST');prepToken=r.token;toast('只读预检查通过；现场确认后可开始使能/回零');await refreshPreparation()}));
 $('prep-enable').addEventListener('click',execute(async()=>{if(!$('prep-ack').checked||!prepToken)throw Error('请先预检查并确认现场安全');const token=prepToken;prepToken=null;
  await request('/api/turntable/prepare/enable','POST',{token,acknowledged:true});prepRunning=true;toast('内部维护指令已发送，正核对状态');await refreshPreparation()}));
 $('prep-start').addEventListener('click',execute(async()=>{if(!$('prep-ack').checked||!prepToken)throw Error('请先预检查并确认现场安全');const token=prepToken;prepToken=null;
  await request('/api/turntable/prepare/start','POST',{token,acknowledged:true});prepRunning=true;toast('开始真实转台准备；保持现场监护');await refreshPreparation()}));
 $('prep-abort').addEventListener('click',execute(async()=>{await request('/api/turntable/prepare/abort','POST');toast('已尝试软件停车，请现场核对真实停止状态',true);await refreshPreparation()}));
}
let dynToken=null, dynRunning=false, dynLastFile=null, dynBusy=false;
function fixtureReady(){return $('dyn-test-mode').value==='x_outer'||$('dyn-fixture-verified').checked||$('auto-ack').checked;}
function dynamicValues(){const mode=$('dyn-test-mode').value;return {axis:2,output:mode==='x_outer'?'roll':mode==='y_inner_90'?'pitch':'both',mounting_mode:mode,fixture_confirmed:fixtureReady()&&mode!=='x_outer',sign:mode==='y_inner_90'?Number($('dyn-pitch-sign').value):Number($('dyn-sign').value),pitch_sign:Number($('dyn-pitch-sign').value),amplitude_deg:Number($('dyn-amp').value),frequency_hz:Number($('dyn-freq').value),cycles:Number($('dyn-cycles').value)}}
function updateDynamicPlan(){const p=dynamicValues(),w=2*Math.PI*p.amplitude_deg*p.frequency_hz,acc=w*2*Math.PI*p.frequency_hz,seconds=p.cycles/p.frequency_hz;
 const staticCompatible=!$('auto-static-before').checked||p.amplitude_deg>=1;
 const valid=staticCompatible&&p.amplitude_deg>=.2&&p.amplitude_deg<=20&&p.frequency_hz>=.01&&p.frequency_hz<=.8&&p.cycles>=2&&p.cycles<=60&&Number.isInteger(p.cycles)&&w<=20&&acc<=40&&seconds>=5&&seconds<=900;
 const stages=p.output==='both'?2:1;
 txt('dyn-plan',Number.isFinite(w)&&Number.isFinite(seconds)?`单项摆动 ${fmt(seconds,1)} 秒 · ${stages} 项合计摆动 ${fmt(stages*seconds,1)} 秒（另含使能、0°/90°定位和停车时间） · 峰值角速度 ${fmt(w,3)}°/s · 峰值角加速度 ${fmt(acc,3)}°/s² · ${valid?'通过软件参数检查':'参数超出软件边界'}`:'参数无效');
 $('dyn-output').value=p.output;$('dyn-axis').value='2';
 const y=p.mounting_mode!=='x_outer';$('dyn-fixture-box').hidden=!y;$('dyn-pitch-sign-box').hidden=p.mounting_mode==='x_outer';$('dyn-roll-sign-box').hidden=p.mounting_mode==='y_inner_90';
 txt('dyn-mount-note',p.mounting_mode==='x_outer'?'Roll：自动将内轴定位0°，外轴2摆动，对比IMU Roll。':p.mounting_mode==='y_inner_90'?'Pitch：在外轴0°时自动将内轴定位90°，外轴2摆动，对比IMU Pitch；无需重新装夹。':'联合测试：内轴0°→外轴测Roll→外轴回0°→内轴90°→外轴测Pitch→双轴回0°；分别生成曲线和误差报告。');
 $('auto-start').disabled=autoRunning||!$('auto-ack').checked||!fixtureReady()||!valid;
 if(!dynRunning&&!autoRunning){dynToken=null;$('dyn-start').disabled=true}
} 
const DYN_COLORS={gravity_observer:'#155c91',gyro_anchor3d:'#117f77',adaptive3d:'#b65a22',lever3d:'#c45c19',accel:'#7e817b',gyro:'#adadae',complementary:'#b47751',mahony:'#2a5249',adaptive:'#638f6e',madgwick:'#9b79a3',kalman:'#3d555f',leverarm:'#569B81',adaptive_lever:'#28518a',motion_guard:'#d78935',gyro_anchor:'#0e91a8',vqf6d:'#734ad4',vqf_lever:'#9f62e4'};
let dynReportRows=[],dynAbsoluteRows=[],dynChartKeys=[];
function dynamicAlgorithmId(key){
 return key.startsWith('cal_factory_')?key.slice('cal_factory_'.length):
   key.startsWith('cal_')?key.slice(4):key.startsWith('raw_')?key.slice(4):key;
}
function dynamicTraceDefs(keys){return keys.map(k=>{const a=dynamicAlgorithmId(k);return {key:k,color:DYN_COLORS[a]||'#888',dashed:k.startsWith('raw_'),name:(k.startsWith('cal_factory_')?'仅厂标定 · ':k.startsWith('cal_')?'标定 · ':'未标定 · ')+(ALGO_INFO[a]?.[0]||a)};});}
function drawDynamicSeries(canvasId,which,keys){
 const canvas=$(canvasId);if(!canvas||(!dynReportRows.length&&!dynAbsoluteRows.length))return;
 const absolute=$('dyn-error-source')?.value==='absolute';
 const actualSource=(which==='errors'&&$('dyn-error-source')?.value==='diagnostic')?'diagnostic_shifted_errors':which;
 const rows=(absolute?dynAbsoluteRows:dynReportRows).map(r=>({t:r.t_s,reference:r.reference_deg, ...r[actualSource]}));
 const defs=dynamicTraceDefs(keys);
 const lines=which==='angles'?[{color:'#292d2a',weight:2.6,value:r=>r.reference},...defs.map(d=>({color:d.color,weight:2.0,opacity:d.dashed?.65:1,dash:d.dashed?[5,3]:[],value:r=>r[d.key]}))]:[...defs.map(d=>({color:d.color,weight:2.0,opacity:d.dashed?.65:1,dash:d.dashed?[5,3]:[],value:r=>r[d.key]})), ...(($('dyn-error-view')?.value==='limits')?[.05,-.05,.1,-.1]:[0]).map(y=>({color:y===0?'#aeb8b0':'#d4afa0',weight:1,opacity:y===0?.6:.75,dash:[4,6],value:r=>y}))];
 drawLine(canvas,rows,'roll',lines,false);
}
function drawDynamicRms(ranking){
 const canvas=$('dyn-rmse-chart');if(!canvas)return;
 const rows=ranking.filter(r=>r.channel==='cal'&&r.algorithm!=='gyro').map(r=>({t:r.algorithm,rmse:r.relative_tracking_rmse_deg}));
 const dpr=Math.min(window.devicePixelRatio||1,2),W=canvas.clientWidth,H=canvas.clientHeight;
 if(!W||!H)return;canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);
 const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);ctx.clearRect(0,0,W,H);
 if(!rows.length)return;
 const max=Math.max(...rows.map(r=>r.rmse),.001),top=20,rowHeight=Math.min(35,(H-36)/rows.length),label=136;
 rows.forEach((r,i)=>{const y=top+i*rowHeight;ctx.font='12px system-ui,sans-serif';ctx.textBaseline='middle';ctx.fillStyle='#52605a';ctx.textAlign='right';ctx.fillText(ALGO_INFO[r.t]?.[0]||r.t,label-10,y+rowHeight*.35);
 ctx.fillStyle='#f0f2ef';ctx.beginPath();ctx.roundRect(label,y,Math.max(20,W-label-70),Math.max(5,rowHeight*.43),4);ctx.fill();
 ctx.fillStyle=DYN_COLORS[r.t]||'#666';ctx.beginPath();ctx.roundRect(label,y,Math.max(2,r.rmse/max*(W-label-70)),Math.max(5,rowHeight*.43),4);ctx.fill();
 ctx.textAlign='left';ctx.fillStyle='#303936';ctx.fillText(fmt(r.rmse,4)+'°',W-64,y+rowHeight*.35);});
}
function renderDynPlots(ranking){
 const selected=Array.from(document.querySelectorAll('#dyn-series-picks input[type=checkbox]:checked')).map(x=>x.value);
 drawDynamicSeries('dyn-angle-chart','angles',selected);
 drawDynamicSeries('dyn-error-chart','errors',selected);
 drawDynamicRms(ranking);
}
async function showAutoReport(file){
 const r=await request('/api/file/reports/'+encodeURIComponent(file));
 const nav=$('dyn-dual-report-nav');
 if(r.kind!=='REAL_2TD600_XY_SEQUENTIAL'){
   nav.hidden=true;nav.innerHTML='';return showDynamicReport(file);
 }
 const parts=(r.tests||[]);
 nav.hidden=false;
 nav.innerHTML=`<div class="dual-report-head"><strong>Roll + Pitch 联合实验已完成</strong><small>外轴2为参考 · 内轴0° / 90° · 两组独立数据 · 研究级时间基准</small></div><div class="dual-report-buttons">${parts.map((x,i)=>`<button type="button" class="btn subtle dual-report-choice" data-idx="${i}">${x.direction==='roll'?'Roll / 内轴0°':'Pitch / 内轴90°'} · 查看曲线</button>`).join('')}<a class="btn subtle" href="/api/file/reports/${encodeURIComponent(file)}" download>下载联合JSON报告</a>${r.html_report_file?`<a class="btn subtle" href="/api/file/reports/${encodeURIComponent(r.html_report_file)}" download>下载交互式HTML报告</a>`:''}</div>`;
 const choose=async(index)=>{
   nav.querySelectorAll('.dual-report-choice').forEach((b,i)=>b.classList.toggle('selected',i===index));
   const name=parts[index]?.report_file;if(name)await showDynamicReport(name);
 };
 nav.querySelectorAll('.dual-report-choice').forEach((b,i)=>b.addEventListener('click',()=>choose(i).catch(e=>toast(e.message,true))));
 if(parts.length)await choose(0);
}
function absolutePanel(a){
 const ab=a.absolute_accuracy||{},rows=ab.comparison||[],fmtErr=v=>Number.isFinite(v)?fmt(v,6)+'°':'—';
 if(!rows.length)return '<p class="dyn-warning">旧报告或参考不足：没有绝对角度误差，不能以相对误差替代。</p>';
 const primary=ab.primary||[],p=primary.find(x=>x.scope==='full_motion');
 const table=(rs)=>`<div class="table-scroll"><table class="dyn-table"><thead><tr><th>范围</th><th>算法</th><th>通道</th><th>执行</th><th>最大绝对误差</th><th>绝对RMSE</th><th>绝对P95</th><th>最大误差时刻</th><th>样本/缺失输出</th></tr></thead><tbody>${rs.map(x=>`<tr><td>${x.scope==='full_motion'?'全运动':'稳态'}</td><td>${escapeHtml(ALGO_INFO[x.algorithm]?.[0]||x.algorithm)}</td><td>${x.channel==='cal_factory'?'仅厂标定':x.channel==='cal'?'可含现场对齐':'未标定'}</td><td>${x.execution_mode==='realtime_capture'?'实时':x.execution_mode==='offline_replay'?'停车后离线':'未计算'}</td><td>${fmtErr(x.absolute_max_error_deg)}</td><td>${fmtErr(x.absolute_angle_rmse_deg)}</td><td>${fmtErr(x.absolute_p95_error_deg)}</td><td>${fmt(x.max_error_time_s,3)}s</td><td>${x.samples}/${x.excluded_output_samples}</td></tr>`).join('')}</tbody></table></div>`;
 const general=rows.filter(x=>x.lever_status==='no_lever'&&x.channel==='cal_factory').sort((x,y)=>x.scope.localeCompare(y.scope)||x.absolute_max_error_deg-y.absolute_max_error_deg);
 const other=rows.filter(x=>x.lever_status!=='no_lever'||x.channel!=='cal_factory');
 return `<section class="dyn-alignment-panel"><h4>V7.16 · 动态绝对角度误差（不扣零位）</h4><p class="dyn-warning">仅研究性对比，未硬件同步。参考为实际编码器角度；须核对编码器零位与水平。缺口内不插值；覆盖不足不得作为全段精度。</p><p><strong>通用实时全运动最大绝对误差：${p?fmtErr(p.absolute_max_error_deg)+(ab.scopes?.full_motion?.complete_reference_coverage&&p.excluded_output_samples===0?'':'（仅可比较片段）'):'无符合条件的实时结果'}</strong> · 目标 ≤0.05°（未认证） · 全段参考覆盖 ${fmt(ab.scopes?.full_motion?.reference_coverage_pct,2)}%</p><p>单轴/三维杆臂（cm）：${escapeHtml(JSON.stringify(ab.lever_parameters_cm||{}))}</p><h4>无杆臂 · 仅厂标定</h4>${table(general)}<details><summary>杆臂及其他通道研究对照（不参与通用排名）</summary>${table(other)}</details></section>`;
}
async function showDynamicReport(file){
 const r=await request('/api/file/reports/'+encodeURIComponent(file));
 const a=r.analysis||{},ranking=a.comparison||[];window.__dynLastRanking=ranking;
 const files=[r.raw_file_table,r.raw_file_imu,r.offline_replay?.file,r.html_report_file,file].filter(Boolean);
 const links=(r.diagnostic_bundle_available?`<a class="btn primary" href="/api/dynamic/bundle/${encodeURIComponent(file)}" download>一键下载完整诊断ZIP</a> <a class="btn" href="/api/dynamic/light-bundle/${encodeURIComponent(file)}" download>轻量原始数据ZIP</a>`:'')+files.map(n=>`<a href="/api/file/reports/${encodeURIComponent(n)}" download>${escapeHtml(n.endsWith('.html')?'下载交互式HTML报告':n.endsWith('_offline_replay.csv')?'下载其他算法离线回放':n.endsWith('_imu.csv')?'下载IMU实时逐样本':n.endsWith('_table.csv')?'下载转台反馈':'下载完整JSON报告')}</a>`).join('');
 const completed=r.state==='completed';
 if(r.offline_replay?.offline_algorithms)toast((r.capture_mode==='offline'?'本次未实时解算角度；全部算法停车后离线回放':'本次实时算法：'+r.imu_algorithm_at_start+'；其他算法停车后离线回放'));
 const status=completed?'动态试验已完成 · 研究级诊断':r.state==='analysis_invalid'?'采集与停车已完成 · 参考或IMU连续性不足，精度评价无效':a.valid?'采集数据可分析 · 停车未确认 / 实验未完成':'测试无效 / 已中止';
 dynReportRows=a.chart||[];dynAbsoluteRows=a.absolute_accuracy?.chart||[];
 dynChartKeys=Array.from(new Set(ranking.map(v=>`${v.channel}_${v.algorithm}`).concat(Object.keys((a.chart||[]).find(x=>x.angles&&Object.keys(x.angles).length)?.angles||{}))));
 const ordered=['gravity_observer','gyro_anchor3d','adaptive3d','lever3d','vqf6d','vqf_lever','gyro_anchor','adaptive_lever','leverarm','adaptive','mahony','kalman','complementary','madgwick','accel','gyro'];
 dynChartKeys.sort((a,b)=>ordered.indexOf(dynamicAlgorithmId(a))-ordered.indexOf(dynamicAlgorithmId(b)));
 const choices=dynChartKeys.map(k=>{const a=dynamicAlgorithmId(k),raw=k.startsWith('raw_'),checked=!raw&&a!=='gyro';return `<label class="dyn-series-option"><input type="checkbox" value="${escapeHtml(k)}" ${checked?'checked':''}/><i style="--trace-color:${DYN_COLORS[a]||'#888'}"></i><span>${escapeHtml((k.startsWith('cal_factory_')?'仅厂标定 · ':raw?'未标定 · ':'已标定 · ')+(ALGO_INFO[a]?.[0]||a))}</span></label>`}).join('');
 const best=ranking.filter(v=>v.channel==='cal'&&v.algorithm!=='gyro').slice().sort((x,y)=>x.relative_tracking_rmse_deg-y.relative_tracking_rmse_deg)[0];
 const gaps=a.reference_quality||{};
 const gapWarning=a.reference_gaps_masked?`<div class="dyn-warning"><strong>${a.partial_research_only?'整段参考不合格，以下仅为片段研究统计':'参考反馈有缺口'}</strong>：已剔除 ${gaps.imu_stable_samples_excluded||0} 条缺口内的IMU样本，稳定段参考覆盖率 ${fmt(gaps.stable_coverage_pct,2)}%，最长反馈间隔 ${fmt(gaps.max_feedback_gap_ms,0)}ms。仅对剩余真实连续片段计算研究性RMSE，不是完整数据精度验收。</div>`:'';
 const cdiag=a.continuity_diagnostics||{},ab=a.continuity_ab||{};
 const leverNote=a.lever_research_note?`<div class="dyn-warning">${escapeHtml(a.lever_research_note)}</div>`:'';
 const continuityHtml=a.continuity_policy?`<div class="dyn-warning"><strong>V7.15 连续性诊断（非验收）</strong>：估算长缺口 ${a.estimated_gaps_over_50ms??0} 次 · 预测 ${a.fusion_gap_bridges??0} 次 · 重置 ${a.fusion_gap_resets??0} 次 · 估算最大步长 ${fmt(cdiag.max_estimated_step_ms,2)}ms。${escapeHtml(a.continuity_policy)}${ab.available?`<p>同数据离线A/B：V7.12重置策略最大误差 ${fmt(ab.legacy_reset_policy.relative_max_error_deg,4)}° → V7.13预测策略 ${fmt(ab.new_bridge_policy.relative_max_error_deg,4)}°；RMSE ${fmt(ab.legacy_reset_policy.relative_tracking_rmse_deg,4)}° → ${fmt(ab.new_bridge_policy.relative_tracking_rmse_deg,4)}°。不替换实时结果。</p>`:''}</div>`:'';
 const clockRecovered=!!a.clock_diagnostics?.recovered;
 const align=a.axis_alignment||{};
 const alignmentHtml=align.valid?`<section class="dyn-alignment-panel"><div class="panel-head"><div><div class="kicker">MOUNTING / AXIS ALIGNMENT</div><h4>IMU—转台外轴对齐诊断</h4></div><span class="page-tag">${escapeHtml(align.target_sensor_axis||'—')}轴目标</span></div><div class="dyn-alignment-grid"><div><small>外轴与目标轴夹角</small><strong>${fmt(align.misalignment_deg,3)}°</strong></div><div><small>XY平面有符号偏差</small><strong>${fmt(align.signed_xy_deviation_deg,3)}°</strong></div><div><small>面外偏差（Z）</small><strong>${fmt(align.out_of_plane_deg,3)}°</strong></div><div><small>外轴向量（IMU坐标）</small><strong>[${(align.estimated_outer_axis_sensor||[]).map(v=>fmt(v,4)).join(', ')}]</strong></div></div><p>${escapeHtml(align.interpretation||'')} · ${escapeHtml(align.lean_direction||'')} · ${align.sample_count||0}条有效陀螺样本 · ${escapeHtml(align.channel||'')}</p><p class="dyn-subtle">${escapeHtml(align.adjustment_note||'')} 该角度不是动态精度验收指标。</p></section>`:`<section class="dyn-alignment-panel"><h4>IMU—转台外轴对齐诊断</h4><p class="dyn-subtle">${escapeHtml(align.reason||'当前报告没有三轴陀螺仪原始数据，无法计算安装轴向偏差。请使用V6.8重新采集。')}</p></section>`;
 const timeInfo=a.time_shift_diagnostics||{};
 const lagHtml=timeInfo.available?`<section class="dyn-alignment-panel"><h4>时间偏移诊断 · 不改变原始RMSE</h4><p>同一参考角时间平移 <strong>${fmt(timeInfo.shift_reference_by_ms,1)} ms</strong>，用前60%数据拟合、后40%独立检验。加速度直算留出段原始RMSE <strong>${fmt(timeInfo.test_raw_rmse_deg,4)}°</strong>，诊断平移后 <strong>${fmt(timeInfo.test_shifted_rmse_deg,4)}°</strong>。</p><p class="dyn-subtle">这只是联合波形拟合，会把算法相位响应当作等效延迟，不能证明硬件同步，也不能把诊断RMSE用于产品精度验收。</p></section>`:`<p class="dyn-subtle">时间差诊断不可用：${escapeHtml(timeInfo.reason||'数据不足或时间轴异常')}</p>`;
 const nativeInfo=r.native_high_rate_capture;
 const nativeHtml=nativeInfo?.file?`<p class="dyn-subtle">厂家原始0xA0状态流：<a href="/api/file/reports/${encodeURIComponent(nativeInfo.file)}" download>下载独立高频状态CSV</a>；试验期间新增 ${Math.max(0,(nativeInfo.samples_at_test_end||0)-(nativeInfo.samples_at_test_start||0))} 帧（未与IMU硬件同步，不参与正式RMSE）。</p>`:'';
 const staticRel=r.static_before_dynamic;
 const staticHtml=staticRel?.report_file?`<section class="dyn-alignment-panel"><h4>动态前静态精度</h4><p>先完成−5°～+5°双向静态角度比对。当前算法的静态最大误差 ${fmt(staticRel.summary?.chosen_static_max_abs_deg,4)}°；${escapeHtml(staticRel.summary?.reason||'')}。</p><a href="/api/file/reports/${encodeURIComponent(staticRel.report_file)}" download>下载逐点静态检查JSON</a></section>`:'<p class="dyn-subtle">本次没有关联完整静态前检，动态误差不能替代静态精度结果。</p>';
 const unsafeStop=r.stopped_verified===false?'<div class="dyn-warning"><strong>停车状态未获确认</strong>：曲线仅代表已记录的运动数据。不得据此认为设备已停稳；不会自动继续下一测试阶段。请现场核验实体状态和DLL反馈。</div>':'';
 const clockAlert=clockRecovered?`<div class="dyn-warning"><strong>研究级时间轴恢复</strong>：IMU会话时间与PC参考时间存在不一致；偏差估计：${Number.isFinite(a.clock_diagnostics.host_clock_error_median_s)?fmt(a.clock_diagnostics.host_clock_error_median_s,2)+'秒':'不可确定'}。已按每批FIFO接收时间恢复可比较的时间轴，但仍有未知通信延迟；此结果不能作为0.05°精度验收。</div>`:'';
 $('dyn-result').innerHTML=`<h3>${status}</h3><p class="dyn-subtle">${escapeHtml(r.error||'运动及停车反馈已确认')} · ${r.plan?.output==='pitch'?'Y轴/Pitch（内轴90°）':'X轴/Roll（内轴0°）'} · 外轴2实际反馈 · 设备 ${escapeHtml(r.uid||'未知')} · ${r.imu_samples||0} 条IMU样本 · ${r.table_samples||0} 次转台反馈</p>`+
 absolutePanel(a)+clockAlert+leverNote+continuityHtml+gapWarning+unsafeStop+staticHtml+alignmentHtml+lagHtml+nativeHtml+(r.offline_replay?.offline_algorithms?`<p class="dyn-warning">实时算法：${escapeHtml(r.imu_algorithm_at_start)}（另含ACC直算）；其他算法均为停车后离线回放，不能视作实时输出。实时CSV未修改。</p>`:'')+
 ((a.valid||a.diagnostic_preview_only)?`<div class="dyn-research-conclusion"><strong>${a.partial_research_only?'不完整数据的局部研究结果（禁止验收）':'本次研究结论'}</strong><p>${best?`在当前相对运动和PC估算时间基准下，${escapeHtml(ALGO_INFO[best.algorithm]?.[0]||best.algorithm)} 的标定后相对跟踪RMSE最低，为 ${fmt(best.relative_tracking_rmse_deg,4)}°。`:'没有可比较的有效融合输出。'} 这里只能比较本次工况，不代表动态精度已达标；尤其需要排除固定时延和安装坐标误差。</p></div>
 ${a.diagnostic_preview_only?`<p class="dyn-warning"><strong>${a.partial_research_only?'仅对足够长的真实连续片段计算研究性指标':'稳态识别未通过，仅显示原始曲线'}</strong> ${escapeHtml(a.reason||'')} · 不得作为整段RMSE或精度验收。</p>`:''}
 <p class="dyn-subtle">角度相对于运动前静止基线 · 转台实际反馈约 ${fmt(a.feedback_rate_hz,1)}Hz · 最大反馈间隔 ${fmt(a.max_feedback_gap_ms,1)}ms。可勾选任意算法，虚线为未标定。</p>
 <div class="dyn-series-toolbar"><strong>显示曲线</strong><button type="button" class="btn subtle" id="dyn-pick-cal">已标定</button><button type="button" class="btn subtle" id="dyn-pick-all">全部</button><button type="button" class="btn subtle" id="dyn-pick-none">清空</button></div>
 <div class="dyn-series-picks" id="dyn-series-picks">${choices}</div>
 <div class="dyn-trace-layout"><section><h4>动态跟踪曲线 · 算法输出 vs 转台实际反馈</h4><canvas class="dyn-chart" id="dyn-angle-chart"></canvas></section><section class="dyn-error-focus"><h4>误差曲线 · 各算法减去转台实际角度 <label class="dyn-error-select">时间轴 <select id="dyn-error-source"><option value="original">相对跟踪（稳态）</option>${dynAbsoluteRows.length?'<option value="absolute" selected>绝对角度（全运动，不扣零位）</option>':''}${timeInfo.available?'<option value="diagnostic">统一时间偏移（仅诊断）</option>':''}</select></label><label class="dyn-error-select">参考线 <select id="dyn-error-view"><option value="auto">自动缩放 / 零位线</option><option value="limits">叠加±0.05° / ±0.1°研究参考线</option></select></label></h4><canvas class="dyn-chart" id="dyn-error-chart"></canvas></section></div>
 <section class="dyn-rmse-panel"><h4>${a.partial_research_only?'局部连续片段研究性RMSE（非验收）':'历史相对跟踪RMSE（研究对照，含杆臂分支）'}</h4><canvas class="dyn-chart dyn-rmse" id="dyn-rmse-chart"></canvas></section>
 <div class="table-scroll"><table class="dyn-table"><thead><tr><th>通道</th><th>方法</th><th>相对RMSE</th><th>P95绝对误差</th><th>最大误差</th><th>幅值比</th><th>表观相位延迟</th></tr></thead><tbody>${ranking.map(v=>`<tr><td>${v.channel==='cal_factory'?'仅厂标定':v.channel==='cal'?'可含静态对齐':'未标定'}</td><td>${escapeHtml(ALGO_INFO[v.algorithm]?.[0]||v.algorithm)}</td><td>${fmt(v.relative_tracking_rmse_deg,4)}°</td><td>${fmt(v.relative_p95_error_deg,4)}°</td><td>${fmt(v.relative_max_error_deg,4)}°</td><td>${fmt(v.amplitude_ratio,3)}</td><td>${fmt(v.apparent_phase_lag_ms,1)}ms</td></tr>`).join('')}</tbody></table></div>`:
 `<p class="dyn-subtle">${escapeHtml(a.reason||'没有形成可比较的数据，不能计算角度误差。')}</p>`)+
 `<p class="dyn-warning">研究级诊断，非正式验收。两台设备尚未完成硬件级时钟同步与固定时延校准；PC侧估算时间可能导致较大的RMSE及表观相位偏差。未证明±0.1°动态精度。</p><div class="dyn-files">${links}</div>`;
 if(a.valid||a.diagnostic_preview_only){
   const root=$('dyn-series-picks');const paint=()=>renderDynPlots(ranking);
   root.addEventListener('change',paint);$('dyn-error-view')?.addEventListener('change',paint);$('dyn-error-source')?.addEventListener('change',paint);
   $('dyn-pick-cal').onclick=()=>{root.querySelectorAll('input').forEach(x=>x.checked=x.value.startsWith('cal_')&&!x.value.endsWith('_gyro'));paint()};
   $('dyn-pick-all').onclick=()=>{root.querySelectorAll('input').forEach(x=>x.checked=true);paint()};
   $('dyn-pick-none').onclick=()=>{root.querySelectorAll('input').forEach(x=>x.checked=false);paint()};
   requestAnimationFrame(paint);
 }
}
async function refreshDynamic(){if(dynBusy)return;dynBusy=true;
 try{const r=await request('/api/dynamic/status');dynRunning=!!r.running;
 txt('dyn-badge',r.running?'动态测试运行中':r.state==='completed'?'已完成':r.state==='analysis_invalid'?'采集完成/精度无效':r.state==='invalid'?'测试无效':'未开始');
 txt('dyn-stage',r.error?`${r.state} · ${r.error}`:({'baseline':'静止基线采集中（2秒）','commanding_sway':'下发摇摆命令','swaying':'正在执行正弦摇摆','stopping':'正在停车并确认','reporting_stopped':'停车已确认 · 检查数据质量或生成报告','capture_complete':'原始数据已保存 · 等全部运动结束后离线分析','completed':'完成，双轴停车已核验','analysis_invalid':'采集与停车完成，但精度评价未通过','invalid':'中断或数据无效','idle':'未开始，可点击上方“开始完整自动测试”'}[r.state]||r.state));
 txt('dyn-progress',r.running?`${r.table_samples} 次转台反馈 / ${r.imu_samples} 条IMU样本`:'');
 txt('dyn-position',r.latest_feedback?encoderAngle(r.latest_feedback.position_deg,4):'—');
 txt('dyn-speed',r.latest_feedback?fmt(r.latest_feedback.speed_dps,4)+'°/s':'—');
 txt('dyn-table-count',r.table_samples||0);txt('dyn-imu-count',r.imu_samples||0);
 for(const id of ['dyn-test-mode','dyn-fixture-verified','dyn-sign','dyn-pitch-sign','dyn-amp','dyn-freq','dyn-cycles'])$(id).disabled=!!r.running||autoRunning;
 $('dyn-preflight').disabled=!!r.running||autoRunning;$('dyn-start').disabled=!!r.running||autoRunning||!dynToken||!$('dyn-ack').checked;
 $('dyn-stop').disabled=!r.running;
 if(!autoRunning&&!r.running&&r.state!=='capture_complete'&&r.report_file&&r.report_file!==dynLastFile){dynLastFile=r.report_file;await showDynamicReport(r.report_file)}
 }catch(e){txt('dyn-stage','动态实验状态读取失败：'+e.message)}finally{dynBusy=false}}
function bindDynamic(){
 window.addEventListener('resize',()=>{if(dynReportRows.length&&$('dyn-angle-chart'))renderDynPlots((window.__dynLastRanking||[]))});
 for(const id of ['dyn-test-mode','dyn-fixture-verified','dyn-sign','dyn-pitch-sign','dyn-amp','dyn-freq','dyn-cycles'])$(id).addEventListener('change',()=>{if(id==='dyn-test-mode'){$('dyn-fixture-verified').checked=false;$('auto-ack').checked=false;}updateDynamicPlan()});
 $('dyn-ack').addEventListener('change',()=>{$('dyn-start').disabled=!dynToken||!$('dyn-ack').checked||dynRunning});
 $('dyn-preflight').addEventListener('click',execute(async()=>{const p=dynamicValues();if(!fixtureReady())throw Error('内轴90°测试需要现场确认安全');if(p.output==='both')throw Error('联合测试请使用上方“一键自动测试”按钮');dynToken=null;const r=await request('/api/dynamic/preflight','POST',p);dynToken=r.token;
 txt('dyn-stage','安全预检查通过；30秒内勾选现场确认并启动');$('dyn-start').disabled=!$('dyn-ack').checked;
 toast('只读安全预检查通过，尚未发送运动命令')}));
 $('dyn-start').addEventListener('click',execute(async()=>{if(!$('dyn-ack').checked)throw Error('请由现场操作员确认安全条件');if(!dynToken)throw Error('请先安全预检查');const t=dynToken;dynToken=null;
 const r=await request('/api/dynamic/start','POST',{token:t,acknowledged:true});dynRunning=!!r.running;
 toast('已启动真实低速正弦实验；请现场监护，硬件急停保持可用');await refreshDynamic()}));
 $('dyn-stop').addEventListener('click',execute(async()=>{const r=await request('/api/dynamic/abort','POST');toast('停车指令已发送；请确认转台实际停止'+(r.stopped_verified?'（反馈确认）':'（等待反馈确认）'),true);await refreshDynamic()}));
 updateDynamicPlan();
}
let tmBusy=false;
function tmAxisStatus(a){
 if(!a)return '未采集';
 const flags=[];flags.push(a.healthy?'正常':'故障');flags.push(a.enabled?'已使能':'未使能');flags.push(a.zeroed?'已找零':'未找零');
 if(a.upper_limit)flags.push('上限位');if(a.lower_limit)flags.push('下限位');
 if(a.driver_fault)flags.push('驱动报警');if(a.over_speed)flags.push('超速报警');
 return flags.join(' · ')+' · 模式 '+String(a.mode??'—');
}
function updateTurntableMonitor(d){
 const connected=!!d.connected,active=!!d.running;
 txt('tm-record-badge',active?'记录中':d.state==='failed'?'采集异常':d.count?'已结束':'未记录');
 txt('tm-rate',active?fmt(d.measured_rate_hz,1)+' Hz':(d.count?'已停止':'—'));
 txt('tm-age',d.latest_age_ms!=null?fmt(d.latest_age_ms,0)+' ms':'—');
 txt('tm-read-ms',d.latest?.read_duration_ms!=null?fmt(d.latest.read_duration_ms,2)+' ms':'—');
 txt('tm-count',String(d.count||0));
 for(const a of ['0','2']){
   const x=d.latest?.axes?.[a];
   txt('tm-pos'+a,x?encoderAngle(x.position_deg,4):'—');
   txt('tm-speed'+a,x?fmt(x.speed_dps,4)+' °/s':'—');
   txt('tm-state'+a,tmAxisStatus(x));
 }
 const start=$('tm-start'),stop=$('tm-stop'),link=$('tm-download');
 start.disabled=active||!connected;stop.disabled=!active;
 if(d.file){link.hidden=false;link.href='/api/file/reports/'+encodeURIComponent(d.file)}else link.hidden=true;
 txt('tm-message',d.error?'采集失败：'+d.error:active?'正在读取真实双轴反馈；请保持现场安全监护。':
     connected?(d.count?'记录已结束，CSV已保存。':'转台已连接，可开始只读记录。'):'转台未连接，请先进入设置连接2TD-600。');
 if(d.recent?.length){$('tm-empty').hidden=true;drawTableFeedback(d.recent)}else $('tm-empty').hidden=false;
}
function drawTableFeedback(rows){
 const canvas=$('tm-chart');if(!canvas||!rows.length)return;
 const rect=canvas.getBoundingClientRect();if(!rect.width)return;
 const dpr=Math.min(2,window.devicePixelRatio||1),w=rect.width,h=245;
 if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr)}
 const c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);
 const left=56,right=18,top=20,bottom=32,cw=w-left-right,ch=h-top-bottom;
 const tmin=rows[0].t_s,tmax=rows[rows.length-1].t_s||tmin+1;
 const ys=rows.flatMap(v=>[v.pos0,v.pos2]).filter(Number.isFinite);
 if(!ys.length)return;
 const mn=Math.min(...ys),mx=Math.max(...ys),padding=Math.max(.05,(mx-mn)*.12),ymin=mn-padding,ymax=mx+padding;
 const x=t=>left+cw*(t-tmin)/Math.max(.001,tmax-tmin),y=v=>top+ch*(1-(v-ymin)/(ymax-ymin));
 c.font='11px -apple-system,Segoe UI,sans-serif';c.textAlign='right';
 for(let i=0;i<5;i++){const v=ymin+(ymax-ymin)*i/4,yy=y(v);c.strokeStyle='#e7eae7';c.beginPath();c.moveTo(left,yy);c.lineTo(w-right,yy);c.stroke();c.fillStyle='#788078';c.fillText(v.toFixed(2)+'°',left-9,yy+4)}
 for(const [k,color] of [['pos0','#303b36'],['pos2','#bf9271']]){
   c.lineWidth=2;c.strokeStyle=color;c.beginPath();
   rows.forEach((r,i)=>{if(i===0)c.moveTo(x(r.t_s),y(r[k]));else c.lineTo(x(r.t_s),y(r[k]))});c.stroke();
 }
 c.fillStyle='#626b63';c.textAlign='right';c.fillText('最近反馈 · '+Math.max(0,tmax-tmin).toFixed(1)+' s',w-right,h-8);
 c.textAlign='left';c.fillStyle='#303b36';c.fillText('● 轴0',left+6,14);c.fillStyle='#bf9271';c.fillText('● 轴2',left+63,14);
}
async function refreshTableMonitor(){
 if(tmBusy)return;
 tmBusy=true;
 try{updateTurntableMonitor(await request('/api/turntable/monitor/status'))}catch(err){txt('tm-message','状态读取失败：'+err.message)}finally{tmBusy=false}
}
function supportedAlgoEntries(){const ids=new Set((state.meta?.algorithms||[]).map(x=>x.id));return ids.size?Object.entries(ALGO_INFO).filter(([id])=>ids.has(id)):Object.entries(ALGO_INFO)}
function buildAlgorithms(){let root=$('algorithm-list');root.innerHTML=supportedAlgoEntries().map(([id,e],i)=>`<button class="algo-item ${id===state.algo?'active':''}" data-algo="${id}"><i>${i+1}</i><span><b>${e[0]}</b><small>${e[1]}</small></span></button>`).join('');root.querySelectorAll('[data-algo]').forEach(b=>b.addEventListener('click',execute(()=>selectAlgorithm(b.dataset.algo))))}
function fillQuickSelector(){const s=$('quick-algorithm');if(!s)return;s.innerHTML=supportedAlgoEntries().map(([id,e])=>`<option value="${id}">${e[0]}</option>`).join('');s.value=state.algo}
function renderQuickParams(){
 const choices={complementary:['alpha'],mahony:['kp','ki'],adaptive:['kp','ki','acc_threshold'],madgwick:['beta'],kalman:['kalman_r'],leverarm:['beta','lever_z_cm','lever_tau_s'],adaptive_lever:['beta','lever_z_cm','lever_tau_s','adaptive_beta_floor','adaptive_acc_innovation_gps'],motion_guard:['kp','acc_threshold'],gyro_anchor:['kp','acc_threshold','lever_z_cm','lever_tau_s'],vqf6d:['vqf_nominal_hz','vqf_tau_acc_s'],vqf_lever:['vqf_nominal_hz','vqf_tau_acc_s','lever_z_cm','lever_tau_s']};
 const ids=choices[state.algo]||[];txt('quick-tune-name',ALGO_INFO[state.algo][0]);
 const p=$('quick-tune-params');
 p.innerHTML=ids.length?PARAMS.filter(([id])=>ids.includes(id)).map(([id,title,min,max,step])=>`<label class="quick-param"><span>${title} <strong id="qv-${id}">${fmt(state.params[id],3)}</strong></span><input type="range" id="qp-${id}" min="${min}" max="${max}" step="${step}" value="${state.params[id]}"></label>`).join(''):'<p class="help">该算法暂无可调参数。</p>';
 for(const id of ids)$('qp-'+id).addEventListener('input',()=>{state.params[id]=Number($('qp-'+id).value);txt('qv-'+id,fmt(state.params[id],3));if($('p-'+id)){$('p-'+id).value=state.params[id];txt('val-'+id,fmt(state.params[id],3))}});
 $('quick-tune-apply').disabled=!ids.length;
}

function buildSliders(){const root=$('parameter-sliders');root.innerHTML=PARAMS.map(([id,name,min,max,step])=>`<div class="param"><div class="param-label"><span>${name}</span><b id="val-${id}">${fmt(state.params[id],3)}</b></div><input type="range" id="p-${id}" value="${state.params[id]}" min="${min}" max="${max}" step="${step}"></div>`).join('');PARAMS.forEach(([id])=>{$('p-'+id).addEventListener('input',()=>{state.params[id]=Number($('p-'+id).value);txt('val-'+id,fmt(state.params[id],3))})})}
async function refreshPorts(){
 const result=await request('/api/ports');
 for(const id of ['serial-port','table-port','v58-table-port','v58-imu-port','native-port']){
   const el=$(id);if(!el)continue;
   let saved='';try{saved=localStorage.getItem('tiltlab_v70_'+id)||''}catch(_e){}
   const prev=el.value||saved;
   el.innerHTML='<option value="">选择COM端口</option>'+result.ports.map(p=>`<option value="${escapeHtml(p.device)}">${escapeHtml(p.device+' — '+p.label)}</option>`).join('');
   if(result.ports.some(x=>x.device===prev))el.value=prev;
   if(!el.dataset.v70PortSaved){
      el.dataset.v70PortSaved='1';
      el.addEventListener('change',()=>{try{localStorage.setItem('tiltlab_v70_'+id,el.value)}catch(_e){}});
   }
 }
}
async function refreshFiles(){let {recordings,reports}=await request('/api/files');for(const [id,kind,items] of [['record-list','recordings',recordings],['report-list','reports',reports]]){$(id).innerHTML=items.length?items.map(f=>`<div class="file-item"><div><span>${escapeHtml(f.name)}</span><small>${Math.round(f.size/1024)} KB · ${escapeHtml(f.modified.replace('T',' '))}</small></div><a href="/api/file/${kind}/${encodeURIComponent(f.name)}">下载 ↗</a></div>`).join(''):'<p>暂无文件</p>'}}
function buildExperiments(){return; const e=state.meta?.experiments||[];$('experiment-cards').innerHTML=e.map((v,i)=>`<article class="exp-card glass"><div class="exp-top"><span class="exp-number">${String(i+1).padStart(2,'0')}</span><span class="exp-duration">◷ ${v.duration}秒</span></div><h3>${escapeHtml(v.name)}</h3><p>${escapeHtml(v.description)}</p><button class="btn subtle" data-experiment="${v.id}">运行离线模拟实验 ↗</button></article>`).join('');all('[data-experiment]').forEach(b=>b.addEventListener('click',execute(async()=>{b.disabled=true;b.textContent='正在计算真实融合结果…';toast('正在生成完整合成IMU样本并计算8种算法');try{const r=await request('/api/experiment','POST',{id:b.dataset.experiment,fs:200});state.latestResult=r;renderExperiment(r);toast('模拟实验报告已生成，可下载JSON和CSV')}finally{b.disabled=false;b.textContent='运行离线模拟实验 ↗'}})))}
function renderExperiment(payload){const r=payload.result,best=r.rankings[0],current=r.rankings.find(x=>x.id==='adaptive')||best;const root=$('experiment-result');root.className='panel glass report-result';root.innerHTML=`<div class="panel-head"><div><div class="kicker">REPRODUCIBLE EXPERIMENT / SIMULATED</div><h2>${escapeHtml(r.title)} · 全算法对照</h2></div><span class="page-tag amber">模拟参考 · 非实测</span></div><p class="report-warning">${escapeHtml(r.warning)}</p><div class="report-stat-grid"><div class="report-stat"><span>自适应Mahony Roll RMSE</span><b>${fmt(current.roll_cal?.rmse,3)}°</b></div><div class="report-stat"><span>未补偿 Roll RMSE</span><b>${fmt(current.roll_raw?.rmse,3)}°</b></div><div class="report-stat"><span>自适应Mahony Pitch RMSE</span><b>${fmt(current.pitch_cal?.rmse,3)}°</b></div><div class="report-stat"><span>参考采样频率</span><b>${r.fs_hz} Hz</b></div></div><div class="chartwrap report-graph"><canvas id="experiment-chart"></canvas></div><div class="table-wrap"><table class="results-table"><thead><tr><th>算法</th><th>Roll RMSE（补偿）</th><th>Roll RMSE（未补偿）</th><th>Pitch RMSE（补偿）</th><th>最大绝对误差</th></tr></thead><tbody>${r.rankings.map(x=>`<tr><td>${escapeHtml(x.name)}</td><td>${fmt(x.roll_cal?.rmse,4)}°</td><td>${fmt(x.roll_raw?.rmse,4)}°</td><td>${fmt(x.pitch_cal?.rmse,4)}°</td><td>${fmt(x.roll_cal?.max,4)}°</td></tr>`).join('')}</tbody></table></div>${r.frequency_response?.length?`<div class="panel-head"><div><div class="kicker">FREQUENCY RESPONSE</div><h2>正弦幅值比 / 相位延迟（模拟）</h2></div></div><div class="table-wrap"><table class="results-table"><thead><tr><th>频率</th><th>补偿幅值比</th><th>补偿相位延迟</th><th>未补偿幅值比</th><th>未补偿相位延迟</th></tr></thead><tbody>${r.frequency_response.map(v=>`<tr><td>${fmt(v.frequency_hz,2)} Hz</td><td>${fmt(v.roll_gain,4)}</td><td>${fmt(v.roll_lag_ms,1)} ms</td><td>${fmt(v.raw_gain,4)}</td><td>${fmt(v.raw_lag_ms,1)} ms</td></tr>`).join('')}</tbody></table></div>`:''}<div class="hero-actions"><a class="btn primary" href="/api/file/reports/${encodeURIComponent(payload.report_file)}">下载JSON测试报告</a><a class="btn subtle" href="/api/file/reports/${encodeURIComponent(payload.data_file)}">下载原始CSV</a></div>`;setTimeout(drawExperiment,80)}
function drawExperiment(){const d=state.latestResult?.result.chart||[];const graph=d.map(r=>({t:r.t,raw:{roll:r.raw,pitch:r.rawPitch},cal:{roll:r.cal,pitch:r.calPitch},ref:{roll:r.reference,pitch:r.refPitch}}));drawLine($('experiment-chart'),graph,'roll',series)}
function drawReplay(){const r=state.replay;if(!r)return;const d=r.chart.map(v=>({t:v.t,raw:v.raw,cal:v.cal,ref:v.ref}));drawLine($('replay-chart'),d,'roll',series)}
function staticReportConclusions(r){
 const rows=(r.comparison||[]).filter(x=>x.channel==='cal' && !['gyro','accel'].includes(x.algorithm));
 const usable=rows.length?rows:(r.comparison||[]).filter(x=>x.channel==='raw'&&!['gyro','accel'].includes(x.algorithm));
 const ordered=[...usable].sort((a,b)=>Math.hypot(a.roll_std,a.pitch_std)-Math.hypot(b.roll_std,b.pitch_std));
 const best=ordered[0],ch=rows.length?'常温/全温补偿':'未标定';
 const notes=[];
 notes.push('加速度直算（无滤波）是基准输出：仅逐样本计算重力倾角，不融合陀螺仪，也不进行时间平滑；补偿后分支只做标定校正。其动态误差会受运动加速度影响。');
 if(best)notes.push(`在本次${fmt(r.elapsed_s,1)}秒记录和当前参数下，${ALGO_INFO[best.algorithm]?.[0]||best.algorithm}的Roll/Pitch标准差合成最小（${fmt(best.roll_std,4)}° / ${fmt(best.pitch_std,4)}°）；这是静态离散度结果，并非动态综合排名。`);
 const ins=r.inputs||{},gx=ins.gyro_cal_x||ins.gyro_raw_x,gz=ins.gyro_cal_z||ins.gyro_raw_z;
 if(gx&&Math.abs(gx.mean)>.1||gz&&Math.abs(gz.mean)>.1){notes.push(`静止假设下陀螺仪残余角速度值得排查：X ${fmt(gx?.mean,3)}°/s，Z ${fmt(gz?.mean,3)}°/s；优先核查标定参数、坐标系、采样单位和测试期间是否真的未运动。`);}
 const m=r.metrics?.cal?.mahony||r.metrics?.raw?.mahony;
 if(m?.yaw && Math.abs(m.yaw.drift_deg_per_min)>1)notes.push(`相对Yaw在本段数据中的线性趋势约 ${fmt(m.yaw.drift_deg_per_min,2)}°/min；六轴IMU没有绝对航向参考，不能从本项静态实验推断长期绝对航向精度。`);
 const motion=(r.warnings||[]).filter(x=>/角速度变化|加速度模长变化|样本过少|数据间隔|运动|振动/.test(x));
 if(motion.length)notes.push('数据质量提示：报告检测到可能的运动、振动或异常采样，当前静态结果需要复测，不能作为正式验收结论。');
 notes.push('没有外部参考角度，不能据此计算绝对精度、动态RMSE、响应延迟或宣布算法达到工业产品指标。');
 return {notes,best,ch,motion};
}
function renderStabilityReport(r){
 if(!r?.metrics)return;
 state.stabilityReport=r;
 const input=r.inputs||{},notes=staticReportConclusions(r);
 const warn=(r.warnings||[]).map(w=>`<div class="stability-warning">${escapeHtml(w)}</div>`).join('');
 const rc=(r.comparison||[]).filter(v=>v.channel==='cal');
 const channel=rc.length?'cal':'raw';
 state.stabilityChannel=channel;
 const stats=`<div class="stability-overview">
   <div><span>设备</span><b>${escapeHtml(r.uid||'未知')}</b></div><div><span>记录时长</span><b>${fmt(r.elapsed_s,1)} s</b></div>
   <div><span>样本数</span><b>${Number(r.samples||0).toLocaleString('zh-CN')}</b></div>
   <div><span>采集均速</span><b>${r.elapsed_s>0?fmt(r.samples/r.elapsed_s,0)+' /s':'—'}</b></div></div>`;
 const rows=(r.comparison||[]).map(x=>`<tr><td>${escapeHtml(ALGO_INFO[x.algorithm]?.[0]||x.algorithm)}</td><td>${x.channel==='cal'?'补偿后':'未标定'}</td><td>${fmt(x.roll_std,4)}</td><td>${fmt(x.pitch_std,4)}</td><td>${fmt(x.roll_pp,3)}</td><td>${fmt(x.pitch_pp,3)}</td><td>${fmt(x.roll_drift_dpm,3)}</td><td>${fmt(x.pitch_drift_dpm,3)}</td><td>${fmt(x.yaw_drift_dpm,2)}</td></tr>`).join('');
 $('stability-output').innerHTML=`<div class="report-heading"><div><div class="kicker">MEASURED DATA / STATIC EVALUATION</div><h3>静态稳定性对比</h3><p>${escapeHtml(r.started_at||'')} · ${r.reference_available?'包含角度参考':'没有外部角度参考'}</p></div><span class="report-quality ${notes.motion.length?'caution':'neutral'}">${notes.motion.length?'静止条件需复核':'仅供静态比较'}</span></div>
 ${stats}<div class="stability-graph-top"><div><b>Roll / Pitch 标准差</b><small>单位 °，越低表示这段记录内波动越小</small></div><div class="seg-control"><button data-report-channel="cal" ${!rc.length?'disabled':''} class="${channel==='cal'?'selected':''}">补偿后</button><button data-report-channel="raw" class="${channel==='raw'?'selected':''}">未标定</button></div></div>
 <div class="stability-graph-wrap"><canvas id="stability-bars" aria-label="多算法的Roll和Pitch角度标准差柱状比较图"></canvas></div><div class="report-legend"><span><i class="roll-mark"></i>Roll 标准差</span><span><i class="pitch-mark"></i>Pitch 标准差</span><span>“无滤波”是加速度直算基线；纯陀螺积分单独列在详细表格中</span></div>
 <div class="report-conclusions"><h3>自动分析结论</h3>${notes.notes.map((t,i)=>`<div class="report-note"><span>${i+1}</span><p>${escapeHtml(t)}</p></div>`).join('')}</div>
 <div class="stability-stats"><div><span>补偿后陀螺仪 X轴均值</span><b>${fmt(input.gyro_cal_x?.mean,4)} °/s</b></div><div><span>补偿后陀螺仪 Z轴均值</span><b>${fmt(input.gyro_cal_z?.mean,4)} °/s</b></div><div><span>原始Z轴均值</span><b>${fmt(input.gyro_raw_z?.mean,4)} °/s</b></div></div>
 ${warn}<details class="report-details"><summary>查看全部算法统计指标</summary><div class="table-scroll"><table><thead><tr><th>算法</th><th>通道</th><th>Roll σ°</th><th>Pitch σ°</th><th>Roll峰峰°</th><th>Pitch峰峰°</th><th>Roll漂移°/min</th><th>Pitch漂移°/min</th><th>Yaw漂移°/min</th></tr></thead><tbody>${rows}</tbody></table></div></details>
 ${r.report_file?`<a class="btn subtle" href="/api/file/reports/${encodeURIComponent(r.report_file)}">下载原始JSON报告</a>`:''}`;
 all('[data-report-channel]').forEach(b=>b.addEventListener('click',()=>{state.stabilityChannel=b.dataset.reportChannel;all('[data-report-channel]').forEach(v=>v.classList.toggle('selected',v===b));drawStabilityBars()}));
 requestAnimationFrame(drawStabilityBars);
}
function drawStabilityBars(){
 const canvas=$('stability-bars'),s=state.stabilityReport;
 if(!canvas||!s||!canvas.getBoundingClientRect().width)return;
 const data=(s.comparison||[]).filter(v=>v.channel===state.stabilityChannel && v.algorithm!=='gyro');
 const order=['kalman','complementary','mahony','adaptive','madgwick','accel'];
 data.sort((a,b)=>order.indexOf(a.algorithm)-order.indexOf(b.algorithm));
 if(!data.length)return;
 const dpr=Math.min(1.5,window.devicePixelRatio||1),w=canvas.getBoundingClientRect().width,h=300;
 canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);const c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);
 const ml=50,mr=12,mt=30,mb=60,cw=w-ml-mr,ch=h-mt-mb;
 const maxRaw=Math.max(...data.map(v=>Math.max(v.roll_std,v.pitch_std))),maxVal=Math.max(.01,maxRaw*1.2);
 const yy=v=>mt+ch*(1-v/maxVal);
 c.textAlign='right';c.font='11px -apple-system,Segoe UI,sans-serif';c.fillStyle='#747b75';c.lineWidth=1;
 for(let i=0;i<5;i++){const v=maxVal*i/4,y=yy(v);c.strokeStyle='rgba(40,50,45,.10)';c.beginPath();c.moveTo(ml,y);c.lineTo(w-mr,y);c.stroke();c.fillText(v.toFixed(maxVal<.15?3:2),ml-7,y+4)}
 const block=cw/data.length,bar=Math.min(23,block*.28);
 for(let i=0;i<data.length;i++){
   const v=data[i],mid=ml+block*(i+.5),values=[[v.roll_std,'#454c48',mid-bar-2],[v.pitch_std,'#c49b80',mid+2]];
   for(const [n,color,x] of values){const top=yy(n);c.fillStyle=color;c.beginPath();if(c.roundRect)c.roundRect(x,top,bar,Math.max(1,mt+ch-top),[5,5,0,0]);else c.rect(x,top,bar,Math.max(1,mt+ch-top));c.fill();}
   c.fillStyle='#505a53';c.textAlign='center';c.font='11px -apple-system,Segoe UI,sans-serif';
   const label={kalman:'Kalman',complementary:'互补滤波',mahony:'Mahony',adaptive:'自适应',madgwick:'Madgwick',accel:'无滤波'}[v.algorithm]||v.algorithm;
   c.fillText(label,mid,h-mb+18);
 }
}
async function refreshStability(){
 const s=await request('/api/stability/status');
 if(!s){if(!state.stabilityImported)txt('stability-progress','未开始');return;}
 if(state.stabilityImported && s.state!=='running')return;
 txt('stability-progress',`${s.state==='running'?'采集中':s.state==='completed'?'已完成':'已结束'} · ${fmt(s.elapsed_s,1)} / ${Number(s.duration_s)===0?'手动结束':fmt(s.duration_s,0)+'秒'} · ${s.samples}点`);
 if(s.state==='running'){if(!state.stabilityReport)$('stability-output').textContent='采集中；结束后自动显示图表与结论。';return;}
 if(!s.metrics){return;}
 const key=`${s.report_file||''}|${s.state}|${s.samples}`;
 if(state.stabilityRenderedKey!==key){state.stabilityRenderedKey=key;renderStabilityReport(s)}
}
function updateLibraryHelp(){
const shared=$('cal-source-kind').value==='shared';
const example=String.raw`\\fileserver\calibration`;
txt('cal-source-help',shared?`输入 Windows 共享路径（例如 ${example}），并确保运行上位机的账户有读取权限。`:'选择本地目录，保存后每次启动都会自动加载；设备连接后按编号匹配标定参数。');
$('cal-folder').placeholder=shared?example:String.raw`D:\Calibration`;
}
/* V7.30.1: Use native <select> elements on every page.
   The legacy glass popup closed itself on bubbled scroll events, preventing
   access to COM ports below the initially visible rows.  Native controls
   preserve wheel/keyboard scrolling and the existing change listeners. */
function bind(){bindWorkbench();all('.nav-link').forEach(el=>el.addEventListener('click',()=>setPage(el.dataset.page)));all('[data-axis]').forEach(el=>el.addEventListener('click',()=>{state.axis=el.dataset.axis;all('[data-axis]').forEach(b=>b.classList.toggle('selected',b===el));drawLive()}));
$('btn-demo').addEventListener('click',()=>setPage('settings'));$('btn-serial').addEventListener('click',execute(()=>begin('serial')));
$('btn-stop').addEventListener('click',execute(async()=>{await request('/api/stop','POST');await refreshStatus(true);toast('采集已停止')}));
$('btn-record').addEventListener('click',execute(async()=>{let s=state.status;if(s?.recording){let r=await request('/api/record/stop','POST');toast('已保存CSV：'+r.file)}else{let r=await request('/api/record/start','POST');toast('开始全速录制：'+r.file)}await refreshStatus()}));
$('btn-params').addEventListener('click',execute(async()=>{await request('/api/config','POST',{params:Object.fromEntries(Object.entries(state.params).filter(([k])=>!k.startsWith('lever3_')))});toast('参数已应用；融合引擎已重置')}));
$('btn-defaults').addEventListener('click',execute(async()=>{state.params={...DEFAULT};buildSliders();await request('/api/config','POST',{params:Object.fromEntries(Object.entries(state.params).filter(([k])=>!k.startsWith('lever3_')))});toast('研究默认参数已恢复')}));
$('btn-lever-example').addEventListener('click',()=>{state.params.lever_z_cm=0;state.params.lever_tau_s=.09;buildSliders();toast('恢复偏心补偿为0cm，不会把历史拟合等效距离当作真实机械尺寸。点击应用参数后生效。')});
 $('btn-cal-paths').addEventListener('click',execute(async()=>{
   const x=await request('/api/calibration/paths');
   const files=(x.matched_factory_files||[]).length?x.matched_factory_files.join('\n'):'尚未找到匹配文件';
   txt('cal-paths-info',`【标定目录设置文件】\n${x.settings_file}\n\n【原厂标定搜索目录】\n${x.calibration_folder||'未配置'}\n\n【实际匹配的ACC/GYRO厂标定JSON】\n${files}\n\n【每次安装轴预检及静态对齐报告保存目录】\n${x.fixture_report_folder}\n\n${x.message}`);
 }));
$('btn-folder').addEventListener('click',execute(async()=>{const p=$('cal-folder').value.trim();const r=await request('/api/calibration/folder','POST',{path:p,source_kind:$('cal-source-kind').value});state.settingsDirty=false;toast(r.status==='matched'?'已找到匹配的ACC/GYRO标定文件':r.detail||'目录已扫描');await refreshStatus()}));
$('btn-rescan').addEventListener('click',execute(async()=>{const r=await request('/api/calibration/refresh','POST');toast(r.status==='matched'?'UID标定匹配成功':r.detail||'扫描完成');await refreshStatus()}));
all('[name="cal-mode"]').forEach(el=>el.addEventListener('change',execute(async()=>{if(!el.checked)return;const r=await request('/api/calibration/mode','POST',{mode:el.value});toast(r.status==='matched'?'已加载'+(el.value==='thermal'?'全温研究模型':'常温参数'):r.detail||'已切换补偿模式');await refreshStatus(true)})));
$('cal-source-kind').addEventListener('change',()=>{state.settingsDirty=true;updateLibraryHelp()});
$('cal-folder').addEventListener('input',()=>{state.settingsDirty=true;txt('cal-save-status','修改尚未保存')});
$('cal-open-settings').addEventListener('click',()=>setPage('settings'));
$('health-open-device').addEventListener('click',()=>setPage('settings'));
$('health-open-calibration').addEventListener('click',()=>setPage('calibration'));
$('btn-browse-folder').addEventListener('click',execute(async()=>{let r=await request('/api/calibration/browse','POST');if(r.path){$('cal-folder').value=r.path;state.settingsDirty=true;toast('已选择文件夹；点击设置目录完成扫描')}}));
$('btn-inspect').addEventListener('click',execute(async()=>{const r=await request('/api/calibration/inspect','POST',{path:$('cal-folder').value.trim(),serial:$('cal-inspect-sn').value.trim(),mode:(state.status?.cal_mode==='thermal'?'thermal':'ambient')});txt('cal-inspect-result',`检查结果：${({matched:'已匹配',invalid:'文件参数无效',missing:'缺少文件',ambiguous:'存在重复版本',incompatible:'文件不兼容'})[r.status]||r.status} · ${r.detail||''} · 未应用参数`);$('cal-matrix-diagnostics').innerHTML=(r.matrix_diagnostics||[]).map(d=>`<div class="matrix-diagnostic ${d.status==='valid'?'valid':'invalid'}"><strong>${escapeHtml(d.file||'')}</strong><span>${d.status==='valid'?`${escapeHtml((d.sensor||'').toUpperCase())} · 条件数 ${fmt(d.condition,3)} · 行列式 ${fmt(d.determinant,6)}`:escapeHtml(d.reason||'校验未通过')}</span></div>`).join('');toast('预检查完成，未改变当前设备的补偿状态')}));
$('btn-refresh-files').addEventListener('click',execute(refreshFiles));$('btn-ports').addEventListener('click',execute(refreshPorts));$('btn-table-ports').addEventListener('click',execute(refreshPorts));
$('tm-start').addEventListener('click',execute(async()=>{const r=await request('/api/turntable/monitor/start','POST',{interval_ms:Number($('tm-interval').value)});updateTurntableMonitor(r);toast('转台只读反馈记录已开始，未发送运动指令')}));
$('tm-stop').addEventListener('click',execute(async()=>{const r=await request('/api/turntable/monitor/stop','POST');updateTurntableMonitor(r);toast(r.running?'正在结束采集，请稍后确认CSV保存状态':'反馈记录已结束'+(r.file?'，CSV已保存':'')+(r.error?'；'+r.error:''))}));
$('btn-table-connect').addEventListener('click',execute(async()=>{if(!$('table-port').value)throw Error('请先从列表中选择转台COM端口');const r=await request('/api/turntable/connect','POST',{port:Number(($('table-port').value||'').replace(/^COM/i,'')),baudrate:Number($('table-baud').value),...connectionAuthorization()});updateTable(r);toast('转台已连接并自动使能双轴')}));
$('btn-table-status').addEventListener('click',execute(async()=>updateTable(await request('/api/turntable/status'))));
$('btn-table-disconnect').addEventListener('click',execute(async()=>{await closeTableSimple()}));
$('btn-table-stop').addEventListener('click',execute(async()=>{const r=await request('/api/turntable/stop','POST');toast(r.stopped_verified?'已发停车命令且双轴反馈停止':'停车尚未得到反馈确认，请立即核查硬件急停',!r.stopped_verified)}));
$('btn-real-test').addEventListener('click',execute(async()=>{if(!$('real-ack').checked)throw Error('必须由现场操作员完成全部安全确认');const r=await request('/api/hardware-test/start','POST',{axis:Number($('real-table-axis').value),output:$('real-imu-axis').value,acknowledged:true});txt('real-test-state','实机实验：'+r.state);toast('实机静态测试已启动，请现场监护')}));
$('btn-real-abort').addEventListener('click',execute(async()=>{const r=await request('/api/hardware-test/abort','POST');txt('real-test-state','已请求中止：'+r.state);toast('已发送停车命令，请现场确认完全停止')}));
$('btn-replay').addEventListener('click',execute(async()=>{const file=$('replay-file').files[0];if(!file)throw Error('请先选择CSV文件');let fd=new FormData();fd.append('file',file);const r=await request('/api/replay','POST',fd);state.replay=r;txt('replay-summary',`${r.name} · ${r.rows} 样本 · 算法 ${r.algorithm} · ${r.metrics?`Roll RMSE ${fmt(r.metrics.roll?.rmse,4)}°，Pitch RMSE ${fmt(r.metrics.pitch?.rmse,4)}°`:'无可信参考角度，未计算绝对精度'}。`);$('replay-empty').style.display='none';drawReplay();toast(`CSV重算完成：${r.rows}个采样点`)}));
$('quick-algorithm').addEventListener('change',execute(()=>selectAlgorithm($('quick-algorithm').value)));
$('quick-tune-toggle').addEventListener('click',()=>{const panel=$('quick-tuning');panel.hidden=!panel.hidden;$('quick-tune-toggle').setAttribute('aria-expanded',String(!panel.hidden));if(!panel.hidden)renderQuickParams()});
$('quick-tune-close').addEventListener('click',()=>{$('quick-tuning').hidden=true;$('quick-tune-toggle').setAttribute('aria-expanded','false')});
$('quick-tune-apply').addEventListener('click',execute(async()=>{await request('/api/config','POST',{params:Object.fromEntries(Object.entries(state.params).filter(([k])=>!k.startsWith('lever3_')))});await refreshStatus(true);toast('参数已应用，滤波状态重新初始化，需等待收敛')}));
$('btn-stability-start').addEventListener('click',execute(async()=>{const manual=$('stability-manual').checked;const n=Number($('stability-duration').value);if(!manual&&(!Number.isInteger(n)||n<1||n>604800))throw Error('自定义时长需为1–604800秒整数；也可以勾选不限时手动结束');state.stabilityImported=false;state.stabilityReport=null;state.stabilityRenderedKey='';await request('/api/stability/start','POST',{duration_s:manual?0:n});toast(manual?'不限时静态记录已开始，完成后点击结束并保存':'实机静态稳定性测试已开始，请保持PCB固定不动');await refreshStability()}));
$('stability-manual').addEventListener('change',()=>{$('stability-duration').disabled=$('stability-manual').checked;});
$('show-unfiltered').addEventListener('change',()=>{scheduleChart();drawLive();});
$('btn-stability-stop').addEventListener('click',execute(async()=>{await request('/api/stability/stop','POST');await refreshStability();toast('本次静态记录已保存')}));
$('stability-report-input').addEventListener('change',execute(async()=>{const file=$('stability-report-input').files?.[0];if(!file)return;const r=JSON.parse(await file.text());if(!r?.metrics||!Array.isArray(r.comparison))throw Error('该JSON不是静态稳定性报告');state.stabilityImported=true;state.stabilityRenderedKey='';txt('stability-progress','已载入报告 · '+file.name);renderStabilityReport(r);toast('历史静态报告分析已加载')}));
window.addEventListener('resize',()=>{scheduleChart();drawExperiment();drawReplay();drawStabilityBars()});}
async function connectWs(){const proto=location.protocol==='https:'?'wss':'ws';let ws=new WebSocket(`${proto}://${location.host}/ws`);state.ws=ws;
 ws.onmessage=e=>{try{
  const s=JSON.parse(e.data);appendChartDelta(s.chart_delta);
  const now=performance.now();
  pushWindowCount++;if(!pushWindowStart)pushWindowStart=now;
  if(now-pushWindowStart>=1000){pushRate=pushWindowCount*1000/(now-pushWindowStart);pushWindowCount=0;pushWindowStart=now;}
  const pose=s.latest?.cal||s.latest?.raw;
  if(pose)window.tiltSensorModel?.setAngles(pose.roll,pose.pitch,pose.yaw);
  if(now-lastUi>95||s.error){lastUi=now;updateStatus(s)}
 }catch(err){console.error(err)}};
 ws.onerror=()=>{console.warn('TiltLab websocket error: see network/console diagnostics; PCB serial status is not implied')};
 ws.onclose=()=>{
   if(state.ws!==ws)return;
   txt('sidebar-status','网页数据连接中断');
   txt('side-source','WebSocket断开；PCB实际连接状态未知，正在重连');
   $('side-dot').className='status-dot gray';
   setTimeout(()=>{if(state.ws===ws)connectWs()},2500);
 };
}
async function refreshTableDiagnostics(){
 if(state.active!=='experiments')return;
 try{
   const r=await request('/api/turntable/diagnostics?limit=70');
   const events=r.events||[];
   txt('tt-diag-count',events.length+'条事件');
   $('tt-diag-list').innerHTML=events.length?events.slice().reverse().map(e=>{
     const fail=/failed|exception|invalid/i.test(e.stage);
     const details=e.details&&Object.keys(e.details).length?`<div class="details">${escapeHtml(JSON.stringify(e.details))}</div>`:'';
     return `<div class="tt-diag-entry ${fail?'fail':''}"><time>${escapeHtml(e.time||'')}</time><span class="tt-diag-stage">${escapeHtml(e.stage||'')}</span><div>${escapeHtml(e.message||'')}${details}</div></div>`;
   }).join(''):'<div class="tt-diag-entry">本次尚无硬件诊断事件。点击“读取状态”或“连接转台”后会记录结果。</div>';
 }catch(e){txt('tt-diag-list','日志读取失败：'+e.message)}
}
function bindTableDiagnostics(){
 $('tt-diag-refresh').addEventListener('click',execute(refreshTableDiagnostics));
}
async function refreshNativeStatus(){
 const r=await request('/api/turntable/native/status');
 txt('native-status',r.running?`正在记录 ${r.samples}帧 · 实测${fmt(r.measured_rate_hz,1)}Hz · 丢帧计数估计 ${r.estimated_missing_counter_values} · 坏帧 ${r.rejected_frames} · 最新帧距今${fmt(r.latest_age_ms,0)}ms · ${r.file||''}`:`未运行${r.error?' · '+r.error:''} · ${r.file||''}`);
 $('native-start').disabled=r.running;$('native-stop').disabled=!r.running;
}
function renderStaticReport(r){
 const ps=r.points||{};let a=r.analysis||{};
 const points=[-3,0,3].map(k=>`<span class="v67-dot ${ps[String(k)]?'done':''}">${k>0?'+':''}${k}° ${ps[String(k)]?'已采样 '+ps[String(k)].samples+'条':'未采集'}</span>`).join('');
 const rows=Object.entries(a.algorithms||{}).filter(([k])=>k.startsWith('cal_')).map(([k,v])=>`<tr><td>${escapeHtml(k.substring(4))}</td><td>${fmt(v.target_gain,4)}</td><td>${fmt(v.cross_axis_gain,4)}</td><td>${fmt(v.apparent_2d_cross_axis_deg,3)}°</td></tr>`).join('');
 $('static-result').innerHTML='<div class="v67-dots">'+points+'</div>'+ (a.ready?`<p><strong>目标轴增益与二维交叉轴串扰</strong> · 实测外轴跨度 ${fmt(a.measured_outer_span_deg,3)}°</p><div class="table-scroll"><table class="dyn-table"><thead><tr><th>算法（常温补偿）</th><th>目标轴增益</th><th>串扰增益</th><th>二维表观偏角</th></tr></thead><tbody>${rows}</tbody></table></div>`:`<p class="help">${escapeHtml(a.reason||'等待采样')}</p>`)+(r.report_file?`<a href="/api/file/reports/${encodeURIComponent(r.report_file)}" download>下载静态对齐JSON</a>`:'');
}
function bindAlignmentAndNative(){
 $('native-start').addEventListener('click',execute(async()=>{const port=$('native-port').value;if(!port)throw Error('请选专用第二个COM口');await request('/api/turntable/native/start','POST',{port,baudrate:Number($('native-baud').value),byte_order:$('native-endian').value});await refreshNativeStatus();toast('独立厂家状态帧只读记录已启动')}));
 $('native-stop').addEventListener('click',execute(async()=>{await request('/api/turntable/native/stop','POST');await refreshNativeStatus()}));
 $('native-compare').addEventListener('click',execute(async()=>{const d=await request('/api/turntable/native/compare');toast(d.agreement_within_0_1deg?`只读核对：内轴差${fmt(d.inner_disagreement_deg,4)}°，外轴差${fmt(d.outer_disagreement_deg,4)}°（还需动态验证）`:`原始流与DLL角度不同：外轴差${fmt(d.outer_disagreement_deg,4)}°，请先核对字节序/数据源`,!d.agreement_within_0_1deg)}));
 $('static-reset').addEventListener('click',execute(async()=>{const r=await request('/api/axis-static/reset','POST',{direction:$('static-direction').value});renderStaticReport(r);txt('static-status','已新建，只读待采样')}));
 $('static-capture').addEventListener('click',execute(async()=>{if(!$('static-ack').checked)throw Error('请先确认实体已安全静止');const st=await request('/api/axis-static/status');if(st.direction!==$('static-direction').value)throw Error('已切换Roll/Pitch方向，请先点击“新建检查”');$('static-capture').disabled=true;txt('static-status','正在只读采集约2秒');try{const r=await request('/api/axis-static/capture','POST',{point:Number($('static-point').value),confirmed:true});renderStaticReport(r);txt('static-status','采样已保存')}finally{$('static-capture').disabled=false}}));
 request('/api/axis-static/status').then(renderStaticReport).catch(()=>{});refreshNativeStatus().catch(()=>{});
}
let leverResult=null;
function renderLeverResult(r){
 const n=v=>Number.isFinite(v)?v.toFixed(4):'不可辨识';
 const metric=(a,b)=>`${n(a)} → ${n(b)}`;
 $('lever-fit-output').innerHTML=`<div class="callout"><strong>${r.eligible_for_session_apply?'研究门槛通过，等待装夹确认':'仅候选，禁止应用'}</strong><p>UID ${escapeHtml(r.uid)} · 可辨识秩 ${r.rank}/3 · X ${n(r.candidate_cm[0])} cm · Y ${n(r.candidate_cm[1])} cm · Z ${n(r.candidate_cm[2])} cm</p><p>${(r.reasons||[]).map(escapeHtml).join('；')||'所有研究检查通过，不代表产品精度验收'}</p></div><div class="table-wrap"><table class="results-table"><thead><tr><th>工况 / 用途</th><th>单组 X/Y/Z (cm)</th><th>ACC幅值误差(°)</th><th>融合相对RMSE(°)</th><th>融合最大相对误差(°)</th><th>样本覆盖 / 最大间隔</th></tr></thead><tbody>${r.runs.map(x=>`<tr><td>${escapeHtml(x.direction.toUpperCase())} ${x.frequency_hz} Hz / ${x.role==='fit'?'拟合':'独立验证'}</td><td>${x.single_run_cm.map(n).join(' / ')}</td><td>${metric(x.amplitude_error_before_deg,x.amplitude_error_after_deg)}</td><td>${metric(x.fusion_before_relative_rmse_deg,x.fusion_after_relative_rmse_deg)}</td><td>${metric(x.fusion_before_relative_max_deg,x.fusion_after_relative_max_deg)}</td><td>${n(x.coverage_pct)}% / ${n(x.max_imu_gap_ms)}ms</td></tr><tr><td colspan="6"><small>${escapeHtml(x.name)} · 每周期候选: ${x.cycle_estimates_cm.map(v=>v.map(n).join('/')).join('；')} · ${x.issues.map(escapeHtml).join('；')||'研究质量门槛通过'} · 共同参考覆盖 ${n(x.common_reference_pct)}% · 因果补偿就绪 ${n(x.causal_ready_pct)}%</small></td></tr>`).join('')}</tbody></table></div><p class="help">${escapeHtml(r.note)} 相对误差使用同一运动前基线、未平移时间轴及真实反馈间隔≤150ms的共同样本；仅研究，非全程最大误差。补偿前后融合均使用同一默认Madgwick参数。</p>`;
 $('lever-apply').disabled=!r.eligible_for_session_apply||!$('lever-confirm-fixture').checked;
 $('lever-save').disabled=false;
}
function bindLeverIdentification(){
 $('lever-research-z').onclick=execute(async()=>{const ack=$('lever-research-ack').checked;if(!ack)throw Error('请先确认同一装夹及研究用途');const r=await request('/api/lever-identify/research-z','POST',{same_fixture_confirmed:ack,research_only_confirmed:ack});state.params={...DEFAULT,...r.params};state.algo=r.algorithm;buildSliders();buildAlgorithms();fillQuickSelector();updateStatus(r);toast('研究候选已启用，仅本次连接；不用于验收')});
 $('lever-fit').onclick=async()=>{const b=$('lever-fit');b.disabled=true;leverResult=null;$('lever-save').disabled=true;$('lever-apply').disabled=true;$('lever-fit-output').textContent='';$('lever-fit-status').textContent='正在读取真实原始数据、拟合并回放……';try{
 const fd=new FormData();for(const f of $('lever-fit-files').files)fd.append('files',f);for(const f of $('lever-validation-files').files)fd.append('validation',f);
 if(!$('lever-fit-files').files.length)throw Error('请先选择拟合数据');leverResult=await request('/api/lever-identify/fit','POST',fd);renderLeverResult(leverResult);$('lever-fit-status').textContent='辨识完成；已保存本地报告。';
 }catch(e){$('lever-fit-status').textContent=e.message;toast(e.message,true)}finally{b.disabled=false}};
 $('lever-confirm-fixture').onchange=()=>{$('lever-apply').disabled=!leverResult?.eligible_for_session_apply||!$('lever-confirm-fixture').checked};
 $('lever-save').onclick=()=>{if(!leverResult)return;const url=URL.createObjectURL(new Blob([JSON.stringify(leverResult,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='TiltLab_lever_'+leverResult.profile_id+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};
 $('lever-apply').onclick=execute(async()=>{const r=await request('/api/lever-identify/apply','POST',{profile_id:leverResult.profile_id,same_fixture_confirmed:$('lever-confirm-fixture').checked});state.params={...DEFAULT,...r.params};state.algo=r.algorithm;buildSliders();buildAlgorithms();fillQuickSelector();updateStatus(r);toast('三维补偿已用于当前会话，滤波状态已重置')});
 $('lever-clear').onclick=execute(async()=>{const r=await request('/api/lever-identify/clear','POST');state.params={...DEFAULT,...r.params};updateStatus(r);toast('本次三维补偿已清除')});
 setInterval(()=>{const st=state.status||{},p=st.params||{},a=st.latest?.cal;const ack=$('anchor3d-auto-ack');if(ack){ack.disabled=autoRunning||dynRunning||autoConnecting;const active=st.algorithm==='gyro_anchor3d'&&Math.abs((p.lever3_z_cm||0)-19.51)<1e-6;txt('anchor3d-auto-status',active?'已启用 · Z=19.51cm · 零偏 '+(a?.stationary_bias_ready?'已就绪':'等待静止')+' · 杆臂 '+(a?.lever_compensation_ready?'已就绪':'未就绪'):(ack.checked?'待自动实验启动时验证并应用（转台须未连接）':'未启用 · 当前算法 '+(st.algorithm||'—')))}},750);
 setInterval(()=>{const p=state.status?.params;if(p){const st=state.status;const a=st.latest?.cal;txt('lever-active','当前算法：'+(st.algorithm||'—')+' · 三维杆臂 X/Y/Z：'+['x','y','z'].map(j=>fmt(p['lever3_'+j+'_cm']??0,3)).join(' / ')+' cm'+(st.algorithm==='gyro_anchor3d'?' · 补偿就绪：'+(a?.lever_compensation_ready?'是':'否')+' · 零偏估计：'+(a?.stationary_bias_ready?'已就绪':'等待静止') : ''))}},1000);
}
const v82LiveRows=[];let v82LiveAxis=null,v82ZeroTable=null,v82ZeroImu=null;
async function updateV82Live(){
 const canvas=$('v82-live-chart');if(!canvas)return;
 const r=await request('/api/dynamic/live-snapshot');
 const show=!!(r.running&&(dynRunning||autoRunning));
 const text=r.mode==='offline'?'默认离线：采集期不计算Roll/Pitch；可查看转台运动角度。停车后统一离线回放。':
   '单算法实时：转台（灰）与IMU（绿色）仅作粗略同步观察，非精度验收。';
 txt('v82-live-text',text);
 if(show && r.reference_angle_deg!=null){
  if(r.output!==v82LiveAxis){v82LiveRows.length=0;v82ZeroTable=null;v82ZeroImu=null;v82LiveAxis=r.output;}
  const rawImu=r.output==='pitch'?r.imu_pitch_deg:r.imu_roll_deg;
  const imu=r.mode==='realtime'&&rawImu!=null&&Number.isFinite(Number(rawImu))?Number(rawImu):null;
  const table=Number(r.reference_angle_deg);
  const wrapDiff=(value,base)=>((value-base+540)%360)-180;
  if(v82ZeroTable==null)v82ZeroTable=table;
  if(v82ZeroImu==null&&imu!=null)v82ZeroImu=imu;
  v82LiveRows.push({ts:performance.now(),table:(Number(r.reference_sign)===-1?-1:1)*wrapDiff(table,v82ZeroTable),imu:imu!=null&&v82ZeroImu!=null?wrapDiff(imu,v82ZeroImu):null});
  if(v82LiveRows.length>240)v82LiveRows.splice(0,v82LiveRows.length-240);
 }else if(v82LiveRows.length){v82LiveRows.length=0;v82ZeroTable=null;v82ZeroImu=null;v82LiveAxis=null;}
 const c=canvas.getContext('2d');if(!c)return;
 const dpr=window.devicePixelRatio||1,w=Math.max(250,canvas.clientWidth||600),h=210;
 if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr)}
 c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);c.fillStyle='#f8faf9';c.fillRect(0,0,w,h);
 c.strokeStyle='#d5ddd8';for(let i=0;i<5;i++){c.beginPath();c.moveTo(36,16+i*43);c.lineTo(w-10,16+i*43);c.stroke()}
 c.font='12px sans-serif';c.fillStyle='#6b7670';c.fillText('现场角度观察 · 未硬件同步',38,15);
 if(v82LiveRows.length<2)return;
 const values=v82LiveRows.flatMap(v=>[v.table,v.imu]).filter(v=>Number.isFinite(v));
 let lo=Math.min(...values),hi=Math.max(...values);let pad=Math.max(.15,(hi-lo)*.2);lo-=pad;hi+=pad;
 const t0=v82LiveRows[0].ts,t1=v82LiveRows[v82LiveRows.length-1].ts,dt=Math.max(1,t1-t0);
 const draw=(key,color)=>{c.strokeStyle=color;c.lineWidth=2;c.beginPath();let open=false;for(const r of v82LiveRows){const value=r[key];if(!Number.isFinite(value)){open=false;continue}const x=38+(r.ts-t0)/dt*(w-52),y=18+(hi-value)/(hi-lo)*(h-35);if(!open){c.moveTo(x,y);open=true}else c.lineTo(x,y)}c.stroke()};
 draw('table','#6b7a86');draw('imu','#0d9488');
 c.fillStyle='#6b7a86';c.fillText('转台',w-142,34);if(r.mode==='realtime'){c.fillStyle='#0d9488';c.fillText('IMU',w-80,34)}
}
async function init(){$('pcb-link-diag').onclick=execute(async()=>{const d=await request('/api/pcb/link-diagnostics');const w=d.watchdog||{};const age=w.fusion_receipt_age_ms;const active=d.pcb_connected&&d.acquisition_running;txt('pcb-link-result',[d.server_alive?'后端服务正常':'后端服务异常',active?'PCB采集运行中':'PCB采集未运行 / 已离线',d.uid?'UID：'+d.uid:'UID尚未读取',age!=null?'最近融合数据接收距今：'+fmt(age,1)+' ms':'最近融合数据：暂无',w.transport_alive===false?'采集进程已退出':w.transport_alive===true?'采集进程运行中':'采集进程：未启动',d.pipeline_error?'链路故障：'+d.pipeline_error:'链路故障：未报告','原始采集记录：'+(d.raw_file||'尚无')].join('\n'));});$('pipeline-apply').onclick=execute(async()=>{const r=await request('/api/pipeline','POST',{mode:$('pipeline-mode').value});updateStatus(r);toast('已应用采集模式')});bindLeverIdentification();bindAlignmentAndNative();bindTableDiagnostics();bind();bindPreparation();bindDynamic();bindAutoTest();requestAnimationFrame(liveChartLoop);setInterval(updateRatePanel,500);setInterval(()=>{if(state.active==='experiments'&&(dynRunning||autoRunning))updateV82Live().catch(()=>{});},300);/* Native dropdowns need no JavaScript bootstrap. */try{state.meta=await request('/api/meta');{const l=state.meta.sway_envelope||{};txt('dyn-sway-envelope','当前软件准入：峰速 '+fmt(l.speed_dps,2)+'°/s，峰值角加速度 '+fmt(l.accel_dps2,2)+'°/s²。依据：'+(l.source||'未提供')+'。这是软件研究准入，不是厂家确认的硬件极限；设备报警、限位、STOP和急停仍需有效。');}if(!String(state.meta.version||'').startsWith('8.3.')){throw Error('后端版本不匹配：当前是 '+(state.meta.version||'未知')+'，必须启动V8.3服务（端口8877）')}buildExperiments();const first=await request('/api/status?history=true');state.params={...DEFAULT,...first.params};state.algo=first.algorithm;buildAlgorithms();fillQuickSelector();buildSliders();updateStatus(first);state.history=first.history||[];$('live-empty').style.display=state.status?.pipeline?.mode==='offline'||!state.history.length?'flex':'none';drawLive();connectWs();setInterval(()=>{if(!state.ws||state.ws.readyState!==1)refreshStatus(true).catch(()=>{});},1500);setInterval(()=>{if(state.active==='experiments')refreshStability().catch(()=>{});},850);setInterval(()=>{if(state.active==='experiments')refreshTableMonitor().catch(()=>{});},450);refreshTableMonitor().catch(()=>{});refreshNativeStatus().catch(()=>{});refreshDynamic().catch(()=>{});refreshPreparation().catch(()=>{});initAutoOptions().catch(()=>{});refreshAutoTest().catch(()=>{});refreshPorts().catch(()=>{});refreshWorkbenchTable().catch(()=>{});refreshTableDiagnostics().catch(()=>{});setInterval(()=>{if(state.active==='experiments'){refreshTableDiagnostics().catch(()=>{});refreshNativeStatus().catch(()=>{});}},1200);setInterval(()=>{refreshDynamic().catch(()=>{});refreshPreparation().catch(()=>{});refreshAutoTest().catch(()=>{})},700);setInterval(()=>{if(state.active==='experiments'&&(prepRunning||dynRunning||autoRunning))refreshWorkbenchTable().catch(()=>{})},1600);setInterval(()=>{if(dynRunning)request('/api/dynamic/heartbeat','POST').catch(()=>{});if(prepRunning&&!autoRunning)request('/api/turntable/prepare/heartbeat','POST').catch(()=>{});if(autoRunning||factoryRunning)request('/api/auto-dynamic/heartbeat','POST').catch(()=>{})},1300);toast('工作台已启动，请在设置中连接RS485设备')}catch(e){toast('无法连接后端，请通过“启动上位机.bat”启动服务：'+e.message,true)}}
init();
})();
