"""Read-only comparison for a complete V7.13/V7.14 DIAG ZIP, no motor control.
Usage: python -m tools.replay_v714 path.zip
Candidate Z=19.51 cm is frozen from earlier PITCH; X/Y unknown -> zero.
Report reference is used only after generating outputs. No phase/gain fitting.
"""
import argparse,csv,io,json,zipfile
from dataclasses import asdict,replace
from app.fusion import Params,create_filter,integrate,q_to_euler
from app.continuity_v713 import advance
from app.static_alignment import align_pose
from app.dynamic_experiment import _analyze_tracking_core

def evaluate(path):
    with zipfile.ZipFile(path) as z:
        report=json.loads(z.read(next(n for n in z.namelist() if n.endswith('_DYNAMIC.json'))))
        def rows(suffix):
            with z.open(next(n for n in z.namelist() if n.endswith(suffix))) as f:
                return list(csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig')))
        imu=rows('_DYNAMIC_imu.csv');table=rows('_DYNAMIC_table.csv')
    if report['uid']!='DTS672516':raise ValueError('历史候选只适用于 DTS672516 研究')
    p=Params(**report['fusion_parameters_used']).validate();p=replace(p,lever3_x_cm=0,lever3_y_cm=0,lever3_z_cm=0)
    cand=replace(p,lever3_z_cm=19.51)
    fs={'adaptive':create_filter('adaptive',p),'adaptive3d':create_filter('adaptive3d',cand)}
    plan=report['plan'];axis=plan['output'];data=[];ready=0
    for i,row in enumerate(imu):
        a=[float(row[f'cal_acc_{j}_g']) for j in 'xyz'];g=[float(row[f'cal_gyro_{j}_dps']) for j in 'xyz']
        dt=float(row['imu_dt_s']) if i else 0.
        out={k:row.get(k) for k in ('host_est_ns','pc_observed_ns','device_t_s','imu_nominal_odr_hz','imu_timestamp_quality','batch_shift_ms','alignment_active')}
        for name,params in [('adaptive',p),('adaptive3d',cand)]:
            fs[name],pose,act=advance(name,fs[name],params,True,a,g,dt)
            if name=='adaptive3d':ready+=bool(pose.get('lever_compensation_ready'))
            if row.get('alignment_active')=='1' and report.get('static_alignment'):pose=align_pose(pose,report['static_alignment'])
            out['cal_'+name+'_'+axis]=pose[axis]
            if name=='adaptive3d':
                # Separate exploratory phase lead, never used by the live algorithm.
                # It uses only received gyro and current pose, not future data.
                out['cal_gyro_'+axis]=q_to_euler(integrate(pose['q'],g,.010))[axis]
        data.append(out)
    r=_analyze_tracking_core(table,data,plan['axis'],axis,plan['sign'],plan['amplitude_deg'],plan['frequency_hz'],report['motion_start_pc_monotonic_ns'],report['motion_end_pc_monotonic_ns'])
    return {'source':path,'uid':report['uid'],'plan':plan,'sample_count':len(imu),'candidate_cm':[0,0,19.51], 'ready_all_capture_pct':100*ready/len(imu), 'comparison':[dict(x,algorithm='adaptive3d_10ms_phase_lead_research' if x['algorithm']=='gyro' else x['algorithm']) for x in r.get('comparison',[])],'reference_quality':r.get('reference_quality'),'certified_dynamic_accuracy':False,'note':'同一真实六轴因果回放；不平移、不缩放；10ms因果前推仅为同次工况探索，未启用实时；参数来自历史PITCH，当前ROLL为研究对照；无硬件同步，非实时实机验收。'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('zip');p.add_argument('--output');args=p.parse_args();r=evaluate(args.zip)
    s=json.dumps(r,ensure_ascii=False,indent=2);print(s)
    if args.output:open(args.output,'w',encoding='utf-8').write(s+'\n')
