"""V7.20 world-frame gravity research, offline only. No hardware access.
Filter input is calibrated six-axis samples and past/current dt only.
Reference is used exclusively in the evaluator, after filtering.
"""
import numpy as np
try:
 from numba import njit
except ImportError:
 def njit(f):return f

@njit
def norm(x):return np.sqrt(np.sum(x*x))
@njit
def mul(a,b):
 w,x,y,z=a;v,p,t,u=b
 return np.array([w*v-x*p-y*t-z*u,w*p+x*v+y*u-z*t,w*t-x*u+y*v+z*p,w*u+x*t-y*p+z*v])
@njit
def tilt(a):
 a=a/norm(a);q=np.array([1+a[2],a[1],-a[0],0.]);return q/norm(q)
@njit
def rotate(q,v):
 u=q[1:];return v+2*np.cross(u,np.cross(u,v)+q[0]*v)
@njit
def replay(a,g,dt,tau,learn):
 q=tilt(a[0]);b=np.zeros(3);lp=g[0].copy();hold=quiet=0.;gs=np.zeros(3);count=0;ready=-1;w1=rotate(q,a[0]/norm(a[0]));w2=w1.copy();last=g[0].copy();out=np.empty((len(dt),2))
 for i in range(len(dt)):
  h=dt[i] if i else 0.;ng=norm(g[i]);na=norm(a[i])
  if 0<h<=.4:
   lp+=(1-np.exp(-h/.07))*(g[i]-lp)
   if norm(lp)>.65 or ng>1.05 or abs(na-1)>.075 or h>.010:hold=.8
   else:hold=max(0.,hold-h)
   rest=hold==0 and norm(lp)<.35 and ng<.8 and .94<na<1.06
   if rest:
    quiet+=h;gs+=g[i];count+=1
    if ready<0 and quiet>=1.5 and count>=100:
     if learn:b=gs/count
     ready=i
   else:quiet=0.;gs[:]=0.;count=0
   v=((g[i]+last)*.5-b)*np.pi/180;angle=norm(v)*h;dq=np.empty(4);dq[0]=np.cos(angle/2);dq[1:]=v*(h*.5 if angle<1e-12 else np.sin(angle/2)/norm(v));q=mul(q,dq);q/=norm(q)
   if h<=.010 and .94<na<1.06:
    w=rotate(q,a[i]/na);c=1-np.exp(-h/(.18 if rest else tau));w1+=c*(w-w1);w2+=c*(w1-w2)
  elif h>.4:hold=.8;quiet=0.;gs[:]=0.;count=0
  z=mul(tilt(w2),q);z/=norm(z);W,X,Y,Z=z;out[i,0]=np.arctan2(2*(W*X+Y*Z),1-2*(X*X+Y*Y))*180/np.pi;out[i,1]=np.arcsin(min(1.,max(-1.,2*(W*Y-Z*X))))*180/np.pi;last=g[i].copy()
 return out,b,ready


def evaluate_files(imu_path, table_path, report_path):
 import csv,json
 from pathlib import Path
 def rows(path):
  with open(path,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
 d=rows(imu_path);t=rows(table_path);p=Path(report_path)
 text=p.read_text(encoding='utf-8-sig')
 r=json.JSONDecoder().raw_decode(text.split('const DATA=',1)[1])[0]['report'] if p.suffix.lower()=='.html' else json.loads(text)
 plan=r['plan'];axis=plan['output'];j=int(axis=='pitch')
 def vector(rs,k):return np.array([float(row[k]) for row in rs],dtype=float)
 a=np.column_stack([vector(d,'cal_acc_'+k+'_g') for k in 'xyz']);g=np.column_stack([vector(d,'cal_gyro_'+k+'_dps') for k in 'xyz']);dt=vector(d,'imu_dt_s')
 if len(a)<100 or not (np.isfinite(a).all() and np.isfinite(g).all() and np.isfinite(dt).all()) or np.any(np.linalg.norm(a,axis=1)<.1):raise ValueError('无效六轴数据')
 if np.any(dt[1:]<=0):raise ValueError('采样间隔无效')
 if any(str(row.get('alignment_active','')).lower() in ('1','true') for row in d):raise ValueError('请使用关闭现场经验对齐的原始数据')
 v,b,i=replay(a,g,dt,2.,True)
 x=vector(d,'host_est_ns')/1e9;tx=vector(t,'pc_mid_ns')/1e9
 if np.any(np.diff(x)<=0) or np.any(np.diff(tx)<=0):raise ValueError('PC时间轴非单调')
 ref=np.unwrap(vector(t,f'axis_{plan["axis"]}_pos')*np.pi/180)*180/np.pi;ref-=360*round(ref[0]/360);ref*=plan['sign']
 rr=np.interp(x,tx,ref);idx=np.clip(np.searchsorted(tx,x),1,len(tx)-1)
 full=(x>=r['motion_start_pc_monotonic_ns']/1e9)&(x<=r['motion_end_pc_monotonic_ns']/1e9)
 m=full&(x>=tx[0])&(x<=tx[-1])&((tx[idx]-tx[idx-1])<=.4)
 if not np.any(m):raise ValueError('无可比较区间')
 e=(v[m,j]-rr[m]+180)%360-180
 return {'algorithm':'world_gravity_double_lp_2s_bias','execution_mode':'offline_causal_research_only','axis':axis,'samples':int(m.sum()),'full_motion_samples':int(full.sum()),'max_abs_deg':float(np.max(abs(e))),'rmse_deg':float(np.sqrt(np.mean(e**2))),'mean_signed_deg':float(np.mean(e)),'stationary_bias_dps':b.tolist(),'bias_ready_index':int(i),'max_gap_ms':float(np.max(dt[1:])*1000),'continuity_qualified':bool(np.max(dt[1:])<=.05),'certified_dynamic_accuracy':False,'note':'PC时间轴未硬件同步；缺口研究结果不能验收；无杆臂，无转台输入，无未来数据，不扣初始零位。'}

if __name__=='__main__':
 import argparse,json
 from pathlib import Path
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('imu');p.add_argument('table');p.add_argument('report');p.add_argument('--output');a=p.parse_args()
 r=evaluate_files(a.imu,a.table,a.report);text=json.dumps(r,ensure_ascii=False,indent=2);print(text)
 if a.output:Path(a.output).write_text(text,encoding='utf-8')
