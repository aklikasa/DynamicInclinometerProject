# -*- coding: utf-8 -*-
"""Read-only TiltLab engineering diagnostics. No COM, table, or settings access."""
import argparse,csv,json,math,datetime,hashlib,zipfile,html,re,sys
from pathlib import Path
import numpy as np
AX='xyz'

def readcols(p, wanted):
    with p.open(encoding='utf-8-sig',newline='') as f:
        r=csv.DictReader(f); fields=set(r.fieldnames or []); keys=[k for k in wanted if k in fields]; data={k:[] for k in keys}
        for row in r:
            if None in row or any(row[k] is None for k in keys): raise ValueError(f'CSV有未写完的行: {p.name}。请使用完整副本。')
            for k in keys:
                v=row[k]; data[k].append(float(v) if v and v.lower() not in ('true','false') else (1. if v.lower()=='true' else 0. if v.lower()=='false' else np.nan))
    return {k:np.asarray(v,dtype=float) for k,v in data.items()}

def vec(d,keys):
    if not all(k in d for k in keys):raise ValueError('缺少列: '+str(keys))
    a=np.column_stack([d[k] for k in keys]);
    if len(a)<2 or not np.isfinite(a).all():raise ValueError('数据不足或含非有限值: '+str(keys))
    return a

def stats(v):
    v=np.asarray(v);v=v[np.isfinite(v)]
    if not len(v):return None
    return dict(n=len(v),mean=float(np.mean(v)),std=float(np.std(v)),min=float(np.min(v)),p50=float(np.median(v)),p95=float(np.percentile(v,95)),p99=float(np.percentile(v,99)),max=float(np.max(v)))

def clock(d,k='host_est_ns'):
    if k not in d or not np.isfinite(d[k]).all() or len(d[k])<2:raise ValueError('时间列不完整 '+k)
    t=d[k]/1e9;dt=np.diff(t)
    if np.any(dt<=0):raise ValueError('时间轴非严格递增；不排序、不修补，请保留原始数据排查')
    return t,dict(samples=len(t),span_s=float(t[-1]-t[0]),average_hz=float((len(t)-1)/(t[-1]-t[0])),step_ms=stats(dt*1000),gaps_gt_10ms=int(sum(dt>.010)),gaps_gt_50ms=int(sum(dt>.050)),gaps_gt_400ms=int(sum(dt>.400)))

def timing(d):
    t,out=clock(d);out['time_source']='host_est_ns: PC接收时刻反推，非真实硬件采样时钟';out['hardware_synchronized']=False
    for k in ['processing_age_ms','sample_age_ms','batch_shift_ms','serial_read_ms','imu_dt_s','fusion_dt_s','reported_odr','imu_nominal_odr_hz']:
        if k in d:out[k]=stats(d[k])
    if 'batch_id' in d:
        first=np.r_[True,np.diff(d['batch_id'])!=0];out['batch_count']=int(sum(first));out['batch_samples']=stats(np.diff(np.r_[np.flatnonzero(first),len(t)]));out['batch_id_gaps']=int(np.sum(np.maximum(0,np.diff(d['batch_id'][first])-1)))
        for k in ('device_tick_delta_s','pc_receipt_delta_s'):
            if k in d:out[k+'_per_batch']=stats(d[k][first])
    if 'seq' in d:out['seq_gaps']=int(np.sum(np.maximum(0,np.diff(d['seq'])-1)));out['seq_nonincreasing']=int(sum(np.diff(d['seq'])<=0))
    if 'pc_observed_ns' in d:
        obs=d['pc_observed_ns'];out['pc_receipt_minus_est_sample_ms']=stats((obs-d['host_est_ns'])/1e6);out['receipt_batch_interval_ms']=stats(np.diff(obs)[np.diff(obs)>0]/1e6)
    return t,out

def poll_stats(p):
    d=readcols(p,['poll_id','request_pc_ns','received_pc_ns','serial_read_ms','previous_idle_ms','accepted_samples','reported_dropped_batches','ipc_delivery_ms','device_tick_ms'])
    o={k:stats(v) for k,v in d.items() if k not in ('request_pc_ns','received_pc_ns','device_tick_ms','poll_id')}
    if 'accepted_samples' in d:o['empty_polls']=int(sum(d['accepted_samples']==0));o['sum_accepted_samples']=int(np.nansum(d['accepted_samples']))
    if 'reported_dropped_batches' in d:
        v=d['reported_dropped_batches'];v=v[np.isfinite(v)];o['dropped_counter_first_last']=[float(v[0]),float(v[-1])] if len(v) else None
    if 'received_pc_ns' in d:o['receipt_interval_ms']=stats(np.diff(d['received_pc_ns'])/1e6)
    if 'poll_id' in d:o['poll_id_gaps']=int(np.nansum(np.maximum(0,np.diff(d['poll_id'])-1)))
    return o

def static(t,a,g,temp,assumed=True):
    # Caller selects a verified stationary segment. No automatic deletion of samples.
    dur=t[-1]-t[0];x=t-t[0];n=np.linalg.norm(a,axis=1);gn=np.linalg.norm(g,axis=1)
    o={'samples':len(t),'duration_s':float(dur),'operator_assumed_stationary':assumed,'absolute_tilt_accuracy_available':False,'gyro_mean_dps':g.mean(axis=0).tolist(),'gyro_std_dps':g.std(axis=0).tolist(),'acc_mean_g':a.mean(axis=0).tolist(),'acc_std_g':a.std(axis=0).tolist(),'acc_norm_g':stats(n),'gyro_norm_dps':stats(gn),'temperature_c':stats(temp),'warnings':[]}
    if np.max(gn)>1 or np.max(abs(n-1))>.075:o['warnings'].append('存在较大角速度/加速度模长异常：不能确认全程静止；原样保留，不作为静止零偏验收')
    if dur<120:o['warnings'].append('静止时长不足120秒，长期稳定性证据不足')
    o['uncompensated_constant_mean_bias_angle_deg']={str(s): (g.mean(axis=0)*s).tolist() for s in (33.333,75,300)}
    rows=[]
    for s in range(int(dur)):
        i,j=np.searchsorted(x,[s,s+1]);
        if j-i<2:continue
        v=g[i:j];u=a[i:j];mn=u.mean(axis=0);mnn=np.linalg.norm(mn)
        rows.append(dict(second=s,samples=j-i,span_s=float(x[j-1]-x[i]),max_dt_ms=float(np.max(np.diff(x[i:j]))*1000),temp_c=float(np.mean(temp[i:j])) if np.isfinite(temp[i:j]).all() else None,**{f'g{k}_mean_dps':float(v[:,q].mean()) for q,k in enumerate(AX)},**{f'g{k}_std_dps':float(v[:,q].std()) for q,k in enumerate(AX)},**{f'a{k}_mean_g':float(mn[q]) for q,k in enumerate(AX)},acc_roll_deg=float(np.degrees(np.arctan2(mn[1],mn[2]))),acc_pitch_deg=float(np.degrees(np.arctan2(-mn[0],np.hypot(mn[1],mn[2])))),acc_norm_g=float(mnn)))
    o['one_second_bins']=len(rows);o['bias_initialization_holdout']=[]
    if len(rows)>=60:
        first=rows[:30];last=rows[-30:];o['first_last_30s_mean_change_dps']=(np.mean([[r[f'g{k}_mean_dps'] for k in AX] for r in last],axis=0)-np.mean([[r[f'g{k}_mean_dps'] for k in AX] for r in first],axis=0)).tolist()
    good=[r for r in rows if r['temp_c'] is not None and r['max_dt_ms']<=10 and r['span_s']>=.95]
    if len(good)>=60 and np.ptp([r['temp_c'] for r in good])>=.5:
        xx=np.array([r['temp_c'] for r in good]);o['descriptive_gyro_temp_slope_dps_per_c']=[float(np.polyfit(xx,[r[f'g{k}_mean_dps'] for r in good],1)[0]) for k in AX]
    o['temperature_note']='芯片温度；温差不足0.5°C不拟合；单姿态相关性不等于温漂因果。'
    for init in (1,3,10,30,60):
        m=x<init
        if m.sum()<2 or dur<init+33.333:continue
        b=g[m].mean(axis=0);e=[];spans=[]
        # Use only subsequent non-overlapping intervals. Estimated drift proxy, not Euler-angle error.
        for start in np.arange(init,dur-33.333,33.333):
            sel=(x>=start)&(x<=start+33.333);tt=x[sel];gg=g[sel]
            if len(tt)<2 or tt[-1]-tt[0]<33.30 or np.max(np.diff(tt))>.010:continue
            e.append(np.sum((gg[:-1]+gg[1:]-2*b)*.5*np.diff(tt)[:,None],axis=0));spans.append(float(tt[-1]-tt[0]))
        o['bias_initialization_holdout'].append(dict(initial_seconds=init,estimated_bias_dps=b.tolist(),subsequent_33s_windows=len(e),max_abs_integrated_rate_residual_deg=np.max(abs(np.array(e)),axis=0).tolist() if e else None,window_span_s=stats(spans)))
    # Allan-like nonoverlapping block means from complete contiguous 1s bins, not a certified Allan test.
    o['allan_approx_dps']=[];rowmap={r['second']:r for r in rows};fs=(len(t)-1)/dur
    for tau in (1,2,5,10,20,30,60,100):
        blocks=[]
        for start in range(0,int(dur)-tau+1,tau):
            q=[rowmap.get(k) for k in range(start,start+tau)]
            if any(r is None or r['samples']<.85*fs or r['max_dt_ms']>10 or r['span_s']<.95 for r in q):blocks.append(None);continue
            blocks.append(np.mean([[r[f'g{k}_mean_dps'] for k in AX] for r in q],axis=0))
        dif=[b-a for a,b in zip(blocks,blocks[1:]) if a is not None and b is not None]
        if len(dif)>=3:o['allan_approx_dps'].append(dict(tau_s=tau,pairs=len(dif),deviation=np.sqrt(np.mean(np.array(dif)**2,axis=0)/2).tolist()))
    o['allan_note']='基于完整1秒均值的非重叠近似 Allan deviation，非硬件等间隔采样认证；无效块不跨越连接。'
    return o,rows

def reports(p):
    s=p.read_text(encoding='utf-8-sig');r=json.JSONDecoder().raw_decode(s.split('const DATA=',1)[1])[0]['report'] if p.suffix.lower()=='.html' else json.loads(s)
    if 'tests' in r:return [v['report'] for v in r['tests']]
    return [r]

def dynamic(p,r,table):
    plan=r['plan'];direction=plan['output'];sgn=plan['sign'];axis=plan['axis'];
    if direction not in ('roll','pitch') or sgn not in (-1,1):raise ValueError('报告轴/符号无效')
    ac=[f'cal_acc_{k}_g' for k in AX];gy=[f'cal_gyro_{k}_dps' for k in AX];algs=['gyro_anchor','accel'];cols=[f'cal_{k}_{direction}' for k in algs];bias=[f'gyro_anchor_gyro_bias_{k}_dps' for k in AX]
    d=readcols(p,['seq','host_est_ns','pc_observed_ns','temp_c','alignment_active','processing_age_ms','sample_age_ms','batch_shift_ms','serial_read_ms','imu_dt_s','fusion_dt_s','reported_odr','imu_nominal_odr_hz','batch_id','batch_index','gyro_anchor_bias_ready','gyro_anchor_motion_detected','gyro_anchor_trust',*ac,*gy,*cols,*bias]); t,tm=timing(d);a=vec(d,ac);g=vec(d,gy)
    if 'alignment_active' not in d or np.any(d['alignment_active']!=0):raise ValueError('静态经验对齐开启或不明，不适用无对齐诊断')
    q=readcols(table,['pc_mid_ns',f'axis_{axis}_pos',f'axis_{axis}_speed','read_ms','position_read_ms','poll_lag_ms']);tt,qt=clock(q,'pc_mid_ns');enc=vec(q,[f'axis_{axis}_pos'])[:,0];enc=np.rad2deg(np.unwrap(np.deg2rad(enc)));enc=(enc-360*round(enc[0]/360))*sgn
    start=r['motion_start_pc_monotonic_ns']/1e9;end=r['motion_end_pc_monotonic_ns']/1e9;motion=(t>=start)&(t<=end);pre=(t>=start-2.5)&(t<start-.1)
    j=np.clip(np.searchsorted(tt,t,side='right'),1,len(tt)-1);ok=(t>=tt[0])&(t<=tt[-1])&((tt[j]-tt[j-1])<=.4);ok|=(t==tt[j])|(t==tt[j-1]);ref=np.interp(t,tt,enc);m=motion&ok
    if m.sum()<2:raise ValueError('无参考覆盖')
    o=dict(kind='dynamic',file=p.name,table=table.name,axis=direction,reference_sign=sgn,plan=plan,timing=tm,table_timing=qt,motion_samples=int(motion.sum()),comparable_samples=int(m.sum()),excluded_reference=int(sum(motion&~ok)),certified=False,note='使用host_est_ns直接对比；不平移、不扣零位、不跨>400ms参考缺口；不是硬件同步验收，也不保证与旧报告恢复时间轴完全一致。',temperature_c=stats(d['temp_c'][motion]),acc_norm_g=stats(np.linalg.norm(a[motion],axis=1)),gyro_norm_dps=stats(np.linalg.norm(g[motion],axis=1)),metrics={})
    if pre.sum()>2:
        o['pre_motion_bias_proxy_dps']=g[pre].mean(axis=0).tolist();o['pre_motion_gyro_std_dps']=g[pre].std(axis=0).tolist();o['pre_motion_duration_s']=float(t[pre][-1]-t[pre][0]);o['pre_motion_note']='运动前2.5秒窗口，需确认静止；不是独立零偏标定'
    if all(k in d for k in bias):o['online_bias_dps']={k:stats(d[k][motion]) for k in bias}
    if 'gyro_anchor_motion_detected' in d:o['motion_flag_fraction']=stats(d['gyro_anchor_motion_detected'][motion])
    if 'gyro_anchor_trust' in d:o['gravity_trust']=stats(d['gyro_anchor_trust'][motion])
    qt['poll_lag_ms']=stats(q.get('poll_lag_ms',[]));qt['position_read_ms']=stats(q.get('position_read_ms',[]));qt['read_ms']=stats(q.get('read_ms',[]))
    # Reference interpolation sensitivity, not a claim of true reference error.
    v=2*math.pi*plan['amplitude_deg']*plan['frequency_hz'];o['ideal_sine_time_budget_ms_0p05deg']=.05/v*1000;o['ideal_sine_time_budget_ms_0p01deg']=.01/v*1000
    o['ideal_sine_interp_bound_deg_at_max_gap']=((2*math.pi*plan['frequency_hz'])**2*plan['amplitude_deg'])*(qt['step_ms']['max']/1000)**2/8
    rows=[]
    for alg,col in zip(algs,cols):
        if col not in d:continue
        u=m&np.isfinite(d[col]);idx=np.flatnonzero(u)
        if len(idx)<2:continue
        e=(d[col][u]-ref[u]+180)%360-180;ae=abs(e);worst=idx[np.argmax(ae)];over=ae>.05;sp=np.split(np.arange(len(idx)),np.flatnonzero((np.diff(idx)!=1)|(np.diff(t[idx])>.010))+1);runs=[]
        for seg in sp:
            oo=seg[over[seg]]
            for run in np.split(oo,np.flatnonzero(np.diff(oo)!=1)+1):
                if len(run):runs.append(t[idx[run[-1]]]-t[idx[run[0]]])
        at=(tt>=start)&(tt<=end)&(tt>=t[0])&(tt<=t[-1]);k=np.clip(np.searchsorted(t,tt),1,len(t)-1);at&=(t[k]-t[k-1]<=.010)
        val=np.interp(tt[at],t,d[col]);ee=(val-enc[at]+180)%360-180;ee=ee[np.isfinite(ee)]
        o['metrics'][alg]=dict(samples=len(idx),excluded_output=int(m.sum()-len(idx)),max_abs_deg=float(ae.max()),rmse_deg=float(np.sqrt(np.mean(e**2))),p95_deg=float(np.percentile(ae,95)),signed_mean_deg=float(e.mean()),over_0p05_count=int(sum(over)),over_0p05_pct=float(100*np.mean(over)),longest_contiguous_over_s=float(max(runs,default=0)),peak_time_s=float(t[worst]-start),at_actual_table_samples_count=len(ee),at_actual_table_samples_max_deg=float(max(abs(ee))) if len(ee) else None)
        for c in range(int(plan['cycles'])):
            w=(t[idx]-start>=c/plan['frequency_hz'])&(t[idx]-start<(c+1)/plan['frequency_hz']);
            if w.any():rows.append(dict(algorithm=alg,cycle=c+1,samples=int(sum(w)),max_abs_deg=float(ae[w].max()),over_0p05_pct=float(100*np.mean(over[w]))))
    return o,rows

def writecsv(p,rows):
    if rows:
        with p.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--mode',choices=['static','dynamic']);ap.add_argument('--input',type=Path);ap.add_argument('--report',type=Path);ap.add_argument('--cal-dir',type=Path);ap.add_argument('--static-start',type=float);ap.add_argument('--confirm-static',action='store_true');ap.add_argument('--static-end',type=float);ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'results');args=ap.parse_args()
    def ask(msg):return input(msg).strip().strip('"')
    if not args.mode:args.mode={'1':'static','2':'dynamic'}.get(ask('1=静止零偏诊断；2=动态与时间诊断：'))
    if args.mode not in ('static','dynamic'):raise ValueError('模式无效')
    if not args.input:args.input=Path(ask('输入文件完整路径（可拖入文件；动态模式输入CSV所在文件夹）：'))
    out=args.output/(datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_'+args.mode);out.mkdir(parents=True)
    result={'version':'1.0','mode':args.mode,'read_only':True,'reports':[]}
    if args.mode=='static':
        p=args.input
        if not p.is_file():raise ValueError('静止模式选择 RAW_LINK CSV 文件，不是目录')
        d=readcols(p,['host_est_ns','pc_observed_ns','batch_shift_ms','batch_id','batch_index','device_tick_delta_s','pc_receipt_delta_s','serial_read_ms','reported_odr','temp','temp_c','ax','ay','az','gx','gy','gz',*[f'cal_acc_{k}_g' for k in AX],*[f'cal_gyro_{k}_dps' for k in AX],*[f'acc_cal_g_{k}' for k in AX],*[f'gyro_cal_dps_{k}' for k in AX]])
        t,tm=timing(d);a=g=None;calnote=''
        if all(f'cal_acc_{k}_g' in d for k in AX):a=vec(d,[f'cal_acc_{k}_g' for k in AX]);g=vec(d,[f'cal_gyro_{k}_dps' for k in AX]);calnote='CSV已标定列，须确认无现场对齐'
        elif all(f'acc_cal_g_{k}' in d for k in AX):a=vec(d,[f'acc_cal_g_{k}' for k in AX]);g=vec(d,[f'gyro_cal_dps_{k}' for k in AX]);calnote='静止诊断CSV已标定列'
        else:
            a=vec(d,['ax','ay','az']);g=vec(d,['gx','gy','gz']);calnote='原始传感器坐标，未标定'
            if args.cal_dir is None and sys.stdin.isatty():
                v=ask('输入采集时对应的ACC/GYRO标定快照目录（回车仅分析原始坐标）：');args.cal_dir=Path(v) if v else None
            if args.cal_dir:
                from r10_calibration import scan
                sn=re.search(r'DTS\d{6}',p.name,re.I)
                if not sn:raise ValueError('RAW_LINK文件名不含设备编号；拒绝自动匹配标定')
                c=scan(args.cal_dir,sn.group().upper(),mode='ambient')
                if c['status']!='matched':raise ValueError(c['detail'])
                a=(a-np.array(c['acc'].bias))@np.array(c['acc'].matrix).T;g=(g-np.array(c['gyro'].bias))@np.array(c['gyro'].matrix).T;calnote='使用显式指定快照常温矩阵；仅按文件名SN匹配，非实时UID验证'
                result['calibration_files']=[{'name':Path(f).name,'sha256':hashlib.sha256(Path(f).read_bytes()).hexdigest()} for f in c['files']]
        if args.static_start is None:
            args.static_start=float(ask('静止区间起始秒（从CSV第一点起算，回车0）：') or '0') if sys.stdin.isatty() else 0.
        if args.static_end is None and sys.stdin.isatty():
            v=ask('静止区间结束秒（回车至文件结束）：');args.static_end=float(v) if v else None
        sel=(t-t[0]>=args.static_start)&(t-t[0]<=(args.static_end if args.static_end is not None else t[-1]-t[0]+.01));temp=d.get('temp',d.get('temp_c',np.full(len(t),np.nan)))
        if sel.sum()<2:raise ValueError('静止区间无数据')
        if not args.confirm_static and (not sys.stdin.isatty() or ask('确认选定时间段从头到尾由现场人员保证静止，输入 YES：').upper()!='YES'):raise ValueError('未确认静止；命令行非交互模式须明确 --confirm-static')
        o,rows=static(t[sel],a[sel],g[sel],temp[sel]);o.update(file=p.name,calibration=calnote,timing_full_file=tm,selected_start_s=args.static_start,selected_end_s=args.static_end);poll=p.with_name(p.stem+'_polls.csv');
        if poll.is_file():o['polls']=poll_stats(poll)
        result['reports'].append(o);writecsv(out/'static_1s.csv',rows)
    else:
        folder=args.input if args.input.is_dir() else args.input.parent
        if not args.report:args.report=Path(ask('输入对应动态或双轴联合 HTML/JSON报告完整路径：'))
        for r in reports(args.report):
            p=folder/Path(r['raw_file_imu']).name;table=folder/Path(r['raw_file_table']).name
            if not p.is_file() or not table.is_file():raise ValueError('找不到匹配CSV：'+str(p)+' / '+str(table))
            print('分析:',p.name,flush=True);o,rows=dynamic(p,r,table);result['reports'].append(o);writecsv(out/(o['axis']+'_cycles.csv'),rows)
    s=json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False);(out/'summary.json').write_text(s,encoding='utf-8')
    # Compact local HTML with selected results and full expandable diagnostics.
    cards=[]
    for r in result['reports']:
        if args.mode=='dynamic':
            body=''.join(f'<tr><td>{html.escape(k)}</td><td>{v["max_abs_deg"]:.6f}°</td><td>{v["over_0p05_pct"]:.2f}%</td><td>{v["rmse_deg"]:.6f}°</td></tr>' for k,v in r['metrics'].items());info=f'<p>IMU {r["timing"]["average_hz"]:.2f} Hz · 转台 {r["table_timing"]["average_hz"]:.2f} Hz · 最大反馈间隔 {r["table_timing"]["step_ms"]["max"]:.2f} ms · 无参考覆盖 {r["excluded_reference"]} 点</p><table><tr><th>实时算法</th><th>最大绝对误差</th><th>超0.05°比例</th><th>RMSE</th></tr>{body}</table>'
        else:
            info=f'<p>记录 {r["duration_s"]:.1f} 秒 · {html.escape(r["calibration"])}</p><table><tr><th>轴</th><th>静止角速度均值 °/s</th><th>标准差 °/s</th></tr>'+''.join(f'<tr><td>{k.upper()}</td><td>{r["gyro_mean_dps"][i]:.7f}</td><td>{r["gyro_std_dps"][i]:.7f}</td></tr>' for i,k in enumerate(AX))+'</table>'
        cards.append('<section><h2>'+html.escape(r.get('axis','静止零偏').upper())+'</h2>'+info+'<details><summary>完整诊断数据</summary><pre>'+html.escape(json.dumps(r,ensure_ascii=False,indent=2))+'</pre></details></section>')
    (out/'report.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>TiltLab 研发诊断</title><style>body{font:15px/1.65 "Microsoft YaHei",sans-serif;max-width:1000px;margin:40px auto;padding:0 20px;background:#f2f6f6;color:#173c40}section{background:white;border:1px solid #ccdcdc;border-radius:12px;padding:20px;margin:20px 0}table{border-collapse:collapse;width:100%}td,th{text-align:left;padding:12px;border-bottom:1px solid #dce6e6}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}summary{cursor:pointer;margin-top:20px}h1{font-size:30px}</style><h1>TiltLab · 六轴研发诊断</h1><p>只读诊断 · 非同步绝对精度验收 · 不修改原数据、标定或运动设置</p>'+''.join(cards)+'</html>',encoding='utf-8')
    z=out.with_suffix('.zip');
    with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as f:
        for p in out.iterdir():f.write(p,p.name)
    print('完成：',z,'\n请保留原始CSV，发送诊断ZIP及必要的原始记录。',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as exc:print('诊断未完成:',exc,file=sys.stderr);raise
