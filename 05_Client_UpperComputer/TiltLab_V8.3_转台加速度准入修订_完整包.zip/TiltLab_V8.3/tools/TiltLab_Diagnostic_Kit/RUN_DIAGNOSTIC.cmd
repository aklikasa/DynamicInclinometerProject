@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if exist "..\.venv\Scripts\python.exe" (
 "..\.venv\Scripts\python.exe" -u diagnose.py %*
 goto END
)
if exist ".venv\Scripts\python.exe" (
 ".venv\Scripts\python.exe" -u diagnose.py %*
 goto END
)
where py >nul 2>&1
if not errorlevel 1 (
 py -3 -u diagnose.py %*
 goto END
)
python -u diagnose.py %*
:END
if errorlevel 1 echo Diagnostic failed. Keep the console output for troubleshooting.
pause
endlocal
