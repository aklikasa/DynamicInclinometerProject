"""Read-only, six-axis VQF research replay (no physical table import).

Reads a TiltLab *_DYNAMIC_imu.csv. Creates NEW derived CSV+JSON in output
folder. Values and fit do not use encoder angles to alter the filter. Shows
IMU-only amplitude/offset, not certified reference RMSE.
"""
from __future__ import annotations
import argparse,csv,json,math,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.fusion import Params, create_filter, FILTERS


def _num(row,key):
    try:
        x=float(row[key]); return x if math.isfinite(x) else None
    except (KeyError,ValueError,TypeError):return None


def _fit(times,values,f):
    if len(times)<80:return None
    t=np.asarray(times);y=np.asarray(values)
    X=np.column_stack([np.sin(2*np.pi*f*t),np.cos(2*np.pi*f*t),np.ones(len(t))])
    coef=np.linalg.lstsq(X,y,rcond=None)[0]
    return {'amplitude_deg':round(float(np.hypot(coef[0],coef[1])),6),
            'dc_offset_deg':round(float(coef[2]),6),'n':len(t)}


def replay(csvfile,output=None,channel='pitch',frequency=.3,start_s=12.,end_s=None,odr=833.,tau=3.,lever_cm=0.):
    csvfile=Path(csvfile).resolve()
    if not csvfile.is_file():raise FileNotFoundError(csvfile)
    if channel not in ('roll','pitch'):raise ValueError('channel should be roll/pitch')
    if 'vqf6d' not in FILTERS:raise RuntimeError('未安装官方 vqf。请先运行 安装依赖.bat，或 pip install vqf。')
    params=Params(vqf_nominal_hz=float(odr),vqf_tau_acc_s=float(tau),lever_z_cm=float(lever_cm)).validate()
    engines={k:create_filter(k,params,calibrated=True) for k in ('vqf6d','vqf_lever')}
    output=Path(output).resolve() if output else csvfile.with_name(csvfile.stem+'_V79_VQF_REPLAY.csv')
    if output==csvfile:raise ValueError('拒绝覆盖原始 CSV')
    output.parent.mkdir(parents=True,exist_ok=True)
    fields=['device_t_s','elapsed_s','v_qf_roll_deg','v_qf_pitch_deg','lever_roll_deg','lever_pitch_deg',
            'vqf_rest','bias_x_dps','bias_y_dps','bias_z_dps','gap_count','model_prediction_only_steps','missing_coverage_s',
            'old_accel_deg','old_adaptive_deg','old_gyro_deg','old_gyro_anchor_deg']
    times={k:[] for k in ('vqf6d','vqf_lever','accel','adaptive','gyro','gyro_anchor')}
    vals={k:[] for k in times}
    count=invalid=0;last_t=first_t=None;last_out=None
    with csvfile.open('r',newline='',encoding='utf-8-sig') as src,output.open('w',newline='',encoding='utf-8-sig') as dest:
        reader=csv.DictReader(src)
        req=['device_t_s']+[f'cal_{typ}_{axis}_{unit}' for typ,unit in (('acc','g'),('gyro','dps')) for axis in 'xyz']
        if not set(req)<=set(reader.fieldnames or []):raise ValueError('缺少标定六轴数据列：'+str(set(req)-set(reader.fieldnames or [])))
        writer=csv.DictWriter(dest,fieldnames=fields);writer.writeheader()
        for row in reader:
            count+=1;t=_num(row,'device_t_s')
            a=[_num(row,f'cal_acc_{axis}_g') for axis in 'xyz']
            g=[_num(row,f'cal_gyro_{axis}_dps') for axis in 'xyz']
            if t is None or None in a or None in g or (last_t is not None and t<=last_t):
                invalid+=1;continue
            if first_t is None:first_t=t
            dt=0. if last_t is None else t-last_t;last_t=t
            u=engines['vqf6d'].update(a,g,dt);v=engines['vqf_lever'].update(a,g,dt);last_out=u
            elapsed=t-first_t
            old={key:_num(row,f'cal_{key}_{channel}') for key in ('accel','adaptive','gyro','gyro_anchor')}
            result={'device_t_s':t,'elapsed_s':elapsed,
                    'v_qf_roll_deg':u['roll'],'v_qf_pitch_deg':u['pitch'],
                    'lever_roll_deg':v['roll'],'lever_pitch_deg':v['pitch'],
                    'vqf_rest':int(u['stationary_detected']),
                    **{f'bias_{ax}_dps':u['gyro_bias_dps'][j] for j,ax in enumerate('xyz')},
                    'gap_count':u['imu_gaps_over_threshold'],
                    'model_prediction_only_steps':u['model_prediction_only_steps'],
                    'missing_coverage_s':u['missing_coverage_s'],
                    **{f'old_{key}_deg':val if val is not None else '' for key,val in old.items()}}
            writer.writerow(result)
            if elapsed>=start_s and (end_s is None or elapsed<=end_s):
                for name,value in [('vqf6d',u[channel]),('vqf_lever',v[channel]),*old.items()]:
                    if value is not None:
                        times[name].append(elapsed);vals[name].append(value)
    if last_out is None:
        output.unlink(missing_ok=True)
        raise ValueError('有效六轴数据为0，不能产生有意义的VQF回放')
    info={'kind':'V79_OFFLINE_VQF_REPLAY','research_only':True,'source_csv':csvfile.name,
          'output_csv':output.name,'channel':channel,'frequency_hz':frequency,
          'start_s':start_s,'end_s':end_s,'nominal_odr_hz':odr,'vqf_tau_acc_s':tau,
          'measured_lever_z_cm':lever_cm,'not_connected_to_turntable':True,
          'used_encoder_to_correct_filter':False,'samples_read':count,'invalid_samples':invalid,
          'quality':'IMU_BATCH_GAPS_AND_UNSYNCHRONIZED_TABLE; NOT ACCURACY CERTIFICATION',
          'diagnostics':{k:last_out.get(k) for k in ('imu_gaps_over_threshold','max_gap_s','missing_coverage_s','model_prediction_only_steps','unmodelled_gap_s','gyro_bias_dps') if last_out},
          'amplitudes':{name:_fit(times[name],vals[name],float(frequency)) for name in times},
          'warning':'幅值只针对IMU通道正弦分量；没有转台时间同步或正式RMSE。预测步不是新增IMU采样；不可替代固件连续FIFO。'}
    summary=output.with_suffix('.json');summary.write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
    return output,summary,info


def main():
    ap=argparse.ArgumentParser(description='V7.9 官方 VQF 只读六轴 CSV 回放')
    ap.add_argument('csv',help='TiltLab原始 *_DYNAMIC_imu.csv')
    ap.add_argument('--channel',choices=('roll','pitch'),default='pitch')
    ap.add_argument('--frequency',type=float,default=.3)
    ap.add_argument('--start-s',type=float,default=12.)
    ap.add_argument('--end-s',type=float,default=None)
    ap.add_argument('--odr',type=float,default=833.)
    ap.add_argument('--tau',type=float,default=3.)
    ap.add_argument('--lever-cm',type=float,default=0.)
    ap.add_argument('--output')
    args=ap.parse_args()
    try:
        a,b,c=replay(args.csv,args.output,args.channel,args.frequency,args.start_s,args.end_s,args.odr,args.tau,args.lever_cm)
        print('研究性 VQF 回放完成（无硬件命令）:')
        print('新CSV:',a,'\n摘要:',b)
        print('仅 IMU 基波幅值（非产品精度）：',json.dumps(c['amplitudes'],ensure_ascii=False))
    except Exception as e:
        print('VQF 离线重放失败：',type(e).__name__,str(e));return 1
    return 0

if __name__=='__main__':raise SystemExit(main())
