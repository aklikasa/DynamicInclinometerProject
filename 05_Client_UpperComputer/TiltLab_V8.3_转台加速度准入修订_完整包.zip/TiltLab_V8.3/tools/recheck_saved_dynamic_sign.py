"""Re-check completed TiltLab dynamic report coordinate polarity OFFLINE.

No device imports, no hardware commands, no edits to any input. Produces a NEW
*_SIGN_RECHECK.json + HTML alongside source; reference sign is checked using
calibrated ACC tilt and calibrated gyro rate, not picked by best-fit RMSE.
"""
import argparse
import csv
import datetime as dt
import json
import sys
from copy import deepcopy
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.dynamic_reference_polarity import infer_dynamic_reference_polarity
from app.dynamic_experiment import recover_imu_timebase, analyze_tracking
from app.html_report import write_interactive_report


def load_csv(folder, relative):
    if not isinstance(relative,str) or not relative or Path(relative).name != relative or not relative.lower().endswith('.csv'):
        raise ValueError('报告引用的CSV路径不安全或无效：'+repr(relative))
    p=folder/relative
    with p.open('r',encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))


def rebuild_stage(stage,folder):
    s=deepcopy(stage)
    r=s.get('report',s)
    plan=r.get('plan') or {}
    if not (r.get('stopped_verified') is True and r.get('motion_capture_state')=='completed'):
        raise ValueError('没有停车确认且完整采集的原始记录；拒绝生成可用的方向重算结果')
    table=load_csv(folder,r.get('raw_file_table'))
    replay_name=(r.get('offline_replay') or {}).get('file')
    src=replay_name if replay_name and (folder/Path(replay_name).name).is_file() else r.get('raw_file_imu')
    imu=load_csv(folder,src)
    axis=plan['axis'];out=plan['output'];requested=plan['sign']
    polarity=infer_dynamic_reference_polarity(table,imu,axis,out,requested,
        r.get('motion_start_pc_monotonic_ns'),r.get('motion_end_pc_monotonic_ns'),recover_imu_timebase)
    r['dynamic_reference_polarity']=polarity
    r['reference_sign_requested']=requested
    r['reference_sign_used']=polarity['selected_sign'] if polarity['valid'] else requested
    r['reference_sign_source']='verified_dynamic_accel_and_gyro' if polarity['valid'] else 'unverified_operator_input'
    r['report_rebuilt_from_existing_csv']=True
    r['certified_dynamic_accuracy']=False
    if polarity['valid']:
        plan['sign']=polarity['selected_sign']
        analysis=analyze_tracking(table,imu,axis,out,plan['sign'],plan['amplitude_deg'],plan['frequency_hz'],
            r['motion_start_pc_monotonic_ns'],r['motion_end_pc_monotonic_ns'])
        analysis['dynamic_reference_polarity']=polarity
        analysis['capture_mode']=r.get('capture_mode')
        analysis['offline_replay']=r.get('offline_replay')
        analysis['certified_dynamic_accuracy']=False
        r['analysis']=analysis
    else:
        r.setdefault('analysis',{})['dynamic_reference_polarity']=polarity
        r['analysis']['quality_warning']=(r['analysis'].get('quality_warning') or '')+'；离线重算未能独立核验符号；保留原报告分析结果，不可作为精度验收。'
    return s,polarity


def main(path):
    source=Path(path).resolve()
    if not source.is_file() or source.suffix.lower()!='.json':
        raise ValueError('请提供已完成动态实验报告的 .json 文件路径')
    data=json.loads(source.read_text(encoding='utf-8'))
    if data.get('kind')=='REAL_2TD600_XY_SEQUENTIAL':
        stages=[];summaries=[]
        for stage in data.get('tests',[]):
            x,pol=rebuild_stage(stage,source.parent);stages.append(x);summaries.append(pol)
        if not stages:raise ValueError('联合报告不包含分项结果')
        data['tests']=stages
        data['dynamic_reference_polarity_rechecks']=summaries
    elif data.get('kind')=='REAL_2TD600_SINE_DIAGNOSTIC':
        data,pol=rebuild_stage(data,source.parent)
    else:
        raise ValueError('仅支持单轴 DYNAMIC.json 或双轴 XY_DYNAMIC_COMBINED.json')
    data['recheck_source_report']=source.name
    data['recheck_created_at']=dt.datetime.now().astimezone().isoformat()
    data['recheck_note']='仅对既有记录重算比较参考方向；原数据与旧报告未修改；未硬件同步，研究用途。'
    out=source.with_name(source.stem+'_SIGN_RECHECK.json')
    if source==out:raise ValueError('不可覆盖输入文件')
    out.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    html=write_interactive_report(out)
    print('[OK] 新报告：',out)
    print('[OK] 新曲线：',html)
    if data.get('kind')=='REAL_2TD600_XY_SEQUENTIAL':
        for pol in data['dynamic_reference_polarity_rechecks']:
            print(pol['output'].upper(),pol['reason'], '已验证='+str(pol['valid']),
                '比较符号='+str(pol['selected_sign']))
    else:
        print(pol['output'].upper(),pol['reason'], '已验证='+str(pol['valid']),
              '比较符号='+str(pol['selected_sign']))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='只读重算历史转台参考方向（不操控硬件，不覆盖原报告）')
    parser.add_argument('report_json',help='DYNAMIC.json 或 XY_DYNAMIC_COMBINED.json')
    args=parser.parse_args()
    try:main(args.report_json)
    except (ValueError,OSError,KeyError,TypeError,RuntimeError) as exc:
        print('[ERROR] '+str(exc),file=sys.stderr)
        sys.exit(1)
