"""Read-only V8.3 analysis of an archived single-axis or XY dynamic report.

Uses recorded encoder feedback only, does not import the hardware adapter,
launch the service, open a port or issue any motor command.  Does not change
original CSV, JSON, motion parameters or calibration data.
"""
from __future__ import annotations
import csv
import json
import sys
from pathlib import Path

# Works from arbitrary working directories when launched as a standalone script.
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.angles import unwrap_encoder_deg
from app.steady_state import find_sway_steady_start


def summarize(report:Path):
    report=report.resolve()
    payload=json.loads(report.read_text(encoding='utf-8-sig'))
    if payload.get('kind')=='REAL_2TD600_XY_SEQUENTIAL':
        stages=[(i.get('direction',f'axis{n}'),i.get('report',{})) for n,i in enumerate(payload.get('tests',[]),1)]
    else:
        stages=[(payload.get('plan',{}).get('output','axis'),payload)]
    output={'source_report':str(report),'method':'encoder_measured_sine_complete_cycles_v830',
            'hardware_synchronized':False,'stages':[]}
    for direction,r in stages:
        plan=r.get('plan') or {}
        refname=Path(str(r.get('raw_file_table','')).replace('\\','/')).name
        if not refname:raise ValueError(f'{direction}: 报告中没有 raw_file_table 文件名')
        source=report.parent/refname
        if not source.is_file():raise FileNotFoundError(f'{direction}: 找不到转台原始反馈文件 {source}')
        with source.open('r',encoding='utf-8-sig',newline='') as file:
            rows=list(csv.DictReader(file))
        axis=int(plan.get('reference_axis',plan.get('axis',2)))
        times=[float(row['pc_mid_ns'])/1e9 for row in rows]
        positions=unwrap_encoder_deg([float(row[f'axis_{axis}_pos']) for row in rows])
        start=float(r['motion_start_pc_monotonic_ns'])/1e9
        end=float(r['motion_end_pc_monotonic_ns'])/1e9
        steady=find_sway_steady_start(times,positions,start,end,
              float(plan['frequency_hz']),float(plan['amplitude_deg']))
        stem=source.stem
        out_csv=report.parent/(stem+'_V83_PHASE_LABELS.csv')
        a=steady.get('steady_start_s');b=steady.get('steady_end_s')
        with out_csv.open('w',encoding='utf-8-sig',newline='') as file:
            w=csv.writer(file)
            w.writerow(['pc_elapsed_from_motion_start_s','encoder_angle_deg','classification','note'])
            for t,pos in zip(times,positions):
                if t<start or t>end:kind='outside_sway_command'
                elif not steady['valid']:kind='unverified'
                elif t<a:kind='startup_or_initial_validation'
                elif t<=b:kind='qualified_steady_sine'
                else:kind='trailing_unverified'
                w.writerow([round(t-start,6),round(float(pos),7),kind,'转台反馈分段，不是IMU误差/厂家加速度证明'])
        output['stages'].append({'direction':direction,'raw_table_file':str(source),
             'phase_labels_csv':str(out_csv), 'steady':steady,
             'motion_start_pc_monotonic_ns':r['motion_start_pc_monotonic_ns'],
             'motion_end_pc_monotonic_ns':r['motion_end_pc_monotonic_ns'],
             'note':'只有完整实测正弦周期可进入稳态比较；原报告及原始CSV未改动。'
         })
    new=report.with_name(report.stem+'_V83_STEADY_REVIEW.json')
    if new==report:raise ValueError('输出不能覆盖输入报告')
    new.write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    return new


if __name__=='__main__':
    if len(sys.argv)!=2:
        print('用法: .venv\\Scripts\\python.exe tools\\review_sine_intervals.py "完整的_DYNAMIC.json路径"')
        raise SystemExit(2)
    try:
        dest=summarize(Path(sys.argv[1]))
        print('只读稳态检查完成：',dest)
    except (OSError,ValueError,KeyError,IndexError) as exc:
        print('无法检查历史报告：',exc)
        raise SystemExit(1)
