# -*- coding: utf-8 -*-
"""TiltLab V8.1 pip installer / offline audit. Never opens COM or controls equipment."""
import argparse
import importlib
import importlib.metadata
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
# pip bundles packaging in all supported CPython installers; no extra bootstrapping needed.
try:
    from pip._vendor.packaging.requirements import Requirement
except ImportError:
    from packaging.requirements import Requirement

MODULES = {
    'fastapi': 'fastapi', 'uvicorn': 'uvicorn', 'websockets': 'websockets',
    'pydantic': 'pydantic', 'python-multipart': 'multipart',
    'pyserial': 'serial', 'numpy': 'numpy',
    'PySide6': 'PySide6.QtWidgets', 'openpyxl': 'openpyxl',
    'xlsxwriter': 'xlsxwriter', 'python-snap7': 'snap7.type',
    'setuptools': 'pkg_resources',
    'pytest': 'pytest', 'vqf': 'vqf',
}
REQUIREMENT_FILES = {
    'core': ('requirements-core.txt',),
    'r10': ('requirements-core.txt', 'requirements-r10.txt'),
    'plc': ('requirements-core.txt', 'requirements-r10.txt', 'requirements-plc.txt'),
    'research': ('requirements-core.txt', 'requirements-research.txt'),
    'full': ('requirements-core.txt', 'requirements-r10.txt', 'requirements-plc.txt', 'requirements-research.txt'),
}


def requirements(mode):
    requirements_by_name = {}
    for filename in REQUIREMENT_FILES[mode]:
        for line in (ROOT / filename).read_text(encoding='utf-8-sig').splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            req = Requirement(line)
            if req.marker and not req.marker.evaluate():
                continue
            requirements_by_name[req.name.lower()] = req
    return list(requirements_by_name.values())


def package_status(req):
    try:
        installed = importlib.metadata.version(req.name)
    except importlib.metadata.PackageNotFoundError:
        return False, 'not installed'
    if not req.specifier.contains(installed, prereleases=True):
        return False, f'{installed} does not match {req.specifier}'
    module = MODULES.get(req.name, req.name.replace('-', '_'))
    try:
        importlib.import_module(module)
        if req.name == 'python-snap7':
            from snap7.type import Areas  # noqa: F401
        if req.name == 'vqf':
            from vqf import VQF  # noqa: F401
    except Exception as exc:
        return False, f'{installed} installed but import {module} failed: {exc}'
    return True, installed


def audit(mode, output=print):
    missing = []
    for req in requirements(mode):
        ok, result = package_status(req)
        output(f"[{'OK' if ok else 'MISSING'}] {req.name} {req.specifier}: {result}")
        if not ok:
            missing.append(req)
    return missing


def main(args=None):
    parser = argparse.ArgumentParser(description='No-hardware Python dependency audit/install')
    parser.add_argument('--mode', choices=REQUIREMENT_FILES, default='core')
    parser.add_argument('--check', action='store_true', help='no network / no installation')
    parser.add_argument('--mirror', action='store_true', help='explicitly choose Tsinghua PyPI mirror')
    parser.add_argument('--timeout', type=int, default=25)
    parser.add_argument('--retries', type=int, default=1)
    parser.add_argument('--log', default=str(ROOT/'install_logs'/'install_v81.txt'))
    options = parser.parse_args(args)
    if not 5 <= options.timeout <= 120 or not 0 <= options.retries <= 3:
        parser.error('timeout: 5..120, retries: 0..3')
    if sys.version_info[:2] < (3, 10) or sys.version_info[:2] > (3, 13) or sys.maxsize <= 2**32:
        print('[FAILED] Requires 64-bit Python 3.10, 3.11, 3.12 or 3.13.')
        return 2
    log_path = Path(options.log)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    # Keep human readable log even when download fails; no sensitive env vars included.
    with log_path.open('a', encoding='utf-8') as log:
        def say(line):
            print(line, flush=True)
            log.write(line+'\n')
            log.flush()
        say('\n=== TiltLab V8.1 dependency audit ===')
        say(f'[INFO] Python: {sys.executable}; mode={options.mode}; check_only={options.check}')
        say('[INFO] Index: ' + ('user-selected Tsinghua mirror' if options.mirror else 'pip configured default'))
        missing = audit(options.mode, say)
        if not missing:
            say('[READY] All required dependencies already installed; no pip/network access needed.')
            return 0
        if options.check:
            say('[ACTION] Run INSTALL_DEPENDENCIES.bat for PCB workstation, or INSTALL_R10_CALIBRATION.bat for R10.')
            return 1
        # One pip invocation and only missing/incompatible packages. Existing env is left intact.
        cmd = [sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check',
               '--prefer-binary', '--only-binary=:all:', '--timeout', str(options.timeout),
               '--retries', str(options.retries)]
        if options.mirror:
            cmd += ['-i', 'https://pypi.tuna.tsinghua.edu.cn/simple']
        cmd += [str(req) for req in missing]
        say('[INSTALL] Only missing/incompatible packages; one attempt (no outer retry loops).')
        say(f'[INFO] Timeout={options.timeout}s, retries={options.retries}; Ctrl+C cancels safely.')
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        # Avoid buffering the entire pip output; display exact failures immediately.
        try:
            with subprocess.Popen(cmd, cwd=str(ROOT), stdout=subprocess.PIPE,
                                  stderr=subprocess.STDOUT, text=True, encoding='utf-8',
                                  errors='replace', env=env, bufsize=1) as proc:
                for line in proc.stdout:
                    say('  '+line.rstrip('\r\n'))
                rc = proc.wait()
        except (KeyboardInterrupt, OSError) as exc:
            say('[CANCELLED/FAILED] '+repr(exc))
            return 130 if isinstance(exc, KeyboardInterrupt) else 2
        if rc:
            say('[FAILED] pip exited with code '+str(rc))
            say('[ACTION] If network timed out, run INSTALL_DEPENDENCIES_MIRROR.bat or retry when the network is stable.')
            return rc
        say('[VERIFY] Checking imports and version requirements again ...')
        missing = audit(options.mode, say)
        if missing:
            say('[FAILED] Installation finished but some imports are unavailable. See the errors above.')
            return 3
        say('[SUCCESS] Dependency setup complete; NO hardware was accessed.')
        return 0

if __name__ == '__main__':
    sys.exit(main())
