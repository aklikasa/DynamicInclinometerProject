#!/usr/bin/env python3
# coding: utf-8
"""Operator-present 2TD600+R10 diagnostic front end for TiltLab V7.24.1.

This program NEVER accesses COM, vendor DLL, or issues raw motor commands.
Only calls the tested localhost TiltLab API which enforces position/velocity,
6-second heartbeat, watchdog, STOP verification and FIFO lossless logging.
No hardware time synchronization is claimed. Requires independent hardware E-stop.
"""
import json,queue,subprocess,sys,threading,time,urllib.error,urllib.request
from datetime import datetime
from pathlib import Path

URL='http://127.0.0.1:8877'
REQUIRED_VERSION='7.24.1'
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'data'/'timebase_diagnostic'

class APIError(RuntimeError):pass

class LocalAPI:
    def __init__(self,base=URL,timeout=2):
        if base!=URL:raise ValueError('拒绝连接非本机既定端口')
        self.base=base;self.timeout=timeout
    def call(self,path,payload=None,timeout=None):
        if not path.startswith('/api/') or any(x in path for x in ('?','..','//')):
            raise APIError('拒绝未知API路径')
        url=self.base+path
        req=urllib.request.Request(url,method='POST' if payload is not None else 'GET',
            data=json.dumps(payload,ensure_ascii=False).encode('utf-8') if payload is not None else None,
            headers={'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req,timeout=timeout or self.timeout) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            try:msg=json.loads(e.read().decode('utf-8')).get('detail','')
            except Exception:msg=''
            raise APIError(f'HTTP {e.code} {path}: {msg}') from e
        except Exception as e:raise APIError(f'服务不可达 {path}: {e}') from e
    def version(self):
        meta=self.call('/api/meta')
        if meta.get('version')!=REQUIRED_VERSION:
            raise APIError('发现上位机版本'+str(meta.get('version'))+'，必须使用本包V7.24.1，不允许连旧版')
        return meta

class SafetySupervisor:
    """Separate heartbeat from GUI thread; fail-closed after repeated request errors.
    The original application's watchdog is the primary software guard.
    """
    def __init__(self,api,events=None,interval=1.0):
        self.api=api;self.events=events if events is not None else queue.Queue()
        self.interval=interval;self.kind=None;self.stopped=threading.Event();self.thread=None
        self._lock=threading.Lock();self.last_state={}
        self.log_path=None;self.failed=False;self.start_wall=None;self.stop_unverified=False
    def emit(self,level,message):
        self.events.put((level,message))
    def start(self,kind):
        if kind not in ('auto','prepare'):raise ValueError('未知运动任务')
        with self._lock:
            if self.thread and self.thread.is_alive():raise RuntimeError('监护线程仍在运行')
            self.kind=kind;self.stopped.clear();self.failed=False;self.start_wall=time.time();self.stop_unverified=True
            OUT.mkdir(parents=True,exist_ok=True)
            self.log_path=OUT/('联动安全诊断_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.jsonl')
            self.thread=threading.Thread(target=self._loop,name='diagnostic-heartbeat',daemon=True)
            self.thread.start()
        self.emit('info','监护已启动；必须有人在转台现场，急停独立可用')
    def _log(self,event,data):
        record={'time_local':datetime.now().astimezone().isoformat(),
                'observer_monotonic_ns':time.monotonic_ns(),'event':event,'payload':data}
        with self.log_path.open('a',encoding='utf-8') as fp:
            fp.write(json.dumps(record,ensure_ascii=False,default=str)+'\n')
    def _after_finished(self,state):
        # Analyze only a successfully verified stopped automatic run; failure
        # states keep the original CSV and demand operator investigation.
        if self.kind!='auto':return
        if state.get('stopped_verified') is not True:
            self.emit('warn','停车未确认：仅保留原始文件，不自动生成结论');return
        try:
            from diagnose import run
            _,text_report,results=run(ROOT/'data'/'reports',OUT,since=self.start_wall-3)
            self.emit('info','自动诊断报告：'+str(text_report))
            self.emit('info','分析了 '+str(len(results))+' 组同次采集数据；属于研究诊断，不是精度合格证')
        except Exception as exc:
            self.emit('warn','运动已停止；自动分析未完成，可用下方按钮手动选择原始CSV：'+str(exc))

    def _safe_stop(self):
        self.emit('alarm','连接/心跳持续异常，正在申请STOP；现场立即准备使用实体急停')
        try:
            self.api.call('/api/auto-dynamic/abort' if self.kind=='auto' else '/api/turntable/prepare/abort',{},timeout=3)
        except Exception as exc:self.emit('alarm','中止请求失败: '+str(exc))
        try:
            result=self.api.call('/api/turntable/stop',{},timeout=27)
            self._log('watchdog_stop',result)
            if result.get('stopped_verified') is True:
                self.stop_unverified=False;self.emit('info','双轴停车反馈已确认')
            else:self.emit('alarm','STOP未确认！现场使用实体急停')
        except Exception as exc:self.emit('alarm','软件STOP未确认！使用实体急停！ '+str(exc))
    def _loop(self):
        fail=0;number=0
        prefix='/api/auto-dynamic/' if self.kind=='auto' else '/api/turntable/prepare/'
        while not self.stopped.is_set():
            began=time.monotonic()
            try:
                # Heartbeat first, before potentially heavy status serialization.
                try:
                    self.api.call(prefix+'heartbeat',{},timeout=2)
                except APIError:
                    # A finished/aborted task legitimately rejects a late heartbeat.
                    state=self.api.call(prefix+'status',timeout=2)
                    if not state.get('running'):
                        self._log('finished',state);self.stop_unverified=(state.get('stopped_verified') is not True);self.emit('finished',state);self._after_finished(state);break
                    raise
                state=self.api.call(prefix+'status',timeout=2)
                self.last_state=state;fail=0
                number+=1
                if number%3==0:
                    try:
                        try:imu=self.api.call('/api/timebase/health',timeout=2)
                        except APIError as error:
                            if 'HTTP 404' not in str(error):raise
                            imu=self.api.call('/api/status',timeout=3)
                        wd=(imu.get('pipeline') or {}).get('watchdog') or {}
                        compact={'auto':state,'imu':{'sample_rate_hz':imu.get('sample_rate_hz'),
                              'cal_status':imu.get('cal_status'),'algorithm':imu.get('algorithm'),
                              'watchdog':wd,'pipeline':{k:v for k,v in (imu.get('pipeline') or {}).items()
                                  if k in ('max_processing_age_ms','raw_written_samples','acquired_samples','peak_queued_batches')}}}
                        self._log('health',compact)
                    except Exception as exc:
                        self._log('health_probe_error',str(exc))
                self.emit('status',state)
                if not state.get('running'):
                    self._log('finished',state);self.stop_unverified=(state.get('stopped_verified') is not True);self.emit('finished',state);self._after_finished(state);break
            except Exception as exc:
                fail+=1;self.emit('warn',f'监护通信失败{fail}次：{exc}')
                self._log('heartbeat_error',str(exc))
                if fail>=2:
                    self.failed=True;self._safe_stop();break
            self.stopped.wait(max(.05,self.interval-(time.monotonic()-began)))
        self.stopped.set()
        self.emit('supervisor_end',self.last_state)
    def disengage(self):
        self.stopped.set()


def run_offline(input_path,out_dir=OUT):
    script=Path(__file__).with_name('diagnose.py')
    result=subprocess.run([sys.executable,str(script),str(input_path),'--out',str(out_dir)],
                          capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=240)
    if result.returncode:raise RuntimeError(result.stderr or result.stdout)
    return result.stdout


def launch_gui():
    import tkinter as tk
    from tkinter import messagebox,filedialog,ttk
    app=tk.Tk();app.title('TiltLab 同次采集·自动归因诊断 V1（实验用途）');app.geometry('865x730')
    q=queue.Queue();api=LocalAPI();sup=SafetySupervisor(api,q)
    top=ttk.Frame(app,padding=10);top.pack(fill='both',expand=True)
    def row():
        r=ttk.Frame(top);r.pack(fill='x',pady=5);return r
    ttk.Label(top,text='2TD-600 + ASM330LHH：通信/时间轴/算法归因（仅研究，不是计量合格证书）',font=('Microsoft YaHei UI',12,'bold')).pack(anchor='w')
    ttk.Label(top,text='本工具调用127.0.0.1:8877原软件接口，不接管串口，不修改500ms保护。现场必须有独立实体急停。',foreground='#9b381d').pack(anchor='w')
    r=row();ttk.Label(r,text='IMU串口').pack(side='left');im_port=tk.StringVar(value='');ttk.Entry(r,textvariable=im_port,width=10).pack(side='left',padx=4)
    ttk.Label(r,text='波特率').pack(side='left');im_baud=tk.StringVar(value='1500000');ttk.Entry(r,textvariable=im_baud,width=11).pack(side='left',padx=4)
    ttk.Label(r,text='从站').pack(side='left');address=tk.StringVar(value='1');ttk.Entry(r,textvariable=address,width=5).pack(side='left',padx=4)
    ttk.Label(r,text='转台COM编号').pack(side='left');table_port=tk.StringVar(value='');ttk.Entry(r,textvariable=table_port,width=6).pack(side='left',padx=4)
    ack1=tk.BooleanVar(value=False);ack2=tk.BooleanVar(value=False);ack3=tk.BooleanVar(value=False)
    ttk.Checkbutton(top,text='我在设备现场，实体急停已验证有效，转台运动区域无人员和障碍物',variable=ack1).pack(anchor='w')
    ttk.Checkbutton(top,text='负载和线缆固定可靠，断使能后有独立机械支撑',variable=ack2).pack(anchor='w')
    ttk.Checkbutton(top,text='如采用PITCH/联合测试，我已确认内轴从0°到90°全路径无遮挡且不会缠线',variable=ack3).pack(anchor='w')
    ttk.Separator(top).pack(fill='x',pady=8)
    def safe_ack(for_pitch=False):
        if not(ack1.get() and ack2.get() and (not for_pitch or ack3.get())):
            raise ValueError('请在现场逐项确认安全，PITCH需额外确认0°→90°完整运动路径')
        if not messagebox.askyesno('最后确认','将控制真实转台，可能立即使能或运动。\n已确认机械路径/急停/现场监护？'):
            raise ValueError('操作员取消')
    def submit(fn):
        def worker():
            try:q.put(('done',fn()))
            except Exception as exc:q.put(('error',str(exc)))
        threading.Thread(target=worker,name='diag-operation',daemon=True).start()
    def chk():
        api.version()
        imu=api.call('/api/status');table=api.call('/api/turntable/status')
        wd=(imu.get('pipeline') or {}).get('watchdog') or {}
        return f'IMU连接={imu.get("connected")} 标定={imu.get("cal_status")} 实时率={imu.get("sample_rate_hz")}Hz；转台连接={table.get("connected")}；融合队列年龄={wd.get("fusion_receipt_age_ms")}ms；故障={wd.get("pipeline_error") or "无"}'
    def conn_imu():
        api.version()
        if api.call('/api/status').get('connected'):return 'IMU已有连接，未中断原采集。'+chk()
        return api.call('/api/start',{'source':'serial','port':im_port.get().strip().upper(),
                         'baudrate':int(im_baud.get()),'address':int(address.get())})
    def conn_table():
        api.version()
        if api.call('/api/turntable/status').get('connected'):return '转台已经连接，未重复使能。'+chk()
        return api.call('/api/turntable/connect',{'port':int(table_port.get()),'baudrate':115200,
                           'operator_confirmed':True,'load_secured':True},timeout=45)
    def prepare():
        api.version()
        pre=api.call('/api/turntable/prepare/preflight',{})
        q.put(('info','回零预检路径: '+json.dumps(pre.get('movement_plan'),ensure_ascii=False)))
        started=api.call('/api/turntable/prepare/start',{'token':pre['token'],'acknowledged':True,'zero_speed_dps':2.0},timeout=4)
        sup.start('prepare');return started
    mode=tk.StringVar(value='both')
    r=row();ttk.Label(r,text='测试模式').pack(side='left')
    for title,val in [('仅ROLL','roll'),('仅PITCH','pitch'),('ROLL+PITCH','both')]:
        ttk.Radiobutton(r,text=title,variable=mode,value=val).pack(side='left',padx=10)
    ttk.Label(top,text='固定研究工况：摆幅 ±5°，频率 0.300Hz，10周期；全程使用转台真实编码器反馈。').pack(anchor='w')
    r=row();roll_sign=tk.StringVar(value='+1');pitch_sign=tk.StringVar(value='-1')
    ttk.Label(r,text='ROLL输出方向').pack(side='left')
    ttk.Combobox(r,textvariable=roll_sign,values=['+1','-1'],state='readonly',width=4).pack(side='left',padx=5)
    ttk.Label(r,text='PITCH输出方向').pack(side='left')
    ttk.Combobox(r,textvariable=pitch_sign,values=['+1','-1'],state='readonly',width=4).pack(side='left',padx=5)
    ttk.Label(r,text='PITCH默认-1仅依据先前装夹记录，当前工装必须重新核实').pack(side='left')
    def auto():
        api.version()
        s=api.call('/api/status')
        if not s.get('connected') or s.get('cal_status')!='matched' or (s.get('pipeline') or {}).get('mode')!='realtime':
            raise ValueError('IMU未连接、校准未匹配或非实时模式；禁止运动')
        md=mode.get()
        p={'axis':2,'output':md,'sign':int(roll_sign.get()),'pitch_sign':int(pitch_sign.get()),
           'amplitude_deg':5.0,'frequency_hz':.3,'cycles':10,
           'zero_speed_dps':2.0,'acknowledged':True,
           'mounting_mode':{'roll':'x_outer','pitch':'y_inner_90','both':'xy_sequential'}[md],
           'fixture_confirmed':md!='roll',
           'static_before_dynamic':True,'static_limit_deg':.1,'auto_static_align':False,'pre_sway_axis_check':True,
           'research_diagnostics':False,'pre_research':False,'research_optimize':False,
           'static_stop_on_fail':True,'static_position_speed_dps':2.0}
        started=api.call('/api/auto-dynamic/start',p,timeout=6)
        sup.start('auto');return started
    def stop():
        for path in ('/api/auto-dynamic/abort','/api/turntable/prepare/abort'):
            try:api.call(path,{},timeout=4)
            except Exception:pass
        done=api.call('/api/turntable/stop',{},timeout=30)
        sup.disengage()
        if done.get('stopped_verified') is True:sup.stop_unverified=False
        if done.get('stopped_verified') is not True:raise RuntimeError('停车未确认，请使用实体急停，不要断使能/拔串口！')
        return 'STOP已下发且双轴停车反馈已确认；保留伺服保持力，未断使能。'
    r=row()
    ttk.Button(r,text='1  检查状态',command=lambda:submit(chk)).pack(side='left',padx=3)
    ttk.Button(r,text='2  连接IMU',command=lambda:submit(conn_imu)).pack(side='left',padx=3)
    def authorize(fn,for_pitch=False):
        try:safe_ack(for_pitch)
        except Exception as e:messagebox.showwarning('安全确认',str(e));return
        submit(fn)
    ttk.Button(r,text='3  连接转台(会使能)',command=lambda:authorize(conn_table)).pack(side='left',padx=3)
    ttk.Button(r,text='4  安全回零',command=lambda:authorize(prepare)).pack(side='left',padx=3)
    r=row()
    ttk.Button(r,text='5  启动自动诊断（真实运动）',command=lambda:authorize(auto,mode.get()!='roll')).pack(side='left',padx=3)
    ttk.Button(r,text='立即请求双轴STOP',command=lambda:submit(stop)).pack(side='left',padx=12)
    ttk.Separator(top).pack(fill='x',pady=8)
    selection=tk.StringVar(value='')
    r=row();ttk.Entry(r,textvariable=selection,width=66).pack(side='left')
    def selectfile():
        x=filedialog.askopenfilename(title='选择原始动态ZIP或 *_DYNAMIC_imu.csv',filetypes=[('ZIP或CSV','*.zip *.csv'),('所有文件','*.*')])
        if x:selection.set(x)
    ttk.Button(r,text='选择已有ZIP/CSV',command=selectfile).pack(side='left',padx=4)
    def analyze():
        if sup.thread and sup.thread.is_alive():raise RuntimeError('运动任务中禁止离线计算，以免抢占融合处理时间')
        path=Path(selection.get());
        if not path.is_file():raise ValueError('请先选择真实存在的ZIP或动态IMU CSV')
        return run_offline(path)
    ttk.Button(top,text='6  只读生成“无融合/纯陀螺/多算法”相位对照报告',command=lambda:submit(analyze)).pack(anchor='w')
    ttk.Label(top,text='实验结束后，也可以选择 data/reports 内生成的*_imu.csv；如有同前缀offline_replay.csv将优先使用。').pack(anchor='w')
    ttk.Label(top,text='原始报告在 data/reports；本工具诊断日志和分析报告在 data/timebase_diagnostic；不修改原数据。').pack(anchor='w')
    log=tk.Text(top,height=18,wrap='word');log.pack(fill='both',expand=True,pady=7)
    def append(x):
        log.insert('end',datetime.now().strftime('%H:%M:%S')+' '+str(x)+'\n');log.see('end')
    def drain():
        while True:
            try:kind,value=q.get_nowait()
            except queue.Empty:break
            if kind=='status':append('状态 '+str(value.get('state'))+' / '+str(value.get('current_stage') or ''))
            elif kind in ('done','info'):
                append(value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,default=str)[:1200])
            elif kind=='finished':
                append('任务结束：'+str(value.get('state'))+'；STOP验证：'+str(value.get('stopped_verified')))
            elif kind in ('error','alarm'):
                append('警告：'+str(value));messagebox.showerror('诊断/安全问题',str(value))
            elif kind!='supervisor_end':append(kind+'：'+str(value))
        app.after(250,drain)
    def close():
        if sup.thread and sup.thread.is_alive():
            messagebox.showwarning('运动中不可关闭','心跳监护正在运行。先按“立即请求双轴STOP”并确认停车后再退出。')
            return
        if sup.stop_unverified:
            messagebox.showwarning('停车状态未知','程序未收到双轴停车确认。请按STOP；若上位机不响应，现场操作独立实体急停，确认机械完全停止。')
            return
        app.destroy()
    app.protocol('WM_DELETE_WINDOW',close)
    append('请先启动本包 START_TILT_LAB.bat，使用 127.0.0.1:8877；切勿启动另一份旧上位机')
    append('注意：本诊断工具不具备硬件级安全功能；软件崩溃时需要现场实体急停。')
    drain();app.mainloop()

if __name__=='__main__':
    try:launch_gui()
    except Exception as exc:
        print('启动失败: '+repr(exc));raise
