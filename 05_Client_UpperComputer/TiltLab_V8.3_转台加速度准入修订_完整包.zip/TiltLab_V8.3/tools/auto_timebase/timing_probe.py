#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TiltLab read-only timing attribution, Python standard library only.
No serial, no DLL, no turntable commands, no curve shifting, no data overwrites.
Outputs phase estimates for investigation only, NOT calibrated accuracy.
"""
import argparse
import csv
import io
import json
import math
import statistics as st
import sys
import time
import zipfile
from collections import defaultdict
from datetime import datetime
from pathlib import Path

FIELDS_IMU = ('seq','host_est_ns','pc_observed_ns','request_pc_ns','device_t_s',
  'batch_id','batch_index','poll_id','reported_odr','imu_nominal_odr_hz',
  'batch_shift_ms','serial_read_ms','processing_age_ms','sample_age_ms',
  'cal_gyro_x_dps','cal_gyro_y_dps','cal_gyro_anchor_roll','cal_gyro_anchor_pitch',
  'cal_accel_roll','cal_accel_pitch','imu_timestamp_quality')
FIELDS_TABLE = ('pc_mid_ns','axis_0_pos','axis_2_pos','read_ms',
  'position_read_ms','feedback_interval_ms','poll_lag_ms')


def num(value):
    try:
        z=float(value)
        return z if math.isfinite(z) else math.nan
    except (ValueError,TypeError):return math.nan


def values(reader, keys):
    found=set(reader.fieldnames or ())
    if not set(keys).issubset(found):
        missing=[x for x in keys if x not in found]
        raise ValueError('CSV缺少必要列: '+', '.join(missing))
    out={k:[] for k in keys}
    for row in reader:
        for k in keys:
            out[k].append(row.get(k,'') if k=='imu_timestamp_quality' else num(row.get(k)))
    return out


def percentiles(x):
    a=sorted(v for v in x if isinstance(v,(int,float)) and math.isfinite(v))
    if not a:return None
    def p(q):
        ix=(len(a)-1)*q;lo=int(ix);hi=min(lo+1,len(a)-1)
        return a[lo]*(hi-ix)+a[hi]*(ix-lo)
    return dict(count=len(a),median=round(p(.5),3),p95=round(p(.95),3),
                p99=round(p(.99),3),max=round(a[-1],3))


def solve_3(m,b):
    a=[list(m[i])+[b[i]] for i in range(3)]
    for j in range(3):
        p=max(range(j,3),key=lambda i:abs(a[i][j]))
        if abs(a[p][j])<1e-9:return None
        a[j],a[p]=a[p],a[j]
        v=a[j][j]
        for k in range(j,4):a[j][k]/=v
        for i in range(3):
            if i==j:continue
            v=a[i][j]
            for k in range(j,4):a[i][k]-=v*a[j][k]
    return [a[i][3] for i in range(3)]


def harmonic(t,y,origin,f,low,high):
    """Least squares a*sin(wt)+b*cos(wt)+c on a *fixed* window."""
    w=2*math.pi*f; n=0
    s=[0.]*3; m=[[0.]*3 for _ in range(3)];rhs=[0.]*3
    for tx,yy in zip(t,y):
        if not math.isfinite(tx) or not math.isfinite(yy) or not low<=tx<=high:continue
        phi=w*(tx-origin);v=(math.sin(phi),math.cos(phi),1.)
        n+=1
        for i in range(3):
            rhs[i]+=v[i]*yy
            for j in range(3):m[i][j]+=v[i]*v[j]
    if n<100:return None
    coeff=solve_3(m,rhs)
    if coeff is None:return None
    a,b,c=coeff
    return {'amplitude':math.hypot(a,b),'phase':math.atan2(b,a),'offset':c,'samples':n}


def angle_deg(z):return (z+180)%360-180

def modulo_polarity(phase):
    """Signal polarity may invert roll/pitch. Restrict phase to +/-90 deg.
    This is a *diagnostic* equivalence, not a sign correction to output.
    """
    return (phase+math.pi/2)%math.pi-math.pi/2


def lag_ms(source_phase, target_phase, freq):
    return 1000*modulo_polarity(source_phase-target_phase)/(2*math.pi*freq)


def frequency_from_crossings(t,position,low,high):
    crossings=[]
    for i in range(1,len(t)):
        if not (low<=t[i-1]<=t[i]<=high):continue
        a,b=position[i-1],position[i]
        if a<0<=b and b>a and b-a<3:
            crossings.append(t[i-1]+(-a)/(b-a)*(t[i]-t[i-1]))
    periods=[b-a for a,b in zip(crossings,crossings[1:]) if 1.5<=b-a<=8]
    return (1/st.median(periods) if len(periods)>=3 else None,len(crossings),periods)


def pairs_for(path):
    path=Path(path)
    if path.is_dir():
        for imu in sorted(path.glob('*_DYNAMIC_imu.csv')):
            table=imu.with_name(imu.name.replace('_imu.csv','_table.csv'))
            if table.exists():
                with imu.open('r',encoding='utf-8-sig',newline='') as a, table.open('r',encoding='utf-8-sig',newline='') as b:
                    yield imu.name,values(csv.DictReader(a),FIELDS_IMU),values(csv.DictReader(b),FIELDS_TABLE)
    elif path.suffix.lower()=='.zip':
        with zipfile.ZipFile(path) as z:
            names=set(z.namelist())
            for imu in sorted(n for n in names if n.endswith('_DYNAMIC_imu.csv')):
                table=imu[:-8]+'_table.csv'
                if table not in names:continue
                with z.open(imu) as aa, z.open(table) as bb:
                    a=io.TextIOWrapper(aa,encoding='utf-8-sig',newline='')
                    b=io.TextIOWrapper(bb,encoding='utf-8-sig',newline='')
                    yield Path(imu).name,values(csv.DictReader(a),FIELDS_IMU),values(csv.DictReader(b),FIELDS_TABLE)
    elif path.name.endswith('_DYNAMIC_imu.csv'):
        table=path.with_name(path.name.replace('_imu.csv','_table.csv'))
        if not table.exists():raise ValueError('缺少配对转台文件 '+str(table))
        with path.open('r',encoding='utf-8-sig',newline='') as a, table.open('r',encoding='utf-8-sig',newline='') as b:
            yield path.name,values(csv.DictReader(a),FIELDS_IMU),values(csv.DictReader(b),FIELDS_TABLE)
    else:raise ValueError('请传入原始IMU ZIP、包含CSV的文件夹或动态_imu.csv')


def analyze_pair(name,d,q):
    it=[v/1e9 for v in d['host_est_ns']]
    tt=[v/1e9 for v in q['pc_mid_ns']]
    if len(it)<300 or len(tt)<100:raise ValueError('数据不足')
    origin=tt[0]
    y=[angle_deg(x) for x in q['axis_2_pos']]
    axis0=st.median(v for v in q['axis_0_pos'] if math.isfinite(v))
    axis='roll' if abs(angle_deg(axis0))<10 else 'pitch' if abs(angle_deg(axis0-90))<10 else 'unknown'
    # Fixed geometric selection (independent of fit residual), excludes startup and end.
    span=tt[-1]-tt[0];low=tt[0]+span*.30;high=tt[0]+span*.90
    f,zc,periods=frequency_from_crossings(tt,y,low,high)
    if not f:f=.3
    reference=harmonic(tt,y,origin,f,low,high)
    angle_key='cal_gyro_anchor_'+axis;gyro_key='cal_gyro_'+('x' if axis=='roll' else 'y')+'_dps'
    accel_key='cal_accel_'+axis
    fits={c:harmonic(it,d[c],origin,f,low,high) for c in (angle_key,gyro_key,accel_key) if c in d}
    phase={}
    if reference and all(fits.get(x) for x in (angle_key,gyro_key,accel_key)):
        r=reference['phase'];g=fits[gyro_key]['phase'];a=fits[angle_key]['phase'];ac=fits[accel_key]['phase']
        phase={'table_vs_gyro_rate_ms':round(lag_ms(r+math.pi/2,g,f),3),
               'table_vs_gyro_anchor_angle_ms':round(lag_ms(r,a,f),3),
               'table_vs_accel_angle_ms':round(lag_ms(r,ac,f),3),
               'gyro_anchor_extra_vs_gyro_ms':round(lag_ms(g-math.pi/2,a,f),3),
               'reference_amp_deg':round(reference['amplitude'],5),
               'gyro_anchor_amp_deg':round(fits[angle_key]['amplitude'],5),
               'gyro_rate_amp_dps':round(fits[gyro_key]['amplitude'],5),
               'accel_angle_amp_deg':round(fits[accel_key]['amplitude'],5)}
        half=(low+high)/2
        phase['split_windows']=[]
        for a0,b0 in ((low,half),(half,high)):
            rr=harmonic(tt,y,origin,f,a0,b0)
            gg=harmonic(it,d[gyro_key],origin,f,a0,b0)
            aa=harmonic(it,d[angle_key],origin,f,a0,b0)
            if rr and gg and aa:
                phase['split_windows'].append({'seconds_from_reference_start':[round(a0-origin,3),round(b0-origin,3)],
                    'gyro_vs_table_ms':round(lag_ms(rr['phase']+math.pi/2,gg['phase'],f),3),
                    'anchor_vs_table_ms':round(lag_ms(rr['phase'],aa['phase'],f),3),
                    'anchor_extra_vs_gyro_ms':round(lag_ms(gg['phase']-math.pi/2,aa['phase'],f),3)})
    per_poll={}
    for i,pid in enumerate(d['poll_id']):
        if not math.isfinite(pid):continue
        if pid not in per_poll:per_poll[pid]=i
    ids=list(per_poll.values())
    serial=[d['serial_read_ms'][i] for i in ids]
    req_after=[(d['pc_observed_ns'][i]-d['request_pc_ns'][i])/1e6 for i in ids]
    seq=d['seq'];bad_seq=sum(1 for a,b in zip(seq,seq[1:]) if b-a!=1)
    host_gap=[(b-a)/1e6 for a,b in zip(d['host_est_ns'],d['host_est_ns'][1:])]
    host_step_bad=sum(1 for g in host_gap if g<=0)
    device_gap=[(b-a)*1000 for a,b in zip(d['device_t_s'],d['device_t_s'][1:])]
    repair=[d['batch_shift_ms'][i] for i in ids]
    old_reported=sorted(set(int(z) for z in d['reported_odr'] if math.isfinite(z)))
    used_odr=sorted(set(int(z) for z in d['imu_nominal_odr_hz'] if math.isfinite(z)))
    table_intervals=[(b-a)*1000 for a,b in zip(tt,tt[1:])]
    # Linear interpolation error bound for a pure +/-5 degree sine. It is an
    # upper bound, not measured error, and assumes a perfect sinusoid.
    m2=5*(2*math.pi*f)**2
    max_gap_s=max(table_intervals)/1000
    gap_limit_ms=math.sqrt(8*.05/m2)*1000
    return {
      'file':name,'direction_inferred_from_axis0':axis,'direction_not_in_csv_plan':True,
      'estimated_frequency_hz_from_encoder':round(f,6),'rising_zero_crossings':zc,
      'stable_window_s_from_first_feedback':[round(low-origin,3),round(high-origin,3)],
      'phase_diagnostic_only_NOT_hardware_lag':phase,
      'imu':{'rows':len(it),'duration_s':round(it[-1]-it[0],3),
             'observed_rows_per_second':round((len(it)-1)/(it[-1]-it[0]),2),
             'polls_with_nonempty_batch':len(per_poll),'nonsequential_app_seq_steps':bad_seq,
             'host_est_nonpositive_steps':host_step_bad,
             'host_est_gap_ms':percentiles(host_gap),'mcu_interpolated_gap_ms':percentiles(device_gap),
             'serial_read_ms_per_poll':percentiles(serial),
             'request_to_receipt_ms_per_poll':percentiles(req_after),
             'batch_repair_ms_per_poll':percentiles(repair),
             'firmware_reported_odr_raw_values':old_reported,
             'software_nominal_odr_hz':used_odr,
             'timestamp_quality_values':sorted(set(d['imu_timestamp_quality']))},
      'table':{'rows':len(tt),'duration_s':round(span,3),
               'pc_mid_interval_ms':percentiles(table_intervals),
               'reference_interval_over_0p05deg_bound_count':sum(x>gap_limit_ms for x in table_intervals),
               'reference_max_gap_sine_interp_bound_deg':round(m2*max_gap_s**2/8,5),
               'reference_gap_limit_ms_for_0p05deg_bound':round(gap_limit_ms,3),
               'read_ms':percentiles(q['read_ms']),
               'position_read_ms':percentiles(q['position_read_ms']),
               'poll_lag_ms':percentiles(q['poll_lag_ms'])},
      'interpretation':[
         '表观相位来自两套PC时间轴与信号处理的叠加，不能单独归因STM32；未实施任何时间/零点/增益修正。',
         '校准陀螺角速度相位与gyro_anchor角度相位差可提示上位机算法贡献；但IMU内部滤波差异仍需固件确认。',
         'reported_odr原值为0时，实际ODR尚未证实；平均接收率不等于真实丢样率。',
         '应用seq是PC生成计数，不是固件每样本连续序号；不能仅凭它证明FIFO无丢样。',
         '缺少硬件同步与转台原生编码器时间戳；所有相位差只供研究归因，不可当作正式精度验收。']
    }


def report_text(results):
    L=['TiltLab 时间基准与相位诊断（只读研究版）','='*50,
       '测量定义：正的毫秒数表示后一信号相对前一参考信号表观滞后。',
       '本工具不调整原始数据、不对齐零点、不改变融合、不控制运动、不用于0.05°合格判定。','']
    for r in results:
        p=r['phase_diagnostic_only_NOT_hardware_lag'];im=r['imu'];tab=r['table']
        L+=['文件：'+r['file'], '方向（按内轴位置推断）：'+r['direction_inferred_from_axis0'].upper(),
             '转台编码器估计频率：%.6f Hz'%r['estimated_frequency_hz_from_encoder'],
             '稳态固定分析区间：%.2f–%.2f s'%tuple(r['stable_window_s_from_first_feedback']),
             'IMU %d行，转台 %d行；PC接收吞吐量 %.2f行/s'%(im['rows'],tab['rows'],im['observed_rows_per_second'])]
        if p:
            L+=['编码器 vs 陀螺角速度：%+.3f ms'%p['table_vs_gyro_rate_ms'],
                '编码器 vs gyro_anchor角度：%+.3f ms'%p['table_vs_gyro_anchor_angle_ms'],
                '编码器 vs 加速度倾角：%+.3f ms'%p['table_vs_accel_angle_ms'],
                'gyro_anchor相对陀螺角速度的额外相位：%+.3f ms'%p['gyro_anchor_extra_vs_gyro_ms'],
                '基准正弦幅值：%.4f°；gyro_anchor幅值：%.4f°'%(p['reference_amp_deg'],p['gyro_anchor_amp_deg'])]
            for j,v in enumerate(p.get('split_windows',[]),1):
                L+=['  分段%d：陀螺/转台%+.2fms，角度/转台%+.2fms，角度额外%+.2fms'%(j,v['gyro_vs_table_ms'],v['anchor_vs_table_ms'],v['anchor_extra_vs_gyro_ms'])]
        for name,v in [('485单次完整查询耗时',im['serial_read_ms_per_poll']),
                      ('PC推算IMU样本间隔',im['host_est_gap_ms']),
                      ('批次时间轴修复量',im['batch_repair_ms_per_poll']),
                      ('转台采集间隔',tab['pc_mid_interval_ms']),('转台DLL读取耗时',tab['read_ms'])]:
            if v:L+=['%s：中位%.3f，P95 %.3f，P99 %.3f，最大%.3f ms'%(name,v['median'],v['p95'],v['p99'],v['max'])]
        L+=['正弦参考插值理论上限：最大间隔对应%.5f°；若要单靠线性插值保证<0.05°，间隔应<=%.1fms；本次超界间隔%d处'%(tab['reference_max_gap_sine_interp_bound_deg'],tab['reference_gap_limit_ms_for_0p05deg_bound'],tab['reference_interval_over_0p05deg_bound_count']),
             '固件ODR寄存器原值：'+str(im['firmware_reported_odr_raw_values']),
             'PC回退/采用ODR：'+str(im['software_nominal_odr_hz']),
             'PC应用序号异常步数：'+str(im['nonsequential_app_seq_steps']),
             '重要：以上毫秒是表观相位，无法判定某个具体硬件环节真实延迟。','']
    return '\n'.join(L)+'\n'


def analyze(path,out):
    results=[]
    for name,im,table in pairs_for(path):results.append(analyze_pair(name,im,table))
    if not results:raise ValueError('找不到名字配对的*_DYNAMIC_imu.csv与*_DYNAMIC_table.csv')
    target=Path(out) if out else Path(path).parent if Path(path).is_file() else Path(path)
    target.mkdir(parents=True,exist_ok=True)
    unique=datetime.now().strftime('%Y%m%d_%H%M%S')
    json_path=target/('TimingDiagnosis_'+unique+'.json')
    txt_path=target/('TimingDiagnosis_'+unique+'.txt')
    json_path.write_text(json.dumps({'source':str(path),'results':results},indent=2,ensure_ascii=False),encoding='utf-8')
    summary=report_text(results);txt_path.write_text(summary,encoding='utf-8-sig')
    print(summary);print('已写出：',json_path, '\n已写出：',txt_path)


def watch(folder,interval):
    """Tail the application's own POLLS journal, never open or query the COM port."""
    folder=Path(folder)
    if not folder.is_dir():raise ValueError('请选择上位机已有记录目录，不是COM口')
    last_file=None;seen=0;history=[]
    print('只读监控开始；只查看现有 *_RAW_LINK_*_polls.csv；按 Ctrl+C 退出。')
    while True:
        found=list(folder.glob('*_RAW_LINK_*_polls.csv'))
        if not found:
            print('未发现轮询日志；确认上位机已开始采集，记录目录正确。')
            time.sleep(interval);continue
        newest=max(found,key=lambda x:x.stat().st_mtime)
        if newest!=last_file:
            last_file=newest;seen=0;history=[];print('监控文件:',newest)
        try:
            with newest.open('r',encoding='utf-8-sig',newline='') as f:
                rdr=csv.DictReader(f);rows=list(rdr)
        except (PermissionError,OSError,csv.Error) as e:
            print('读取暂不可用:',str(e));time.sleep(interval);continue
        if len(rows)<seen:seen=0;history=[]
        new=rows[seen:];seen=len(rows)
        for row in new:
            if not row.get('poll_id') or not row.get('received_pc_ns'):continue
            history.append(row)
        history=history[-1500:]
        if new:
            def group(key):return percentiles(num(x.get(key)) for x in history)
            serial=group('serial_read_ms');ipc=group('ipc_delivery_ms');idle=group('previous_idle_ms')
            dropped=[num(x.get('reported_dropped_batches')) for x in history]
            dropped=[z for z in dropped if math.isfinite(z)]
            dropchange=(dropped[-1]-dropped[0]) if len(dropped)>1 else None
            def fmt(s):return '无数据' if s is None else 'P99=%.1fms MAX=%.1fms'%(s['p99'],s['max'])
            print(datetime.now().strftime('%H:%M:%S'),'新增轮询',len(new),
                  '串口:',fmt(serial),'进程IPC:',fmt(ipc),'采集轮询空档:',fmt(idle),
                  '累计溢出/跳批计数变化:',dropchange)
            # Do not infer MCU faults from a high Windows scheduling latency.
        time.sleep(interval)


def main():
    p=argparse.ArgumentParser(description='TiltLab只读时间诊断，不接管串口/转台')
    sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('analyze',help='离线分析包含两组CSV的ZIP或文件夹')
    a.add_argument('path');a.add_argument('--out',help='输出目录，默认输入文件所在目录')
    w=sub.add_parser('watch',help='只读跟踪运行中的*_polls.csv文件')
    w.add_argument('folder');w.add_argument('--interval',type=float,default=3.0)
    args=p.parse_args()
    try:
        if args.command=='analyze':analyze(args.path,args.out)
        else:watch(args.folder,max(.5,args.interval))
    except KeyboardInterrupt:print('\n用户结束只读监控。')
    except Exception as exc:
        print('诊断失败：'+type(exc).__name__+': '+str(exc),file=sys.stderr);sys.exit(1)

if __name__=='__main__':main()
