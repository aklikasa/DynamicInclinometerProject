# coding: utf-8
"""All tests offline. No COM, no DLL, no motor action."""
import math,queue,sys,tempfile,time,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import diagnose as d
from control_client import LocalAPI,SafetySupervisor

class DiagnosisTests(unittest.TestCase):
    def synth(self,del_ms=10,axis='roll'):
        f=.3;origin=9000.
        imu={k:[] for k in ('host_est_ns','pc_observed_ns','seq','device_t_s','imu_nominal_odr_hz','reported_odr','batch_shift_ms',
                                 'cal_gyro_x_dps','cal_gyro_y_dps','cal_accel_roll','cal_accel_pitch',
                                 'cal_gyro_anchor_roll','cal_gyro_anchor_pitch','cal_gyro_roll','cal_gyro_pitch')}
        table={k:[] for k in ('pc_mid_ns','axis_0_pos','axis_2_pos','read_ms')}
        for i in range(5000):
            t=origin+i*.01;ang=2*math.pi*f*(t-origin)
            imu['host_est_ns'].append(str(int(t*1e9)));imu['pc_observed_ns'].append(str(int(t*1e9)))
            imu['seq'].append(str(i+1));imu['device_t_s'].append(str(i*.01))
            imu['imu_nominal_odr_hz'].append('100');imu['reported_odr'].append('100');imu['batch_shift_ms'].append('0')
            for ax in ('x','y'):imu['cal_gyro_'+ax+'_dps'].append(str(5*2*math.pi*f*math.cos(ang)))
            for ax in ('roll','pitch'):
                imu['cal_accel_'+ax].append(str(5*math.sin(ang)))
                imu['cal_gyro_'+ax].append(str(5*math.sin(ang)))
                imu['cal_gyro_anchor_'+ax].append(str(5*math.sin(ang-2*math.pi*f*del_ms/1000)))
        for i in range(750):
            t=origin+i*(50/749)
            table['pc_mid_ns'].append(str(int(t*1e9)))
            table['axis_0_pos'].append('0' if axis=='roll' else '90')
            table['axis_2_pos'].append(str(5*math.sin(2*math.pi*f*(t-origin))))
            table['read_ms'].append('4.0')
        return imu,table
    def test_algorithm_delay_isolated_without_curve_shift(self):
        im,tab=self.synth(10)
        src=list(im['cal_gyro_anchor_roll'])
        result=d.analyze_channels('synth_DYNAMIC_imu.csv',im,tab,False)
        self.assertTrue(result['valid'])
        rows={x['algorithm']:x for x in result['algorithms']}
        self.assertAlmostEqual(rows['gyro_anchor']['apparent_extra_lag_vs_gyro_integration_ms'],10,delta=.1)
        self.assertAlmostEqual(rows['accel']['apparent_extra_lag_vs_gyro_integration_ms'],0,delta=.1)
        self.assertEqual(im['cal_gyro_anchor_roll'],src)
        self.assertAlmostEqual(result['encoder_frequency_hz'],.3,delta=.001)
    def test_pitch_and_no_model_fallback(self):
        im,tab=self.synth(0,'pitch');r=d.analyze_channels('synth_DYNAMIC_imu.csv',im,tab,False)
        self.assertEqual(r['direction_inferred_from_inner_axis'],'pitch')
        self.assertAlmostEqual(r['calibrated_gyro_integral_apparent_lag_ms'],0,delta=.1)
        tab['axis_2_pos']=['0']*len(tab['axis_2_pos'])
        r=d.analyze_channels('synth_DYNAMIC_imu.csv',im,tab,False)
        self.assertFalse(r['valid'])
    def test_refuse_unknown_axis(self):
        im,tab=self.synth();tab['axis_0_pos']=['45']*len(tab['axis_0_pos'])
        with self.assertRaises(ValueError):d.analyze_channels('synth_DYNAMIC_imu.csv',im,tab,False)
    def test_readonly_report(self):
        im,tab=self.synth()
        with tempfile.TemporaryDirectory() as tmp:
            import csv
            a=Path(tmp)/'X_DYNAMIC_imu.csv';b=Path(tmp)/'X_DYNAMIC_table.csv'
            for fn,data in ((a,im),(b,tab)):
                with fn.open('w',newline='',encoding='utf-8') as out:
                    writer=csv.writer(out);writer.writerow(data)
                    for i in range(len(next(iter(data.values())))):
                        writer.writerow([vals[i] for vals in data.values()])
            old=(a.read_bytes(),b.read_bytes())
            j,t,rs=d.run(tmp,Path(tmp)/'out')
            self.assertTrue(j.exists() and t.exists() and len(rs)==1)
            self.assertEqual(old,(a.read_bytes(),b.read_bytes()))
    def test_refuses_remote_url(self):
        with self.assertRaises(ValueError):LocalAPI('http://other-host:8877')

class FailCloseTests(unittest.TestCase):
    class Fake:
        def __init__(self):self.paths=[]
        def call(self,path,payload=None,timeout=None):
            self.paths.append(path)
            if path.endswith('heartbeat'):raise RuntimeError('lost')
            if path.endswith('/status'):raise RuntimeError('lost')
            if path.endswith('/stop'):return {'stopped_verified':True}
            return {}
    def test_connection_loss_attempts_abort_and_stop(self):
        api=self.Fake();q=queue.Queue();v=SafetySupervisor(api,q,.01)
        v.start('auto');v.thread.join(2)
        self.assertTrue(v.failed)
        self.assertIn('/api/auto-dynamic/abort',api.paths)
        self.assertIn('/api/turntable/stop',api.paths)
        self.assertFalse(v.thread.is_alive())

if __name__=='__main__':unittest.main()
