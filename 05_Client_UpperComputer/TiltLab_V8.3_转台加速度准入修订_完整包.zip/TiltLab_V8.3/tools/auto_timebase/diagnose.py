#!/usr/bin/env python3
# coding: utf-8
"""No-motion comparison of all recorded algorithms with the original encoder.

Never changes reference/IMU timestamps, curve samples, offsets, amplitudes or data.
Phasor comparisons quantify *apparent* lag only; they are NOT accuracy metrics,
clock synchronization, firmware latency measurements, or calibration corrections.
"""
import argparse,csv,io,json,math,sys,zipfile
from datetime import datetime
from pathlib import Path
import timing_probe as tp


def open_pairs(path, since=None):
    """Prefer the *after STOP* offline replay for comparators where available.
    Dynamically discovered channels are never filled or silently substituted.
    """
    p=Path(path)
    if p.is_dir():
        def read_file(x):
            with x.open('r',encoding='utf-8-sig',newline='') as f:
                return read_table(csv.DictReader(f))
        for imup in sorted(p.glob('*_DYNAMIC_imu.csv')):
            if since is not None and imup.stat().st_mtime < since:continue
            tablep=imup.with_name(imup.name.replace('_imu.csv','_table.csv'))
            replay=imup.with_name(imup.name.replace('_imu.csv','_offline_replay.csv'))
            if tablep.is_file():
                meta_path=imup.with_name(imup.name.replace('_imu.csv','.json'))
                active=None
                if meta_path.is_file():
                    try:active=json.loads(meta_path.read_text(encoding='utf-8')).get('imu_algorithm_at_start')
                    except (ValueError,OSError):pass
                yield imup.name,read_file(replay if replay.is_file() else imup),read_file(tablep),replay.is_file(),active
    elif p.is_file() and p.suffix.lower()=='.zip':
        with zipfile.ZipFile(p) as z:
            names=set(z.namelist())
            for fn in sorted(x for x in names if x.endswith('_DYNAMIC_imu.csv')):
                table=fn[:-8]+'_table.csv';replay=fn[:-8]+'_offline_replay.csv'
                if table not in names:continue
                use=replay if replay in names else fn
                with z.open(use) as a,z.open(table) as b:
                    aa=read_table(csv.DictReader(io.TextIOWrapper(a,encoding='utf-8-sig',newline='')))
                    bb=read_table(csv.DictReader(io.TextIOWrapper(b,encoding='utf-8-sig',newline='')))
                active=None
                meta=fn[:-8]+'.json'
                if meta in names:
                    try:active=json.loads(z.read(meta)).get('imu_algorithm_at_start')
                    except (ValueError,OSError):pass
                yield Path(fn).name,aa,bb,use==replay,active
    elif p.is_file() and p.name.endswith('_DYNAMIC_imu.csv'):
        table=p.with_name(p.name.replace('_imu.csv','_table.csv'))
        replay=p.with_name(p.name.replace('_imu.csv','_offline_replay.csv'))
        if not table.exists():raise ValueError('缺少配对转台CSV: '+str(table))
        with (replay if replay.exists() else p).open('r',encoding='utf-8-sig',newline='') as a,table.open('r',encoding='utf-8-sig',newline='') as b:
            aa=read_table(csv.DictReader(a));bb=read_table(csv.DictReader(b))
        active=None
        metadata=p.with_name(p.name.replace('_imu.csv','.json'))
        if metadata.is_file():
            try:active=json.loads(metadata.read_text(encoding='utf-8')).get('imu_algorithm_at_start')
            except (ValueError,OSError):pass
        yield p.name,aa,bb,replay.exists(),active
    else:raise ValueError('选择完整ZIP、报告文件夹或单个 *_DYNAMIC_imu.csv')


def read_table(reader):
    cols=reader.fieldnames or []
    data={key:[] for key in cols}
    for row in reader:
        for key in cols:data[key].append(row.get(key,''))
    return data


def measured_f(t,y):
    low=t[0]+.30*(t[-1]-t[0]);high=t[0]+.90*(t[-1]-t[0])
    f,crossings,_=tp.frequency_from_crossings(t,y,low,high)
    return f,crossings,low,high


def analyze_channels(name,im,table,is_replay,active_algorithm=None):
    wanted=['host_est_ns','pc_observed_ns','cal_gyro_x_dps','cal_gyro_y_dps','cal_accel_roll','cal_accel_pitch',
            'seq','device_t_s','imu_nominal_odr_hz','reported_odr','batch_shift_ms']
    missing=[x for x in wanted if x not in im]
    missing += [x for x in ('pc_mid_ns','axis_0_pos','axis_2_pos','read_ms') if x not in table]
    if missing:raise ValueError('缺少必要字段: '+','.join(missing))
    tt=[tp.num(x)/1e9 for x in table['pc_mid_ns']]
    yy=[tp.angle_deg(tp.num(x)) for x in table['axis_2_pos']]
    inner=[tp.angle_deg(tp.num(x)) for x in table['axis_0_pos']]
    if len(tt)<100 or len(im['host_est_ns'])<300:raise ValueError('采样太少，不足以估计0.3Hz相位')
    med=sorted(inner)[len(inner)//2]
    axis=('roll' if abs(med)<10 else 'pitch' if abs(med-90)<10 else 'unknown')
    if axis=='unknown':raise ValueError('内轴位置无法辨认ROLL/PITCH方向，拒绝自动推断')
    f,crossings,lo,hi=measured_f(tt,yy)
    base={'file':name,'direction_inferred_from_inner_axis':axis,'has_offline_replay':is_replay,'real_time_algorithm_from_run_report':active_algorithm,
          'data_quality':'RESEARCH_DIAGNOSTIC_ONLY_NOT_HARDWARE_SYNC',
          'raw_data_unchanged':True,'origin':'recorded PC timestamps, not absolute sample clock',
          'reference_rising_crossings':crossings,
          'warnings': ['估计的是表观相位，绝不证明硬件时间同步或STM32实际延迟',
                       '加速度直算不是严格无算法输出；它没有陀螺融合，但仍有传感器内部滤波/标定',
                       '纯陀螺积分受零偏、初始姿态和漂移影响，正弦相位诊断不等于绝对角度精度',
                       '离线重放与实时算法的CPU延迟、状态初始化不同，不可以混为同一性能',
                       '没有在原始数据上做参考曲线平移、零点校准或幅度修正。']}
    if not f or not .01<f<=.8:
        base.update(valid=False,reason='参考编码器有效周期不足；未使用指令频率代替实际频率',algorithms=[])
        return base
    origin=tt[0]
    ref=tp.harmonic(tt,yy,origin,f,lo,hi)
    if ref is None:
        base.update(valid=False,reason='有效参考点不足',algorithms=[]);return base
    it=[tp.num(v)/1e9 for v in im['host_est_ns']]
    gyro_col='cal_gyro_x_dps' if axis=='roll' else 'cal_gyro_y_dps'
    gr=tp.harmonic(it,[tp.num(x) for x in im[gyro_col]],origin,f,lo,hi)
    gg=(gr['phase']-math.pi/2 if gr else None)
    all_alg=sorted(x for x in im if x.startswith('cal_') and not x.startswith('cal_factory_') and x.endswith('_'+axis) and x not in ('cal_accel_'+axis,))
    all_alg=['cal_accel_'+axis]+all_alg
    alg=[]
    for col in all_alg:
        v=[tp.num(x) for x in im[col]]
        fit=tp.harmonic(it,v,origin,f,lo,hi)
        if not fit:continue
        key=col.removeprefix('cal_').removesuffix('_'+axis)
        lag=tp.lag_ms(ref['phase'],fit['phase'],f)
        extra=tp.lag_ms(gg,fit['phase'],f) if gg is not None else None
        alg.append({'algorithm':key,'channel':col,'time_axis':'estimated PC reception backprojection',
                    'execution_mode':('realtime_capture' if active_algorithm and key in ('accel',active_algorithm)
                     else 'offline_replay' if is_replay and active_algorithm
                     else 'unknown_provenance_check_dynamic_json'),
                    'amplitude_deg':round(fit['amplitude'],5),
                    'amplitude_ratio_to_encoder':round(fit['amplitude']/ref['amplitude'],5) if ref['amplitude'] else None,
                    'apparent_lag_vs_encoder_ms':round(lag,3),
                    'apparent_extra_lag_vs_gyro_integration_ms':round(extra,3) if extra is not None else None,
                    'fit_sample_count':fit['samples']})
    gaps=[(b-a)*1000 for a,b in zip(tt,tt[1:])]
    estimated=[(tp.num(b)-tp.num(a))/1e6 for a,b in zip(im['host_est_ns'],im['host_est_ns'][1:])]
    delivered=[(tp.num(b)-tp.num(a))/1e6 for a,b in zip(im['pc_observed_ns'],im['pc_observed_ns'][1:])]
    reported=sorted(set(x for x in im['reported_odr'] if x not in ('',None)))
    base.update(valid=True,encoder_frequency_hz=round(f,6),encoder_amp_deg=round(ref['amplitude'],5),
                steady_window_seconds=[round(lo-origin,3),round(hi-origin,3)],
                encoder_sample_count=len(tt),imu_sample_count=len(it),
                encoder_gap_ms=tp.percentiles(gaps),imu_host_est_gap_ms=tp.percentiles(estimated),
                imu_receipt_gap_ms=tp.percentiles(delivered),
                imu_firmware_reported_odr_raw=reported[:20],
                calibrated_gyro_angle_integral_amplitude_deg=(round(gr['amplitude']/(2*math.pi*f),5) if gr else None),
                calibrated_gyro_integral_apparent_lag_ms=(round(tp.lag_ms(ref['phase'],gg,f),3) if gg is not None else None),
                algorithms=alg)
    base['reference_gap_over_100ms_count']=sum(x>100 for x in gaps)
    if max(gaps)>100:base['warnings'].append('转台反馈间隔超过100ms；此处为研究相位估算，不可进行0.05°合格验收')
    if reported==['0'] or reported==['0.0']:base['warnings'].append('固件上报ODR=0；PC名义ODR不能证明真实FIFO采样速率')
    return base


def summary(r):
    out=[f'试验: {r["file"]}',f'方向: {r["direction_inferred_from_inner_axis"].upper()}',
         f'有离线对照CSV: {r["has_offline_replay"]}',f'有效: {r["valid"]}']
    if not r['valid']:return '\n'.join(out+[str(r.get('reason'))])+'\n'
    out += [f'编码器估计频率: {r["encoder_frequency_hz"]:.6f} Hz  正弦幅度: ±{r["encoder_amp_deg"]:.5f}°',
            f'IMU采样行数: {r["imu_sample_count"]}  转台反馈: {r["encoder_sample_count"]}',
            f'转台最大时间缺口: {r["encoder_gap_ms"]["max"]:.1f} ms',
            f'校准陀螺角速度积分正弦的表观滞后: {r["calibrated_gyro_integral_apparent_lag_ms"]}ms',
            '对照算法                         表观滞后vs转台ms  相对陀螺积分额外滞后ms   幅比']
    for a in r['algorithms']:
        out.append(f'{a["algorithm"]:<32} {a["apparent_lag_vs_encoder_ms"]:>9.3f} {str(a["apparent_extra_lag_vs_gyro_integration_ms"]):>23} {str(a["amplitude_ratio_to_encoder"]):>9}')
    out.extend(['','判定说明：只用于定位时间轴/算法嫌疑，不能用于动态0.05°合格验收。'])
    out.extend('注意: '+x for x in r['warnings'])
    return '\n'.join(out)+'\n'


def run(path,output,since=None):
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    results=[]
    for name,im,table,replay,active in open_pairs(path,since):
        results.append(analyze_channels(name,im,table,replay,active))
    if not results:raise ValueError('没有找到成对的动态 IMU/转台 CSV')
    stem=datetime.now().strftime('%Y%m%d_%H%M%S')
    rp=out/('同次采集_算法时间诊断_'+stem+'.json')
    tp_=out/('同次采集_算法时间诊断_'+stem+'.txt')
    rp.write_text(json.dumps({'input':str(path),'results':results},ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    tp_.write_text('【仅用于研发诊断，不是第三方精度认证】\n\n'+'\n'.join(summary(r) for r in results),encoding='utf-8-sig')
    return rp,tp_,results


def main():
    p=argparse.ArgumentParser(description='多算法同源信号、真实转台反馈研究性相位对比；完全只读')
    p.add_argument('input',help='原始ZIP/报告目录/*_DYNAMIC_imu.csv')
    p.add_argument('--out',default=str(Path.cwd()/'diagnostic_outputs'))
    p.add_argument('--since',type=float,default=None,help='only files modified after this UNIX time, directory input only')
    a=p.parse_args()
    try:
        _,report,results=run(a.input,a.out,a.since)
        print(report.read_text(encoding='utf-8-sig'))
        print('保存到',report)
    except Exception as exc:
        print('分析未完成：',repr(exc),file=sys.stderr)
        raise SystemExit(1)

if __name__=='__main__':main()
