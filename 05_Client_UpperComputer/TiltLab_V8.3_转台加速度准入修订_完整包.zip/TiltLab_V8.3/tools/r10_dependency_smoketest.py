# -*- coding: utf-8 -*-
"""Safe import-only dependency check for ambient R10. No vendor DLL, COM, PLC, or motion calls."""
import importlib
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
REQUIRED_MODULES=(
    'PySide6.QtWidgets', 'openpyxl', 'xlsxwriter', 'numpy', 'serial',
)
# A file presence check is NOT a driver load or an equipment readiness test.
R10_FILES=(
    'r10_ambient/tiltlab_ambient_worker.py',
    'r10_ambient/2TD600.dll',
    'r10_ambient/2FDT600WK.dll',
)


def audit(output=print):
    problems=[]
    output('[INFO] Using Python: '+sys.executable)
    for module in REQUIRED_MODULES:
        try:
            importlib.import_module(module)
        except Exception as exc:
            problems.append(f'{module}: {exc}')
            output(f'[MISSING/BROKEN] {module}: {exc}')
        else:
            output('[OK] '+module)
    for filename in R10_FILES:
        if not (ROOT/filename).is_file():
            problems.append('missing file: '+filename)
            output('[MISSING FILE] '+filename)
    return problems


def main():
    print('=== TiltLab V8.1 ambient R10 Python import test ===')
    problems=audit()
    if problems:
        print('[FAILED] Python deps or packaged files incomplete. No hardware accessed by this check.')
        return 1
    print('[READY] Ambient R10 Python dependencies import successfully in this interpreter.')
    print('[NOTICE] Vendor DLL loading, serial communication, and real motor safety are NOT tested.')
    return 0

if __name__=='__main__': raise SystemExit(main())
