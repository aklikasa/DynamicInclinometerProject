"""Give previously generated self-contained TiltLab HTML a readable condition header.

Usage: python tools/label_old_dynamic_html.py C:\\path\\report.html
Creates *_CLEAR.html without editing the original HTML. No internet, no hardware.
"""
from __future__ import annotations
import argparse
from pathlib import Path

CSS = '''<style id="tiltlab-summary-style">
#tiltlab-condition-banner{font:14px/1.6 sans-serif;max-width:1180px;margin:16px auto;padding:20px;background:#fff;border:1px solid #d9e6dd;border-radius:14px;color:#223}
#tiltlab-condition-banner h2{margin:0 0 12px;font-size:21px}#tiltlab-condition-banner table{border-collapse:collapse;width:100%;font-size:14px}#tiltlab-condition-banner td,#tiltlab-condition-banner th{text-align:left;padding:10px;border-bottom:1px solid #e5e9e6;white-space:normal}
#tiltlab-condition-banner .note{background:#fff9eb;padding:12px;border-left:3px solid #bf8740;margin:12px 0}#tiltlab-condition-banner .overflow{overflow:auto}
</style>'''
JS = r'''<script id="tiltlab-summary-script">
(function(){
 const e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const f=(v,n=2)=>v==null||v===''||!Number.isFinite(Number(v))?'—':Number(v).toFixed(n);
 if(typeof DATA==='undefined'||!Array.isArray(DATA.stages)){return;}
 let anchor=document.querySelector('.hero')||document.querySelector('header')||document.querySelector('main');if(!anchor)return;
 const box=document.createElement('section');box.id='tiltlab-condition-banner';
 const rr=DATA.stages.map(s=>{let r=s.report||{},p=r.plan||{},d=s.direction||p.output,st=r.analysis?.reference_steady_state||{},amps=(st.cycle_amplitudes||[]).filter(x=>x.quality==='near_command_amplitude'&&Number.isFinite(Number(x.reference_amplitude_deg))).map(x=>Number(x.reference_amplitude_deg)).sort((a,b)=>a-b);let a=st.valid&&amps.length?'±'+f(amps[Math.floor(amps.length/2)],3)+'°（采样反馈估计）':'尚无可信实测稳态幅度';return `<tr><td><b>${d==='roll'?'ROLL横滚':d==='pitch'?'PITCH俯仰':'方向未知'}</b></td><td>${f(s.inner_target_deg??p.inner_target_deg,1)}°</td><td><b>±${f(p.amplitude_deg)}°</b></td><td><b>${f(p.frequency_hz,3)}Hz</b></td><td>${e(p.cycles??'—')}</td><td>${e(a)}</td><td>${e(r.state||'未知')}，停车${r.stopped_verified===true?'已确认':'未确认'}</td></tr>`});
 box.innerHTML='<h2>本报告测试方向与工况一览</h2><p class="note"><b>设定≠实测：</b> ±幅度、Hz与周期数来自测试指令；下面“实测幅度”仅取通过稳态判定的实际编码器反馈周期。实测频率未独立估计。不能将指令值直接当成实际验证值。</p><div class="overflow"><table><thead><tr><th>方向</th><th>内轴</th><th>设定摆幅</th><th>设定频率</th><th>设定周期</th><th>实测稳态摆幅</th><th>状态</th></tr></thead><tbody>'+rr.join('')+'</tbody></table></div>';
 anchor.insertAdjacentElement('afterend',box);
})();
</script>'''

def improve(path:Path) -> Path:
    path=Path(path)
    s=path.read_text(encoding='utf-8-sig')
    if 'const DATA=' not in s or 'DATA.stages' not in s:
        raise ValueError('文件不是带有嵌入数据的 TiltLab 动态HTML，未作修改')
    if 'tiltlab-condition-banner' in s:raise ValueError('已添加报告工况总览，无需重复处理')
    if '</head>' not in s or '</body>' not in s:raise ValueError('HTML未包含完整结构')
    s=s.replace('</head>',CSS+'</head>',1)
    s=s.replace('</body>',JS+'</body>',1)
    out=path.with_name(path.stem+'_CLEAR.html')
    if out.exists():raise FileExistsError(f'不会覆盖已有文件：{out}')
    out.write_text(s,encoding='utf-8')
    return out

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('html',type=Path)
    args=parser.parse_args()
    print('已生成清晰版报告：',improve(args.html))
