"""Read-only offline completion of a V7.23 pending capture; no hardware access."""
from pathlib import Path
import argparse,json,sys,zipfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.dynamic_experiment import _report_process

def finalize(source):
    source=Path(source).resolve(); r=json.loads(source.read_text(encoding='utf-8-sig'))
    if r.get('kind')!='REAL_2TD600_SINE_DIAGNOSTIC' or r.get('data_analysis_state')!='pending_offline_analysis':
        raise ValueError('请选择尚未生成完整报告的原始动态JSON')
    if not (r.get('motion_period_collected') is True and r.get('stopped_verified') is True):
        raise ValueError('原始记录未确认完整运动和停车；禁止将其作为完整报告恢复')
    def path(key):
        name=r[key]
        if Path(name).name!=name:raise ValueError('文件名不合法')
        return source.parent/name
    imu,table=path('raw_file_imu'),path('raw_file_table');snapshot={}
    if r.get('calibration_snapshot_file'):
        with zipfile.ZipFile(path('calibration_snapshot_file')) as z:
            snapshot={n:z.read(n) for n in z.namelist() if Path(n).name==n and n.endswith('.json')}
    trace=source.stem+'_V723_RECOVERED';out=source.parent/(trace+'.json')
    if out.exists():raise FileExistsError(f'已存在恢复报告：{out}')
    r['state']='completed';r['error']='';r['offline_recovery_source']=source.name
    _report_process(str(out),str(imu),str(table),r,r.get('static_alignment'),snapshot,True,True,'',trace)
    return out
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('report',nargs='?');p.add_argument('--optimize',action='store_true',help='恢复后执行单轴离线寻优');a=p.parse_args()
    source=a.report or input('拖入待恢复动态JSON路径：').strip().strip('"')
    out=finalize(source);print('已保存独立恢复报告：',out)
    if a.optimize:
        from app.research_optimizer import optimize
        r=json.loads(out.read_text(encoding='utf-8-sig'))
        print('独立寻优：',optimize(out.parent,[r],out.stem+'_OPTIMIZER'))
