"""Offline-only repair of the V7.24 deferred-report state transition bug.

Does NOT open serial ports, connect to a table, command motion, adjust raw
measurements, recompute errors, or certify accuracy. Original reports remain.
"""
from __future__ import annotations
import argparse
import datetime as dt
import json
from pathlib import Path


def repair_status(source: Path):
    source=Path(source).resolve()
    if not source.name.endswith('_DYNAMIC.json'):
        raise ValueError('请选择原始 *_DYNAMIC.json，不是自动流程总账或修改后的文件')
    data=json.loads(source.read_text(encoding='utf-8-sig'))
    reasons=[]
    def require(ok,reason):
        if not ok:reasons.append(reason)
    require(data.get('kind')=='REAL_2TD600_SINE_DIAGNOSTIC','不是实际动态实验报告')
    require(data.get('state')=='capture_complete','状态不是已知V7.24延迟报告错误 capture_complete')
    require(data.get('stopped_verified') is True,'厂家DLL双轴STOP未获确认')
    require(data.get('motion_period_collected') is True,'没有完整运动时间段')
    require(data.get('motion_capture_state')=='completed','运动采集未完成')
    require(data.get('deferred_capture_gate',{}).get('valid') is True,'初始采集质量门禁未通过')
    require(data.get('analysis',{}).get('valid') is True,'离线精度分析没有有效结果')
    require(data.get('data_analysis_state')=='available_research_only','离线分析非有效研究状态')
    require(not data.get('error'),'动态报告已有错误原因')
    require(data.get('analysis',{}).get('fusion_gap_resets')==0,'IMU融合出现重置或未记录')
    require(data.get('analysis',{}).get('estimated_gaps_over_50ms')==0,'IMU存在50ms以上缺口或未记录')
    require(data.get('certified_dynamic_accuracy') is False,'不是未认证的研发报告，拒绝改变状态')
    require(int(data.get('imu_samples') or 0)>=100 and int(data.get('table_samples') or 0)>=12,'采集样本数量不足')
    if reasons:raise ValueError('状态修复被拒绝；'+ '；'.join(reasons))
    # The state-only repair uses the already-written quality assessment.
    # It does not modify raw CSV, change metrics, or alter the original ledger.
    suffix='_V7241_STATUS_REPAIRED'
    out=source.with_name(source.stem+suffix+'.json')
    if out.exists():raise FileExistsError('输出文件已存在，未覆盖：'+str(out))
    data['state']='completed'
    data['status_repair']={'tool':'V7.24.1','source_report':source.name,
        'repaired_at':dt.datetime.now().astimezone().isoformat(),
        'what_changed':'仅修复已完成、停车已确认、分析门禁通过的capture_complete状态字段；原始数据和精度指标未修改',
        'original_auto_run_ledger_unchanged':True,
        'quality':'RESEARCH_ONLY_UNSYNCHRONIZED',
        'certified_dynamic_accuracy':False}
    out.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    # A separate HTML copy is optional and never required for evidence.
    try:
        from app.html_report import write_interactive_report
        write_interactive_report(out)
    except Exception as exc:
        print('JSON状态修复完成；HTML生成失败（原始报告未受影响）：',repr(exc))
    return out


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report',nargs='?')
    args=parser.parse_args()
    try:
        path=args.report or input('拖入已做完整离线分析的 *_DYNAMIC.json：').strip().strip('"')
        dest=repair_status(Path(path))
        print('已创建只读修复副本：',dest)
        print('请同时保留原始JSON、CSV和_AUTO_FULL_RUN.json；状态完成不代表0.1°或0.05°动态精度合格。')
    except Exception as exc:
        print('已拒绝状态修复：',str(exc));raise SystemExit(1)
