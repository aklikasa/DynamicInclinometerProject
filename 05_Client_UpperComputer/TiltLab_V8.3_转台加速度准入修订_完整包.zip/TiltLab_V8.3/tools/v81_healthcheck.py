# -*- coding: utf-8 -*-
"""V8.1 no-hardware diagnostics: examine local Python dependencies and release wiring."""
import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main(argv=None):
    parser = argparse.ArgumentParser(description='V8.1 read-only environment self-check, no COM/DLL/PLC access')
    parser.add_argument('--mode', choices=('core','r10','plc','full'), default='core')
    opts = parser.parse_args(argv)
    print('[V8.1] read-only environment check (no hardware or network actions)')
    print('[INFO] Python:',sys.executable)
    print('[INFO] Python version:',sys.version.split()[0], '; 64-bit:',sys.maxsize>2**32)
    print('[INFO] project:',ROOT)
    problems=[]
    if not (sys.maxsize>2**32 and (3,10)<=sys.version_info[:2]<=(3,13)):
        problems.append('Requires 64-bit Python 3.10–3.13')
    if not (ROOT/'r10_ambient'/'tiltlab_ambient_worker.py').is_file():
        problems.append('R10 worker file is missing')
    if not (ROOT/'web'/'index.html').is_file():
        problems.append('Web UI is missing')
    try:
        from setup_v730 import audit
        modes = ('core',) if opts.mode=='core' else ('core','r10') if opts.mode=='r10' else ('core','r10','plc') if opts.mode=='plc' else ('core','r10','plc','research')
        for mode in modes:
            print('[CHECK]',mode)
            missing=audit(mode)
            if missing:
                problems.append(mode+': '+', '.join(str(x) for x in missing))
    except Exception as exc:
        problems.append('Dependency inspection failed: '+str(exc))
    # Safe imports only. The real worker additionally loads proprietary DLLs;
    # the installer must never load device DLLs or connect any COM port.
    if opts.mode in ('r10','plc','full') and not problems:
        from r10_dependency_smoketest import audit as smoke_audit
        smoke_problems=smoke_audit()
        if smoke_problems:
            problems.append('R10 Python import test: '+', '.join(smoke_problems))
    if problems:
        print('[NOT READY]')
        for issue in problems:print(' -',issue)
        print('[HELP] One-click PCB + R10: INSTALL_DEPENDENCIES.bat; PLC (optional): INSTALL_PLC_TEMPERATURE.bat')
        return 1
    print('[READY] Software dependency check passed. This does NOT validate live PCB, turntable or calibration safety.')
    return 0

if __name__=='__main__':raise SystemExit(main())
