"""Read-only CSV replay for V7.8 gyro_anchor. Never touches motion hardware.

Usage: python tools/replay_v78.py old_dynamic_imu.csv --frequency .3 --from-s 14
Replays the exact recorded six axes on their existing device_t_s time axis.
Does not use the turntable to alter the filter or claim accuracy.
"""
from __future__ import annotations
import argparse,csv,json,math,sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.fusion import Params,create_filter


def choose_number(row,name):
    try:
        val=float(row[name]);return val if math.isfinite(val) else None
    except (KeyError,TypeError,ValueError):return None


def amplitude(t,y,f):
    # A sine fit of an IMU channel is diagnostic; this is NOT a turntable fit.
    import numpy as np
    if len(t)<80:return None
    om=2*math.pi*f
    X=np.column_stack((np.sin(om*np.asarray(t)),np.cos(om*np.asarray(t)),np.ones(len(t))))
    a=np.linalg.lstsq(X,np.asarray(y),rcond=None)[0]
    return {'amplitude_deg':round(float(np.hypot(a[0],a[1])),5),
            'constant_deg':round(float(a[2]),5),'samples':len(t)}


def replay(path,out=None,frequency=None,from_s=12.,to_s=None,calibrated=True):
    path=Path(path).expanduser().resolve()
    if not path.is_file():raise FileNotFoundError(str(path))
    out=Path(out) if out is not None else path.with_name(path.stem+'_V78_REPLAY.csv')
    if out.resolve()==path:raise ValueError('禁止覆盖原始CSV')
    prefix='cal' if calibrated else 'raw'
    filter=create_filter('gyro_anchor',Params())
    output_keys=['gyro_anchor_roll_deg','gyro_anchor_pitch_deg','gyro_anchor_yaw_deg',
                 'gyro_anchor_acc_trust','gyro_anchor_stationary','gyro_anchor_bias_ready',
                 'gyro_anchor_motion','gyro_anchor_bias_x_dps','gyro_anchor_bias_y_dps',
                 'gyro_anchor_bias_z_dps','gyro_anchor_gaps_over_50ms']
    original_channels=['gyro','accel','adaptive','motion_guard']
    refcols={name:f'{prefix}_{name}_roll' for name in original_channels}
    sample=0;valid=0;invalid=0;seams=0;max_dt=0.;first_t=last_t=None
    fit={name:([],[]) for name in ['gyro_anchor']+original_channels}
    with path.open(encoding='utf-8-sig',newline='') as r, out.open('w',encoding='utf-8-sig',newline='') as w:
        reader=csv.DictReader(r)
        if not reader.fieldnames or 'device_t_s' not in reader.fieldnames:
            raise ValueError('不是TiltLab原始动态IMU CSV，缺少 device_t_s')
        for name in 'xyz':
            for kind in ('acc','gyro'):
                if f'{prefix}_{kind}_{name}_'+('g' if kind=='acc' else 'dps') not in reader.fieldnames:
                    raise ValueError(f'缺少{prefix}三轴六轴数据；请选择正确的--raw/--cal')
        writer=csv.DictWriter(w,fieldnames=reader.fieldnames+output_keys,extrasaction='ignore');writer.writeheader()
        for row in reader:
            sample+=1
            t=choose_number(row,'device_t_s')
            a=[choose_number(row,f'{prefix}_acc_{n}_g') for n in 'xyz']
            g=[choose_number(row,f'{prefix}_gyro_{n}_dps') for n in 'xyz']
            if t is None or None in a or None in g or (last_t is not None and t<=last_t):
                invalid+=1;writer.writerow(row);continue
            if first_t is None:first_t=t
            dt=t-last_t if last_t is not None else 0.
            last_t=t
            if dt>.05:seams+=1
            max_dt=max(max_dt,dt)
            result=filter.update(a,g,dt)
            row.update({'gyro_anchor_roll_deg':result['roll'],
                        'gyro_anchor_pitch_deg':result['pitch'],
                        'gyro_anchor_yaw_deg':result['yaw'],
                        'gyro_anchor_acc_trust':result['trust'],
                        'gyro_anchor_stationary':int(result['stationary_detected']),
                        'gyro_anchor_bias_ready':int(result['stationary_bias_ready']),
                        'gyro_anchor_motion':int(result['motion_detected']),
                        'gyro_anchor_gaps_over_50ms':result['imu_gaps_over_50ms']})
            for i,n in enumerate('xyz'):
                row[f'gyro_anchor_bias_{n}_dps']=result['gyro_bias_dps'][i]
            writer.writerow(row);valid+=1
            elapsed=t-first_t
            if frequency and elapsed>=from_s and (to_s is None or elapsed<=to_s):
                fit['gyro_anchor'][0].append(elapsed);fit['gyro_anchor'][1].append(result['roll'])
                for name,col in refcols.items():
                    val=choose_number(row,col)
                    if val is not None:
                        fit[name][0].append(elapsed);fit[name][1].append(val)
    diagnostics={'origin_csv':path.name,'replay_csv':out.name,'channel':prefix,
                 'read_only_original':True,'filter':'gyro_anchor',
                 'filter_tuning_uses_turntable':False,'hardware_synchronized':False,
                 'samples_read':sample,'samples_replayed':valid,'invalid_samples':invalid,
                 'observed_steps_over_50ms':seams,'largest_step_ms':round(max_dt*1000,3),
                 'gyro_bias_ready':filter.bias_ready,'gyro_bias_dps':[round(x,6) for x in filter.bias],
                 'reference_note':'无转台参考；下面只比较IMU自身基波幅值，不能计算真实动态RMSE或精度。',
                 'amplitudes':{name:amplitude(*pair,frequency) for name,pair in fit.items()} if frequency else {}}
    summary=out.with_suffix('.json')
    summary.write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2),encoding='utf8')
    return out,summary,diagnostics


if __name__=='__main__':
    p=argparse.ArgumentParser(description='TiltLab V7.8 原始六轴只读回放')
    p.add_argument('imu_csv',help='旧 DYNAMIC_imu.csv 的完整路径')
    p.add_argument('--output',help='另存为CSV，禁止与原文件重名')
    p.add_argument('--frequency',type=float,help='仅作本机IMU基波对比，不改变滤波器；例如 .3')
    p.add_argument('--from-s',type=float,default=12.,help='从CSV第一条起经过多少秒开始拟合')
    p.add_argument('--to-s',type=float,help='拟合至CSV第一条起多少秒为止')
    g=p.add_mutually_exclusive_group()
    g.add_argument('--raw',action='store_true',help='使用未经标定的raw六轴')
    g.add_argument('--cal',action='store_true',help='使用cal六轴（默认）')
    opts=p.parse_args()
    if opts.frequency is not None and not .01<=opts.frequency<=5.:p.error('frequency需在.01～5Hz')
    outfile,summary,info=replay(opts.imu_csv,opts.output,opts.frequency,opts.from_s,opts.to_s,not opts.raw)
    print('重放完成（从未连接或控制转台）')
    print('新CSV: ',outfile)
    print('诊断: ',summary)
    print('原始样本:',info['samples_read'],'有效:',info['samples_replayed'],
          '间隔>50ms:',info['observed_steps_over_50ms'])
    if opts.frequency:print('IMU幅值基波（非转台精度）:',info['amplitudes'])
