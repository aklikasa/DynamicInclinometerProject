"""Read-only 2TD-600 research sine profile audit. Does not open any device."""
from __future__ import annotations
import math
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.sway_envelope import SWAY_LIMITS,PROFILE_PATH,verify_sway_motion


def main():
    lim=SWAY_LIMITS
    print('=== 2TD-600 运动软件准入值只读检查（不连接设备）===')
    print('配置文件:',PROFILE_PATH)
    print('证据类型:',lim['evidence_type'])
    print('最大软件准入峰速: %.3f deg/s'%lim['speed_dps'])
    print('最大软件准入峰值角加速度: %.3f deg/s^2'%lim['accel_dps2'])
    print('依据:',lim['source'])
    print('说明书JC10468YS：角速率范围 ±0.01~60 deg/s；角加速度无精度要求（并非无限制）。')
    print('本机/负载/工装变化后应重新验证，不得以软件限制代替物理限位、STOP和急停。')
    for amp,freq in [(1,.3),(1,.5),(1,.8),(2,.3),(2,.5),(2,.8),(3,.3),(3,.5),(4,.1),(4,.3)]:
        speed=2*math.pi*amp*freq
        accel=(2*math.pi*freq)**2*amp
        try:
            verify_sway_motion(amp,freq)
            status='软件准入通过（不代表现场允许运动）'
        except ValueError:
            status='软件准入阻止（缺本机验证，不建议绕过）'
        print(f'±{amp:g}° / {freq:g}Hz：峰速{speed:.2f}°/s，峰加速度{accel:.2f}°/s²；{status}')

if __name__=='__main__':
    main()
