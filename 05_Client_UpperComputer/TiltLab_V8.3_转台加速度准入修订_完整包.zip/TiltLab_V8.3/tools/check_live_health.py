"""V7.24 read-only, stationary host capture/processing health monitor.

No POST, no COM port access, no DLL movement, no recovery or restart.
Run only after an operator has started TiltLab and secured stationary hardware.
"""
import argparse
import csv
import datetime as dt
import json
import sys
import time
import urllib.request
from pathlib import Path


def observe(seconds=1800, interval=0.5, folder=None, fetch=None,
            monotonic=time.monotonic, sleep=time.sleep):
    if seconds < 1 or not 0.2 <= interval <= 5.:
        raise ValueError('观察时长至少1秒，轮询间隔0.2–5秒')
    if fetch is None:
        def fetch():
            with urllib.request.urlopen('http://127.0.0.1:8877/api/status', timeout=3) as response:
                return json.load(response)
    root = Path(folder or Path(__file__).resolve().parents[1]/'data'/'reports')
    root.mkdir(parents=True, exist_ok=True)
    prefix = root/(dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_LIVE_HEALTH_V724')
    columns = ('elapsed_s','uid','count','acquired','raw_written','queued_batches',
               'max_processing_age_ms','child_receipt_age_ms','fusion_receipt_age_ms',
               'pipeline_error','performance_json')
    started = monotonic();count = 0;previous = None;first = None;last = None
    worst_processing = 0.;worst_queue = 0;failure = ''
    with prefix.with_suffix('.csv').open('w',encoding='utf-8-sig',newline='') as out:
        writer = csv.DictWriter(out,fieldnames=columns);writer.writeheader()
        while True:
            try:
                state = fetch()
                pipeline = state['pipeline'];watchdog = pipeline['watchdog']
                row = {'elapsed_s':round(monotonic()-started,3),'uid':state.get('uid'),
                       'count':int(state['count']),
                       'acquired':int(pipeline['acquired_samples']),
                       'raw_written':int(pipeline['raw_written_samples']),
                       'queued_batches':int(pipeline['queued_batches']),
                       'max_processing_age_ms':float(pipeline['max_processing_age_ms']),
                       'child_receipt_age_ms':watchdog.get('child_receipt_age_ms'),
                       'fusion_receipt_age_ms':watchdog.get('fusion_receipt_age_ms'),
                       'pipeline_error':watchdog.get('pipeline_error'),
                       'performance_json':json.dumps(watchdog.get('performance',{}),ensure_ascii=False)}
                writer.writerow(row);out.flush();count += 1
                if first is None:first = row
                last = row
                worst_processing = max(worst_processing,row['max_processing_age_ms'])
                worst_queue = max(worst_queue,row['queued_batches'])
                if not(state.get('running') and state.get('connected') and state.get('source')=='serial'
                       and pipeline.get('mode')=='realtime' and state.get('cal_status')=='matched'):
                    raise RuntimeError('非真实IMU、标定未匹配或非单算法实时模式')
                if not watchdog.get('transport_alive') or watchdog.get('pipeline_error'):
                    raise RuntimeError(watchdog.get('pipeline_error') or 'IMU通信进程已停止')
                if any(watchdog.get(k) is None or watchdog[k]<0 or watchdog[k]>500
                       for k in ('child_receipt_age_ms','fusion_receipt_age_ms')):
                    raise RuntimeError('原始采集或融合处理超时')
                if worst_processing>500:raise RuntimeError('处理时间曾超过500ms')
                if previous and (row['uid']!=previous['uid'] or
                        row['count']<=previous['count'] or
                        row['acquired']<previous['acquired'] or
                        row['raw_written']<previous['raw_written']):
                    raise RuntimeError('采集会话发生变化、计数倒退或数据停止更新')
                previous = row
                if monotonic()-started >= seconds:break
                sleep(interval)
            except (Exception,KeyboardInterrupt) as exc:
                failure = str(exc) or type(exc).__name__
                break
    result = {'state':'failed' if failure else 'observed_pass',
              'observed_s':round(monotonic()-started,3),'requested_s':seconds,'poll_count':count,
              'reason':failure,'worst_processing_ms':worst_processing,
              'worst_queued_batches_observed':worst_queue,'first':first,'last':last,
              'interpretation':'只读观察不控制转台。通过仅表示此期间未发现主机延迟故障；不能证明传感器无漏采，也不是运动或精度验收许可。'}
    prefix.with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result,prefix


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds',type=int,default=1800)
    parser.add_argument('--interval',type=float,default=.5)
    args=parser.parse_args()
    print('V7.24只读观察：请先在现场确保设备安全静止并连接真实IMU。此程序不操作转台。',flush=True)
    value,prefix=observe(args.seconds,args.interval)
    print(json.dumps({k:v for k,v in value.items() if k not in ('first','last')},ensure_ascii=False,indent=2))
    print('完整CSV/JSON：',prefix)
    sys.exit(0 if value['state']=='observed_pass' else 1)
