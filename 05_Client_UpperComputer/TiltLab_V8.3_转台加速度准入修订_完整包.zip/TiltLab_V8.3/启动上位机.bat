@echo off
cd /d "%~dp0"
call "START_TILT_LAB.bat"
