TiltLab V7.29.2 — WebSocket 依赖修复说明

本补丁修复依赖安装清单遗漏 WebSocket 库的问题。
修改文件：requirements-core.txt、requirements.txt、INSTALL_DEPENDENCIES_DEBUG.cmd、START_TILT_LAB.bat。
未修改自动标定算法、串口通讯、运动控制及安全停车逻辑。

使用方法：
1. 关闭软件和旧的 Python 服务，备份原项目。
2. 将本压缩包完整解压到新目录。
3. 运行 INSTALL_DEPENDENCIES.bat，给项目的 .venv 安装依赖。
4. 运行 START_TILT_LAB.bat。

如果只需要给已经安装的旧环境补库：在项目根目录打开 CMD，执行
  .venv\Scripts\python.exe -m pip install "uvicorn[standard]>=0.30,<1"
如果项目没有 .venv，先运行 INSTALL_DEPENDENCIES.bat。

限制：此修复只解决缺失 WebSocket 支持的问题；PCB 真正的串口掉线及自动标定功能需要联机日志和硬件验证。
