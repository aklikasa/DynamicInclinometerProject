@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" "标定文件诊断.py"
) else (
    where py >nul 2>nul
    if not errorlevel 1 (
        py -3 "标定文件诊断.py"
    ) else (
        python "标定文件诊断.py"
    )
)
if errorlevel 1 (
    echo.
    echo Calibration check returned an error. Please capture the details above.
    pause
)
