@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title TiltLab V7.9 - VQF CSV Read-only Replay
set "PYTHON=python"
if exist ".venv\Scripts\python.exe" set "PYTHON=.venv\Scripts\python.exe"
echo This tool reads an existing IMU CSV; it does not connect or control a turntable.
echo Drag and drop the original _DYNAMIC_imu.csv file into this window, or paste its path.
set /p IMUFILE=IMU CSV full path: 
if "%IMUFILE%"=="" goto END
set /p CHANNEL=Roll or pitch [pitch]: 
if "%CHANNEL%"=="" set "CHANNEL=pitch"
"%PYTHON%" tools\replay_v79.py "%IMUFILE%" --channel "%CHANNEL%" --frequency .3 --start-s 12
:END
pause
endlocal
