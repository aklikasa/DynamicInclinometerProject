@echo off
cd /d "%~dp0"
echo Optional thermal-chamber PLC dependencies only. Ambient ACC/GYRO calibration does not require this.
call "INSTALL_DEPENDENCIES_DEBUG.cmd" --mode plc
