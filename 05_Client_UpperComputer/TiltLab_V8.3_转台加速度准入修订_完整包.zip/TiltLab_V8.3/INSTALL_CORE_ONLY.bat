@echo off
cd /d "%~dp0"
echo [INFO] ADVANCED: PCB server only. This does NOT install R10 GUI.
call "INSTALL_DEPENDENCIES_DEBUG.cmd" --mode core
exit /b %errorlevel%
