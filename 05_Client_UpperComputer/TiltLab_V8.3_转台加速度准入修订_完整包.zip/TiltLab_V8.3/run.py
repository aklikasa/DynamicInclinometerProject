"""TiltLab V8.1 integrated workstation; localhost port 8877, no automatic hardware connect."""
import os,socket,sys,threading,time,webbrowser
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[key]='1'
os.chdir(os.path.dirname(os.path.abspath(__file__)))
PORT=8877
if __name__=='__main__':
    import multiprocessing
    multiprocessing.freeze_support()
    import uvicorn
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as sock:
        try:sock.bind(('127.0.0.1',PORT))
        except OSError:
            print(f'[ERROR] Port {PORT} is already occupied. Close that service; this launcher will NOT open a potentially old page.')
            sys.exit(2)
    url=f'http://127.0.0.1:{PORT}/'
    print('TILTLAB V8.1.0  |  INTEGRATED REAL DYNAMIC TEST  |  '+url,flush=True)
    print('Close old TiltLab windows first so COM ports are not held by old instances.',flush=True)
    threading.Thread(target=lambda:(time.sleep(2),webbrowser.open(url)),daemon=True).start()
    uvicorn.run('app.main:app',host='127.0.0.1',port=PORT,log_level='warning')
