"""离线恢复工具：不打开串口、不加载2TD600.dll、不控制转台。"""
from pathlib import Path
from app.offline_recovery import recover_report

def main():
    print('2TD600 既有数据离线分析：只读CSV，不连接转台，不发送任何运动指令。')
    print('请将本次 *_DYNAMIC.json 和对应的 _table.csv、_imu.csv 放在同一目录。')
    text=input('输入本次 *_DYNAMIC.json 完整路径（可拖入文件）: ').strip().strip('"').strip("'")
    if not text:return
    try:
        json_path,html_path,data=recover_report(Path(text))
        print('数据状态：',data['state'])
        print('角度曲线与误差曲线：',html_path)
        print('研究级JSON分析报告：',json_path)
        print('注意：原实验停车状态不变；离线分析绝不等同安全确认。')
    except Exception as exc:print('无法分析：',type(exc).__name__,str(exc))
    input('按回车结束...')
if __name__=='__main__':main()
