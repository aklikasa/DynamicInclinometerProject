@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto FAILED
if not exist "run.py" goto FAILED
if not exist "tools\setup_v730.py" goto FAILED
if not exist "tools\r10_dependency_smoketest.py" goto FAILED
if not exist "install_logs" mkdir "install_logs"
set "PY_CMD="
set "PY_ARG="
set "INSTALL_ARGS=%*"
set "VERIFY_R10=1"
rem Default installer restores the old one-click PCB + ambient R10 behavior.
if "%~1"=="" set "INSTALL_ARGS=--mode r10"
if /i "%~1"=="--mirror" set "INSTALL_ARGS=--mode r10 --mirror"
rem Advanced modes are allowed, but do not claim R10 verified for core/research.
if /i "%~1"=="--mode" if /i "%~2"=="core" set "VERIFY_R10=0"
if /i "%~1"=="--mode" if /i "%~2"=="research" set "VERIFY_R10=0"
echo =========================================================
echo  TiltLab V8.1 - ONE-CLICK INSTALL (PCB + R10 AMBIENT)
echo  Only missing packages are downloaded; existing .venv reused.
echo =========================================================
if exist ".venv\Scripts\python.exe" goto ENV_READY
rem Choose a 64-bit supported Python. Prefer already installed 3.13.
py -3.13 -c "import sys;assert sys.maxsize>2**32" >nul 2>&1
if not errorlevel 1 (
  set "PY_CMD=py"
  set "PY_ARG=-3.13"
  goto CREATE_VENV
)
py -3.12 -c "import sys;assert sys.maxsize>2**32" >nul 2>&1
if not errorlevel 1 (
  set "PY_CMD=py"
  set "PY_ARG=-3.12"
  goto CREATE_VENV
)
py -3.11 -c "import sys;assert sys.maxsize>2**32" >nul 2>&1
if not errorlevel 1 (
  set "PY_CMD=py"
  set "PY_ARG=-3.11"
  goto CREATE_VENV
)
py -3.10 -c "import sys;assert sys.maxsize>2**32" >nul 2>&1
if not errorlevel 1 (
  set "PY_CMD=py"
  set "PY_ARG=-3.10"
  goto CREATE_VENV
)
python -c "import sys;assert (3,10)<=sys.version_info[:2]<=(3,13) and sys.maxsize>2**32" >nul 2>&1
if not errorlevel 1 (
  set "PY_CMD=python"
  goto CREATE_VENV
)
echo [FAILED] No supported 64-bit Python 3.10-3.13 found.
goto FAILED
:CREATE_VENV
echo [STEP 1/3] Creating .venv in this project folder (only once) ...
%PY_CMD% %PY_ARG% -m venv .venv
if errorlevel 1 goto FAILED
:ENV_READY
if not exist ".venv\Scripts\python.exe" goto FAILED
echo [STEP 1/3] Using local Python: %CD%\.venv
".venv\Scripts\python.exe" --version
if errorlevel 1 goto FAILED
echo [STEP 2/3] Checking/installing required modules in SAME .venv ...
echo [INFO] Default mode installs PCB and ambient R10 dependencies together.
echo [INFO] Thermal chamber PLC/snap7 NOT required for ambient ACC/GYRO.
echo [INFO] Network is skipped when all required imports already pass.
".venv\Scripts\python.exe" -u "tools\setup_v730.py" --log "install_logs\install_v81.txt" %INSTALL_ARGS%
if errorlevel 1 goto FAILED
if "%VERIFY_R10%"=="0" goto DONE_CORE
:VERIFY_WORKER
echo [STEP 3/3] Checking R10 Python imports and packaged files (NO DLL load) ...
set "PYTHONIOENCODING=utf-8"
".venv\Scripts\python.exe" "tools\r10_dependency_smoketest.py" >"install_logs\r10_worker_check.txt" 2>&1
if errorlevel 1 goto FAILED_R10
if exist "install_logs\r10_worker_check.txt" type "install_logs\r10_worker_check.txt"
echo [SUCCESS] PCB dependencies and ambient R10 Python module import check passed.
echo [NEXT] Run START_TILT_LAB.bat. This check does NOT validate motors/PCB.
goto DONE
:DONE_CORE
echo [SUCCESS] Selected dependencies ready; R10 was NOT verified in this mode.
echo [NEXT] For ambient R10 use INSTALL_DEPENDENCIES.bat.
goto DONE
:FAILED_R10
echo [FAILED] R10 import smoke-test failed. pip success alone is NOT sufficient.
echo [DETAIL] install_logs\r10_worker_check.txt
if exist "install_logs\r10_worker_check.txt" type "install_logs\r10_worker_check.txt"
goto FAILED
:FAILED
echo.
echo [FAILED] Dependency setup NOT complete for this selected mode.
echo [LOG] install_logs\install_v81.txt
set "RESULT=1"
goto END
:DONE
set "RESULT=0"
:END
echo.
pause
endlocal & exit /b %RESULT%
