"""V7.27 direct per-axis vendor controls with monitored finite-duration jobs.

This is a research UI integration, not a safety-rated motion controller.
Only existing 2TD600 vendor functions are called. All continuous operations
require a live browser heartbeat, verified feedback, position envelope and STOP.
"""
from __future__ import annotations
from contextlib import contextmanager, ExitStack

import math
import threading
import time
from .angles import angle_delta_deg, zero_distance_deg
from .table_diagnostics import DIAG
from .sway_envelope import verify_sway_motion
from .motion_profile_v728 import position_limits

class NativeAxisConsole:
    def __init__(self, table, occupied, admission_locks=()):
        self.table=table
        self.occupied=occupied
        self.lock=threading.RLock()
        self.admission_locks=tuple(admission_locks)
        self.cancel=threading.Event()
        self.running=False
        self.safety_latched=False
        self.state='idle'
        self.error=''
        self.axis=None
        self.mode=None
        self.args={}
        self.heartbeat_ns=0
        self.stopped_verified=None
        self.thread=None
        self.last_feedback=None

    def status(self):
        with self.lock:
            return {'running':self.running,'safety_latched':self.safety_latched,
                    'state':self.state,'error':self.error,'axis':self.axis,
                    'mode':self.mode,'arguments':dict(self.args),
                    'stopped_verified':self.stopped_verified,
                    'last_feedback':self.last_feedback}

    @contextmanager
    def _admission(self):
        # Serialize motor admissions against the pre-existing guarded-position
        # and servo-disable controllers. Their own locks remain unchanged.
        with ExitStack() as stack:
            for lock in self.admission_locks:
                stack.enter_context(lock)
            stack.enter_context(self.lock)
            yield

    def _exclusive(self):
        if not self.table.connected:raise ValueError('请先连接转台')
        if self.running or self.occupied():raise ValueError('有其他转台运动/记录/维护任务正在进行')
        if self.safety_latched:raise ValueError('上次任务停车确认失败，本进程拒绝再次启动运动')

    @staticmethod
    def _limits(axis):
        return position_limits(axis)

    def _read_checked(self,axis,*,allow_unzeroed=False,stationary=False):
        data=self.table.read_status()
        axes=data['axes']
        for which in (0,2):
            s=axes[str(which)]
            if (not s['healthy'] and s['enabled']) or any(s[k] for k in ('driver_fault','upper_limit','lower_limit','over_speed')):
                raise ValueError(f'轴{which}异常、限位或驱动器报警')
            for key in ('position_deg','speed_dps'):
                if not math.isfinite(float(s[key])):raise ValueError('厂家DLL位置或速度反馈无效')
            if stationary and (abs(s['speed_dps'])>.06 or s['mode'] not in (0,2,20)):
                raise ValueError(f'轴{which}正在运动，不能启动另一动作')
        current=axes[str(axis)]
        if not current['enabled']:raise ValueError(f'轴{axis}未使能')
        if not allow_unzeroed and not current['zeroed']:raise ValueError(f'轴{axis}尚未机械找零')
        return data

    def enable_axis(self,axis):
        axis=int(axis)
        with self._admission():
            self._exclusive()
            if axis not in (0,2):raise ValueError('轴号必须是0或2')
            before=self.table.read_status()
            for a in (0,2):
                x=before['axes'][str(a)]
                if any(x[k] for k in ('driver_fault','upper_limit','lower_limit','over_speed')) or abs(x['speed_dps'])>.06:
                    raise ValueError('驱动异常或转台仍在运动，拒绝使能')
            if not before['axes'][str(axis)]['enabled']:
                self.table.enable_axis(axis)
            after=self.table.read_status()
            if not after['axes'][str(axis)]['enabled'] or not after['axes'][str(axis)]['healthy']:
                raise RuntimeError('DLL使能指令发出，但未观察到使能反馈')
            DIAG.snapshot('native_axis_enabled',after,f'轴{axis}单独使能')
            return {'axis':axis,'enabled':True,'status':after}

    def start(self,axis,mode,*,speed=10.,accel=.5,amp=5.,freq=.3,duration=10.):
        axis=int(axis)
        if mode not in ('velocity','sway','home'):raise ValueError('未知的厂商运动模式')
        if axis not in (0,2):raise ValueError('仅支持轴0和轴2')
        values=(speed,accel,amp,freq,duration)
        if any(not isinstance(v,(int,float)) or not math.isfinite(v) for v in values):
            raise ValueError('运动参数必须是有限数字')
        with self._admission():
            self._exclusive()
            data=self._read_checked(axis,allow_unzeroed=(mode=='home'),stationary=True)
            st=data['axes'][str(axis)]
            another=data['axes'][str(2 if axis==0 else 0)]
            if mode!='home':
                if not another['zeroed'] or not another['enabled']:
                    raise ValueError('另一轴尚未使能/找零')
            lo,hi=self._limits(axis)
            position=angle_delta_deg(st['position_deg']) if axis==2 else float(st['position_deg'])
            if mode=='velocity':
                if speed == 0 or not(.1<=accel<=5.):
                    raise ValueError('速度须为非零有限数值，角加速度须在0.1–5°/s²')
                if not(.5<=duration<=15.):raise ValueError('连续速度运动时长须为0.5–15秒')
                # R10 vendor controller, not the former software profile, is
                # authoritative for accepted speeds. Hard limit flags, STOP,
                # heartbeat, finite duration and feedback remain monitored.
            elif mode=='sway':
                if not (.2<=amp<=20. and .01<=freq<=.8 and 1.<=duration<=90.):
                    raise ValueError('摇摆幅度、频率或时长无效')
                verify_sway_motion(amp,freq)
                if position-amp<lo+.2 or position+amp>hi-.2:
                    raise ValueError('摇摆目标区间超出已验证的行程，请先调整轴位置')
            else:
                if not (.1<=speed<=.5 and .1<=accel<=.5):
                    raise ValueError('机械找零速度/角加速度须在0.1–0.5范围内')
                if not (5.<=duration<=180.):raise ValueError('机械找零监控最长180秒')
            self.cancel.clear()
            self.running=True
            self.state='running'
            self.error=''
            self.axis=axis
            self.mode=mode
            self.args={'speed_dps':speed,'accel_dps2':accel,'amplitude_deg':amp,'frequency_hz':freq,'duration_s':duration}
            self.stopped_verified=None
            self.heartbeat_ns=time.monotonic_ns()
            self.last_feedback=None
            DIAG.record('native_manual_started','V7.27 厂家接口逐轴运动',axis=axis,mode=mode,args=self.args)
            self.thread=threading.Thread(target=self._run,daemon=True,name='2TD600-native-console')
            self.thread.start()
            return self.status()

    def heartbeat(self):
        with self.lock:
            if not self.running:raise ValueError('当前没有手动厂商运动任务')
            self.heartbeat_ns=time.monotonic_ns()
            return {'ok':True}

    def abort(self):
        self.cancel.set()
        if self.table.connected:self.table.stop()
        return self.status()

    def _run(self):
        mode,axis,params=self.mode,self.axis,dict(self.args)
        try:
            if mode=='velocity':
                self.table.velocity(axis,params['speed_dps'],params['accel_dps2'])
            elif mode=='sway':
                self.table.sway(axis,params['amplitude_deg'],params['frequency_hz'])
            else:
                self.table.find_zero(axis,params['speed_dps'],params['accel_dps2'])
            deadline=time.monotonic()+params['duration_s']
            # For home, a successful homed + stationary feedback ends early.
            home_stable=0
            while time.monotonic()<deadline:
                if self.cancel.is_set():raise RuntimeError('用户点击停止')
                if time.monotonic_ns()-self.heartbeat_ns>6_000_000_000:
                    raise RuntimeError('浏览器心跳超时6秒，执行双轴停车')
                if not self.table.connected:raise RuntimeError('设备失去连接')
                data=self._read_checked(axis,allow_unzeroed=(mode=='home'))
                axes=data['axes'];current=axes[str(axis)]
                if mode=='velocity':
                    # Do not infer physical end stops from modulo-360 angles.
                    # _read_checked() still stops on vendor hard-limit/fault flags.
                    if abs(current['speed_dps'])>abs(params['speed_dps'])+1.0:
                        raise RuntimeError('实际速度高于命令速度，执行停车')
                if mode=='sway':
                    lo,hi=self._limits(axis)
                    if (angle_delta_deg(current['position_deg']) if axis==2 else current['position_deg'])<lo-.5 or (angle_delta_deg(current['position_deg']) if axis==2 else current['position_deg'])>hi+.5:
                        raise RuntimeError('摇摆反馈超出软件行程边界，执行停车')
                self.last_feedback={'time_monotonic_ns':data.get('time_monotonic_ns'),
                        'axis':axis,'position_deg':current['position_deg'],'speed_dps':current['speed_dps']}
                if mode=='home':
                    if current['zeroed'] and abs(current['speed_dps'])<.06 and current['mode'] in (0,2,20):
                        home_stable+=1
                        if home_stable>=3:break
                    else:home_stable=0
                if self.cancel.wait(.14):raise RuntimeError('用户点击停止')
            else:
                if mode=='home':raise TimeoutError('机械找零未在设定时长内确认完成')
            self.state='finished'
        except Exception as exc:
            self.state='failed'
            self.error=f'{type(exc).__name__}: {exc}'
            DIAG.record('native_manual_failed','逐轴运动中止/异常，准备STOP',error=self.error,axis=axis,mode=mode)
        finally:
            try:
                self.table.stop()
                verified=self.table.stopped_verified(timeout=20)
                self.stopped_verified=bool(verified)
                if not verified:
                    self.safety_latched=True
                    self.state='failed'
                    self.error+='；STOP未获反馈确认，请使用实体急停'
            except Exception as exc:
                self.stopped_verified=False
                self.safety_latched=True
                self.state='failed'
                self.error+='；STOP调用失败：'+repr(exc)
            finally:
                DIAG.record('native_manual_finished','V7.27厂家操作结束',axis=axis,mode=mode,
                            state=self.state,verified=self.stopped_verified,error=self.error)
                with self.lock:self.running=False
