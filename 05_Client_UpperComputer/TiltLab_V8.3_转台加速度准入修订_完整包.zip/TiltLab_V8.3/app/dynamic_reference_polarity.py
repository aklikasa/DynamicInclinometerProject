"""Post-stop, read-only reference sign inference for dynamic sway reports.

This is a comparison-coordinate diagnostic only. It NEVER commands hardware,
reverses a motor, edits calibration, time-shifts the IMU, or overwrites raw CSV.
The sign must be corroborated by independently measured calibrated gravity
angle and calibrated gyro rate, rather than selected to minimize fusion errors.
"""
from __future__ import annotations

import math
import numpy as np
from .angles import unwrap_encoder_deg


def infer_dynamic_reference_polarity(table_rows, imu_rows, axis, output,
                                      requested_sign, motion_start_ns,
                                      motion_end_ns, recover_timebase):
    result = {
        'valid': False, 'output': output, 'requested_sign': requested_sign,
        'selected_sign': None, 'changed': False,
        'method': 'post_stop_calibrated_accel_and_gyro_rate_vs_real_encoder',
        'hardware_synchronized': False, 'channels': {},
        'note': ('仅校正报告中转台编码器的比较符号；没有额外运动、时间平移、'
                 '误差最小化选符号、修改厂标定或更改转台运动方向。'),
    }
    def reject(msg):
        result['reason'] = msg
        return result
    if output not in ('roll', 'pitch') or axis not in (0, 2) or requested_sign not in (-1, 1):
        return reject('测试方向或输入符号无效')
    if not motion_start_ns or not motion_end_ns or len(table_rows) < 30 or len(imu_rows) < 150:
        return reject('缺少足够的真实转台或IMU运动记录')
    try:
        tt = np.array([float(r['pc_mid_ns']) / 1e9 for r in table_rows])
        enc = unwrap_encoder_deg([float(r[f'axis_{axis}_pos']) for r in table_rows])
        ti, info = recover_timebase(imu_rows, int(tt[0] * 1e9), int(tt[-1] * 1e9))
        if not (np.isfinite(tt).all() and np.isfinite(ti).all()
                and np.all(np.diff(tt) > 0) and np.all(np.diff(ti) > 0)):
            return reject('IMU/转台时间戳非严格递增，无法安全判断参考方向')
        start, end = motion_start_ns / 1e9, motion_end_ns / 1e9
        # Exclude startup and shutdown transients. A sign check uses only actual
        # measured movement, never the commanded sine phase or desired angle.
        motion = (ti >= start + 0.6) & (ti <= end - 0.6)
        right = np.clip(np.searchsorted(tt, ti, side='right'), 1, len(tt)-1)
        gap_ok = (tt[right] - tt[right-1]) <= 0.4
        motion &= (ti >= tt[0]) & (ti <= tt[-1]) & gap_ok
        indices = np.flatnonzero(motion)
        if len(indices) < 150:
            return reject('没有足够的连续真实运动数据或参考时间覆盖')
        indices = indices[::max(1, math.ceil(len(indices) / 3500))]
        x = np.interp(ti[indices], tt, enc)
        # Derivative from independently read encoder samples. No fit to a
        # commanded waveform and no late/early shift selected to improve error.
        speed = np.gradient(enc, tt)
        ref_rate = np.interp(ti[indices], tt, speed)
        if np.ptp(x) < 0.3 or np.std(ref_rate) < 0.1:
            return reject('实际运动幅值或角速度不足，无法识别参考方向')
        # The calibrated ACC tilt is geometrically independent of the gyro
        # rate; both must agree. Target axes reflect TiltLab's roll/pitch
        # conventions, not the signs of motor commands.
        gravity_key = f'cal_accel_{output}'
        gyro_axis = 'x' if output == 'roll' else 'y'
        rate_key = f'cal_gyro_{gyro_axis}_dps'
        for label, key, ref in (('calibrated_accel_tilt', gravity_key, x),
                                ('calibrated_gyro_rate', rate_key, ref_rate)):
            y = np.array([float(imu_rows[i].get(key) or 'nan') for i in indices])
            good = np.isfinite(y) & np.isfinite(ref)
            if good.sum() < 120:
                return reject('缺少有效的'+label+'数据，拒绝自动判定')
            xg, yg = ref[good], y[good]
            corr = float(np.corrcoef(xg, yg)[0, 1])
            gain = float(np.polyfit(xg, yg, 1)[0])
            result['channels'][label] = {
                'samples': int(good.sum()), 'slope': round(gain, 6),
                'correlation': round(corr, 6), 'vote': 1 if gain > 0 else -1,
            }
            if not (math.isfinite(corr) and abs(corr) >= 0.85 and 0.45 <= abs(gain) <= 2.0):
                return reject(label+'与转台反馈幅值/相关性不一致，禁止自动改变方向')
        votes = {c['vote'] for c in result['channels'].values()}
        if len(votes) != 1:
            return reject('校正后的重力倾角与陀螺角速度方向不一致，保留手动符号并标记待核验')
        selected = votes.pop()
        result.update(valid=True, selected_sign=selected,
                      changed=selected != requested_sign,
                      samples_used=len(indices),
                      reason=('经校正ACC倾角和GYRO角速度双通道核对，报告比较方向应为'
                              + ('同向（+）' if selected == 1 else '反向（−）')))
        result['timebase_note'] = info.get('time_source', 'unsynchronized')
        return result
    except (ValueError, TypeError, KeyError, IndexError, FloatingPointError,
            np.linalg.LinAlgError) as exc:
        return reject('参考方向诊断失败：'+str(exc))
