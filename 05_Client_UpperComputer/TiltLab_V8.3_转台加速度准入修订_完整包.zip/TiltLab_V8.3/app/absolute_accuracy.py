"""Independent absolute angle error on estimated, UNSYNCHRONIZED clocks.
No per-run zero removal, phase fit, gain fit or invented reference samples.
"""
import math
import numpy as np
from .angles import unwrap_encoder_deg

RESEARCH_LEVER_ALGORITHMS={'gyro_anchor3d','adaptive3d','lever3d','leverarm','adaptive_lever','vqf_lever'}

def lever_status(algorithm,params):
    if algorithm in RESEARCH_LEVER_ALGORITHMS:return 'research_lever_branch'
    if algorithm=='gyro_anchor' and abs(float(params.get('lever_z_cm',0)))>1e-10:return 'research_lever_branch'
    return 'no_lever'

def absolute_metrics(table_rows,imu_rows,axis,output,sign,start_ns,end_ns,relative,algorithms,recover):
    out={'available':False,'certified_dynamic_accuracy':False,'reference':'sign × actual encoder angle; encoder 0° must be physically aligned to gravity datum',
         'method':'不扣初始零位；原始估算时间轴；实测编码器线性插值；>400ms参考缺口不插值；未硬件同步。',
         'scopes':{},'comparison':[],'chart':[]}
    if len(table_rows)<2 or len(imu_rows)<2:return out
    ts=np.array([float(r['pc_mid_ns'])/1e9 for r in table_rows]);ix,clock=recover(imu_rows,int(ts[0]*1e9),int(ts[-1]*1e9))
    if not (np.isfinite(ts).all() and np.isfinite(ix).all()) or np.any(np.diff(ts)<=0) or np.any(np.diff(ix)<=0):return out
    p=unwrap_encoder_deg([float(r[f'axis_{axis}_pos']) for r in table_rows]);p=p-360*round(float(p[0])/360)
    start=start_ns/1e9;end=end_ns/1e9
    right=np.clip(np.searchsorted(ts,ix,side='right'),1,len(ts)-1)
    good=(ix>=ts[0])&(ix<=ts[-1])&((ts[right]-ts[right-1])<=.4+1e-10)
    # Keep exact observed encoder timestamps even at the edge of a stale bracket.
    good |= (ix==ts[right]) | (ix==ts[right-1])
    ref=sign*np.interp(ix,ts,p)
    full=(ix>=start)&(ix<=end)
    masks={'full_motion':full}
    st=(relative.get('reference_steady_state') or {})
    if st.get('valid') and not relative.get('partial_research_only') and relative.get('valid'):
        masks['steady']=(ix>=float(st['steady_start_s']))&(ix<=float(st.get('steady_end_s',end-.3)))
    curves={}
    for scope,window in masks.items():
        mask=window&good;total=int(window.sum());n=int(mask.sum())
        out['scopes'][scope]={'imu_samples_in_window':total,'reference_comparable_samples':n,'excluded_reference_samples':total-n,
                             'reference_coverage_pct':round(100*n/max(1,total),4),'complete_reference_coverage':bool(total and n==total)}
        if n<2:continue
        for ch in ('cal_factory','cal','raw'):
            for alg in algorithms:
                col=f'{ch}_{alg}_{output}';v=np.array([float(r[col]) if r.get(col) not in (None,'') else np.nan for r in imu_rows]);use=mask&np.isfinite(v)
                if use.sum()<2:continue
                err=(v[use]-ref[use]+180)%360-180;idx=np.flatnonzero(use);j=int(np.argmax(np.abs(err)));i=idx[j]
                row={'scope':scope,'channel':ch,'algorithm':alg,'samples':int(use.sum()),'excluded_output_samples':n-int(use.sum()),
                     'absolute_angle_rmse_deg':round(float(np.sqrt(np.mean(err**2))),6),'absolute_max_error_deg':round(float(np.max(np.abs(err))),6),
                     'absolute_p95_error_deg':round(float(np.percentile(np.abs(err),95)),6),'signed_mean_error_deg':round(float(np.mean(err)),6),
                     'max_error_time_s':round(float(ix[i]-start),6),'max_error_imu_deg':round(float(v[i]),6),'max_error_reference_deg':round(float(ref[i]),6),'max_error_signed_deg':round(float(err[j]),6)}
                out['comparison'].append(row)
                if scope=='full_motion':curves[f'{ch}_{alg}']=v
    ids=np.flatnonzero(full);stride=max(1,math.ceil(len(ids)/650));plot_ids=set(ids[::stride].tolist())
    # Include every channel's true peak in the plot, not just regular decimation.
    for row in out['comparison']:
        if row['scope']=='full_motion':plot_ids.add(int(np.argmin(abs(ix-start-row['max_error_time_s']))))
    for i in sorted(plot_ids):
        if not good[i]:out['chart'].append({'t_s':round(float(ix[i]-start),6),'reference_deg':None,'angles':{},'errors':{}});continue
        angles={k:round(float(v[i]),6) for k,v in curves.items() if np.isfinite(v[i])}
        out['chart'].append({'t_s':round(float(ix[i]-start),6),'reference_deg':round(float(ref[i]),6),'angles':angles,
                             'errors':{k:round(float((v-ref[i]+180)%360-180),6) for k,v in angles.items()}})
    out['available']=bool(out['comparison']);return out
