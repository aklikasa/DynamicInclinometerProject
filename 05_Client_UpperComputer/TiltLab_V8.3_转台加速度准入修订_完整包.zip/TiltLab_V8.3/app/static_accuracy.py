"""Controlled static-angle verification preceding manufacturer-native sway.

Nothing here changes the native sway controller or the safety stop logic.
All commands are limited to outer axis 2 small-angle positioning in an
operator-approved, monitored workflow; inner 0/90 is handled separately.
"""
from __future__ import annotations
import datetime as dt
import json,math,time
from pathlib import Path
import numpy as np
from .angles import angle_delta_deg
from .table_diagnostics import DIAG

# Repeat 5/3/1/0/-1/-3/-5 in both travel directions to identify hysteresis.
STATIC_STEPS=(-5.,-3.,-1.,0.,1.,3.,5.,3.,1.,0.,-1.,-3.,-5.,0.)


def summarize_static(steps, output, reference_sign, threshold_deg, active_algo='complementary'):
    """Analyze absolute stationary angle errors relative to ACTUAL encoder angles.

    No arbitrary zeroing, scaling or curve fitting is subtracted from the
    official static errors. Regression is a separate descriptive diagnostic.
    """
    if len(steps)<7 or output not in ('roll','pitch') or reference_sign not in (-1,1):
        return {'valid':False,'reason':'静态数据不完整或映射无效'}
    result={'valid':True,'reference_sign':reference_sign,'direction':output,
            'threshold_deg':float(threshold_deg),'algorithm_metrics':{},
            'note':'原始静态绝对误差＝IMU角度－方向符号×转台实测角度。诊断性线性拟合不用于删减误差。'}
    for channel in ('cal','raw'):
        names=set.intersection(*(set(st.get('angles',{}).get(channel,{}) or {}) for st in steps))
        for algo in sorted(names):
            rows=[]
            for st in steps:
                m=st.get('angles',{}).get(channel,{}).get(algo)
                if not m or output not in m:break
                measured=float(m[output]); ref=reference_sign*float(st['actual_outer_deg'])
                if not (math.isfinite(measured) and math.isfinite(ref)):break
                rows.append((float(st['actual_outer_deg']),measured,ref,
                             float(m.get('roll' if output=='pitch' else 'pitch',float('nan'))),st.get('travel',''),float(st['target_deg'])))
            if len(rows)!=len(steps):continue
            data=np.array([[a,b,c,d] for a,b,c,d,_,_ in rows],dtype=float)
            errors=data[:,1]-data[:,2]
            # Estimated scale/bias are diagnostics, NEVER applied to error values.
            reg=np.polyfit(data[:,2],data[:,1],1)
            residual=data[:,1]-(reg[0]*data[:,2]+reg[1])
            centers={}
            for actual,measured,ref,cross,travel,nominal in rows:
                key=round(nominal,4)
                centers.setdefault(key,{}).setdefault(travel,[]).append(measured)
            hysteresis=[abs(float(np.mean(d['out']))-float(np.mean(d['back'])))
                        for d in centers.values() if 'out' in d and 'back' in d]
            other=(data[:,3]-data[:,3].mean()) if np.all(np.isfinite(data[:,3])) else np.full(len(data),np.nan)
            cross_gain=float(np.polyfit(data[:,2],other,1)[0]) if np.all(np.isfinite(other)) else None
            result['algorithm_metrics'][f'{channel}_{algo}']={
                'samples':len(rows), 'mean_signed_error_deg':round(float(errors.mean()),6),
                'static_rmse_deg':round(float(np.sqrt(np.mean(errors**2))),6),
                'static_p95_abs_deg':round(float(np.percentile(np.abs(errors),95)),6),
                'static_max_abs_deg':round(float(np.max(np.abs(errors))),6),
                'static_zero_bias_deg':round(float(np.mean([b for a,b,c,d,z,nominal in rows if abs(nominal)<1e-6])),6),
                'observed_gain':round(float(reg[0]),6),
                'gain_error_percent':round(float(100*(reg[0]-1)),5),
                'linearity_residual_rmse_deg':round(float(np.sqrt(np.mean(residual**2))),6),
                'hysteresis_max_deg':round(max(hysteresis) if hysteresis else float('nan'),6),
                'cross_axis_slope':round(cross_gain,6) if cross_gain is not None else None,
                'errors_deg':[round(float(e),6) for e in errors]}
    check=result['algorithm_metrics'].get(f'cal_{active_algo}')
    if check is None:
        result.update(pass_for_chosen_algorithm=False,reason=f'当前算法{active_algo}未获得有效标定静态输出')
    else:
        result.update(pass_for_chosen_algorithm=check['static_max_abs_deg']<=threshold_deg,
                      chosen_algorithm=active_algo,
                      chosen_static_max_abs_deg=check['static_max_abs_deg'],
                      reason=('静态绝对误差满足用户设置的研发阈值' if check['static_max_abs_deg']<=threshold_deg
                              else f'静态最大绝对误差{check["static_max_abs_deg"]:.4f}°超过{threshold_deg:.3f}°研发参考阈值'))
    return result


class StaticBeforeDynamic:
    def __init__(self,table,engine,folder):
        self.table=table;self.engine=engine;self.folder=Path(folder)
        self._collect_mount_gyro=False;self._mount_gyro_moving=[]

    def _check(self,watcher,target_inner,outer_target):
        watcher()
        st=self.table.read_status()
        axes=st['axes']
        for idx in (0,2):
            x=axes[str(idx)]
            if not(x.get('enabled') and x.get('zeroed') and x.get('healthy')):
                raise RuntimeError(f'静态前检：轴{idx}未使能/未找零/状态异常')
            if any(x.get(k) for k in ('driver_fault','upper_limit','lower_limit','over_speed')):
                raise RuntimeError(f'静态前检：轴{idx}限位/故障/超速')
        if abs(angle_delta_deg(axes['0']['position_deg'],target_inner))>.20:
            raise RuntimeError('静态前检：内轴离开当前Roll/Pitch工况')
        if abs(float(axes['0']['speed_dps']))>.06:
            raise RuntimeError('静态前检：内轴运动中')
        return axes

    def _collect_moving_samples(self,last_sequence):
        """Collect only NEW calibrated gyro vectors while a static move is pending.

        IMU recent is a bounded ring: poll inside the existing 150ms safety
        loop, rather than reading it after 2 seconds of settling when the
        movement samples might have been evicted.
        """
        if not self._collect_mount_gyro:return last_sequence
        with self.engine.lock:
            fresh=[]
            for r in reversed(self.engine.recent):
                if r.get('sequence',0)<=last_sequence:break
                fresh.append(r)
        fresh.reverse()
        for r in fresh:
            vals=r.get('gyro_cal')
            if vals is None:continue
            try:v=[float(x) for x in vals]
            except (ValueError,TypeError):continue
            if len(v)==3 and all(math.isfinite(x) for x in v):
                self._mount_gyro_moving.append(v)
        return max((int(r.get('sequence',0)) for r in fresh),default=last_sequence)

    def _position_outer(self,target,watcher,inner,speed):
        axes=self._check(watcher,inner,target)
        current=angle_delta_deg(axes['2']['position_deg'])
        if abs(current-target)<.06 and abs(axes['2']['speed_dps'])<.06:
            return
        if abs(axes['2']['speed_dps'])>.06 or axes['2']['mode'] not in (0,2,20):
            raise RuntimeError('外轴处于运动模式，不能开始静态定位')
        with self.engine.lock:
            last_sequence=int(self.engine.counter)
        self.table.move(2,target,speed)
        deadline=time.monotonic()+max(18,2.2*abs(target-current)/speed+15)
        consecutive=0
        while time.monotonic()<deadline:
            axes=self._check(watcher,inner,target);outer=axes['2']
            last_sequence=self._collect_moving_samples(last_sequence)
            if (abs(angle_delta_deg(outer['position_deg'],target))<.07 and
                abs(outer['speed_dps'])<.06 and outer['mode'] in (0,2,20)):
                consecutive+=1
                if consecutive>=3:
                    self._collect_moving_samples(last_sequence)
                    return
            else:consecutive=0
            time.sleep(.15)
        raise TimeoutError(f'外轴静态定位{target:+.1f}°超时；保留停车安全保护')

    def _sample(self,target,watcher,inner,output,sign,uid,active,travel):
        # 0.6s settling and >=1.8s read-only observation.
        at=time.monotonic()+.55
        while time.monotonic()<at:
            self._check(watcher,inner,target);time.sleep(.10)
        starts=time.monotonic_ns();readings=[]
        for i in range(11):
            axes=self._check(watcher,inner,target)
            x=axes['2']
            if abs(angle_delta_deg(x['position_deg'],target))>.12:
                raise RuntimeError('静态采样：角度已离开目标位置')
            if abs(x['speed_dps'])>.06 or x['mode'] not in (0,2,20):
                raise RuntimeError('静态采样：转台反馈非静止，不能把运动数据作为静态精度')
            readings.append(angle_delta_deg(x['position_deg']))
            if i<10:time.sleep(.19)
        ended=time.monotonic_ns()
        if max(readings)-min(readings)>.025:
            raise RuntimeError('静态采样：2秒内编码器位置变化过大')
        with self.engine.lock:
            rows=[]
            for r in reversed(self.engine.recent):
                observed=r.get('pc_observed_ns',0)
                if observed<starts:break
                if observed<=ended and r.get('uid')==uid:rows.append(r)
        rows.reverse()
        if len(rows)<100:raise RuntimeError('静态采样：有效IMU样本不足100条')
        angles={'cal':{},'raw':{}}
        algos=set.intersection(*(set(r.get('outputs',{})) for r in rows))
        for channel in ('cal','raw'):
            for algo in algos:
                v=[r.get('outputs',{}).get(algo,{}).get(channel) for r in rows]
                v=[x for x in v if x is not None and math.isfinite(float(x['roll'])) and math.isfinite(float(x['pitch']))]
                if len(v)<max(60,int(.75*len(rows))):continue
                angles[channel][algo]={'roll':float(np.mean([x['roll'] for x in v])),
                                       'pitch':float(np.mean([x['pitch'] for x in v])),
                                       'roll_std':float(np.std([x['roll'] for x in v])),
                                       'pitch_std':float(np.std([x['pitch'] for x in v]))}
        # The settled rows supply a gyro bias/noise baseline for
        # mounting-axis PCA. Never estimate this bias from the moving data.
        stationary=[]
        for r in rows:
            v=r.get('gyro_cal')
            if v is None:continue
            try:v=[float(x) for x in v]
            except (ValueError,TypeError):continue
            if len(v)==3 and all(math.isfinite(x) for x in v):stationary.append(v)
        gyro_stationary={}
        if len(stationary)>=100:
            gyro_stationary={'mean':np.mean(stationary,axis=0).tolist(),
                             'std':np.std(stationary,axis=0).tolist(),
                             'count':len(stationary)}
        if f'{output}' not in angles['cal'].get(active,{}):
            raise RuntimeError(f'静态采样：当前融合算法{active}缺少标定后的{output}输出')
        return {'target_deg':target,'travel':travel,'actual_outer_deg':float(np.mean(readings)),
                'actual_inner_deg':float(inner),'imu_sample_count':len(rows),
                'encoder_spread_deg':float(max(readings)-min(readings)),
                'gyro_cal_stationary':gyro_stationary,
                'angles':angles,'current_algorithm':active,
                'current_signed_error_deg':angles['cal'][active][output]-sign*float(np.mean(readings))}

    def run(self,output,inner_target,sign,speed,threshold_deg,watcher,progress=None,span_deg=5.):
        # On cancel, watchdog loss, controller fault or any exception, release
        # the collector. The parent auto-workflow retains original stop and
        # physical stopped_verified semantics; never touch those here.
        try:
            return self._run_measurement(output,inner_target,sign,speed,
                                         threshold_deg,watcher,progress,span_deg)
        finally:
            self._collect_mount_gyro=False
            self._mount_gyro_moving=[]

    def _run_measurement(self,output,inner_target,sign,speed,threshold_deg,watcher,progress=None,span_deg=5.):
        if output not in ('roll','pitch') or inner_target not in (0,90):raise ValueError('静态轴映射错误')
        if not (.2<=speed<=3.):raise ValueError('静态定位速度需0.2–3°/s')
        if not (.01<=threshold_deg<=5.):raise ValueError('静态精度门槛范围0.01–5°')
        if not (1.<=span_deg<=5.):raise ValueError('当前摆幅不足1°，本版14点自动静态前检最小范围为±1°，请单独进行小角度静态验证')
        uid=self.engine.uid;active=self.engine.active;cal_files=list(getattr(self.engine,'cal_files',[]) or [])
        self._mount_gyro_moving=[];self._collect_mount_gyro=True
        items=[]
        for i,nominal in enumerate(STATIC_STEPS):
            target=round(nominal*span_deg/5.,4)
            if progress:progress(i+1,len(STATIC_STEPS),target)
            self._position_outer(target,watcher,inner_target,speed)
            item=self._sample(target,watcher,inner_target,output,sign,uid,active,
                 'out' if i<=6 else 'back')
            items.append(item)
            DIAG.record('static_precheck_point',f'{output.upper()}静态位置{target:+g}°采样完成',
                        encoder_deg=item['actual_outer_deg'],error_deg=item['current_signed_error_deg'],samples=item['imu_sample_count'])
        # Sampling includes final zero, but verify real position before issuing sway.
        self._check(watcher,inner_target,0)
        self._collect_mount_gyro=False
        from .mount_axis_precheck import diagnose_mount_axis
        axis_precheck=diagnose_mount_axis(
            output,[st['gyro_cal_stationary'] for st in items if st.get('gyro_cal_stationary')],
            self._mount_gyro_moving)
        result=summarize_static(items,output,sign,threshold_deg,active)
        report={'kind':'REAL_STATIC_BEFORE_DYNAMIC','created_at':dt.datetime.now().astimezone().isoformat(),
                'uid':uid,'output':output,'inner_target_deg':inner_target,'static_span_deg':span_deg,
                'operator_approved_small_angle_motion':True,'reference':'真实2TD-600外轴2编码器',
                'calibration_mode':self.engine.cal_mode,'algorithm_at_start':active,
                'threshold_deg':threshold_deg,'items':items,'analysis':result,
                'mount_axis_precheck':axis_precheck,
                'no_dynamic_sway_yet':True,'time_sync_needed_for_static_averages':False,
                'note':'绝对静态误差已保留；不能通过拟合零点/斜率来自动提高静态精度数字。'}
        self.folder.mkdir(parents=True,exist_ok=True)
        name=f'{dt.datetime.now():%Y%m%d_%H%M%S_%f}_{uid}_{output.upper()}_STATIC_PRECHECK.json'
        html_name=name.replace('.json','.html')
        try:
            from .static_report_html import make_static_html
            (self.folder/html_name).write_text(make_static_html(report),encoding='utf-8')
            report['interactive_html_file']=html_name
        except Exception as exc:
            report['html_warning']=repr(exc)
        (self.folder/name).write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        return name,report
