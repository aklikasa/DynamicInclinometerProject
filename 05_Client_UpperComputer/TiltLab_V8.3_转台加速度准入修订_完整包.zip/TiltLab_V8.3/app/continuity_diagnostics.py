"""Post-capture diagnostics only. Reference never enters the real-time filter."""
import math
from .fusion import Params,create_filter
from .continuity_v713 import advance
from .static_alignment import align_pose


def gap_summary(rows,start_ns,end_ns):
    events=[];short=long=motion_long=0;max_dt=0.;max_age=None
    for i,row in enumerate(rows):
        d=float(row.get('imu_dt_s') or 0);max_dt=max(max_dt,d)
        age=row.get('sample_age_ms')
        if age not in (None,'') and math.isfinite(float(age)):max_age=max(float(age),max_age if max_age is not None else float(age))
        if d<=.010:continue
        short+=1
        if d<=.05:continue
        long+=1;ns=int(row['host_est_ns']);in_motion=start_ns<=ns<=end_ns;motion_long+=int(in_motion)
        prev=rows[i-1] if i else {}
        events.append({'relative_s':round((ns-start_ns)/1e9,5),'estimated_gap_ms':round(d*1000,3),
                       'in_motion':in_motion,'action':row.get('gap_action'),'poll_id':row.get('poll_id'),
                       'previous_poll_id':prev.get('poll_id'),'serial_read_ms':row.get('serial_read_ms'),
                       'pc_receipt_interval_ms':round((int(row['pc_observed_ns'])-int(prev['pc_observed_ns']))/1e6,3) if prev.get('pc_observed_ns') else None,
                       'device_interval_ms':round((float(row['device_t_s'])-float(prev['device_t_s']))*1000,3) if prev.get('device_t_s') is not None else None})
    return {'estimated_steps_over_10ms':short,'estimated_steps_over_50ms':long,'motion_steps_over_50ms':motion_long,
            'max_estimated_step_ms':round(max_dt*1000,3),'max_estimated_sample_age_ms':max_age,
            'largest_gap_events':sorted(events,key=lambda x:x['estimated_gap_ms'],reverse=True)[:30],
            'note':'时间为估算；poll_id用于关联独立轮询日志。不等于证实实际丢样。样本年龄不包含未知传感器采样延迟。'}


def compare_adaptive(rows,table,params,alignment,plan,start_ns,end_ns):
    """Offline A/B with equal timestamps, parameters, initialization, sample set.
    The old V7.12 gap policy reset all state at >50ms. New uses bounded gyro.
    Reuse the actual reference quality gate; never replace captured angle fields.
    """
    from .dynamic_experiment import analyze_tracking
    p=Params(**params).validate();old=create_filter('adaptive',p);new=create_filter('adaptive',p)
    diagnostic=[];resets_old=resets_new=bridges=0
    for i,r in enumerate(rows):
        try:
            a=[float(r[f'cal_acc_{k}_g']) for k in 'xyz'];g=[float(r[f'cal_gyro_{k}_dps']) for k in 'xyz']
        except (KeyError,TypeError,ValueError):return {'available':False,'reason':'标定六轴不完整，拒绝A/B'}
        if not all(math.isfinite(x) for x in a+g):return {'available':False,'reason':'标定六轴存在非有限值'}
        d=float(r.get('imu_dt_s') or 0) if i else 0.;od=d
        if d>.05:old=create_filter('adaptive',p);od=0.;resets_old+=1
        o=old.update(a,g,od);new,n,act=advance('adaptive',new,p,True,a,g,d)
        resets_new+=act=='reset';bridges+=act=='gyro_bridge'
        if alignment and str(r.get('alignment_active')).lower() in ('1','true'):
            o=align_pose(o,alignment);n=align_pose(n,alignment)
        # Internal slot names are intentionally remapped below; no change to
        # actual report rankings or realtime data, and no duplicate curve export.
        row={k:r.get(k) for k in ('host_est_ns','pc_observed_ns','device_t_s','imu_nominal_odr_hz','imu_timestamp_quality','batch_shift_ms','cal_gyro_x_dps','cal_gyro_y_dps','cal_gyro_z_dps')}
        row['cal_adaptive_'+plan['output']]=o[plan['output']];row['cal_mahony_'+plan['output']]=n[plan['output']]
        diagnostic.append(row)
    a=analyze_tracking(table,diagnostic,plan['axis'],plan['output'],plan['sign'],plan['amplitude_deg'],plan['frequency_hz'],start_ns,end_ns)
    m={x['algorithm']:x for x in a.get('comparison',[]) if x['channel']=='cal'}
    if not all(k in m for k in ('adaptive','mahony')):return {'available':False,'reason':a.get('reason','参考不足')}
    def metric(k):return {name:value for name,value in m[k].items() if name not in ('algorithm','channel')}
    return {'available':True,'legacy_reset_policy':metric('adaptive'),'new_bridge_policy':metric('mahony'),
            'legacy_resets':resets_old,'new_resets':resets_new,'new_bridges':bridges,
            'reference_valid_for_research':a.get('valid',False),'certified_dynamic_accuracy':False,
            'note':'两种离线因果回放均从本次捕获基线初始化，使用同一六轴、估算时间轴、转台参考和评价样本；不覆盖实时输出，不等于实时达标。'}
