"""Reference six-axis attitude filters. Input: accel in g (+Z when level), gyro in deg/s.
Body->world quaternion, ZYX Euler; yaw is NOT absolute without heading reference.
Streaming only: no future samples or smoothing. Research, not certified firmware.
"""
from __future__ import annotations
import math
from dataclasses import dataclass, asdict

R = math.pi / 180.0
D = 180.0 / math.pi

def clamp(x, a, b): return max(a, min(b, x))
def norm(v): return math.sqrt(sum(x*x for x in v))
def cross(a,b): return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
def qnorm(q):
    n=norm(q)
    return [v/n for v in q] if n>1e-12 else [1.,0.,0.,0.]
def qmul(a,b):
    w,x,y,z=a; v,p,t,u=b
    return [w*v-x*p-y*t-z*u,w*p+x*v+y*u-z*t,w*t-x*u+y*v+z*p,w*u+x*t-y*p+z*v]
def euler_to_q(roll,pitch,yaw=0.):
    a,b,c=[x*R/2 for x in (roll,pitch,yaw)]
    cr,sr=math.cos(a),math.sin(a); cp,sp=math.cos(b),math.sin(b); cy,sy=math.cos(c),math.sin(c)
    return qnorm([cr*cp*cy+sr*sp*sy,sr*cp*cy-cr*sp*sy,cr*sp*cy+sr*cp*sy,cr*cp*sy-sr*sp*cy])
def q_to_euler(q):
    w,x,y,z=q
    return dict(roll=math.atan2(2*(w*x+y*z),1-2*(x*x+y*y))*D,
                pitch=math.asin(clamp(2*(w*y-z*x),-1,1))*D,
                yaw=math.atan2(2*(w*z+x*y),1-2*(y*y+z*z))*D)
def gravity_body(q):
    w,x,y,z=q
    return [2*(x*z-w*y),2*(w*x+y*z),1-2*(x*x+y*y)]
def accel_tilt(a):
    return dict(roll=math.atan2(a[1],a[2])*D,pitch=math.atan2(-a[0],math.hypot(a[1],a[2]))*D,yaw=0.)
def initial_q(a):
    e=accel_tilt(a);return euler_to_q(e['roll'],e['pitch'])
def integrate(q,g,dt):
    v=[x*R for x in g]; angle=norm(v)*dt
    if angle<1e-10: d=[1.,*[x*dt*.5 for x in v]]
    else:
        s=math.sin(angle/2)/(angle/dt)
        d=[math.cos(angle/2),*[x*s for x in v]]
    return qnorm(qmul(q,d))
def emit(q,trust): return {**q_to_euler(q),'q':q[:],'trust':round(trust,5)}

@dataclass
class Params:
    kp:float=2.3
    ki:float=0.035
    alpha:float=0.985
    beta:float=0.075
    acc_threshold:float=0.14
    kalman_r:float=0.15
    lever3_x_cm:float=0.0
    lever3_y_cm:float=0.0
    lever3_z_cm:float=0.0
    lever_z_cm:float=0.0  # Experimental geometric compensation, disabled by default
    lever_tau_s:float=0.09  # Causal angular-rate derivative smoothing
    adaptive_beta_floor:float=0.12  # Minimum fractional gyro-correction gain, <=1
    adaptive_acc_innovation_gps:float=0.12  # Body-gravity acceleration innovation threshold g/s
    vqf_nominal_hz:float=833.0  # Must match real IMU ODR; not host received rate
    vqf_tau_acc_s:float=3.0  # Official VQF gravity correction time constant
    def validate(self):
        for k,(lo,hi) in {'kp':(0,20),'ki':(0,2),'alpha':(0,1),'beta':(0.001,2),
                          'acc_threshold':(.015,1.0),'kalman_r':(.001,20),
                          'lever3_x_cm':(-50.,50.),'lever3_y_cm':(-50.,50.),'lever3_z_cm':(-50.,50.),'lever_z_cm':(-50.,50.),'lever_tau_s':(.02,.4),
                          'adaptive_beta_floor':(.01,1.),'adaptive_acc_innovation_gps':(.02,1.),
                          'vqf_nominal_hz':(52.,1667.),'vqf_tau_acc_s':(.3,30.)}.items():
            v=getattr(self,k)
            if not isinstance(v,(int,float)) or not math.isfinite(v) or not lo<=v<=hi:
                raise ValueError(f'{k} 允许范围 {lo}–{hi}')
        return self

class AccelOnly:
    """Unsmoothed gravity-tilt reference: no temporal filter, no gyro integration.

    Calibration (raw vs calibrated branch) is separate; 3D output yaw=0 is
    a display convention, not an observable heading measurement.
    """
    def __init__(self,p):pass
    def update(self,a,g,dt):return emit(initial_q(a),1)
class GyroOnly:
    def __init__(self,p):self.q=None
    def update(self,a,g,dt):
        if self.q is None:self.q=initial_q(a)
        elif dt>0:self.q=integrate(self.q,g,dt)
        return emit(self.q,0)
class Complementary:
    def __init__(self,p): self.p=p;self.q=None
    def update(self,a,g,dt):
        if self.q is None: self.q=initial_q(a)
        elif dt>0:
            predicted=integrate(self.q,g,dt)
            # Correct only roll/pitch to gravity, retain integrated yaw.
            pe=q_to_euler(predicted); ae=accel_tilt(a)
            b=1-self.p.alpha
            self.q=euler_to_q(pe['roll']+b*((ae['roll']-pe['roll']+180)%360-180),
                              pe['pitch']+b*(ae['pitch']-pe['pitch']),pe['yaw'])
        return emit(self.q,1-self.p.alpha)
class Mahony:
    def __init__(self,p,adaptive=False):self.p=p;self.adaptive=adaptive;self.q=None;self.bias=[0.,0.,0.];self.previous=None
    def update(self,a,g,dt):
        if self.q is None:self.q=initial_q(a)
        n=norm(a); trust=0.
        if dt>0 and n>.2:
            unit=[x/n for x in a]; expected=gravity_body(self.q)
            error=cross(unit,expected)
            trust=1.
            if self.adaptive:
                residual=norm(error)
                jerk=norm([a[i]-self.previous[i] for i in range(3)])/dt if self.previous is not None else 0.
                t=self.p.acc_threshold
                trust=clamp(math.exp(-((n-1)/t)**2) * math.exp(-(max(0,residual-.07)/.48)**2)
                            * math.exp(-(max(0,jerk-1)/15)**2),0,1)
            if trust>.65:
                self.bias=[clamp(self.bias[i]+self.p.ki*error[i]*dt,-.3,.3) for i in range(3)]
            adjusted=[g[i]+(self.p.kp*trust*error[i]+self.bias[i])*D for i in range(3)]
            self.q=integrate(self.q,adjusted,dt)
        elif dt>0: self.q=integrate(self.q,g,dt)
        self.previous=list(a)
        return emit(self.q,trust)
class Madgwick:
    def __init__(self,p):self.p=p;self.q=None
    def _correction_trust(self,a,g,dt):
        # Original Madgwick keeps a constant beta; override only in the new filter.
        return 1.0
    def update(self,a,g,dt):
        if self.q is None:self.q=initial_q(a)
        if dt<=0:return emit(self.q,0)
        q0,q1,q2,q3=self.q;gx,gy,gz=[v*R for v in g]
        qdot=[.5*(-q1*gx-q2*gy-q3*gz),.5*(q0*gx+q2*gz-q3*gy),.5*(q0*gy-q1*gz+q3*gx),.5*(q0*gz+q1*gy-q2*gx)]
        n=norm(a); trust=0.
        if n>.2:
            ax,ay,az=[v/n for v in a]
            s0=4*q0*q2*q2+2*q2*ax+4*q0*q1*q1-2*q1*ay
            s1=4*q1*q3*q3-2*q3*ax+4*q0*q0*q1-2*q0*ay-4*q1+8*q1*q1*q1+8*q1*q2*q2+4*q1*az
            s2=4*q0*q0*q2+2*q0*ax+4*q2*q3*q3-2*q3*ay-4*q2+8*q2*q1*q1+8*q2*q2*q2+4*q2*az
            s3=4*q1*q1*q3-2*q1*ax+4*q2*q2*q3-2*q2*ay
            sn=norm([s0,s1,s2,s3]);trust=clamp(self._correction_trust(a,g,dt),0,1)
            if sn>1e-9:qdot=[qdot[i]-self.p.beta*trust*s/sn for i,s in enumerate((s0,s1,s2,s3))]
        self.q=qnorm([self.q[i]+qdot[i]*dt for i in range(4)])
        return emit(self.q,trust)
class KalmanAxis:
    def __init__(self):self.angle=None;self.bias=0.;self.p00=1.;self.p01=0.;self.p10=0.;self.p11=1.
    def update(self,z,rate,dt,noise):
        if self.angle is None:self.angle=z
        if dt<=0:return self.angle
        self.angle+=(rate-self.bias)*dt
        a,b,c,d=self.p00,self.p01,self.p10,self.p11
        a+=dt*(dt*d-b-c+.02);b-=dt*d;c-=dt*d;d+=dt*.0006
        k0=a/(a+noise);k1=c/(a+noise);innovation=z-self.angle
        self.angle+=k0*innovation;self.bias+=k1*innovation
        self.p00=a-k0*a;self.p01=b-k0*b;self.p10=c-k1*a;self.p11=d-k1*b
        return self.angle
class DualKalman:
    def __init__(self,p):self.p=p;self.r=KalmanAxis();self.pitch=KalmanAxis();self.yaw=0.
    def update(self,a,g,dt):
        z=accel_tilt(a); roll=self.r.angle if self.r.angle is not None else z['roll'];pitch=self.pitch.angle if self.pitch.angle is not None else z['pitch']
        sr,cr=math.sin(roll*R),math.cos(roll*R);tp=math.tan(clamp(pitch,-88,88)*R)
        rollrate=g[0]+(g[1]*sr+g[2]*cr)*tp
        pitchrate=g[1]*cr-g[2]*sr
        trust=clamp(math.exp(-((norm(a)-1)/self.p.acc_threshold)**2),.02,1)
        rr=self.r.update(z['roll'],rollrate,dt,self.p.kalman_r/trust)
        pp=self.pitch.update(z['pitch'],pitchrate,dt,self.p.kalman_r/trust)
        if dt>0:self.yaw+=g[2]*dt
        return emit(euler_to_q(rr,pp,self.yaw),trust)

from .rotation_compensation import LeverArmMadgwick, AdaptiveLeverArmMadgwick
from .motion_guard import MotionGuard
from .lever3d import Lever3DFusion, AdaptiveLever3DFusion, GyroAnchorLever3DFusion
from .gyro_anchor import GyroAnchor, AdaptiveGravityObserver

FILTERS={'accel':('加速度直算（无滤波）',AccelOnly),'gyro':('纯陀螺积分',GyroOnly),
         'complementary':('互补滤波',Complementary),'mahony':('Mahony',Mahony),
         'adaptive':('自适应 Mahony',lambda p:Mahony(p,True)),
         'madgwick':('Madgwick',Madgwick),'kalman':('双轴 Kalman',DualKalman),
         'lever3d':('三维杆臂补偿融合（Madgwick实验）',Lever3DFusion),
         'adaptive3d':('三维杆臂 + Adaptive（V7.14研究）',AdaptiveLever3DFusion),
         'leverarm':('旋转附加加速度补偿融合（试验）',LeverArmMadgwick),
         'adaptive_lever':('自适应旋转补偿融合（研发）',AdaptiveLeverArmMadgwick),
         'motion_guard':('运动干扰抑制融合（实验对照）',MotionGuard),
         'gyro_anchor3d':('动态重力约束 + 三维杆臂（V7.15研究）',GyroAnchorLever3DFusion),
         'gravity_observer':('自适应重力观测器（V7.16无杆臂实验）',AdaptiveGravityObserver),
         'gyro_anchor':('陀螺主导·动态重力约束（V7.8实验）',GyroAnchor)}

def create_filter(name,p,calibrated=True):
    if name not in FILTERS:raise ValueError('未知算法: '+name)
    if name=='lever3d':return Lever3DFusion(p,calibrated=calibrated)
    if name=='gyro_anchor3d':return GyroAnchorLever3DFusion(p,calibrated=calibrated)
    if name=='adaptive3d':return AdaptiveLever3DFusion(p,calibrated=calibrated)
    if name=='leverarm':return LeverArmMadgwick(p,calibrated=calibrated)
    if name=='adaptive_lever':return AdaptiveLeverArmMadgwick(p,calibrated=calibrated)
    return FILTERS[name][1](p)

# Register the *actual* official VQF only when its optional dependency is present.
# No silent fallback to a different algorithm is allowed. Legacy modes still run
# even if VQF installation failed or is offline.
from .vqf_fusion import VQF_AVAILABLE, VQF6D
if VQF_AVAILABLE:
    FILTERS['vqf6d'] = ('VQF-6D（论文基准，实验）', VQF6D)
    FILTERS['vqf_lever'] = ('VQF-6D + Z杆臂补偿（实验）', lambda p: VQF6D(p, lever_compensate=True))
