"""2TD-600 read-only feedback monitor.

This module NEVER sends motion, enable, homing or stop commands.
PC receive/read-midpoint timestamps are diagnostic, NOT hardware-synchronized timestamps.
"""
from __future__ import annotations
import csv
import datetime as dt
import json
import math
import threading
import time
from collections import deque
from pathlib import Path

HEADERS = (
    'sequence','pc_utc','pc_monotonic_ns','read_started_monotonic_ns',
    'read_finished_monotonic_ns','read_duration_ms','axis_0_position_pc_mid_ns','axis_0_position_read_ms','axis_2_position_pc_mid_ns','axis_2_position_read_ms',
    'axis_0_position_deg','axis_0_speed_dps','axis_0_mode','axis_0_enabled',
    'axis_0_zeroed','axis_0_healthy','axis_0_in_place','axis_0_upper_limit',
    'axis_0_lower_limit','axis_0_driver_fault','axis_0_over_speed',
    'axis_2_position_deg','axis_2_speed_dps','axis_2_mode','axis_2_enabled',
    'axis_2_zeroed','axis_2_healthy','axis_2_in_place','axis_2_upper_limit',
    'axis_2_lower_limit','axis_2_driver_fault','axis_2_over_speed',
    'imu_source','imu_uid','imu_algorithm','imu_cal_mode','imu_t_s',
    'imu_latest_age_ms','imu_roll_raw_deg','imu_pitch_raw_deg',
    'imu_roll_cal_deg','imu_pitch_cal_deg',
)

class TableMonitor:
    def __init__(self,table,engine,reports_dir:Path):
        self.table=table
        self.engine=engine
        self.reports_dir=Path(reports_dir)
        self.lock=threading.RLock()
        self.stop_event=threading.Event()
        self.worker=None
        self.running=False
        self.state='idle'
        self.error=''
        self.interval_ms=100
        self.count=0
        self.last=None
        self.recent=deque(maxlen=200)
        self.path=None
        self.started_at=None
        self.started_ns=None
        self.ended_at=None

    def start(self,interval_ms=100):
        if type(interval_ms) is not int or not 50<=interval_ms<=1000:
            raise ValueError('读取间隔需为50–1000ms的整数')
        with self.lock:
            if self.running:
                raise ValueError('转台反馈记录正在运行')
            if not self.table.connected:
                raise ValueError('请先连接真实2TD-600，才能开始只读反馈记录')
            self.reports_dir.mkdir(parents=True,exist_ok=True)
            timestamp=dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            self.path=self.reports_dir/(timestamp+'_2TD600_FEEDBACK_READONLY.csv')
            self.interval_ms=interval_ms
            self.running=True
            self.state='recording'
            self.error=''
            self.count=0
            self.last=None
            self.recent.clear()
            self.started_at=dt.datetime.now().astimezone().isoformat(timespec='milliseconds')
            self.started_ns=time.monotonic_ns()
            self.ended_at=None
            self.stop_event.clear()
            self.worker=threading.Thread(target=self._loop,daemon=True,name='2TD600-feedback-monitor')
            self.worker.start()
            return self.status(include_history=False)

    def _capture_imu(self,stamp_ns):
        # This is a concurrent observation, not a synchronized IMU sample.
        e=self.engine
        with e.lock:
            cur=e.latest
            if e.source!='serial' or not e.running or not e.connected or cur is None:
                return {}
            age=max(0.,(time.time()-e.last_wall)*1000) if e.last_wall else None
            raw=cur.get('raw') or {}
            cal=cur.get('cal') or {}
            return dict(imu_source='serial',imu_uid=e.uid,imu_algorithm=e.active,
                imu_cal_mode=e.cal_mode,imu_t_s=cur.get('t'),
                imu_latest_age_ms=round(age,2) if age is not None else None,
                imu_roll_raw_deg=raw.get('roll'),imu_pitch_raw_deg=raw.get('pitch'),
                imu_roll_cal_deg=cal.get('roll'),imu_pitch_cal_deg=cal.get('pitch'))

    def _loop(self):
        f=None
        try:
            f=self.path.open('w',newline='',encoding='utf-8-sig')
            writer=csv.DictWriter(f,fieldnames=HEADERS)
            writer.writeheader()
            next_poll=time.monotonic()
            while not self.stop_event.is_set():
                if not self.table.connected:
                    raise RuntimeError('转台连接已断开，停止反馈记录')
                started=time.monotonic_ns()
                result=self.table.read_status()
                finished=time.monotonic_ns()
                if not result.get('connected'):
                    raise RuntimeError('转台状态读取失败：未连接')
                axes=result.get('axes') or {}
                if '0' not in axes or '2' not in axes:
                    raise RuntimeError('转台反馈缺少轴0或轴2')
                midpoint=(started+finished)//2
                utc=dt.datetime.now().astimezone().isoformat(timespec='milliseconds')
                row={'sequence':self.count+1,'pc_utc':utc,
                    'pc_monotonic_ns':midpoint,
                    'read_started_monotonic_ns':started,
                    'read_finished_monotonic_ns':finished,
                    'read_duration_ms':round((finished-started)/1e6,3)}
                for a in ('0','2'):
                    state=axes[a]
                    row[f'axis_{a}_position_pc_mid_ns']=state.get('position_pc_mid_ns')
                    row[f'axis_{a}_position_read_ms']=state.get('position_read_ms')
                    for key,out in [('position_deg','position_deg'),('speed_dps','speed_dps'),
                                    ('mode','mode'),('enabled','enabled'),('zeroed','zeroed'),
                                    ('healthy','healthy'),('in_place','in_place'),
                                    ('upper_limit','upper_limit'),('lower_limit','lower_limit'),
                                    ('driver_fault','driver_fault'),('over_speed','over_speed')]:
                        value=state.get(key)
                        if key in ('position_deg','speed_dps') and not isinstance(value,(int,float)):
                            raise RuntimeError(f'轴{a}缺少有效的{key}反馈')
                        if key in ('position_deg','speed_dps') and not math.isfinite(value):
                            raise RuntimeError(f'轴{a}反馈非有限数值')
                        row[f'axis_{a}_{out}']=int(value) if isinstance(value,bool) else value
                row.update(self._capture_imu(midpoint))
                writer.writerow(row)
                if (self.count+1)%10==0:
                    f.flush()
                with self.lock:
                    self.count+=1
                    self.last={'sequence':self.count,'pc_utc':utc,'pc_monotonic_ns':midpoint,
                               'read_duration_ms':row['read_duration_ms'],'axes':axes,
                               'imu_age_ms':row.get('imu_latest_age_ms')}
                    self.recent.append({'sequence':self.count,'t_s':(midpoint-self.started_ns)/1e9,
                        'pos0':axes['0']['position_deg'],'speed0':axes['0']['speed_dps'],
                        'pos2':axes['2']['position_deg'],'speed2':axes['2']['speed_dps']})
                next_poll+=self.interval_ms/1000.
                delay=next_poll-time.monotonic()
                if delay<0:
                    next_poll=time.monotonic()
                    delay=0
                if self.stop_event.wait(delay):
                    break
        except Exception as exc:
            with self.lock:
                self.error=f'{type(exc).__name__}: {exc}'
                self.state='failed'
        finally:
            if f is not None:
                f.flush()
                f.close()
            with self.lock:
                self.running=False
                self.ended_at=dt.datetime.now().astimezone().isoformat(timespec='milliseconds')
                if self.state!='failed':
                    self.state='stopped'
                if self.path:
                    metadata={'kind':'REAL_2TD600_PC_POLL_FEEDBACK',
                        'recording_file':self.path.name,
                        'started_at':self.started_at,'ended_at':self.ended_at,
                        'state':self.state,'error':self.error,
                        'count':self.count,'requested_poll_interval_ms':self.interval_ms,
                        'timestamp_source':'PC monotonic midpoint of DLL read call',
                        'timestamp_accuracy':'NOT calibrated to turntable controller / IMU clock',
                        'reference_qualification':'NOT sufficient for dynamic RMSE or phase delay',
                        'motion_commands_sent':False,
                        'comment':'采样包含两轴真实反馈与可选IMU最新快照；两设备未精确同步，不能用于动态精度验收。'}
                    try:
                        self.path.with_suffix('.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
                    except Exception as e:
                        self.error+='; 元数据文件保存失败: '+str(e)

    def stop(self,wait_seconds=3.0):
        with self.lock:
            self.stop_event.set()
            worker=self.worker
        if worker and worker.is_alive() and worker is not threading.current_thread():
            worker.join(timeout=wait_seconds)
        return self.status(include_history=False)

    def status(self,include_history=True):
        with self.lock:
            age=(time.monotonic_ns()-self.last['pc_monotonic_ns'])/1e6 if self.last else None
            elapsed=(time.monotonic_ns()-self.started_ns)/1e9 if self.running and self.started_ns else 0
            measured=self.count/elapsed if elapsed>0 else 0
            result={'running':self.running,'state':self.state,'error':self.error,'connected':self.table.connected,
                'count':self.count,'poll_interval_ms':self.interval_ms,
                'measured_rate_hz':round(measured,2),
                'latest_age_ms':round(age,1) if age is not None else None,
                'file':self.path.name if self.path else None,
                'latest':self.last,
                'timestamp_note':'PC读取时间(非转台硬件时间戳)，尚未完成与IMU的严格同步'}
            if include_history:
                result['recent']=list(self.recent)
            return result
