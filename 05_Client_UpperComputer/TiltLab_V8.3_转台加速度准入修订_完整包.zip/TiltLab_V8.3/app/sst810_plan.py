"""Reference test conditions copied from the user-supplied SST810 report.

This is a read-only plan: no remote commands or safety-limit overrides.
The calibration report does not publish the exact error statistic.
"""
from .dynamic_experiment import limits

SST810_CASES = (
    (1.0, .3), (1.0, .5), (1.0, .8),
    (2.0, .3), (2.0, .5), (2.0, .8),
    (3.0, .3), (3.0, .5),
    (4.0, .1), (4.0, .3),
)

def cases(cycles=10):
    result=[]
    for i,(amp,freq) in enumerate(SST810_CASES,1):
        speed=2*__import__('math').pi*amp*freq
        accel=(2*__import__('math').pi*freq)**2*amp
        try:
            plan=limits(amp,freq,cycles)
            supported=True;reason='软件预检运动参数在当前保守边界内；现场仍须检查转台额定能力、装夹及安全联锁。'
        except ValueError as ex:
            plan={};supported=False;reason=str(ex)
        result.append({'id':i,'amplitude_deg':amp,'frequency_hz':freq,
                       'cycles':cycles,'peak_speed_dps':round(speed,4),
                       'peak_accel_dps2':round(accel,4),
                       'software_preflight_allowed':supported,'reason':reason,
                       'plan':plan})
    return result
