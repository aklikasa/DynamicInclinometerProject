"""Safe operator-gated servo disable. STOP and DISABLE are different actions.

The machine may lose holding torque when disabled. No automatic disable at the
end of an experiment; explicit two-step approval and fresh stationary
telemetry are mandatory, and hardware safety interlocks are outside software.
"""
from __future__ import annotations
import math,secrets,threading,time
from .angles import angle_delta_deg
from .table_diagnostics import DIAG

class DisableSupervisor:
    def __init__(self,table,busy):
        self.table=table;self.busy=busy;self.lock=threading.RLock()
        self.pending=None
        self.in_progress=False

    def _sample_stop(self,axis,seconds=1.0):
        positions=[];speeds=[];modes=[];faults=[]
        deadline=time.monotonic()+seconds
        while True:
            status=self.table.read_status()
            axes=status['axes']
            for which in (0,2):
                a=axes[str(which)]
                if (a['enabled'] and not a['healthy']) or any(a.get(k) for k in ('driver_fault','upper_limit','lower_limit','over_speed')):
                    raise ValueError('轴存在故障、限位或状态异常，不能执行软件断使能')
                if a['mode'] not in (0,2,20):
                    raise ValueError('存在运动模式，禁止断使能（摇摆/定位/找零与STOP是不同状态）')
                if not math.isfinite(float(a['speed_dps'])) or abs(a['speed_dps'])>.06:
                    raise ValueError('DLL反馈角速度非零/异常，禁止断使能；如反馈与实体矛盾，请先排查，不可绕过')
                positions.append((which,angle_delta_deg(a['position_deg'])))
                speeds.append((which,float(a['speed_dps'])))
                modes.append((which,int(a['mode'])))
            if time.monotonic()>=deadline:break
            time.sleep(.20)
        for which in (0,2):
            series=[x for a,x in positions if a==which]
            if max(series)-min(series)>.02:
                raise ValueError(f'轴{which}在确认窗口内有位置变化，不可断使能')
        return {'axis':axis,'axes':status['axes'],
                'position_spread_deg':{str(k):round(max(v for a,v in positions if a==k)-min(v for a,v in positions if a==k),6) for k in (0,2)},
                'maximum_reported_speed_abs_dps':max(abs(v) for _,v in speeds)}

    def preflight(self,axis):
        if axis not in (0,2):raise ValueError('请选择内轴0或外轴2')
        if self.busy():raise ValueError('有自动任务正在运行，不能断使能')
        if not self.table.connected:raise ValueError('请先连接真实转台')
        with self.lock:
            evidence=self._sample_stop(axis,1.0)
            if not evidence['axes'][str(axis)]['enabled']:
                raise ValueError('所选轴已处于未使能状态，无需重复断使能')
            token=secrets.token_urlsafe(22)
            self.pending={'axis':axis,'token':token,'created':time.monotonic()}
            return {'ready_for_operator':True,'axis':axis,'token':token,'expires_in_s':30,
                    'stationary_evidence':evidence,'warning':'取消使能可能丧失保持力！必须现场确认工装/负载受可靠支撑、不会因失电运动。'}

    def disable(self,axis,token,operator_confirmed=False,load_secured=False):
        with self.lock:
            pending=self.pending;self.pending=None  # one-time only, even on errors
            if not(operator_confirmed is True and load_secured is True):
                raise ValueError('需要双重确认：人员现场监护、负载失去保持力后仍安全')
            if not pending or pending['axis']!=axis or pending['token']!=token or time.monotonic()-pending['created']>30:
                raise ValueError('断使能预检查凭据失效，请重新检查')
            if self.busy():raise ValueError('自动任务正在执行，禁止断使能')
            self.in_progress=True
            try:
                return self._disable_checked(axis)
            finally:
                self.in_progress=False

    def _disable_checked(self,axis):
        with self.lock:
            evidence=self._sample_stop(axis,.6)
            if self.busy():raise ValueError('预检查后其他运动任务已启动，拒绝断使能')
            if not evidence['axes'][str(axis)]['enabled']:
                return {'axis':axis,'command_sent':False,'confirmed_disabled':True,'message':'该轴已未使能'}
            DIAG.record('disable_before',f'轴{axis}操作员确认取消使能',evidence=evidence)
            # Vendor DLL supports SetAxisDisable(axis); no STOP, no re-enable.
            self.table.disable_axis(axis)
            deadline=time.monotonic()+3.
            last_status=None
            while time.monotonic()<deadline:
                last_status=self.table.read_status();a=last_status['axes'][str(axis)]
                if not a['enabled']:
                    DIAG.snapshot('disable_confirmed',last_status,f'轴{axis}确认断使能')
                    return {'axis':axis,'command_sent':True,'confirmed_disabled':True,
                            'message':'DLL已反馈该轴使能位为0；现场仍需验证负载状态'}
                time.sleep(.18)
            DIAG.snapshot('disable_not_confirmed',last_status,f'轴{axis}断使能指令返回但未获反馈')
            raise RuntimeError('断使能指令已发送，但使能状态未确认；请使用厂家控制器现场检查')

    def disable_after_owned_calibration(self, *, operator_confirmed=False, load_secured=False, stop_confirmed=False):
        """Called ONLY by the active mount-calibration worker after verified STOP.

        Unlike the separate human-triggered two-step disable flow, the operator
        grants consent BEFORE starting calibration. No unverified or failed
        calibration should invoke this method. Do not change the manual flow.
        """
        if operator_confirmed is not True or load_secured is not True:
            raise ValueError('未确认负载失去伺服保持力后仍有独立支撑，禁止自动断使能')
        if stop_confirmed is not True:
            raise ValueError('未获得真实两轴停车确认，禁止自动断使能')
        if not self.table.connected:
            raise RuntimeError('转台已断开，不能安全断使能')
        with self.lock:
            if self.in_progress:raise RuntimeError('正在执行另一个断使能动作')
            self.in_progress=True
            results=[]
            try:
                for axis in (2,0):
                    evidence=self._sample_stop(axis,1.0)
                    for other in (0,2):
                        from .angles import zero_distance_deg
                        if zero_distance_deg(evidence['axes'][str(other)]['position_deg'])>.10:
                            raise RuntimeError('双轴未处于已确认的0°停稳位置，禁止自动断使能')
                    if not evidence['axes'][str(axis)]['enabled']:
                        results.append({'axis':axis,'command_sent':False,'confirmed_disabled':True,'message':'原本已断使能'})
                        continue
                    DIAG.record('calibration_disable_before',f'标定结束按预授权自动断使能轴{axis}',evidence=evidence)
                    self.table.disable_axis(axis)
                    deadline=time.monotonic()+3.0
                    confirmed=False
                    while time.monotonic()<deadline:
                        status=self.table.read_status()
                        current=status['axes'][str(axis)]
                        if any(current.get(k) for k in ('driver_fault','upper_limit','lower_limit','over_speed')):
                            raise RuntimeError(f'轴{axis}断使能时出现设备故障，请现场检查')
                        if not current['enabled']:
                            confirmed=True;break
                        time.sleep(.18)
                    if not confirmed:
                        raise RuntimeError(f'轴{axis}断使能指令已发出但未获使能位0反馈，请现场检查')
                    DIAG.snapshot('calibration_disable_confirmed',status,f'标定结束轴{axis}断使能反馈已确认')
                    results.append({'axis':axis,'command_sent':True,'confirmed_disabled':True,'message':'DLL反馈已断使能；现场仍应核对负载'})
                # Detect a no-holding-torque drift immediately after the last disable.
                before=self.table.read_status()
                time.sleep(.35)
                after=self.table.read_status()
                from .angles import angle_delta_deg
                for axis in (0,2):
                    if after['axes'][str(axis)]['enabled']:
                        raise RuntimeError(f'轴{axis}反馈仍然使能，完成状态不可信')
                    if abs(angle_delta_deg(after['axes'][str(axis)]['position_deg'],before['axes'][str(axis)]['position_deg']))>.02:
                        raise RuntimeError(f'断使能后轴{axis}位置发生移动，请现场检查机械支撑')
                return results
            finally:
                self.in_progress=False
