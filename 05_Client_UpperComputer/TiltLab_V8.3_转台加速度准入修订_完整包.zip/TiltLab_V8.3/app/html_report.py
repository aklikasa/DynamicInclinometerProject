
'''Self-contained interactive HTML reports for real dynamic experiments.
No CDN or network assets are used; charts are rendered with local canvas JavaScript.
'''
from __future__ import annotations
import json
from pathlib import Path

_TEMPLATE = r'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TiltLab 动态实验报告</title>
<style>
:root{color-scheme:light;--ink:#202a25;--muted:#68736d;--line:#e2e8e3;--paper:#f6f8f6;--green:#245b48}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:14px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif}
main{max-width:1180px;margin:0 auto;padding:28px 22px 64px}.hero,.panel{background:#fff;border:1px solid var(--line);border-radius:16px;padding:20px 22px;margin:16px 0}
.hero{padding:26px 28px}.eyebrow{font-size:11px;letter-spacing:.16em;color:var(--green);font-weight:700}.hero h1{margin:7px 0 4px;font-size:27px}.muted{color:var(--muted)}
.pills,.nav,.toolbar,.files{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0}.pill{border:1px solid var(--line);background:#fafcfb;border-radius:99px;padding:5px 10px;font-size:12px}
.panel h2{font-size:18px;margin:0 0 12px}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.metric,.align-item{border:1px solid var(--line);border-radius:12px;padding:12px}.metric small,.align-item small{display:block;color:var(--muted)}.metric strong{display:block;font-size:22px;margin-top:4px;font-variant-numeric:tabular-nums}
.align-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.align-item strong{font-size:20px;display:block;margin-top:3px}
.warn{border-left:4px solid #c38b55;background:#fff9f2;padding:12px 14px;border-radius:8px;color:#664d35;margin:12px 0}
.nav button,.toolbar button{border:1px solid var(--line);background:#fff;border-radius:9px;padding:8px 12px;cursor:pointer;color:var(--ink)}.nav button.active,.toolbar button.active{background:#eaf2ed;border-color:#9db9a7;color:var(--green)}
.checks{display:flex;flex-wrap:wrap;gap:7px 12px;margin:10px 0 16px}.checks label{display:flex;align-items:center;gap:6px;font-size:12px;color:#48534d}.swatch{width:10px;height:10px;border-radius:3px;display:inline-block}
.chart-wrap{margin:14px 0}.chart-wrap h3{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap}.chart{width:100%;height:300px;display:block;border:1px solid #edf0ed;border-radius:12px;background:#fff}
.table-scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:9px 10px;border-bottom:1px solid var(--line);white-space:nowrap}th{color:var(--muted);font-weight:600}
.files a{color:var(--green);text-decoration:none;border:1px solid var(--line);padding:7px 10px;border-radius:8px}.files a:hover{text-decoration:underline}.empty{padding:18px;background:#f8faf8;border:1px dashed var(--line);border-radius:10px;color:var(--muted)}
.footer{font-size:12px;color:var(--muted);padding:10px 2px}
@media(max-width:760px){main{padding:14px 12px 40px}.hero,.panel{padding:16px}.grid{grid-template-columns:repeat(2,minmax(0,1fr))}.align-grid{grid-template-columns:1fr 1fr}.hero h1{font-size:22px}.chart{height:250px}}
</style></head><body><main>
<header class="hero"><div class="eyebrow">TILTLAB · REAL 2TD-600 DYNAMIC TEST</div><h1>动态实验交互式报告</h1>
<div id="subtitle" class="muted">真实转台反馈与IMU多算法跟踪分析</div><div class="pills" id="meta-pills"></div></header>
<section class="panel"><h2>一眼看懂：本报告测了什么</h2><div id="condition-summary"></div></section>
<section class="panel"><h2>本次实验概况</h2><div class="grid" id="overview"></div>
<div class="warn">本报告为研究级绝对角度误差、相对跟踪与安装对齐诊断。IMU与转台尚未完成硬件时钟同步及固定传输延迟标定；结果不能作为±0.1°动态精度验收结论。软件安全确认不能替代实体急停。</div></section>
<section class="panel"><h2>动态绝对角度误差 · 无杆臂通用模式</h2><div id="absolute-panel"></div></section><section class="panel"><h2>IMU—转台外轴对齐诊断</h2><div id="alignment"></div></section>
<section class="panel"><h2>时间差诊断 · 原始数据与统一平移对比</h2><div id="time-diagnostic"></div><p class="muted">诊断性时间偏移只用于定位问题，正式算法排名仍采用原始时间轴。时间拟合可能同时吸收滤波器的相位延迟，不能证明采集硬件已同步。</p></section>
<section class="panel"><h2>V7.15 · 动态误差归因（不改变实时算法或正式RMSE）</h2><div id="root-causes"></div></section>
<section class="panel"><h2>真实转台稳态识别与IMU采样缺口</h2><p class="muted">黄色浅色区表示未纳入稳定正弦评价的起步/尾段及不完整周期；摇摆命令期误差在独立表格保留，不用理想正弦替代编码器，也不删除原始CSV。末尾未评估不一定证明电机正在减速；发出STOP后的制动反馈另存于停车确认诊断，不包含在摇摆命令期角度比较中。</p><div id="quality-diagnostics"></div></section>
<section class="panel"><h2>分项实验曲线</h2><div class="nav" id="stage-nav"></div><div id="stage-info" class="muted"></div>
<div class="toolbar"><button id="pick-cal">只看标定后</button><button id="pick-all">全选</button><button id="pick-none">清空</button></div><div class="checks" id="checks"></div>
<div class="chart-wrap"><h3>动态跟踪曲线 <span class="muted">IMU估计角度 vs 转台实际反馈</span></h3><canvas id="angle-chart" class="chart"></canvas></div>
<div class="chart-wrap"><h3>误差曲线 <span class="muted">IMU估计角度 − 转台实际反馈</span></h3><label class="muted">时间轴：<select id="error-time-view"><option value="absolute">绝对角度（摇摆命令期、不扣零位）</option><option value="errors">相对跟踪（稳态）</option><option value="diagnostic_shifted_errors">统一时间平移（仅诊断）</option></select></label><canvas id="error-chart" class="chart"></canvas></div>
<h3>算法误差统计</h3><div class="table-scroll" id="ranking"></div></section>
<section class="panel"><h2>原始数据与文件</h2><div class="files" id="files"></div></section>
<div class="footer">TiltLab V8.3.0 · 本地独立HTML，无需联网。若下载链接需要使用，请将本HTML与同目录原始CSV一起保存。</div>
</main><script>
const DATA=__REPORT_DATA__;
const COLORS={gravity_observer:'#155c91',gyro_anchor3d:'#117f77',adaptive3d:'#b65a22',accel:'#7e817b',gyro:'#adadae',complementary:'#b47751',mahony:'#2a5249',adaptive:'#638f6e',madgwick:'#9b79a3',kalman:'#3d555f',lever3d:'#c45c19',leverarm:'#569B81',adaptive_lever:'#28518a',motion_guard:'#d78935',gyro_anchor:'#0e91a8',vqf6d:'#694bd1',vqf_lever:'#ca3077'};
const LABELS={gravity_observer:'自适应重力观测器（V7.16无杆臂）',gyro_anchor3d:'动态重力约束 + 三维杆臂（研究）',adaptive3d:'三维杆臂 + Adaptive（研究）',accel:'加速度直接解算',gyro:'陀螺积分',complementary:'互补滤波',mahony:'Mahony',adaptive:'自适应融合',madgwick:'Madgwick',kalman:'卡尔曼',lever3d:'三维杆臂补偿融合',leverarm:'旋转附加加速度补偿（试验）',adaptive_lever:'自适应旋转补偿融合（研发）',motion_guard:'运动干扰抑制（实验对照）',gyro_anchor:'陀螺主导·动态重力约束（V7.8）',vqf6d:'VQF-6D（论文对照）',vqf_lever:'VQF杆臂实验'};
let stageIndex=0,selected=[],selectionInitialized=false;const $=id=>document.getElementById(id);
const fmt=(v,n=4)=>v!=null&&v!==''&&Number.isFinite(Number(v))?Number(v).toFixed(n):'—';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function stages(){return DATA.stages||[]}function cur(){return stages()[stageIndex]||{}}
function report(){return cur().report||{}}function analysis(){return report().analysis||{}}
function renderMeta(){const r=DATA.report||{},p=r.plan||{},first=stages()[0]?.report||r;
 $('subtitle').textContent=(DATA.kind==='REAL_2TD600_XY_SEQUENTIAL'?'Roll + Pitch 自动联合测试':'单方向动态跟踪实验')+' · 外轴2实际反馈作为参考';
 $('meta-pills').innerHTML=[`设备 UID：${esc(r.uid||first.uid||'未知')}`,`状态：${esc(r.state||first.state||'未知')}`,`方向：${stages().map(x=>x.direction==='pitch'?'Pitch':'Roll').join(' + ')}`,`采集时间：${esc(r.finished_at||first.finished_at||'—')}`].map(x=>`<span class="pill">${x}</span>`).join('');
 const valid=stages().filter(x=>x.report),imu=valid.reduce((n,x)=>n+(x.report.imu_samples||0),0),table=valid.reduce((n,x)=>n+(x.report.table_samples||0),0);
 $('overview').innerHTML=[['分项数量',valid.length+' 项'],['IMU样本',imu.toLocaleString()],['转台反馈',table.toLocaleString()],['动态幅度',fmt(p.amplitude_deg??first.plan?.amplitude_deg,2)+'°']].map(x=>`<div class="metric"><small>${x[0]}</small><strong>${x[1]}</strong></div>`).join('');
}
function renderConditions(){
 const names={roll:'ROLL（横滚）',pitch:'PITCH（俯仰）'};
 const summaries=stages().map((s,i)=>{
   const r=s.report||{},p=r.plan||{},direction=s.direction||p.output||'';
   const steady=r.analysis?.reference_steady_state||{};
   const amps=(steady.cycle_amplitudes||[]).filter(x=>x.quality==='near_command_amplitude'&&Number.isFinite(Number(x.reference_amplitude_deg))).map(x=>Number(x.reference_amplitude_deg)).sort((a,b)=>a-b);
   const measured=steady.valid===true&&amps.length?`±${fmt(amps[Math.floor(amps.length/2)],3)}°（稳态周期估计）`:'没有合格的实测幅度证明';
   const good=r.state==='completed'&&r.stopped_verified===true;
   return {direction:names[direction]||'未标明方向',inner:s.inner_target_deg??p.inner_target_deg,
    amplitude:p.amplitude_deg,frequency:p.frequency_hz,cycles:p.cycles,
    status:good?'该方向报告完成且停车确认':r.stopped_verified===true?'已确认停车；请核查采集及分析完成状态':'未确认停车/记录不完整',measured,
    feedback:steady.valid===true?'稳态周期验证通过':'稳态周期未验证通过或缺少信息',
    analysis:r.analysis?.valid===true?'研究分析有效':'分析无效/不完整',file:r.raw_file_imu||''};
 });
 $('condition-summary').innerHTML=`<div class="warn"><b>务必区分：</b>下表“设定”来自本次转台指令参数，不代表设备实际达到该幅度、频率；“实测幅度”仅为采样编码器稳态周期幅度估计。实测频率尚未独立测定，不能把0.300Hz指令直接写成实测0.300Hz。此页不是计量认证。</div>
  <div class="table-scroll"><table><thead><tr><th>测试方向</th><th>内轴位置</th><th>设定摆幅</th><th>设定频率</th><th>设定周期</th><th>实测稳态摆幅</th><th>参考与报告状态</th></tr></thead><tbody>${summaries.map(x=>`<tr><td><strong>${esc(x.direction)}</strong></td><td>${fmt(x.inner,1)}°</td><td><strong>±${fmt(x.amplitude,2)}°</strong></td><td><strong>${fmt(x.frequency,3)}Hz</strong></td><td>${esc(x.cycles??'—')}</td><td>${esc(x.measured)}</td><td>${esc(x.feedback)}；${esc(x.status)}</td></tr>`).join('')}</tbody></table></div>
  <p class="muted">ROLL与PITCH分项报告分别显示，不会把两方向误差合并冒充单轴指标。实测频率：没有独立测量结论。设备与算法仍需核对时间同步。</p>`;
}
function renderAlignment(){const a=analysis().axis_alignment||{};
 if(!a.valid){$('alignment').innerHTML=`<div class="empty">${esc(a.reason||'当前报告没有轴向对齐估计。请使用本版本重新采集三轴陀螺仪数据。')}</div>`;return}
 $('alignment').innerHTML=`<p>${esc(a.interpretation||'')}</p><div class="align-grid">
 <div class="align-item"><small>目标IMU轴</small><strong>${esc(a.target_sensor_axis||'—')}</strong></div>
 <div class="align-item"><small>外轴与目标轴夹角</small><strong>${fmt(a.misalignment_deg,3)}°</strong></div>
 <div class="align-item"><small>XY平面有符号偏差</small><strong>${fmt(a.signed_xy_deviation_deg,3)}°</strong></div>
 <div class="align-item"><small>面外偏差（Z方向）</small><strong>${fmt(a.out_of_plane_deg,3)}°</strong></div>
 <div class="align-item"><small>估计外轴向量（IMU坐标）</small><strong style="font-size:14px">[${(a.estimated_outer_axis_sensor||[]).map(x=>fmt(x,4)).join(', ')}]</strong></div>
 <div class="align-item"><small>主轴一致性 / 横向残差</small><strong>${fmt(a.gyro_axis_coherence,4)} / ${fmt(a.cross_axis_ratio_pct,2)}%</strong></div></div>
 <p class="muted">陀螺仪通道：${esc(a.channel)} · 有效样本：${a.sample_count||0} · ${esc(a.lean_direction||'')}。${esc(a.adjustment_note||'')}</p>`;
}
function keyName(k){const factory=k.startsWith('cal_factory_');let p=k.split('_'),algo=factory?k.substring(12):p.slice(1).join('_');return (factory?'仅厂标定（对齐前） · ':p[0]==='cal'?'厂标定＋静态对齐 · ':'未标定 · ')+(LABELS[algo]||algo)}
function renderTiming(){const t=analysis().time_shift_diagnostics||{};
 const view=$('error-time-view');view.querySelector('option[value="diagnostic_shifted_errors"]').disabled=!t.available;
 if(!t.available){$('time-diagnostic').textContent=t.reason||'当前数据不足或时间轴异常，不能估计时延';view.value='errors';return;}
 $('time-diagnostic').innerHTML=`<div class="align-grid"><div class="align-item"><small>共同参考时间平移</small><strong>${fmt(t.shift_reference_by_ms,1)} ms</strong></div><div class="align-item"><small>独立留出段原始RMSE</small><strong>${fmt(t.test_raw_rmse_deg,4)}°</strong></div><div class="align-item"><small>独立留出段诊断平移RMSE</small><strong>${fmt(t.test_shifted_rmse_deg,4)}°</strong></div><div class="align-item"><small>参与拟合的数据</small><strong>${esc(t.fit_channel)}</strong></div></div><p class="muted">前60%用于拟合，后40%用于验证；固定平移对所有算法相同。未进行硬件级时钟同步。</p>`;
}
function renderRootCauses(){const d=analysis().root_cause_diagnostics||{};
 if(!d.available){$('root-causes').innerHTML=`<div class="empty">${esc(d.reason||'旧报告没有本模块数据。需使用V7.8重新采集，或使用只读旧报告诊断工具。')}</div>`;return}
 const components=d.components||[];
 const find=k=>components.find(x=>x.algorithm===k);
 const gyro=find('gyro'),acc=find('accel'),guard=find('motion_guard'),adaptive=find('adaptive');
 let messages=[];
 if(gyro&&acc){const dev=Math.abs(gyro.amplitude_ratio-1),adv=Math.abs(acc.amplitude_ratio-1);
    messages.push((dev<.025&&adv>dev+.025)?'GYRO基波幅值接近参考、ACC幅值偏差更大：优先检查摇摆线加速度、偏心与重力可信度；这不直接证明标定有误。':'ACC/GYRO幅值证据不足以唯一指向融合环节，需多频率复核。');}
 if(adaptive)messages.push(`Adaptive的独立留出段：仅平移参考时间后RMSE由 ${fmt(adaptive.holdout_rmse_original_deg)}° 变为 ${fmt(adaptive.holdout_rmse_shift_only_deg)}°；剩余误差不是单靠时间平移就能证明可消除。`);
 if(gyro)messages.push(`纯GYRO在留出段的残差线性趋势约 ${fmt(gyro.holdout_residual_trend_deg_per_s,5)}°/s；该值包含时延等因素，不能直接作为传感器零偏。`);
 if(guard)messages.push('新运动干扰抑制算法与原算法并排记录；仅在独立频率和正反向工况都更好时才可进一步考虑采用。');
 $('root-causes').innerHTML=`<p class="muted">${esc(d.method||'')} · 已避开参考缺口 ${d.reference_gaps_excluded??0} 处 · 有效IMU样本 ${d.eligible_imu_samples??0}</p><div class="table-scroll"><table><thead><tr><th>校正后算法</th><th>实际参考基波</th><th>IMU基波</th><th>幅值比</th><th>表观相位滞后</th><th>留出段原始RMSE</th><th>仅平移RMSE</th><th>拟合参考平移</th></tr></thead><tbody>${components.map(x=>`<tr><td>${esc(LABELS[x.algorithm]||x.algorithm)}</td><td>±${fmt(x.reference_sine_amplitude_deg,3)}°</td><td>±${fmt(x.imu_sine_amplitude_deg,3)}°</td><td>${fmt(x.amplitude_ratio,4)}</td><td>${fmt(x.apparent_phase_lag_ms,1)}ms</td><td>${fmt(x.holdout_rmse_original_deg)}°</td><td>${fmt(x.holdout_rmse_shift_only_deg)}°</td><td>${fmt(x.holdout_optimal_reference_shift_ms,1)}ms</td></tr>`).join('')}</tbody></table></div><p>${messages.map(s=>`<p>• ${esc(s)}</p>`).join('')}</p><p class="muted">${esc(d.note||'')} 本表仅用于故障归因；时间平移、增益、零偏均未写入设备或用于正式算法排名。</p>`;
}
function renderQuality(){const a=analysis(),s=a.reference_steady_state||{},i=a.imu_sampling_diagnostics||{};
 const cycleRows=(s.cycle_amplitudes||[]).map(x=>`第${x.cycle}周期: ${x.reference_amplitude_deg==null?'无效':('±'+fmt(x.reference_amplitude_deg,3)+'°')} (${esc(x.quality)})`).join(' · ');
 const timebase=a.clock_diagnostics||{};
 $('quality-diagnostics').innerHTML=`<p><b>转台稳态门槛：</b>${s.valid?'通过':'未通过或旧报告无此记录'} · ${esc(s.reason||'旧报告未保存本项')} · 已排除启动确认周期 ${s.cycles_excluded??'—'} 个 · 有效实测整周期 ${s.cycles_evaluated??'—'} 个 · 稳态区间 ${Number.isFinite(s.steady_start_s)?fmt(s.steady_start_s-(report().motion_start_pc_monotonic_ns||0)/1e9,3)+'s':'—'} 至 ${Number.isFinite(s.steady_end_s)?fmt(s.steady_end_s-(report().motion_start_pc_monotonic_ns||0)/1e9,3)+'s':'—'} · 尾部未评估 ${fmt(s.trailing_unverified_s,2)}s</p><p class="muted">${cycleRows||'暂无逐周期反馈'}</p><div class="align-grid"><div class="align-item"><small>IMU记录平均速率</small><strong>${fmt(i.recorded_average_hz,1)} Hz</strong></div><div class="align-item"><small>设备声明 ODR</small><strong>${fmt(i.reported_odr_hz,0)} Hz</strong></div><div class="align-item"><small>IMU批间 >10ms 数量</small><strong>${i.batch_seams_over_10ms??'—'}</strong></div><div class="align-item"><small>最大记录间隔</small><strong>${fmt(i.largest_step_ms,2)} ms</strong></div><div class="align-item"><small>时间轴来源</small><strong style="font-size:13px">${esc(timebase.time_source||'未知')}</strong></div></div><p class="muted">${esc(i.warning||'仅研究级诊断；原始时间轴和数据不得伪造或插补。')}</p>`;}
function absolutePanel(a){
 const ab=a.absolute_accuracy||{},rows=ab.comparison||[],fmtErr=v=>Number.isFinite(v)?fmt(v,6)+'°':'—';
 if(!rows.length)return '<p class="warn">旧报告或参考不足：没有绝对角度误差，不能以相对误差替代。</p>';
 const primary=ab.primary||[],p=primary.find(x=>x.scope==='full_motion');
 const table=(rs)=>`<div class="table-scroll"><table class="dyn-table"><thead><tr><th>范围</th><th>算法</th><th>通道</th><th>执行</th><th>最大绝对误差</th><th>绝对RMSE</th><th>绝对P95</th><th>最大误差时刻</th><th>样本/缺失输出</th></tr></thead><tbody>${rs.map(x=>`<tr><td>${x.scope==='full_motion'?'摇摆命令期':'稳态整周期'}</td><td>${esc(LABELS[x.algorithm]||x.algorithm)}</td><td>${x.channel==='cal_factory'?'仅厂标定':x.channel==='cal'?'可含现场对齐':'未标定'}</td><td>${x.execution_mode==='realtime_capture'?'实时':'离线/未知'}</td><td>${fmtErr(x.absolute_max_error_deg)}</td><td>${fmtErr(x.absolute_angle_rmse_deg)}</td><td>${fmtErr(x.absolute_p95_error_deg)}</td><td>${fmt(x.max_error_time_s,3)}s</td><td>${x.samples}/${x.excluded_output_samples}</td></tr>`).join('')}</tbody></table></div>`;
 const general=rows.filter(x=>x.lever_status==='no_lever'&&x.channel==='cal_factory').sort((x,y)=>x.scope.localeCompare(y.scope)||x.absolute_max_error_deg-y.absolute_max_error_deg);
 const other=rows.filter(x=>x.lever_status!=='no_lever'||x.channel!=='cal_factory');
 return `<section class="panel"><h4>V7.24 · 动态绝对角度误差（不扣零位）</h4><p class="warn">仅研究性对比，未硬件同步。参考为实际编码器角度；须核对编码器零位与水平。缺口内不插值；覆盖不足不得作为全段精度。</p><p><strong>通用实时摇摆命令期最大绝对误差：${p?fmtErr(p.absolute_max_error_deg)+(ab.scopes?.full_motion?.complete_reference_coverage&&p.excluded_output_samples===0?'':'（仅可比较片段）'):'无符合条件的实时结果'}</strong> · 目标 ≤0.05°（未认证） · 全段参考覆盖 ${fmt(ab.scopes?.full_motion?.reference_coverage_pct,2)}%</p><p>单轴/三维杆臂（cm）：${esc(JSON.stringify(ab.lever_parameters_cm||{}))}</p><h4>无杆臂 · 仅厂标定</h4>${table(general)}<details><summary>杆臂及其他通道研究对照（不参与通用排名）</summary>${table(other)}</details></section>`;
}
function renderStage(){const nav=$('stage-nav');nav.innerHTML=stages().map((x,i)=>`<button data-i="${i}" class="${i===stageIndex?'active':''}">${x.direction==='pitch'?'Pitch / 内轴90°':'Roll / 内轴0°'}</button>`).join('');
 nav.querySelectorAll('button').forEach(b=>b.onclick=()=>{stageIndex=Number(b.dataset.i);renderStage()});
 const r=report(),a=analysis(),p=r.plan||{},q=a.reference_quality||{};$('stage-info').textContent=`${cur().direction==='pitch'?'Pitch · IMU Y轴对应外轴':'Roll · IMU X轴对应外轴'} · 摆幅 ±${fmt(p.amplitude_deg,2)}° · 频率 ${fmt(p.frequency_hz,3)}Hz · ${p.cycles||'—'} 周期 · 停车确认 ${r.stopped_verified===true?'通过':'未通过'}${a.reference_gaps_masked?' · 参考缺口已排除 '+q.stable_missing_reference_pct+'%，仅研究性统计':''}`;
 if(a.reference_gaps_masked)$('stage-info').textContent+=' · 注意：图中断线表示转台实际反馈缺口，绝不跨缺口插值';
 if(a.diagnostic_preview_only)$('stage-info').textContent+=a.partial_research_only?' · ⚠ 整段数据无效：仅对真实连续片段提供研究性RMSE（非验收）':' · ⚠ 稳态或参考数据不足：仅显示真实曲线，不宣称RMSE或动态精度';
 const pol=r.dynamic_reference_polarity;
 if(pol){const msg=pol.valid
   ?`参考方向核对：用户填写 ${pol.requested_sign===1?'+':'−'}，报告使用 ${pol.selected_sign===1?'+':'−'}${pol.changed?'（已修正比较方向，不改变电机运动）':'（一致）'}。依据：校正ACC角度＋校正GYRO角速度。`
   :`⚠ 参考方向尚未核实：${pol.reason||'证据不足'}；按手动符号展示，不得用作精度验收。`;
   const notice=document.createElement('p');notice.className='warn';notice.textContent=msg+' 未硬件同步，仅供研究分析。';
   $('stage-info').appendChild(notice);
 }
 $('absolute-panel').innerHTML=absolutePanel(a);$('error-time-view').querySelector('option[value=absolute]').disabled=!(a.absolute_accuracy?.chart||[]).length;if($('error-time-view').value==='absolute'&&!(a.absolute_accuracy?.chart||[]).length)$('error-time-view').value='errors';
 const ranking=a.comparison||[],previewKeys=(a.chart||[]).find(x=>x.angles&&Object.keys(x.angles).length)?.angles||{},keys=[...new Set(ranking.map(x=>`${x.channel}_${x.algorithm}`).concat(Object.keys(previewKeys)))];
 if(!selectionInitialized||selected.some(k=>!keys.includes(k))){selected=['cal_factory_gravity_observer','cal_gravity_observer','cal_gyro_anchor','cal_factory_gyro_anchor','cal_accel'].filter(k=>keys.includes(k));selectionInitialized=true;}
 $('checks').innerHTML=keys.map(k=>{let algo=k.startsWith('cal_factory_')?k.slice(12):k.split('_').slice(1).join('_');return `<label><input type="checkbox" value="${esc(k)}" ${selected.includes(k)?'checked':''}><i class="swatch" style="background:${COLORS[algo]||'#888'}"></i>${esc(keyName(k))}</label>`}).join('');
 $('checks').querySelectorAll('input').forEach(x=>x.onchange=()=>{selected=[...$('checks').querySelectorAll('input:checked')].map(v=>v.value);drawCharts()});
 $('ranking').innerHTML=ranking.length?`<p class="warn">${a.partial_research_only?'整段稳态参考质量不合格；下表仅涵盖连续可用片段，数字不能作为整次实验RMSE或精度验收。':'仅用于研究性相对跟踪比较，未进行硬件时间同步。'}</p><table><thead><tr><th>通道</th><th>算法</th><th>相对RMSE</th><th>最大误差</th><th>P95</th><th>幅值比</th><th>表观延迟</th></tr></thead><tbody>${ranking.map(x=>`<tr><td>${x.channel==='cal'?'厂标定＋静态对齐':x.channel==='cal_factory'?'仅厂标定':'未标定'}</td><td>${esc(LABELS[x.algorithm]||x.algorithm)}</td><td>${fmt(x.relative_tracking_rmse_deg)}°</td><td>${fmt(x.relative_max_error_deg)}°</td><td>${fmt(x.relative_p95_error_deg)}°</td><td>${fmt(x.amplitude_ratio,3)}</td><td>${fmt(x.apparent_phase_lag_ms,1)}ms</td></tr>`).join('')}</tbody></table>`:'<div class="empty">'+esc(a.reason||'没有有效算法误差统计')+'</div>';
 if(a.lever_research_note){const x=document.createElement('p');x.className='warn';x.textContent=a.lever_research_note;document.getElementById('root-causes').appendChild(x);}
 if(a.continuity_policy){const x=document.createElement('p');x.className='warn';const b=a.continuity_ab||{};x.textContent='V7.15 连续性：估算长缺口 '+(a.estimated_gaps_over_50ms??0)+' 次，预测 '+(a.fusion_gap_bridges??0)+' 次，重置 '+(a.fusion_gap_resets??0)+' 次。'+a.continuity_policy+(b.available?' 同数据离线A/B最大误差 '+fmt(b.legacy_reset_policy.relative_max_error_deg,4)+'° → '+fmt(b.new_bridge_policy.relative_max_error_deg,4)+'°；不替换实时结果。':'');$('files').before(x);}
 if(r.offline_replay?.offline_algorithms){const x=document.createElement('p');x.className='muted';x.textContent='实时算法：'+r.imu_algorithm_at_start+'（另含ACC直算）；其他算法仅停车后离线回放，实时CSV原样保留。';$('files').before(x);}
 $('files').innerHTML=[r.raw_file_table,r.raw_file_imu,r.offline_replay?.file,r.native_high_rate_capture?.file,DATA.report?.research_diagnosis?.html_file,DATA.report?.research_diagnosis?.zip_file].filter(Boolean).map(n=>`<a href="${esc(n)}" download>${esc(n)}</a>`).join('')||'<span class="muted">本报告未附原始CSV文件名</span>';
 renderAlignment();renderTiming();renderRootCauses();renderQuality();drawCharts();
}
function draw(id,mode){const c=$(id),ctx=c.getContext('2d'),dpr=Math.min(2,devicePixelRatio||1),w=c.clientWidth,h=c.clientHeight;if(!w||!h)return;
 c.width=w*dpr;c.height=h*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
 const absView=$('error-time-view').value==='absolute';const rows=(absView?analysis().absolute_accuracy?.chart:analysis().chart)||[];if(!rows.length){ctx.fillStyle='#68736d';ctx.fillText('没有可绘制的有效时间序列',20,28);return}
 const lines=[];if(mode==='angles')lines.push({name:'转台实际反馈',color:'#202a25',value:r=>r.reference_deg,width:2.5});
 selected.forEach(k=>lines.push({name:keyName(k),color:COLORS[k.split('_').slice(1).join('_')]||'#888',dash:k.startsWith('raw_')?[5,4]:k.startsWith('cal_factory_')?[3,4]:[],value:r=>r[(mode==='errors'&&!absView?$('error-time-view').value:mode)]?.[k]}));
 const vals=lines.flatMap(l=>rows.map(l.value).filter(Number.isFinite));if(!vals.length)return;
 let ymin=Math.min(...vals),ymax=Math.max(...vals);if(ymax-ymin<.01){ymin-=.5;ymax+=.5}else{let pad=(ymax-ymin)*.12;ymin-=pad;ymax+=pad}
 const left=62,right=18,top=18,bottom=34,cw=w-left-right,ch=h-top-bottom,xmin=rows[0].t_s,xmax=rows[rows.length-1].t_s||xmin+1;
 const X=t=>left+(t-xmin)/Math.max(.001,xmax-xmin)*cw,Y=v=>top+(ymax-v)/(ymax-ymin)*ch;
 // Measured reference-only interval, independent of any IMU algorithm result.
 // All original measurements are retained; this only labels the plot regions.
 const steady=analysis().reference_steady_state||{},begin=Number(report().motion_start_pc_monotonic_ns)/1e9;
 if(steady.valid===true&&Number.isFinite(begin)&&begin>0&&Number.isFinite(steady.steady_start_s)&&Number.isFinite(steady.steady_end_s)){
  const a=Math.max(xmin,steady.steady_start_s-begin),b=Math.min(xmax,steady.steady_end_s-begin);
  if(a>b){/* no overlap */}else{
   ctx.fillStyle='rgba(224,159,61,.10)';ctx.fillRect(left,top,Math.max(0,X(a)-left),ch);ctx.fillRect(X(b),top,Math.max(0,w-right-X(b)),ch);
   ctx.strokeStyle='rgba(13,148,136,.65)';ctx.setLineDash([4,3]);
   for(const v of [a,b]){ctx.beginPath();ctx.moveTo(X(v),top);ctx.lineTo(X(v),top+ch);ctx.stroke();}ctx.setLineDash([]);
   ctx.fillStyle='#53645e';ctx.font='10px sans-serif';ctx.fillText('仅绿色边界内为实测稳态',left+5,top+13);
  }
 }
 ctx.font='11px sans-serif';ctx.textAlign='right';ctx.fillStyle='#68736d';
 for(let i=0;i<=4;i++){let v=ymin+(ymax-ymin)*i/4,y=Y(v);ctx.strokeStyle='#e9eeea';ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(w-right,y);ctx.stroke();ctx.fillText(v.toFixed(2)+'°',left-8,y+4)}
 ctx.textAlign='center';for(let i=0;i<=4;i++){let t=xmin+(xmax-xmin)*i/4,x=X(t);ctx.fillText(t.toFixed(1)+'s',x,h-10)}
 lines.forEach(l=>{ctx.beginPath();ctx.strokeStyle=l.color;ctx.lineWidth=l.width||1.8;ctx.setLineDash(l.dash||[]);let open=false;
 rows.forEach(r=>{let v=l.value(r);if(!Number.isFinite(v)){open=false;return}let x=X(r.t_s),y=Y(v);if(!open){ctx.moveTo(x,y);open=true}else ctx.lineTo(x,y)});ctx.stroke();ctx.setLineDash([])});
 ctx.textAlign='left';ctx.fillStyle='#68736d';ctx.fillText(mode==='angles'?'角度（°）':'误差（°）',left,12);
}
function drawCharts(){draw('angle-chart','angles');draw('error-chart','errors')}
$('error-time-view').onchange=drawCharts;
$('pick-cal').onclick=()=>{selected=[...$('checks').querySelectorAll('input')].map(x=>x.value).filter(k=>k.startsWith('cal_')&&!k.startsWith('cal_factory_')&&!k.endsWith('_gyro'));renderStage()};
$('pick-all').onclick=()=>{selected=[...$('checks').querySelectorAll('input')].map(x=>x.value);renderStage()};
$('pick-none').onclick=()=>{selected=[];renderStage()};window.addEventListener('resize',drawCharts);
renderMeta();renderConditions();renderStage();
</script></body></html>'''


def _safe_json(data: dict) -> str:
    return (json.dumps(data, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
            .replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e")
            .replace("</", "<\\/"))


def write_interactive_report(report_path: Path) -> Path:
    report_path = Path(report_path)
    report = json.loads(report_path.read_text(encoding="utf-8"))
    if report.get("kind") == "REAL_2TD600_XY_SEQUENTIAL":
        stages = [{"direction": item.get("direction"), "inner_target_deg": item.get("inner_target_deg"),
                   "report": item.get("report") or {}} for item in report.get("tests", [])]
    else:
        stages = [{"direction": (report.get("plan") or {}).get("output"),
                   "inner_target_deg": (report.get("plan") or {}).get("inner_target_deg"),
                   "report": report}]
    data = {"kind": report.get("kind"), "report": report, "stages": stages}
    out = report_path.with_suffix(".html")
    out.write_text(_TEMPLATE.replace("__REPORT_DATA__", _safe_json(data)), encoding="utf-8")
    return out
