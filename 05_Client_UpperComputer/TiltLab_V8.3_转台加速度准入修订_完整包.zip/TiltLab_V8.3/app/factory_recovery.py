"""V7.17 factory calibration handoff. No motion, no calibration fitting.
Original calibrator must be operated separately; only imports its genuine outputs.
"""
import hashlib, json, os, shutil, tempfile, uuid
from pathlib import Path
from datetime import datetime
from .calibration import scan


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.now().astimezone().isoformat()


def write_json(path, doc):
    Path(path).write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf-8')


def atomic_copy(src,dst):
    dst=Path(dst)
    fd,tmp=tempfile.mkstemp(prefix='.calibration-',suffix='.tmp',dir=dst.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(Path(src).read_bytes());f.flush();os.fsync(f.fileno())
        os.replace(tmp,dst)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def prepare(engine, run, workspace, *, manual=False):
    if run.get('running') or (not manual and (run.get('state')!='stopped_or_failed' or run.get('stopped_verified') is not True)):
        raise ValueError('仅允许在本次实验中止并确认停车后准备标定交接')
    if not manual and ('静态未达到设定门槛' not in str(run.get('error','')) or (run.get('plan') or {}).get('calibration_only')):
        raise ValueError('不是静态精度门槛失败，不自动建议重标定')
    if not engine.connected or engine.source!='serial' or engine.cal_mode!='ambient' or engine.cal_status!='matched' or not engine.uid or not engine.uid_hex:
        raise ValueError('需要当前真实设备及有效常温ACC/GYRO配对')
    base=Path(engine.cal_root).resolve(); work=Path(workspace).resolve()
    if work==base or base in work.parents:raise ValueError('备份与暂存目录不可位于标定扫描目录内')
    old=scan(base,engine.uid,engine.uid_hex)
    if old['status']!='matched' or old.get('issues'):raise ValueError('原标定目录不具备唯一无冲突配对：'+old['detail'])
    targets=[Path(old[s].path).resolve() for s in ('acc','gyro')]
    if targets[0]==targets[1] or any(base not in p.parents for p in targets):raise ValueError('仅支持两份独立常温JSON，且位于原标定目录中')
    if any(old[s]!=engine.cal[s] for s in ('acc','gyro')):raise ValueError('磁盘标定与当前内存参数不同，请先处理文件冲突')
    job=work/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+engine.uid+'_'+uuid.uuid4().hex[:8]);job.mkdir(parents=True)
    backup=job/'backup';stage=job/'new_calibration';backup.mkdir();stage.mkdir()
    pairs=[]
    for sensor,p in zip(('acc','gyro'),targets):
        b=backup/(sensor+'_'+p.name);shutil.copy2(p,b)
        h=digest(p)
        if digest(b)!=h:raise ValueError('备份内容校验失败')
        pairs.append({'sensor':sensor,'target':str(p),'backup':str(b),'old_sha256':h})
    state={'state':'awaiting_external_calibration','uid':engine.uid,'uid_hex':engine.uid_hex,'cal_root':str(base),'job':str(job),'stage_folder':str(stage),'pairs':pairs,'started_at':now(),'run_manifest_file':run.get('run_manifest_file'),'note':'R10标定结果先暂存；主进程验证配对后事务式导入。'}
    write_json(job/'handoff.json',state)
    return state


def import_pair(engine, state):
    if state.get('state')!='awaiting_external_calibration':raise ValueError('没有待导入标定任务')
    if not engine.connected or not engine.running or engine.source!='serial' or engine.uid!=state['uid'] or engine.uid_hex!=state['uid_hex'] or engine.cal_mode!='ambient' or Path(engine.cal_root).resolve()!=Path(state['cal_root']):
        raise ValueError('请关闭原标定软件，重新连接相同IMU、原标定目录和常温模式')
    if engine.record_fp or (engine.stability and engine.stability.state=='running'):raise ValueError('先结束IMU录制及静态实验')
    new=scan(state['stage_folder'],state['uid'],state['uid_hex'])
    if new['status']!='matched' or new.get('issues'):raise ValueError('暂存目录未得到唯一有效的新ACC/GYRO配对：'+new['detail'])
    src=[Path(new[s].path).resolve() for s in ('acc','gyro')]
    stage=Path(state['stage_folder']).resolve()
    if src[0]==src[1] or any(stage not in p.parents for p in src):raise ValueError('要求两份独立新标定文件')
    new_hashes=[digest(p) for p in src]
    for pair,h in zip(state['pairs'],new_hashes):
        if h==pair['old_sha256']:raise ValueError('新'+pair['sensor']+'文件与旧文件内容完全一致，无法确认重新标定')
        if digest(pair['target'])!=pair['old_sha256'] or digest(pair['backup'])!=pair['old_sha256']:
            raise ValueError('原文件或备份已变化；禁止自动覆盖，请人工处理')
    # Keep immutable source copies for provenance and use existing parser/loader.
    job=Path(state['job']);saved=job/'imported';saved.mkdir(exist_ok=True)
    frozen=[]
    for i,p in enumerate(src):
        q=saved/(state['pairs'][i]['sensor']+'_'+p.name);shutil.copy2(p,q)
        if digest(q)!=new_hashes[i]:raise ValueError('新文件复制时发生变化')
        frozen.append(q)
    with engine.lock:
        installed=[]
        try:
            for pair,p in zip(state['pairs'],frozen):
                atomic_copy(p,pair['target']);installed.append(pair)
            engine.params.lever_z_cm=0.;engine.clear_lever3d();engine.active='gyro_anchor'
            result=engine.lookup_calibration();engine.latest=None
            if result['status']!='matched' or any(digest(engine.cal[s].path)!=h for s,h in zip(('acc','gyro'),new_hashes)):
                raise ValueError('新标定未能通过原加载流程或内容指纹不符')
            out={**state,'state':'loaded','finished_at':now(),'new_sha256':dict(zip(('acc','gyro'),new_hashes)), 'loaded_files':list(engine.cal['files']), 'quality':new.get('quality'),'temperature':new.get('temperature'),'algorithm':'gyro_anchor','note':'新参数已加载，重新收敛；未执行独立精度验收，需重新开始静态预检。'}
            write_json(job/'handoff.json',out)
            engine.log('V7.23 新常温ACC/GYRO已加载，融合重置；待重新静态前检')
            return out
        except Exception:
            for pair in installed:atomic_copy(pair['backup'],pair['target'])
            engine.lookup_calibration();engine.latest=None
            raise
