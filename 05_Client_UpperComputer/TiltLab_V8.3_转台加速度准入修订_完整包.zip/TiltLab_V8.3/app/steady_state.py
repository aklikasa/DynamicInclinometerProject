"""Conservative, encoder-only detection of steady sinusoidal table motion.

The timing of a manufacturer DLL sway command is NOT a zero-crossing timestamp.
Search multiple phase origins, require two *distinct, non-overlapping* full
periods with comparable measured peak-to-peak amplitude, then reserve a further
full period for evaluation. The true table readings are the only reference;
commanded sine values are never substituted for missing position samples.

A gap in candidate cycles is not silently filled. Gaps >400 ms in the chosen
measurement interval are censored later by ``analyze_tracking`` and a severe
gap invalidates research metrics. Safety/motor commands do not depend on this
function.
"""
from __future__ import annotations
import math
import numpy as np


def find_sway_steady_start(times, positions, motion_start_s, motion_end_s,
                           frequency_hz, target_amplitude_deg):
    t=np.asarray(times,dtype=float); p=np.asarray(positions,dtype=float)
    result={'valid':False,'method':'measured_phase_sine_cycles_with_terminal_validation_v830',
            'hardware_synchronized':False,'cycle_amplitudes':[],
            'reason':'尚未识别到两个连续的稳定完整周期'}
    if len(t)<20 or len(t)!=len(p) or not np.isfinite(t).all() or not np.isfinite(p).all():
        result['reason']='反馈数不足或存在无效数值';return result
    if not np.all(np.diff(t)>0):
        result['reason']='转台反馈时间戳非严格递增';return result
    if frequency_hz<=0 or target_amplitude_deg<=0 or motion_end_s<=motion_start_s:
        result['reason']='实验参数无效';return result
    period=1./frequency_hz
    if motion_end_s-motion_start_s < 3*period-.31:
        result['reason']='运动周期过短，不能完成两周期稳态识别并留下一周期评价';return result
    # Search origin independently of the moment the DLL acknowledged the motion
    # command: the controller can ramp in and its sine phase is not specified.
    offsets=np.linspace(0.,period,13,endpoint=False)
    winners=[];traces_by_offset={};best_trace=[];best_passed=-1;best_pair=False;best_missing=None
    gaps=np.diff(t)
    for offset in offsets:
        trace=[];passed=[]
        origin=motion_start_s+float(offset)
        k=0
        while origin+(k+1)*period <= motion_end_s+.001:
            left=origin+k*period;right=left+period
            ids=np.flatnonzero((t>=left)&(t<right))
            subset=p[ids];stamp=t[ids]
            large=float(np.max(np.diff(stamp))) if len(stamp)>1 else math.inf
            # Allow one modest missing bracket during *selection*; the metric
            # layer still excludes ALL brackets above 400 ms, and enforces its
            # own maximum lost-time ratio. Never interpolate to find peaks.
            enough=(len(stamp)>=max(9,int(period*3)) and large<=.750
                    and stamp[0]-left<=min(.4,period*.15)
                    and right-stamp[-1]<=min(.4,period*.15)) if len(stamp) else False
            amplitude=float((np.percentile(subset,97)-np.percentile(subset,3))/2) if enough else None
            fit_rms=None;fit_phase=None
            if enough:
                # Fit only the *measured* encoder samples; no synthetic positions,
                # no table-command phase alignment and no IMU-based selection.
                w=2*math.pi*frequency_hz
                mat=np.column_stack((np.sin(w*stamp),np.cos(w*stamp),np.ones(len(stamp))))
                params=np.linalg.lstsq(mat,subset,rcond=None)[0]
                fit_rms=float(np.sqrt(np.mean((subset-mat@params)**2)))
                fit_phase=float(math.atan2(params[1],params[0]))
            amplitude_good=bool(amplitude is not None and .90*target_amplitude_deg<=amplitude<=1.10*target_amplitude_deg)
            waveform_good=bool(fit_rms is not None and fit_rms<=max(.03,.08*target_amplitude_deg))
            good=amplitude_good and waveform_good
            passed.append(good)
            trace.append({'cycle':k+1,'phase_offset_s':round(float(offset),4),
                          'start_s':round(float(left),6),'end_s':round(float(right),6),
                          'samples':int(len(stamp)),'reference_amplitude_deg':round(amplitude,5) if amplitude is not None else None,
                          'sine_fit_rmse_deg':round(fit_rms,5) if fit_rms is not None else None,
                          'fit_phase_rad':round(fit_phase,5) if fit_phase is not None else None,
                          'largest_in_cycle_gap_ms':round(large*1000,1) if np.isfinite(large) else None,
                          'quality':'near_command_amplitude' if good else ('insufficient_or_stale_feedback' if not enough else 'ramping_or_non_sinusoidal')})
            if k>=1 and passed[k] and passed[k-1]:
                prev=trace[-2]['reference_amplitude_deg']
                if abs(amplitude-prev)<=max(.3,target_amplitude_deg*.06):
                    steady_start=right
                    stable_end=motion_end_s-.3
                    if stable_end-steady_start >= period-.31:
                        # The eventual analysis does not bridge >400ms feedback
                        # gaps. Prefer a candidate whose evaluation region is
                        # sufficiently covered to allow meaningful statistics.
                        lost=0.;largest=0.
                        for i in np.flatnonzero(gaps>.4+1e-10):
                            overlap=max(0.,min(float(t[i+1]),stable_end)-max(float(t[i]),steady_start))
                            if overlap>0:
                                lost+=overlap;largest=max(largest,float(gaps[i]))
                        missing_pct=100.*lost/max(.001,stable_end-steady_start)
                        best_pair=True
                        best_missing=missing_pct if best_missing is None else min(best_missing,missing_pct)
                        # Do not evade a large late gap by choosing a later
                        # start: the research metric layer must see and reject
                        # such gaps instead of silently shortening the test.
                        winners.append((steady_start,missing_pct,float(offset),k+1,trace.copy()))
            k+=1
        traces_by_offset[float(offset)]=trace
        good_count=sum(passed)
        if good_count>best_passed:
            best_passed=good_count;best_trace=trace
    if winners:
        # Evaluate an independent series of COMPLETE observed sine cycles.
        # Never include a potentially decelerating last partial cycle, and
        # never shorten a run to hide an internal transient or reference gap.
        for start,missing,phase,excluded,_ in sorted(winners,key=lambda x:(x[0],x[1])):
            trace=traces_by_offset[phase]
            eligible=[x for x in trace[excluded:] if x['end_s']<=motion_end_s-.3+1e-6]
            if not eligible:continue
            first_bad=None
            for j,x in enumerate(eligible):
                if x['quality']!='near_command_amplitude':
                    first_bad=j;break
            if first_bad is not None:
                # A bad period with later good periods is an internal quality
                # anomaly, not a valid stop-ramp to discard silently.
                if any(x['quality']=='near_command_amplitude' for x in eligible[first_bad+1:]):
                    result['reason']='已检测到运动中段波形异常或反馈缺口，不能将其伪装成停车过渡段'
                    continue
                if eligible[first_bad]['quality']=='insufficient_or_stale_feedback':
                    result['reason']='稳态评价周期出现反馈缺口，不能以截断周期绕过数据质量检查'
                    continue
                if first_bad==0:continue
                accepted=eligible[:first_bad]
            else:
                accepted=eligible
            if not accepted:continue
            # All accepted periods are full, measured, phase-independent sine
            # comparisons, not just a fixed 0.3s haircut at the final STOP.
            end=float(accepted[-1]['end_s'])
            if end-start < period-.01:continue
            # Recompute reference gaps ONLY in the chosen full-cycle window.
            lost=0.;largest=0.
            for gi in np.flatnonzero(gaps>.4+1e-10):
                overlap=max(0.,min(float(t[gi+1]),end)-max(float(t[gi]),start))
                if overlap>0:
                    lost+=overlap;largest=max(largest,float(gaps[gi]))
            lost_pct=100.*lost/max(.001,end-start)
            result.update(valid=True,steady_start_s=float(start),steady_end_s=end,
                          cycles_excluded=int(excluded),cycles_evaluated=len(accepted),
                          phase_offset_s=round(phase,5),
                          stable_missing_reference_pct=round(lost_pct,3),
                          trailing_unverified_s=round(max(0.,motion_end_s-end),4),
                          cycle_amplitudes=trace,
                          reason='前两个实测周期确认稳定；仅评价后续完整、连续、实测正弦合格周期；尾段独立保留，不用于稳态排名')
            return result
    result['cycle_amplitudes']=best_trace
    result['qualifying_cycles_in_best_phase']=max(0,best_passed)
    if best_pair:
        result['reason']=('检测到稳态周期，但剩余参考反馈存在缺口；'
                          f'最小缺失比例约{best_missing:.2f}%，后续分析须独立检查')
    else:
        result['reason']=('多相位搜索后仍不足两个连续完整稳态周期；'
                          f'最优周期划分中单独符合幅值条件的周期有{max(0,best_passed)}个，'
                          '请检查逐周期幅值及采样缺口')
    return result
