"""Operator-approved, single-action 2TD-600 Roll / Pitch / joint experiment.

Kinematics from user-confirmed U-T fixture:
  inner 0°: IMU X // outer shaft 2 => Roll
  inner 90°: IMU Y // outer shaft 2 => Pitch
The inner shaft changes the measurement orientation ONLY when outer is at zero.
All actual sinusoidal motion is issued to outer shaft 2. There is no unattended
operation: a live browser heartbeat, feedback and physical E-stop are required.
"""
from __future__ import annotations
import datetime as dt,json,math,threading,time
from pathlib import Path
from .angles import angle_delta_deg,zero_distance_deg
from .dynamic_experiment import limits
from .table_diagnostics import DIAG
from .static_accuracy import StaticBeforeDynamic
from .static_alignment import fit_static_alignment
from .reference_polarity import infer_static_polarity, update_static_polarity
from .run_ledger_html import write_run_ledger_html
from .mount_calibration_storage import store_verified_mount_alignment

MODES={
    'x_outer':(('roll',0),),
    'y_inner_90':(('pitch',90),),
    'xy_sequential':(('roll',0),('pitch',90)),
}

def is_completed_capture_with_invalid_analysis(done):
    """Only reference/steady-state quality invalid, with verified physical stop.

    This classification NEVER permits unverified stop or another automatic axis
    movement. It does not classify a genuinely incomplete/unsafe run as success.
    """
    return (done.get('state')=='analysis_invalid'
            and done.get('stopped_verified') is True
            and bool(done.get('report_file')))


class IMUWatchdogError(RuntimeError):
    """Latching fault; never autorun another motion after a watchdog trip."""


class AutoDynamicWorkflow:
    def __init__(self,table,engine,preparation,dynamic,monitor=None,static=None):
        self.table=table;self.engine=engine;self.prep=preparation;self.dynamic=dynamic
        self.monitor=monitor;self.static=static
        self.static_precheck=StaticBeforeDynamic(table,engine,getattr(dynamic,'dir',Path('.')))
        self.static_reports=[];self.static_check_info=[];self.static_progress=None
        self.alignment_result=None;self.alignment_file=None;self.polarity_checks=[];self.mount_axis_checks=[]
        self.lock=threading.RLock();self.cancel=threading.Event();self.thread=None
        self.running=False;self.state='idle';self.error='';self.plan=None
        self.heartbeat_ns=0;self.started_at=None;self.report_file=None
        self.stopped_verified=None;self.stages=[];self.current_stage=None;self.run_manifest_file=None;self.run_manifest_html_file=None
        self.disable_supervisor=None;self.mount_calibration_file=None;self.servo_disable_results=[]
        self.mount_recovery=None;self.interrupted_dynamic_stage=None
        self.pre_research_results=[];self.pre_research_progress=None;self.optimization={'state':'not_requested'}
        self.diagnosis={'state':'not_requested'};self.motion_completed=False;self.report_completed=False;self.post_report_health=None
    def status(self):
        with self.lock:
            return {'running':self.running,'state':self.state,'error':self.error,
                    'plan':self.plan,'started_at':self.started_at,
                    'report_file':self.report_file,'run_manifest_file':self.run_manifest_file,'run_manifest_html_file':self.run_manifest_html_file,'stopped_verified':self.stopped_verified,
                    'completed_stages':list(self.stages),'current_stage':self.current_stage,
                    'research_diagnosis':dict(self.diagnosis),'pre_research_results':list(self.pre_research_results),'pre_research_progress':self.pre_research_progress,'optimization':dict(self.optimization),'motion_completed':self.motion_completed,'report_completed':self.report_completed,'post_report_health':self.post_report_health,
                    'static_reports':list(self.static_reports),'static_check_info':list(self.static_check_info),
                    'static_progress':self.static_progress,'static_alignment':self.alignment_result,'static_alignment_file':self.alignment_file,
                    'polarity_checks':list(self.polarity_checks),'mount_axis_checks':list(self.mount_axis_checks),
                    'mount_calibration_file':self.mount_calibration_file,'servo_disable_results':list(self.servo_disable_results),
                    'mount_recovery':self.mount_recovery,'interrupted_dynamic_stage':self.interrupted_dynamic_stage,
                    'preparation':self.prep.status(),'experiment':self.dynamic.status(),
                    'note':'测试期间必须现场监护，外轴0°时才可切换内轴方向；硬件急停随时可用'}
    def _check_inputs(self,axis,output,sign,amp,freq,cycles,zero_speed,mounting_mode='x_outer',fixture_confirmed=False,pitch_sign=1):
        if axis!=2:raise ValueError('动态摆动固定外轴2；内轴0只用于切换方向')
        if sign not in (-1,1) or pitch_sign not in (-1,1):raise ValueError('角度正负方向必须选+1或-1')
        if mounting_mode not in MODES:raise ValueError('请选择Roll、Pitch或联合测试')
        expected={'x_outer':'roll','y_inner_90':'pitch','xy_sequential':'both'}[mounting_mode]
        if output!=expected:raise ValueError('所选测试模式与输出通道不匹配')
        if mounting_mode!='x_outer' and fixture_confirmed is not True:
            raise ValueError('涉及内轴90°定位，须现场确认0–90°运动路径、滑环和装夹空间')
        metrics=limits(amp,freq,cycles)
        if not math.isfinite(zero_speed) or not .2<=zero_speed<=5:
            raise ValueError('普通回零/方向定位速度需在0.2–5.0°/s之间')
        return metrics
    def _preconditions(self):
        if not self.table.connected:raise ValueError('请先连接2TD-600转台')
        if self.monitor and self.monitor.running:raise ValueError('请先结束转台只读记录')
        if self.static and self.static.running:raise ValueError('请先结束转台静态自动测试')
        if self.prep.running or self.dynamic.running:raise ValueError('转台已有其他运动任务')
        e=self.engine
        if getattr(e,'pipeline_mode','offline') not in ('offline','realtime'):
            raise ValueError('完整自动实验仅支持离线采集或选定单算法实时；并行研究模式不允许')
        if not (e.running and e.connected and e.source=='serial' and e.latest):raise ValueError('请先连接真实PCB并确认数据正在更新')
        if not(e.cal_status=='matched' and e.cal and e.cal_mode in ('ambient','thermal') and ((e.latest.get('acc_cal') is not None and e.latest.get('gyro_cal') is not None) or (getattr(e,'pipeline_mode','realtime')=='realtime' and e.latest.get('cal') is not None))):
            raise ValueError('标定文件未应用；不能运行本次自动测试')
        if time.time()-e.last_wall>.75:raise ValueError('倾角仪数据已停止更新')
        health=e.link_watchdog_status() if hasattr(e,'link_watchdog_status') else {}
        if health.get('pipeline_error') or any(health.get(k) is not None and health[k]>750 for k in ('child_receipt_age_ms','fusion_receipt_age_ms')):
            raise ValueError('实时采集异常；请在确认停车后人工恢复连接，禁止启动运动')
        if e.stability and e.stability.state=='running':raise ValueError('请先结束静态稳定性实验')
        if e.record_fp:raise ValueError('请先停止普通录制，自动实验独立保存数据')
        st=self.table.read_status();self.prep._safety(st)
        return st
    def start(self,axis,output,sign,amp,freq,cycles,zero_speed,acknowledged,mounting_mode='x_outer',fixture_confirmed=False,pitch_sign=1,
              static_before_dynamic=False,static_limit_deg=.1,static_stop_on_fail=True,auto_static_align=False,pre_sway_axis_check=False,
              calibration_only=False,load_secured=False,research_diagnostics=False,pre_research=False,pre_research_seconds=60,research_optimize=False,static_position_speed_dps=None):
        if acknowledged is not True:raise ValueError('请在现场确认工装、运动路径和实体急停后再启动')
        if any(type(v) is not bool for v in (research_diagnostics,pre_research,research_optimize)):raise ValueError('研发选项必须是布尔值')
        if type(pre_research_seconds) is not int or pre_research_seconds not in (30,60,120,600):raise ValueError('静止诊断时间须为30/60/120/600秒')
        if research_optimize and not research_diagnostics:raise ValueError('离线寻优须启用实验后诊断')
        if (pre_research or research_optimize) and auto_static_align:raise ValueError('研发闭环不允许现场经验对齐')
        if calibration_only and (pre_research or research_optimize):raise ValueError('独立安装标定不执行研发闭环')
        if calibration_only and research_diagnostics:raise ValueError('独立安装标定不执行动态研发诊断')
        if calibration_only:
            if not (mounting_mode=='xy_sequential' and fixture_confirmed is True and
                    static_before_dynamic is True and auto_static_align is True and pre_sway_axis_check is True and
                    static_stop_on_fail is True and load_secured is True):
                raise ValueError('一键安装标定必须执行两轴静态检查/独立验证，并确认完整机械路径及负载支撑')
        zero_speed=float(zero_speed)
        static_speed=min(zero_speed,3.) if static_position_speed_dps is None else float(static_position_speed_dps)
        if not math.isfinite(static_speed) or not .2<=static_speed<=3.:raise ValueError('静态定位速度须为0.2–3°/s')
        metrics=self._check_inputs(axis,output,sign,amp,freq,cycles,zero_speed,mounting_mode,fixture_confirmed,pitch_sign)
        if any(type(v) is not bool for v in (static_before_dynamic,static_stop_on_fail,auto_static_align,pre_sway_axis_check)):
            raise ValueError('静态检查选择必须是明确的布尔值')
        if not math.isfinite(static_limit_deg) or not .01<=static_limit_deg<=5:
            raise ValueError('静态参考阈值需在0.01°～5°之间')
        if getattr(self.engine,'pipeline_mode','offline')=='offline' and (static_before_dynamic or auto_static_align or pre_sway_axis_check or pre_research):
            raise ValueError('离线采集模式不支持动态前14点角度精度/现场对齐/融合初始化；请取消这些选项或切换单算法实时模式。独立安装标定仍保留原安全流程。')
        if pre_sway_axis_check and not static_before_dynamic:
            raise ValueError('安装轴预检必须同时启用动态前静态14点检测')
        if auto_static_align and (not static_before_dynamic or mounting_mode!='xy_sequential'):
            raise ValueError('自动两轴安装对齐要求Roll+Pitch联合实验且启用静态多点前检；单方向可关闭自动对齐后单独测试')
        if static_before_dynamic and amp<1.:
            raise ValueError('当前动态幅度小于1°，不适用14点静态前检；请先手动核验小角度静态精度，或明确关闭此自动前检')
        with self.lock:
            if self.running:raise ValueError('自动测试正在运行')
            try:
                st=self._preconditions()
                if pre_research and (getattr(self.engine,'active',None)!='gyro_anchor' or abs(self.engine.params.lever_z_cm)>1e-12):raise ValueError('静止研发初始化仅支持无杆臂Gyro Anchor')
                DIAG.snapshot('auto_preconditions',st,'联合测试启动前转台状态')
            except Exception as exc:
                DIAG.record('auto_preconditions_failed','启动条件未满足，未发送运动指令',error_message=str(exc),exception=type(exc).__name__)
                raise
            self.plan={'axis':2,'output':output,'sign':sign,'pitch_sign':pitch_sign,
                       'requested_roll_sign':sign,'requested_pitch_sign':pitch_sign,
                       'amplitude_deg':amp,'frequency_hz':freq,'cycles':cycles,'zero_speed_dps':zero_speed,'static_position_speed_dps':static_speed,
                       'mounting_mode':mounting_mode,'fixture_confirmed':bool(fixture_confirmed),
                       'static_before_dynamic':static_before_dynamic,'static_limit_deg':float(static_limit_deg),
                       'static_stop_on_fail':static_stop_on_fail,'auto_static_align':auto_static_align,'pre_sway_axis_check':pre_sway_axis_check,
                       'calibration_only':bool(calibration_only),'load_secured':bool(load_secured),'research_diagnostics':research_diagnostics,'pre_research':pre_research,'pre_research_seconds':pre_research_seconds,'research_optimize':research_optimize,
                       'stages':[{'output':out,'inner_target_deg':deg} for out,deg in MODES[mounting_mode]],**metrics}
            self.cancel.clear();self.running=True;self.state='prechecking';self.error=''
            self.pre_research_results=[];self.pre_research_progress=None;self.optimization={'state':'pending' if research_optimize else 'not_requested'}
            self.diagnosis={'state':'pending' if research_diagnostics else 'not_requested'};self.motion_completed=False;self.report_completed=False;self.post_report_health=None
            self.report_file=None;self.stopped_verified=None;self.stages=[];self.current_stage=None;self.run_manifest_file=None;self.run_manifest_html_file=None
            self.static_reports=[];self.static_check_info=[];self.static_progress=None;self.alignment_result=None;self.alignment_file=None;self.polarity_checks=[];self.mount_axis_checks=[];self.run_manifest_html_file=None
            self.mount_calibration_file=None;self.servo_disable_results=[];self.mount_recovery=None;self.interrupted_dynamic_stage=None
            self.heartbeat_ns=time.monotonic_ns();self.started_at=time.time()
            self.thread=threading.Thread(target=self._run,daemon=True,name='2TD600-XY-sequential-test')
            DIAG.record('auto_start','操作员确认启动自动动态测试',plan=self.plan)
            self.thread.start()
        return self.status()
    def heartbeat(self):
        with self.lock:
            if not self.running:raise ValueError('没有运行中的自动实验')
            self.heartbeat_ns=time.monotonic_ns()
        return {'ok':True}
    def abort(self):
        self.cancel.set()
        with self.lock:
            if self.running:self.state='aborting'
        if self.prep.running:self.prep.abort()
        if self.dynamic.running:self.dynamic.abort()
        if self.table.connected:self.table.stop()
        return self.status()
    def _watch(self):
        if self.cancel.is_set():raise RuntimeError('操作员中止实验')
        if time.monotonic_ns()-self.heartbeat_ns>6_000_000_000:
            raise RuntimeError('操作页面失去心跳，已申请停车')
        if not self.table.connected:raise RuntimeError('转台失去连接')
        e=self.engine
        health=e.link_watchdog_status() if hasattr(e,'link_watchdog_status') else {}
        stale=any(health.get(k) is not None and health[k]>750 for k in ('child_receipt_age_ms','fusion_receipt_age_ms'))
        if not(e.running and e.connected and e.source=='serial') or time.time()-e.last_wall>.75 or stale or health.get('pipeline_error'):
            DIAG.record('imu_watchdog_failure','原始收包/融合数据新鲜度不合格；停止运动',**health)
            raise IMUWatchdogError('倾角仪数据中断，停止运动')
    def _await(self,subtask):
        while subtask.running:
            self._watch()
            try:subtask.heartbeat()
            except ValueError:
                if subtask.running:raise
            if self.cancel.wait(.25):raise RuntimeError('操作员已中止自动测试')
        self._watch()
    def _validate_staging_feedback(self,st):
        axes=st.get('axes') or {}
        for i in (0,2):
            x=axes.get(str(i),{})
            if not(x.get('enabled') and x.get('zeroed') and x.get('healthy')):
                raise RuntimeError(f'轴{i}使能、零位或正常反馈失效，停止定位')
            if any(x.get(k) for k in ('driver_fault','upper_limit','lower_limit','over_speed')):
                raise RuntimeError(f'轴{i}出现限位/驱动/超速报警')
            if not all(isinstance(x.get(k),(int,float)) and math.isfinite(x[k]) for k in ('position_deg','speed_dps')):
                raise RuntimeError(f'轴{i}位置或速度反馈异常')
            if abs(x['speed_dps'])>max(6.5,self.plan['zero_speed_dps']+1):
                raise RuntimeError(f'轴{i}速度超出方向定位监控包络')
        return axes
    def _position(self,axis,target):
        """Sequentially move into one of the three allowed staging states.
        Outer must be at 0° before inner moves; NEVER move the two together.
        """
        if (axis,target) not in ((2,0),(0,0),(0,90)):
            raise ValueError('禁止未定义的测试位置')
        self._watch();speed=self.plan['zero_speed_dps']
        axes=self._validate_staging_feedback(self.table.read_status())
        other=0 if axis==2 else 2
        if abs(axes[str(other)]['speed_dps'])>.06 or axes[str(other)]['mode'] not in (0,2,20):
            raise RuntimeError('另一轴仍在运动，禁止方向切换')
        if axis==0 and zero_distance_deg(axes['2']['position_deg'])>.12:
            raise RuntimeError('外轴未回0°，禁止内轴0°/90°方向切换')
        now=axes[str(axis)]['position_deg']
        if abs(angle_delta_deg(now,target))<=.08 and abs(axes[str(axis)]['speed_dps'])<.06 and axes[str(axis)]['mode'] in (0,2,20):
            DIAG.record('stage_position_skip',f'轴{axis}已在目标{target}°，无需定位')
            return
        with self.lock:self.state=f'positioning_axis_{axis}_to_{target}'
        DIAG.record('stage_position_start',f'轴{axis}按{speed}°/s定位{target}°',current=now,target=target)
        if axis==0:
            self.table.move_inner_test_orientation(target,speed)
        else:self.table.move(axis,0,speed)
        # Allow the commanded motion to start and then wait for 3 consecutive
        # valid stationary feedback samples. 90° at 2°/s is ~45 seconds.
        wait_seconds=min(900,max(25,2.2*abs(angle_delta_deg(now,target))/speed+25))
        deadline=time.monotonic()+wait_seconds;stable=0
        while time.monotonic()<deadline:
            self._watch()
            axes=self._validate_staging_feedback(self.table.read_status())
            x=axes[str(axis)]
            if axis==0 and zero_distance_deg(axes['2']['position_deg'])>.12:
                raise RuntimeError('内轴运动过程中外轴偏离0°，停止定位')
            if abs(axes[str(other)]['speed_dps'])>.06:
                raise RuntimeError('非目标轴发生运动，停止定位')
            if abs(angle_delta_deg(x['position_deg'],target))<=.08 and abs(x['speed_dps'])<.06 and x['mode'] in (0,2,20):
                stable+=1
                if stable>=3:
                    DIAG.record('stage_position_done',f'轴{axis}已定位{target}°',feedback=x['position_deg'])
                    return
            else:stable=0
            if self.cancel.wait(.15):raise RuntimeError('操作员已中止')
        raise TimeoutError(f'轴{axis}定位{target}°超时；停止所有轴')
    def _create_joint_report(self,stages,partial=False):
        """After verified STOP: never parse/serialize multi-MB reports in live process."""
        from .auto_research_report import run_postprocess
        folder=Path(self.dynamic.dir);folder.mkdir(parents=True,exist_ok=True)
        label=dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        uid=''.join(c for c in str(getattr(self.engine,'uid',None) or 'UNKNOWN') if c.isalnum() or c in '-_')[:48]
        fname=f'{label}_{uid}_XY_DYNAMIC_COMBINED.json'
        metadata={'kind':'REAL_2TD600_XY_SEQUENTIAL','state':'partial' if partial else 'completed','uid':uid,
             'plan':self.plan,'finished_at':dt.datetime.now().astimezone().isoformat(),
             'pre_research_results':self.pre_research_results,'static_prechecks':self.static_check_info,'static_alignment':self.alignment_result,
             'calibration_mode':getattr(self.engine,'cal_mode',None),
             'factory_calibration_files':list((self.engine.cal or {}).get('files',[])),
             'quality':'RESEARCH_ONLY_UNSYNCHRONIZED','certified_dynamic_accuracy':False,
             'polarity_checks':list(self.polarity_checks),'mount_axis_checks':list(self.mount_axis_checks),
             'note':'外轴2真实反馈分别与Roll/Pitch比较；IMU与转台尚无硬件同步，不能用于绝对动态精度验收'}
        stem=f'{label}_{uid}_RESEARCH_DIAGNOSTIC' if self.plan.get('research_diagnostics') else None
        if stem:
            with self.lock:
                self.diagnosis={'state':'running'}
                if self.plan.get('research_optimize'):self.optimization={'state':'running'}
        result=run_postprocess(folder,stages,metadata,fname,stem,self.cancel)
        with self.lock:
            self.diagnosis=result['diagnosis'];self.optimization=result.get('optimization',{'state':'not_requested'})
        DIAG.record('auto_research_diagnosis','停车后研发诊断状态',diagnosis=self.diagnosis)
        return result['report_file']
    def _write_run_manifest(self):
        """Persist safe progress, including a partial run that could not continue.

        Never report an incomplete safety state as completed. This is a run
        ledger only; vendor DLL faults must continue to block further motion.
        """
        folder=Path(self.dynamic.dir)
        folder.mkdir(parents=True,exist_ok=True)
        stamp=dt.datetime.fromtimestamp(self.started_at or time.time()).strftime('%Y%m%d_%H%M%S_%f')
        uid=''.join(c for c in str(getattr(self.engine,'uid',None) or 'UNKNOWN') if c.isalnum() or c in '-_')[:48]
        basename=f'{stamp}_{uid}_AUTO_FULL_RUN.json'
        with self.lock:
            result={'kind':('2TD600_MOUNT_CALIBRATION_LEDGER' if self.plan and self.plan.get('calibration_only') else '2TD600_FULL_AUTO_RUN_LEDGER'),'version':'7.24.1',
                    'started_at':self.started_at,'finished_at':dt.datetime.now().astimezone().isoformat(),
                    'state':self.state,'error':self.error,'plan':self.plan,
                    'stopped_verified':self.stopped_verified,
                    'static_prechecks':list(self.static_check_info),'static_alignment':self.alignment_result,'static_alignment_file':self.alignment_file,
                    'polarity_checks':list(self.polarity_checks),'mount_axis_checks':list(self.mount_axis_checks),
                    'static_report_files':list(self.static_reports),
                    'completed_dynamic_stages':list(self.stages),
                    'last_dynamic_report_file':self.report_file,
                    'motion_completed':self.motion_completed,'report_completed':self.report_completed,
                    'research_diagnosis':self.diagnosis,'pre_research_results':self.pre_research_results,'optimization':self.optimization,'post_report_health':self.post_report_health,
                    'mount_calibration_file':self.mount_calibration_file,
                    'servo_disable_results':list(self.servo_disable_results),
                    'mount_recovery':self.mount_recovery,'interrupted_dynamic_stage':self.interrupted_dynamic_stage,
                    'all_requested_stages_completed':self.state=='completed',
                    'calibration_mode':getattr(self.engine,'cal_mode',None),
                    'factory_calibration_files':list((self.engine.cal or {}).get('files',[])),
                    'safety_note':'未确认停车或中止时，绝不自动继续下一方向。该运行记录不是安全停止证明。',
                    'certified_dynamic_accuracy':False,'quality':'RESEARCH_ONLY_UNSYNCHRONIZED'}
        (folder/basename).write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        try:
            html_name=write_run_ledger_html(folder,basename,result)
        except Exception as html_exc:
            html_name=None
            DIAG.record('run_html_warning','静态/异常运行HTML生成失败；JSON仍已保存',error_message=str(html_exc))
        if html_name:
            result["html_report_file"]=html_name
            (folder/basename).write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
        with self.lock:
            self.run_manifest_file=basename
            self.run_manifest_html_file=html_name
        DIAG.record('auto_run_ledger','完整自动测试运行记录已保存',filename=basename,state=result['state'])
        return basename
    def _validate_and_save_polarity(self, report, filename, requested_sign):
        """No new motion. Use all static point pairs to validate encoder-output polarity."""
        result=infer_static_polarity(report,requested_sign,self.engine.active)
        with self.lock:self.polarity_checks.append(result)
        DIAG.record('auto_polarity_check',result['reason'],**{k:v for k,v in result.items() if k!='reason'})
        if not result['valid']:
            raise RuntimeError('静态角度方向无法自动确认，禁止进入动态：'+result['reason'])
        selected=result['selected_sign']
        report['polarity_detection']=result
        update_static_polarity(report,requested_sign,selected,self.engine.active)
        folder=Path(self.dynamic.dir)
        path=folder/filename
        # Preserve original calibration readings and an explicit before/after-sign analysis.
        path.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        try:
            from .static_report_html import make_static_html
            html_name=filename.replace('.json','.html')
            (folder/html_name).write_text(make_static_html(report),encoding='utf-8')
            report['interactive_html_file']=html_name
            path.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        except Exception as exc:
            DIAG.record('static_html_warning','极性验证后静态HTML更新失败，JSON仍可用',error_message=str(exc))
        key='sign' if report['output']=='roll' else 'pitch_sign'
        with self.lock:self.plan[key]=selected
        if result['changed']:
            DIAG.record('auto_reference_sign_corrected',
                        f"{report['output'].upper()}参考方向已自动从{requested_sign:+d}改成{selected:+d}，运动指令不变",
                        output=report['output'],requested=requested_sign,selected=selected)
        return result

    def _capture_static_with_axis_retry(self, output, inner, sign, progress):
        """On weak *observable* motion, reacquire once at permitted 3°/s.

        This is not factory ACC/GYRO calibration. The 14-point fixture
        observations are retained, as are all original failure reports.
        No retry is allowed for limit, drive, alignment or feedback faults;
        those remain guarded by StaticBeforeDynamic and _watch.
        """
        speed=self.plan.get('static_position_speed_dps',min(self.plan['zero_speed_dps'],3.))
        options=(output,inner,sign,speed,self.plan['static_limit_deg'],self._watch,progress)
        report,data=self.static_precheck.run(*options,span_deg=min(5.,self.plan['amplitude_deg']))
        first=data.get('mount_axis_precheck') or {}
        metadata={'attempts':1,'initial_report_file':report,'initial_axis_precheck':first,
                  'retry_report_file':None,'retry_speed_dps':None}
        reason=first.get('reason','')
        if (not first.get('pass_for_dynamic') and '运动角速度信噪比不足' in reason
                and speed<2.99):
            with self.lock:
                self.state='auto_calibration_signal_retry'
                self.mount_recovery={'state':'rechecking_signal','output':output,
                                     'reason':reason,'retry_speed_dps':3.0}
            DIAG.record('mount_axis_signal_retry',f'{output.upper()}运动信号不足，在原授权±5°范围内以3°/s重采14点',
                        initial_file=report,original_result=first)
            # Result of first run ends at zero, so the new sweep remains in
            # exactly the same permitted mechanical region and mode.
            retry_file,retry_data=self.static_precheck.run(
                output,inner,sign,3.0,self.plan['static_limit_deg'],self._watch,progress,
                span_deg=min(5.,self.plan['amplitude_deg']))
            metadata.update(attempts=2,retry_report_file=retry_file,retry_speed_dps=3.0)
            report,data=retry_file,retry_data
            DIAG.record('mount_axis_signal_retry_result',f'{output.upper()}重测结果',
                        valid=bool((data.get('mount_axis_precheck') or {}).get('pass_for_dynamic')),
                        reason=(data.get('mount_axis_precheck') or {}).get('reason'),report_file=retry_file)
        return report,data,metadata

    def _run(self):
        try:
            plan=self.plan;self._watch()
            deferred=hasattr(self.dynamic,'finalize_deferred_reports')
            if deferred:self.dynamic.deferred_reports.clear()
            DIAG.record('auto_phase','只读安全预检查及双轴使能/回0°')
            check=self.prep.preflight()
            with self.lock:self.state='enabling_and_zeroing'
            self.prep.start(check['token'],True,only_enable=False,zero_speed_dps=plan['zero_speed_dps'])
            self._await(self.prep)
            ready=self.prep.status()
            if not ready['ready']:raise RuntimeError('自动使能/回零未完成：'+(ready['error'] or ready['state']))
            if hasattr(self.engine,'clear_static_alignment'):
                self.engine.clear_static_alignment()  # never carry old fixture corrections into a new experiment
            if plan.get('auto_static_align'):
                # Both stationary axes must be measured before fitting a joint
                # 2D alignment. Training: outbound points, test: reverse points.
                raw_static=[]
                for pre_idx,(out_name,inner_name) in enumerate(MODES[plan['mounting_mode']],1):
                    self._watch()
                    with self.lock:
                        self.state='static_alignment_calibration'
                        self.current_stage={'number':pre_idx,'count':2,'output':out_name,'inner_target_deg':inner_name}
                    self._position(2,0)
                    self._position(0,inner_name)
                    sign=plan['sign'] if out_name=='roll' else plan['pitch_sign']
                    def update_cal_static(step,total,target):
                        with self.lock:
                            self.static_progress={'direction':out_name,'step':step,'total':total,'target_deg':target}
                    static_file,data,retry_info=self._capture_static_with_axis_retry(
                        out_name,inner_name,sign,update_cal_static)
                    # Save stage references FIRST: even if direction recognition
                    # fails, the complete measured static charts must remain visible.
                    info={'output':out_name,'report_file':static_file,
                          'interactive_html_file':data.get('interactive_html_file'),
                          'analysis':data['analysis'],'axis_signal_sampling':retry_info}
                    if retry_info['attempts']==2:
                        with self.lock:self.static_reports.append(retry_info['initial_report_file'])
                    with self.lock:
                        self.static_reports.append(static_file)
                        self.static_check_info.append(info)
                        self.static_progress=None
                    # Before dynamic sway: check actual gyro rotation axis while
                    # performing the ALREADY requested static low-speed moves.
                    axis_check=data.get('mount_axis_precheck',{})
                    with self.lock:
                        self.mount_axis_checks.append(axis_check)
                    info['mount_axis_precheck']=axis_check
                    DIAG.record('pre_sway_mount_axis',f'{out_name.upper()}装夹轴向预检',
                                valid=axis_check.get('valid'),
                                misalignment_deg=axis_check.get('misalignment_deg'),
                                reason=axis_check.get('reason'))
                    if plan.get('pre_sway_axis_check') and not axis_check.get('pass_for_dynamic'):
                        # A failed gyro-axis check is *not* an excuse to issue sway.
                        # Still finish the already authorized 2-axis stationary
                        # measurement, compute an independent fixture-fit candidate
                        # and then stop unless gyro observability is restored.
                        with self.lock:
                            self.state='auto_mount_calibration_recovery'
                            self.mount_recovery={'state':'fitting_fixture_candidate',
                                'output':out_name,'reason':axis_check.get('reason','未知原因'),
                                'note':'完成双轴静态标定候选，但陀螺仪轴向证据不合格时严禁动态摇摆'}
                        DIAG.record('auto_mount_calibration_recovery',
                            f'{out_name.upper()}预检失败，继续已授权双轴静态点和独立反向验证，不发摇摆命令',
                            reason=axis_check.get('reason'))
                    # Infer reference sign without changing motor motion commands.
                    polarity=self._validate_and_save_polarity(data,static_file,sign)
                    info.update(polarity_detection=polarity,analysis=data['analysis'],
                                interactive_html_file=data.get('interactive_html_file'))
                    raw_static.append(data)
                    self._position(2,0)
                with self.lock:self.state='validating_static_alignment'
                candidate=fit_static_alignment(raw_static,self.engine.uid,self.engine.cal_mode,
                                               self.engine.active,plan['static_limit_deg'])
                candidate['polarity_checks']=list(self.polarity_checks)
                with self.lock:self.alignment_result=candidate
                folder=Path(self.dynamic.dir);folder.mkdir(parents=True,exist_ok=True)
                afile=f'{dt.datetime.now():%Y%m%d_%H%M%S_%f}_{self.engine.uid}_STATIC_ALIGNMENT.json'
                (folder/afile).write_text(json.dumps(candidate,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
                with self.lock:self.alignment_file=afile
                DIAG.record('static_alignment','自动静态双轴对齐：仅经反向验证才允许启用',
                            valid=candidate['valid'],reason=candidate.get('reason'),report_file=afile)
                if not candidate['valid']:
                    if plan['static_stop_on_fail']:
                        raise RuntimeError('自动安装标定候选未通过独立反向验证，已禁止动态：'+candidate['reason'])
                else:
                    if (not candidate['active_statically_pass'] or not candidate['gravity_statically_pass']) and plan['static_stop_on_fail']:
                        raise RuntimeError('自动安装标定已拟合，但反向验证仍超研发阈值；未应用补偿，已禁止动态')
                    failed_axes=[x for x in self.mount_axis_checks if not x.get('pass_for_dynamic')]
                    if plan.get('pre_sway_axis_check') and failed_axes:
                        details='；'.join((x.get('output','?').upper()+': '+x.get('reason','未知')) for x in failed_axes)
                        with self.lock:
                            self.mount_recovery={'state':'candidate_saved_dynamic_blocked',
                                'reason':details,'alignment_file':afile,'static_fit_valid':True,
                                'note':'已完成常温小角度安装标定候选和独立反向验证，但陀螺运动轴证据不足，禁止应用于动态'}
                        raise RuntimeError('已自动完成双轴静态安装标定并保留候选报告，但安装轴动态预检仍未通过，禁止摇摆：'+details)
                    if hasattr(self.engine,'install_static_alignment') and not plan.get('calibration_only'):
                        self.engine.install_static_alignment(candidate)
                        with self.lock:
                            self.alignment_result['applied']=True
                            if self.mount_recovery:self.mount_recovery={'state':'validated_applied',
                                'reason':'重采通过、双轴静态拟合及独立反向验证通过', 'alignment_file':afile}
                        (folder/afile).write_text(json.dumps(self.alignment_result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
            if plan.get('calibration_only'):
                # One-click fixture alignment deliberately does NOT issue SetAxisSway.
                candidate=self.alignment_result or {}
                if not (candidate.get('valid') is True and candidate.get('gravity_statically_pass') is True
                        and candidate.get('active_statically_pass') is True):
                    raise RuntimeError('安装标定拟合或反向验证未通过，未保存可用标定')
                with self.lock:self.state='returning_to_zero'
                self._watch()
                self._position(2,0)
                self._position(0,0)
                self._watch()
                self.table.stop()
                verified=self.table.stopped_verified(timeout=20)
                with self.lock:self.stopped_verified=verified
                if not verified:raise RuntimeError('两轴物理停车未获确认，禁止发布安装标定文件')
                self._watch()
                # Never release holding torque at calibration completion.
                status=self.table.read_status()['axes']
                results=[{'axis':a,'confirmed_enabled':bool(status[str(a)]['enabled'] and status[str(a)]['healthy'] and status[str(a)]['zeroed'])} for a in (0,2)]
                if not all(x['confirmed_enabled'] for x in results):raise RuntimeError('停车后未确认双轴保持使能，禁止保存')
                with self.lock:self.state='saving_calibration'
                files=list((self.engine.cal or {}).get('files') or [])
                fname=store_verified_mount_alignment(Path(self.dynamic.dir).parent.parent,candidate,
                    uid=self.engine.uid,mode=self.engine.cal_mode,factory_files=files,
                    stop_confirmed=verified,holding_results=results)
                with self.lock:self.mount_calibration_file=fname
                # Install only after calibration, STOP, verified holding, and durable save.
                if hasattr(self.engine,'install_static_alignment'):
                    self.engine.install_static_alignment(candidate)
                    with self.lock:self.alignment_result['applied']=True
                    folder=Path(self.dynamic.dir)
                    (folder/self.alignment_file).write_text(json.dumps(self.alignment_result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
                DIAG.record('mount_calibration_completed','安装标定已保存、双轴已确认停车并保持使能',file=fname)
                with self.lock:self.state='completed'
                return
            for num,(output,inner_angle) in enumerate(MODES[plan['mounting_mode']],1):
                self._watch()
                self.current_stage={'number':num,'count':len(MODES[plan['mounting_mode']]),
                                    'output':output,'inner_target_deg':inner_angle}
                with self.lock:self.state='switching_orientation'
                # First park outer at zero, THEN position the inner axis.
                self._position(2,0)
                self._position(0,inner_angle)
                self._watch()
                sign=plan['sign'] if output=='roll' else plan['pitch_sign']
                if plan.get('static_before_dynamic') and not plan.get('auto_static_align'):
                    with self.lock:self.state='static_accuracy_precheck'
                    DIAG.record('static_precheck_start',f'{output.upper()}动态前进行±5°双向14位置静态核验')
                    def update_static(step,total,target):
                        with self.lock:
                            self.static_progress={'direction':output,'step':step,'total':total,'target_deg':target}
                    if getattr(self.engine,'active',None) in ('gyro_anchor','gravity_observer') and plan.get('pre_sway_axis_check'):
                        static_file,static_data,retry_info=self._capture_static_with_axis_retry(output,inner_angle,sign,update_static)
                        if retry_info['attempts']==2:
                            with self.lock:self.static_reports.append(retry_info['initial_report_file'])
                        # Direction only, no angle fit is installed in general mode.
                        polarity=self._validate_and_save_polarity(static_data,static_file,sign)
                        sign=polarity['selected_sign']
                    else:
                        static_file,static_data=self.static_precheck.run(
                            output,inner_angle,sign,plan.get('static_position_speed_dps',min(plan['zero_speed_dps'],3.)),
                            plan['static_limit_deg'],self._watch,update_static,span_deg=min(5.,plan['amplitude_deg']))
                    info={'output':output,'report_file':static_file,'interactive_html_file':static_data.get('interactive_html_file'),
                          'analysis':static_data['analysis']}
                    with self.lock:
                        self.static_reports.append(static_file);self.static_check_info.append(info)
                        self.static_progress=None
                    axis_check=static_data.get('mount_axis_precheck',{})
                    with self.lock:self.mount_axis_checks.append(axis_check)
                    info['mount_axis_precheck']=axis_check
                    if plan.get('pre_sway_axis_check') and not axis_check.get('pass_for_dynamic'):
                        raise RuntimeError(f'{output.upper()}安装轴预检未通过，已禁止动态：'+axis_check.get('reason','缺少有效装夹数据'))
                    DIAG.record('static_precheck_complete',f'{output.upper()}静态精度检查完成',
                        report_file=static_file,summary=static_data['analysis'].get('reason'))
                    if not static_data['analysis'].get('pass_for_chosen_algorithm') and plan['static_stop_on_fail']:
                        raise RuntimeError(f'{output.upper()}静态未达到设定门槛，已保留静态报告并拒绝进入动态：'
                            +static_data['analysis'].get('reason','数据无效'))
                    # Must re-obtain a valid outer zero & standstill after static sweeps.
                    self._position(2,0)
                    self._watch()
                if plan.get('pre_research'):
                    from .pre_research import capture_with_retry
                    with self.lock:self.state='pre_research_static'
                    capture_with_retry(self,output,inner_angle,plan['pre_research_seconds'])
                    self._watch()
                with self.lock:self.state='preparing_test'
                mode='x_outer' if output=='roll' else 'y_inner_90'
                trial=self.dynamic.preflight(2,output,sign,plan['amplitude_deg'],plan['frequency_hz'],plan['cycles'],
                                             mode,plan['fixture_confirmed'])
                self._watch()
                with self.lock:self.state='testing'
                DIAG.record('auto_phase',f'开始第{num}项 {output.upper()}：内轴{inner_angle}°，外轴正弦摆动')
                if deferred:self.dynamic.start(trial['token'],True,defer_report=True)
                else:self.dynamic.start(trial['token'],True)
                try:self._await(self.dynamic)
                except Exception:
                    # Preserve a finished report even if a post-report watchdog
                    # rejects the next motion. Never classify it as a completed stage.
                    partial=self.dynamic.status()
                    if partial.get('report_file') or partial.get('pending_report_file'):
                        with self.lock:
                            self.report_file=partial.get('report_file')
                            self.interrupted_dynamic_stage={'output':output,'inner_target_deg':inner_angle,**{k:partial.get(k) for k in ('report_file','pending_report_file','table_file','imu_file','state','stopped_verified')}}
                    raise
                done=self.dynamic.status()
                if plan.get('pre_research') and hasattr(self.engine,'release_research_bias'):self.engine.release_research_bias()
                if is_completed_capture_with_invalid_analysis(done):
                    # The scheduled physical motion and verified STOP succeeded;
                    # only reference quality / steady-state accuracy evaluation
                    # failed. Preserve the report and never move to another axis.
                    record={'output':output,'inner_target_deg':inner_angle,
                            'report_file':done['report_file'],'table_file':done.get('table_file'),
                            'imu_file':done.get('imu_file'),'stopped_verified':True,
                            'data_analysis_state':'invalid','motion_capture_state':'completed'}
                    with self.lock:
                        self.stages.append(record)
                        self.report_file=done['report_file']
                        self.stopped_verified=True
                        self.state='analysis_invalid'
                        if self.optimization.get('state')=='pending':self.optimization={'state':'not_completed','error':'采集质量门禁不通过'}
                        if self.diagnosis.get('state')=='pending':self.diagnosis={'state':'not_completed','error':'采集质量门禁未通过，未完成全部运动'}
                        self.error=(f'{output.upper()}运动与停车确认完成、数据已保存；'
                                    '参考数据不足，精度评价无效。未自动进入下一方向。')
                    if deferred:
                        self.dynamic.finalize_deferred_reports()
                    DIAG.record('auto_analysis_invalid','运动及安全停车完成，精度评价无效，未继续下一方向',
                                report_file=done['report_file'],reason=done.get('error'))
                    return
                if done['state'] not in ('completed','capture_complete'):
                    # Expose the stage report for data inspection only. Do NOT
                    # continue to Pitch, perform automatic repositioning or
                    # mark the combined experiment completed on stop failure.
                    if done.get('report_file'):
                        with self.lock:self.report_file=done['report_file']
                    raise RuntimeError(f'{output.upper()}测试未完成：'+(done.get('error') or done['state']))
                record={'output':output,'inner_target_deg':inner_angle,
                        'static_precheck_file':(next((x['report_file'] for x in self.static_check_info if x['output']==output),None) if plan.get('static_before_dynamic') else None),
                        'report_file':done['report_file'],'table_file':done['table_file'],
                        'imu_file':done['imu_file'],'stopped_verified':done['stopped_verified'],
                        'data_analysis_state':'pending_offline_analysis' if done['state']=='capture_complete' else 'available_research_only'}
                if plan.get('pre_research'):
                    record['pre_research']=self.pre_research_results[-1]
                if record['static_precheck_file'] or record.get('pre_research'):
                    report_path=Path(self.dynamic.dir)/done['report_file']
                    try:
                        document=json.loads(report_path.read_text(encoding='utf-8'))
                        if record['static_precheck_file']:
                            document['static_before_dynamic']={'report_file':record['static_precheck_file'],
                                'summary':next((x['analysis'] for x in self.static_check_info if x['output']==output),{}),
                                'alignment':self.alignment_result}
                        if record.get('pre_research'):document['pre_research']=record['pre_research']
                        report_path.write_text(json.dumps(document,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
                    except (OSError,ValueError,TypeError) as exc:
                        DIAG.record('static_report_link_failed','静态报告与动态JSON关联失败',error_message=str(exc))
                with self.lock:self.stages.append(record)
                DIAG.record('auto_stage_complete',f'{output.upper()}运动及停车完成，已保存原始数据',record=record)
            # A normal complete experiment returns to the known mounting zero.
            with self.lock:self.state='returning_to_zero'
            self._position(2,0)
            self._position(0,0)
            self._watch()
            with self.lock:self.state='saving_report'
            self.stopped_verified=self.table.stopped_verified(timeout=20)
            if not self.stopped_verified:raise RuntimeError('归零后未确认两轴完全停止')
            self._watch()  # final motion/STOP gate; all subsequent work is offline only
            with self.lock:self.motion_completed=True
            if deferred:
                DIAG.record('auto_offline_report_start','全部运动结束、停车确认；开始统一离线报告')
                reports=self.dynamic.finalize_deferred_reports()
                for stage in self.stages:
                    detail=reports.get(stage['report_file'])
                    if detail:
                        stage['data_analysis_state']='available_research_only' if detail['state']=='completed' else 'invalid'
                        if detail['state']!='completed':
                            self.report_file=stage['report_file']
                            error=detail.get('error') or ('离线报告状态='+str(detail.get('state'))+'；请查看该方向动态JSON及原始数据')
                            DIAG.record('auto_offline_report_failed','运动与停车已完成，离线报告分析状态无效',
                                        output=stage.get('output'),report_file=stage.get('report_file'),
                                        report_state=detail.get('state'),error_message=error)
                            raise RuntimeError('运动已完成，离线精度评价未通过：'+error)
                if self.cancel.is_set():raise RuntimeError('操作员已中止；离线数据保留')
            self.report_file=(self._create_joint_report(self.stages)
                              if len(self.stages)==2 or self.plan.get('research_diagnostics') else self.stages[0]['report_file'])
            with self.lock:self.report_completed=True
            if self.cancel.is_set():raise RuntimeError('操作员已中止；报告及数据保留')
            if not self.table.stopped_verified(timeout=20):
                self.stopped_verified=False
                raise RuntimeError('离线报告完成后停车反馈未确认，需现场核查')
            health=self.engine.link_watchdog_status() if hasattr(self.engine,'link_watchdog_status') else {}
            with self.lock:self.post_report_health=health
            if health.get('pipeline_error') or any(health.get(k) is not None and health[k]>750 for k in ('child_receipt_age_ms','fusion_receipt_age_ms')):
                raise RuntimeError('运动和报告已完成；实时采集故障，需人工恢复后才能进行新实验：'+(health.get('pipeline_error') or '实时数据过期'))
            DIAG.record('auto_completed','双向动态实验完成',report_file=self.report_file,stages=self.stages)
            with self.lock:self.state='completed'
        except Exception as exc:
            DIAG.record('auto_failed','自动实验中止',exception=type(exc).__name__,error_message=str(exc),phase=self.state)
            with self.lock:
                self.state='stopped_or_failed';self.error=str(exc)
                if self.diagnosis.get('state') in ('pending','running'):
                    self.diagnosis={'state':'not_completed','error':str(exc)}
                if self.optimization.get('state') in ('pending','running'):self.optimization={'state':'not_completed','error':str(exc)}
            if self.plan and self.plan.get('calibration_only') and hasattr(self.engine,'clear_static_alignment'):
                try:self.engine.clear_static_alignment()
                except Exception:pass
            failure_stop_verified=False
            try:
                if self.prep.running:self.prep.abort()
                if self.dynamic.running:self.dynamic.abort()
                if self.table.connected:
                    self.table.stop()
                    ok=self.table.stopped_verified(timeout=20)
                    failure_stop_verified=ok is True
                    with self.lock:self.stopped_verified=ok
                    if not ok:
                        with self.lock:self.error+='；未确认转台停止，请使用硬件急停并现场核查'
            except Exception as stop_exc:
                with self.lock:self.stopped_verified=False;self.error+='；软件停车失败，请立即使用实体急停：'+str(stop_exc)
            # A completed earlier stage is still useful after a static-window
            # failure. Never resume/reposition; only analyze after verified STOP.
            from .pre_research import StaticContinuityError
            if (isinstance(exc,(StaticContinuityError,IMUWatchdogError)) and failure_stop_verified and self.table.connected
                    and self.stages and not self.cancel.is_set()
                    and not self.dynamic.running and hasattr(self.dynamic,'finalize_deferred_reports')):
                try:
                    # Keep the original stopped_or_failed state and error.
                    reports=self.dynamic.finalize_deferred_reports()
                    for stage in self.stages:
                        detail=reports.get(stage['report_file'])
                        if detail:stage['data_analysis_state']='available_research_only' if detail['state']=='completed' else 'invalid'
                    good=[stage for stage in self.stages if stage['data_analysis_state']=='available_research_only']
                    if good and not self.cancel.is_set():
                        self.report_file=self._create_joint_report(good,partial=True) if self.plan.get('research_diagnostics') else good[0]['report_file']
                        DIAG.record('auto_partial_report_saved','中止后已停车；已完成方向离线报告保留，未继续运动',report_file=self.report_file)
                except Exception as recovery_exc:
                    DIAG.record('auto_partial_report_failed','部分报告分析失败；原始数据保留',error_message=str(recovery_exc))
        finally:
            if self.plan and self.plan.get('pre_research') and hasattr(self.engine,'release_research_bias'):
                self.engine.release_research_bias()
            try:
                self._write_run_manifest()
            except Exception as ledger_exc:
                DIAG.record('auto_run_ledger_failed','自动测试报告归档失败，运动状态仍按原安全判断',exception=repr(ledger_exc))
            with self.lock:self.running=False
