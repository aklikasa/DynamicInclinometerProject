"""Threaded data processing pipeline shared by demo, real serial and offline replay.
Full-rate sample logging, ring buffer for UI; algorithms run once per IMU sample.
"""
import csv,json,threading,time,collections,datetime,traceback,math,os,queue
from pathlib import Path
from dataclasses import asdict
from .fusion import Params,FILTERS,create_filter
from .calibration import scan,apply,Cal
from .simulation import DemoDevice,DEMO_ACC,DEMO_GYRO,SIM_SN
from .devices import R10Device,DeviceError
from .analysis import summarize
from .stability import StationaryEvaluation
from .static_alignment import align_pose
from .acquisition_v712 import BatchClock, RAW_FIELDS, raw_row, POLL_FIELDS, windows_timer_resolution
from .continuity_v713 import advance, LONG_GAP_S
from .acquisition_v714 import ProcessTransport
from .runtime_perf import RuntimePerf

ROOT=Path(__file__).resolve().parent.parent
RECORD_DIR=ROOT/'data'/'recordings';RECORD_DIR.mkdir(exist_ok=True,parents=True)
# Keep user preferences outside release folders on Windows, so updates do not reset settings.
BUNDLED_SETTINGS_FILE=ROOT/'data'/'settings.json'
SETTINGS_FILE=(Path(os.environ['LOCALAPPDATA'])/'TiltLab'/'settings.json') if os.environ.get('LOCALAPPDATA') else BUNDLED_SETTINGS_FILE
CSV_KEYS=['t_s','source','uid','calibration_state','calibration_mode','calibration_runtime_error','acc_x_g','acc_y_g','acc_z_g','gyro_x_dps','gyro_y_dps','gyro_z_dps',
          'acc_cal_x_g','acc_cal_y_g','acc_cal_z_g','gyro_cal_x_dps','gyro_cal_y_dps','gyro_cal_z_dps',
          'roll_raw_deg','pitch_raw_deg','yaw_raw_deg','roll_cal_deg','pitch_cal_deg','yaw_cal_deg',
          'roll_cal_factory_deg','pitch_cal_factory_deg','alignment_active','ref_roll_deg','ref_pitch_deg','temperature_c','dt_s','algorithm','device_t_s','host_est_ns','pc_observed_ns',
          'imu_nominal_odr_hz','imu_fifo_state','timestamp_quality','estimated_batch_seam_gap','fusion_t_s','fusion_dt_s','gap_reset','batch_id','batch_index','batch_shift_ms','reported_odr','processing_age_ms','sample_age_ms','gap_bridge','gap_action','timing_degraded','request_pc_ns','serial_read_ms','poll_id']

class Workstation:
    def __init__(self):
        self.perf=RuntimePerf();self._fault_perf=None
        self.lock=threading.RLock();self.source='offline';self.connected=False;self.running=False;self.thread=None
        self.device=None;self.worker=None;self.raw_worker=None;self.pipeline_mode='offline';self._queue=None;self._raw_queue=None;self._acq_done=threading.Event();self._raw_done=threading.Event();self._pipeline_error='';self._acquired=0;self._raw_written=0;self._queue_peak=0;self._raw_peak=0;self._acq_started=0.;self._acq_end=0.;self._max_age_ms=0.;self._gap_resets=0;self._gap_bridges=0;self._long_gap_bridges=0;self._continuity_degraded=False;self._clock=BatchClock();self.raw_path=None;self.poll_path=None;self._poll_id=0;self._empty_polls=0;self._max_poll_ms=0.;self._max_idle_ms=0.;self.uid=None;self.uid_hex=None;self.cal=None;self.cal_status='unloaded';self.cal_mode='ambient';self.cal_root='';self.cal_source='local';self.cal_detail='';self.cal_issues=[];self.cal_diagnostics=[];self.cal_runtime_error=''
        self.params=Params();self.active='gyro_anchor';self.pipes={};self.static_alignment=None
        try:
            cfg_path=SETTINGS_FILE if SETTINGS_FILE.is_file() else BUNDLED_SETTINGS_FILE
            cfg=json.loads(cfg_path.read_text(encoding='utf-8'))
            self.params=Params(**{k:v for k,v in cfg.get('params',{}).items() if k in Params.__dataclass_fields__ and not k.startswith('lever3_')}).validate()
            if cfg.get('algorithm') in FILTERS and cfg['algorithm'] not in ('lever3d','adaptive3d','gyro_anchor3d'):self.active=cfg['algorithm']
            self.params.lever_z_cm=0.0
            self.cal_root=cfg.get('calibration_folder','')
            if cfg.get('calibration_source') in ('local','shared'):self.cal_source=cfg['calibration_source']
            if cfg.get('calibration_mode') in ('ambient','thermal','none'):self.cal_mode=cfg['calibration_mode']
        except (OSError,ValueError,TypeError,KeyError):pass
        self.reset_algorithms()
        self.history=collections.deque(maxlen=1200);self.recent=collections.deque(maxlen=3000)
        self.latest=None;self.error='';self.events=collections.deque(maxlen=60);self.counter=0
        self.record_fp=None;self.record_writer=None;self.record_rows=0;self.record_path=None
        self.history_seq=0;self.stability=None
        self.last_t=None;self.last_wall=0;self.demo_mode='sine';self.session_started=None
        self.actual_rate_hz=0.0;self._rate_clock=time.perf_counter();self._rate_count=0;self._host_anchor_t=None;self._host_anchor_ns=None;self._last_host_est_ns=0
        self.log('系统已准备；真实设备和转台均未连接')
    def log(self,msg):
        self.events.appendleft({'time':datetime.datetime.now().strftime('%H:%M:%S'),'message':str(msg)[:250]})
    def save_settings(self):
        document={'algorithm':self.active if self.active not in ('lever3d','adaptive3d','gyro_anchor3d') else ({'adaptive3d':'adaptive','gyro_anchor3d':'gyro_anchor','lever3d':'madgwick'}[self.active]),'params':{k:v for k,v in asdict(self.params).items() if not k.startswith('lever3_')},'calibration_folder':self.cal_root,'calibration_source':self.cal_source,'calibration_mode':self.cal_mode}
        SETTINGS_FILE.parent.mkdir(parents=True,exist_ok=True)
        temp=SETTINGS_FILE.with_suffix('.tmp')
        temp.write_text(json.dumps(document,ensure_ascii=False,indent=2),encoding='utf-8')
        temp.replace(SETTINGS_FILE)
    def clear_static_alignment(self):
        with self.lock:
            self.static_alignment=None
            self.log('静态装夹对齐已停用；原始厂标定角保持不变')

    def install_static_alignment(self,candidate):
        with self.lock:
            if not candidate.get('valid') or candidate.get('uid')!=self.uid or candidate.get('calibration_mode')!=self.cal_mode:
                raise ValueError('静态补偿未通过验证或UID/标定模式不一致')
            if self.source!='serial' or self.cal_status!='matched':
                raise ValueError('只能对实际UID匹配标定的设备启用现场静态对齐')
            self.static_alignment=dict(candidate)
            self.static_alignment['applied']=True
            self.log('静态Roll/Pitch现场对齐启用（仅本次连接会话，保留原始角度）')

    def seed_research_gyro_anchor(self,acc,bias,last_sequence):
        from .fusion import initial_q
        from .gyro_anchor import GyroAnchor
        with self.lock:
            if self.active!='gyro_anchor' or self.static_alignment is not None or abs(self.params.lever_z_cm)>1e-12 or self.cal_status!='matched':
                raise ValueError('静止研发初始化仅支持无杆臂、无现场对齐的Gyro Anchor')
            if not self.latest or not 0<=self.latest['sequence']-last_sequence<=400 or self.latest.get('processing_age_ms',999)>500:
                raise ValueError('静止初始化数据已过期')
            f=self.pipes['gyro_anchor'][1]
            if type(f) is not GyroAnchor:raise ValueError('滤波状态类型不符')
            current_acc=self.latest.get('acc_cal');current_gyro=self.latest.get('gyro_cal')
            if any(v is None or len(v)!=3 or not all(math.isfinite(x) for x in v) for v in (acc,bias,current_acc,current_gyro)):
                raise ValueError('静止初始化六轴输入不完整')
            q=initial_q(acc)
            f.q=q;f.bias=list(bias);f.bias_ready=True;f.research_bias_locked=True
            f._clear_samples();f.static_elapsed=0.;f._last_gyro=list(current_gyro);f._last_a=list(current_acc);f._v713_previous_g=list(current_gyro)
    def release_research_bias(self):
        with self.lock:
            f=self.pipes.get('gyro_anchor',(None,None))[1]
            if f is not None:f.research_bias_locked=False

    def reset_algorithms(self):
        self.pipes={name:(create_filter(name,self.params,calibrated=False),create_filter(name,self.params,calibrated=True)) for name in FILTERS}
        self.last_t=None
    def reset_corrected_filters(self):
        self.pipes={name:(pair[0],create_filter(name,self.params,calibrated=True)) for name,pair in self.pipes.items()}
    def configure(self,algorithm=None,params=None):
        with self.lock:
            if self.stability and self.stability.state=='running' and params is not None:
                raise ValueError('静态对比测试运行中，请先完成或结束测试后再调整参数')
            if algorithm is not None:
                if algorithm not in FILTERS:raise ValueError('未知融合算法')
                changed=algorithm!=self.active
                self.active=algorithm
                if changed and self.pipeline_mode=='realtime':
                    self.reset_algorithms();self.history.clear();self.recent.clear()
            if params is not None:
                merged={**asdict(self.params),**params}
                self.params=Params(**merged).validate()
                self.reset_algorithms();self.history.clear();self.recent.clear()
                self.log('参数已更新，滤波状态重新初始化；等待重新收敛')
            else:
                self.log('当前算法：'+self.active+('，单算法状态切换后重新收敛' if self.pipeline_mode=='realtime' else '，并行滤波状态保持不变'))
            self.save_settings()
    def set_folder(self,path,source_kind=None):
        if not path:raise ValueError('请设置标定文件夹的完整路径')
        if source_kind is not None and source_kind not in ('local','shared'):raise ValueError('只支持本地目录或Windows共享目录')
        with self.lock:
            if self.record_fp:raise ValueError('录制过程中不可切换标定目录；请先停止录制')
            folder=Path(path).expanduser().resolve()
            if not folder.is_dir():raise ValueError('标定目录不存在：'+str(folder))
            self.cal_root=str(folder)
            self.cal_source=source_kind or ('shared' if str(path).startswith('\\\\') else 'local')
            result=self.lookup_calibration()
            self.save_settings()
            self.log('标定目录已设置：'+self.cal_root)
            return result
    def set_mode(self,mode):
        if mode not in ('ambient','thermal','none'):raise ValueError('补偿模式无效')
        with self.lock:
            if self.record_fp:raise ValueError('录制过程中不可改变补偿模式；请先停止录制')
            self.cal_mode=mode
            result=self.lookup_calibration()
            self.save_settings()
            self.log('补偿模式切换为：'+{'ambient':'常温','thermal':'全温研究','none':'关闭补偿'}[mode])
            return result
    def clear_lever3d(self):
        for j in 'xyz':setattr(self.params,'lever3_'+j+'_cm',0.0)
        if self.active=='lever3d':self.active='madgwick'
        elif self.active=='adaptive3d':self.active='adaptive'
        elif self.active=='gyro_anchor3d':self.active='gyro_anchor'

    def lookup_calibration(self):
        # Called under the workstation lock; do not retain a stale calibration
        # when the selected mode or UID changes.
        self.clear_lever3d()
        self.cal=None;self.static_alignment=None;self.cal_runtime_error='';self.cal_issues=[];self.cal_diagnostics=[]
        self.reset_algorithms();self.history.clear();self.recent.clear()
        if self.cal_mode=='none':
            self.cal_status='disabled';self.cal_detail='补偿关闭；原始六轴仍参与姿态融合'
            return {'status':self.cal_status,'detail':self.cal_detail,'mode':self.cal_mode}
        if not self.cal_root:
            self.cal_status='unloaded';self.cal_detail='尚未选择标定目录'
            return {'status':self.cal_status,'detail':self.cal_detail,'mode':self.cal_mode}
        if self.source=='serial' and not self.uid:
            self.cal_status='uid_missing';self.cal_detail='PCB UID未读取成功；禁止自动加载补偿'
            return {'status':self.cal_status,'detail':self.cal_detail,'mode':self.cal_mode}
        if self.source!='serial':
            self.cal_status='uid_missing';self.cal_detail='真实PCB未连接；可使用离线文件预检查，但不可自动应用'
            return {'status':self.cal_status,'detail':self.cal_detail,'mode':self.cal_mode}
        result=scan(self.cal_root,self.uid,self.uid_hex,mode=self.cal_mode)
        self.cal=result if result['status']=='matched' else None
        self.cal_status=result['status'];self.cal_detail=result.get('detail','')
        self.cal_issues=result.get('issues',[])
        self.cal_diagnostics=result.get('matrix_diagnostics',[])
        self.log(f'{self.cal_mode}标定匹配：{self.cal_status}，设备 {self.uid or "未知"}')
        return {k:v for k,v in result.items() if k not in ('acc','gyro')}
    def set_pipeline_mode(self,mode):
        if mode not in ('offline','realtime','research'):raise ValueError('无效运行模式')
        with self.lock:
            if self.running:raise ValueError('请先断开IMU再切换运行模式')
            self.pipeline_mode=mode
            self.reset_algorithms()
            self.history.clear();self.recent.clear()
            self.log('运行模式：'+('离线优先，采集时不解算姿态角' if mode=='offline' else '单算法实时' if mode=='realtime' else '历史研究并行'))
            return self.status()
    def stop(self):
        with self.lock:
            if self.stability and self.stability.state=='running':
                self.stability.state='interrupted'
                if self.stability.samples:self.stability.save(ROOT/'data'/'reports')
                self.log('设备采集终止，静态实验已中断并保存已采样数据')
        self.running=False
        if isinstance(self.device,ProcessTransport):self.device.request_stop()
        if self.thread and self.thread.is_alive() and threading.current_thread()!=self.thread:
            self.thread.join(timeout=2.5)
        if self.thread and self.thread.is_alive():
            raise RuntimeError('采集线程仍未结束，请勿重新连接')
        for worker in (self.worker,self.raw_worker):
            if worker and worker.is_alive() and worker is not threading.current_thread():
                worker.join(timeout=5)
            if worker and worker.is_alive():raise RuntimeError('后台处理尚未结束，请勿重新连接')
        if self.device:
            try:self.device.close()
            except Exception:pass
            self.device=None
        with self.lock:
            self.static_alignment=None;self.clear_lever3d();self.reset_algorithms()
            self.connected=False;self.source='offline'
            self.stop_record()
            self.log('采集已停止')
    def start(self,source='serial',port='',baudrate=1500000,address=1,mode='sine'):
        self.stop()
        with self.lock:
            self.latest=None;self.counter=0;self.error='';self.static_alignment=None;self.history.clear();self.recent.clear();self.reset_algorithms()
            self.actual_rate_hz=0.;self._rate_clock=time.perf_counter();self._rate_count=0;self._host_anchor_t=None;self._host_anchor_ns=None;self._last_host_est_ns=0
            if source=='simulation':
                self.device=DemoDevice(mode)
                self.uid=SIM_SN;self.uid_hex='SIMULATION-ONLY';self.cal={'acc':DEMO_ACC,'gyro':DEMO_GYRO,'files':['SYNTHETIC_ACC','SYNTHETIC_GYRO']}
                self.cal_status='simulated';self.demo_mode=mode;self.connected=False
            elif source=='serial':
                if not port:raise ValueError('请选择真实串口')
                device=ProcessTransport(R10Device,port,baudrate,address)
                device.open()
                self.serial_connection=(port,baudrate,address);self.device=device;self.uid=device.serial_no;self.uid_hex=device.uid;self.cal=None;self.cal_status='unloaded';self.cal_detail='等待标定匹配';self.connected=True
            else:raise ValueError('未知数据源')
            self.source=source
            if source=='serial':self.lookup_calibration()
            if source=='serial' and not self.uid:
                self.cal=None;self.cal_status='uid_missing';self.cal_detail='设备UID读取失败，原始融合可用'
                self.log('警告：PCB UID读取失败；仅显示与记录未补偿数据，禁止应用常温标定')
            self.session_started=datetime.datetime.now().astimezone().isoformat()
            self.running=True
            self._queue=queue.Queue(maxsize=64);self._raw_queue=queue.Queue(maxsize=256)
            self.perf=RuntimePerf();self._fault_perf=None
            self._acq_done=threading.Event();self._raw_done=threading.Event();self._pipeline_error='';self._acquired=0;self._raw_written=0;self._queue_peak=0;self._raw_peak=0;self._acq_started=time.monotonic();self._acq_end=0.;self._max_age_ms=0.;self._gap_resets=0;self._gap_bridges=0;self._long_gap_bridges=0;self._continuity_degraded=False;self._clock=BatchClock();self.raw_path=None;self.poll_path=None;self._poll_id=0;self._empty_polls=0;self._max_poll_ms=0.;self._max_idle_ms=0.
            self.worker=self.raw_worker=None
            if source=='serial':
                self.raw_path=RECORD_DIR/(datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_RAW_LINK_'+str(self.uid or 'UNKNOWN')+'.csv')
                self.poll_path=self.raw_path.with_name(self.raw_path.stem+'_polls.csv')
                self.raw_worker=threading.Thread(target=self._raw_loop,daemon=True,name='IMU-raw-journal');self.raw_worker.start()
                self.worker=threading.Thread(target=self._fusion_loop,daemon=True,name='IMU-fusion');self.worker.start()
            self.thread=threading.Thread(target=self._serial_loop if source=='serial' else self._loop,daemon=True,name='IMU-acquisition');self.thread.start()
            self.log('已启动：'+('模拟数据源 / 非真实设备' if source=='simulation' else f'RS485 {port} / 从站{address} / UID {self.uid or "未读取"}'))
        return self.status()
    def _fail_pipeline(self,exc):
        self._fault_perf=self.perf.snapshot()
        self._pipeline_error=f'{type(exc).__name__}: {exc}'
        self.running=False;self.connected=False
        if isinstance(self.device,ProcessTransport):self.device.request_stop()
        with self.lock:
            self.error=self._pipeline_error;self.log('采集链路失效：'+self.error)
            if self.stability and self.stability.state=='running':self.stability.state='interrupted'
    def _serial_loop(self):
        # Child owns COM and captures actual request/receipt times; this thread
        # drains IPC and distributes batches without touching the serial port.
        try:
            self.device.begin.set()
            while True:
                item=self.device.next_poll()
                if item is None:break
                if not item:continue
                batch,poll=item
                poll['parent_dequeue_pc_ns']=time.monotonic_ns()
                poll['ipc_delivery_ms']=(poll['parent_dequeue_pc_ns']-poll['received_pc_ns'])/1e6
                self.perf.observe('ipc',poll['ipc_delivery_ms'])
                self._poll_id=poll['poll_id'];requested=poll['request_pc_ns'];observed=poll['received_pc_ns']
                read_ms=poll['serial_read_ms'];idle_ms=poll['previous_idle_ms']
                self._max_poll_ms=max(self._max_poll_ms,read_ms);self._max_idle_ms=max(self._max_idle_ms,idle_ms)
                if not batch:self._empty_polls+=1
                rows=[]
                if batch:
                    for sample in batch:sample.update(request_pc_ns=requested,serial_read_ms=read_ms,poll_id=self._poll_id)
                    rows=self._clock.stamp(batch,observed);self._acquired+=len(rows)
                self._raw_queue.put_nowait((rows,poll));self._raw_peak=max(self._raw_peak,self._raw_queue.qsize())
                if rows:
                    if self._clock.max_repair_ms>50:raise RuntimeError('批次重建偏移超过50ms，时间轴不可用；已保留原始记录')
                    self._queue.put_nowait(rows);self._queue_peak=max(self._queue_peak,self._queue.qsize())
        except Exception as exc:self._fail_pipeline(exc if not isinstance(exc,queue.Full) else RuntimeError('原始或融合队列已满；停止采集，不静默丢点'))
        finally:
            self._acq_end=time.monotonic();self._acq_done.set()
            try:self.device.close()
            except Exception:pass
    def _fusion_loop(self):
        try:
            while not self._acq_done.is_set() or not self._queue.empty():
                try:rows=self._queue.get(timeout=.05)
                except queue.Empty:continue
                if self._pipeline_error:continue
                batch_begin=time.monotonic_ns()
                self.perf.batch_id=rows[0][0].get('batch_id') if rows else None
                for sample,ns,observed in rows:
                    self.perf.batch_index=sample.get('batch_index')
                    self.perf.phase_change('sample_age_check')
                    age=(time.monotonic_ns()-observed)/1e6
                    self._max_age_ms=max(self._max_age_ms,age)
                    if age>500:raise RuntimeError('融合队列延迟超过500ms，实时输出失效；性能诊断见watchdog.performance')
                    compute_start=time.monotonic_ns()
                    self.process(sample,host_est_ns=ns,observed_ns=observed)
                    self.perf.observe('process',(time.monotonic_ns()-compute_start)/1e6)
                    # Also verify the final sample: an expensive last sample may
                    # otherwise escape the next-batch latency test.
                    age=(time.monotonic_ns()-observed)/1e6
                    self._max_age_ms=max(self._max_age_ms,age)
                    if age>500:raise RuntimeError('融合队列延迟超过500ms，实时输出失效；性能诊断见watchdog.performance')
                self.perf.observe('batch',(time.monotonic_ns()-batch_begin)/1e6)
                self.perf.phase_change('waiting_batch')
        except Exception as exc:self._fail_pipeline(exc)
    def _raw_loop(self):
        try:
            with self.raw_path.open('w',newline='',encoding='utf-8-sig') as fp, self.poll_path.open('w',newline='',encoding='utf-8-sig') as pp:
                w=csv.DictWriter(fp,fieldnames=RAW_FIELDS);w.writeheader()
                pw=csv.DictWriter(pp,fieldnames=POLL_FIELDS);pw.writeheader();last=time.monotonic()
                while not self._acq_done.is_set() or not self._raw_queue.empty():
                    try:rows,poll=self._raw_queue.get(timeout=.05)
                    except queue.Empty:continue
                    pw.writerow(poll);w.writerows(raw_row(item) for item in rows);self._raw_written+=len(rows)
                    if time.monotonic()-last>1:fp.flush();pp.flush();last=time.monotonic()
        except Exception as exc:self._fail_pipeline(exc)
        finally:self._raw_done.set()
    def link_watchdog_status(self):
        """Actual child receipt and processed sample ages, not just last UI update.
        Keep existing watchdog timeouts; old queued data must not mask a stall.
        """
        now=time.monotonic_ns();latest=self.latest or {};dev=self.device
        child_ns=dev.last_sample_ns.value if isinstance(dev,ProcessTransport) else 0
        receipt_ns=latest.get('pc_observed_ns') or 0
        return {'child_receipt_age_ms':(now-child_ns)/1e6 if child_ns else None,
                'fusion_receipt_age_ms':(now-receipt_ns)/1e6 if receipt_ns else None,
                'last_fusion_update_age_ms':(time.time()-self.last_wall)*1000 if self.last_wall else None,
                'pipeline_error':self._pipeline_error,'performance':self._fault_perf or self.perf.snapshot(),'transport_alive':dev.proc.is_alive() if isinstance(dev,ProcessTransport) and not dev.closed else None}
    def pipeline_status(self):
        duration=max(.001,(self._acq_end or time.monotonic())-self._acq_started) if self._acq_started else 1.
        return {'watchdog':self.link_watchdog_status(),'mode':self.pipeline_mode,'acquired_samples':self._acquired,'raw_written_samples':self._raw_written,
                'transport_mode':'isolated_process' if isinstance(self.device,ProcessTransport) else 'inactive_or_demo','ipc_peak_polls':getattr(self.device,'peak',0),'acquisition_hz':round(self._acquired/duration,1),'fusion_count':self.counter,
                'queued_batches':self._queue.qsize() if self._queue else 0,'peak_queued_batches':self._queue_peak,
                'raw_peak_batches':self._raw_peak,'max_processing_age_ms':round(self._max_age_ms,3),
                'latest_processing_age_ms':(self.latest or {}).get('processing_age_ms'),
                'latest_receipt_age_ms':round((time.monotonic_ns()-self.latest['pc_observed_ns'])/1e6,2) if self.latest and self.latest.get('pc_observed_ns') else None,
                'batch_clock_repairs':self._clock.repairs,'max_batch_shift_ms':self._clock.max_repair_ms,
                'estimated_long_gaps':self._clock.long_gaps,'gap_resets':self._gap_resets,'gap_bridges':self._gap_bridges,'long_gap_bridges':self._long_gap_bridges,
                'poll_count':self._poll_id,'empty_polls':self._empty_polls,'max_serial_read_ms':round(self._max_poll_ms,3),'max_poll_idle_ms':round(self._max_idle_ms,3),
                'poll_file':self.poll_path.name if self.poll_path else None,'continuity_degraded_since_connect':self._continuity_degraded,
                'latest_sample_age_ms':(self.latest or {}).get('sample_age_ms'),
                'raw_file':self.raw_path.name if self.raw_path else None,'error':self._pipeline_error,
                'hardware_synchronized':False,'timestamp_note':'PC接收时刻反推，名义ODR；并非真实采样时刻'}
    def _loop(self):
        try:
            while self.running:
                started=time.perf_counter()
                if self.source=='simulation':batch=self.device.next_batch(4)
                else:batch=self.device.next_batch()
                # One host clock anchor for the entire IMU session. This approximates
                # FIFO sample host times but NOT transport latency or hardware sync.
                observed_ns=time.monotonic_ns()
                if batch and self._host_anchor_t is None:
                    self._host_anchor_t=float(batch[-1]['t']);self._host_anchor_ns=observed_ns
                if batch and self._host_anchor_t is not None:
                    predicted_ns=self._host_anchor_ns+round((float(batch[-1]['t'])-self._host_anchor_t)*1e9)
                    # A large discrepancy indicates a stale clock anchor, not a physical
                    # sensor timestamp. Re-anchor to this batch's observed PC time.
                    # This is NOT hardware synchronization; transport latency remains.
                    if abs(predicted_ns-observed_ns)>500_000_000:
                        delta_s=(predicted_ns-observed_ns)/1e9
                        self._host_anchor_t=float(batch[-1]['t'])
                        self._host_anchor_ns=observed_ns
                        self._last_host_est_ns=0
                        self.log(f'IMU会话时钟重新锚定：原推算与PC接收时间相差{delta_s:+.3f}s；时间戳仅供研究，非硬件同步')
                for sample in batch:
                    if not self.running:break
                    est_ns=self._host_anchor_ns+round((float(sample['t'])-self._host_anchor_t)*1e9)
                    self.process(sample,host_est_ns=est_ns,observed_ns=observed_ns)
                if self.source=='simulation':
                    delay=.02-(time.perf_counter()-started)
                    if delay>0:time.sleep(delay)
                else:
                    # The old unconditional 20ms sleep made 16-sample reads
                    # fall behind an 833Hz 19.2ms frame even before I/O cost.
                    # Poll adaptively; do not fabricate missing MCU samples.
                    hz=float(getattr(self.device,'last_odr',0) or 833.)
                    frame_s=16.0/max(10.,hz)
                    wait=min(.016,max(.003,frame_s*.50)) if batch else min(.012,max(.003,frame_s*.18))
                    time.sleep(wait)
        except Exception as e:
            with self.lock:
                self.error=f'{type(e).__name__}: {e}'
                self.log('采集终止：'+self.error)
            self.running=False
            with self.lock:
                if self.stability and self.stability.state=='running':
                    self.stability.state='interrupted'
                    if self.stability.samples:self.stability.save(ROOT/'data'/'reports')
            if self.device and self.source=='serial':self.device.close();self.connected=False
    def process(self,s,host_est_ns=None,observed_ns=None):
        waiting=time.monotonic_ns()
        self.perf.phase_change('waiting_fusion_lock')
        with self.lock:
            self.perf.observe('lock',(time.monotonic_ns()-waiting)/1e6)
            self.perf.phase_change('fusion_compute')
            t=float(s['t']); dt=t-self.last_t if self.last_t is not None else 0.
            if self.last_t is not None and dt<=0:return
            self.last_t=t
            original_dt=dt;gap_reset=False;gap_bridge=False;gap_action='normal'
            protect='device_t_original' in s
            if not protect and dt>.5:
                gap_reset=True;self._gap_resets+=1
                if self.stability and self.stability.state=='running':self.stability.gaps+=1
                self.reset_algorithms();self.last_t=t;dt=0
            if protect and original_dt>LONG_GAP_S and self.stability and self.stability.state=='running':self.stability.gaps+=1
            if host_est_ns is None:host_est_ns=time.monotonic_ns()
            if observed_ns is None:observed_ns=host_est_ns
            # Model timestamp evolution must be monotonic; otherwise invalidate
            # the PC time mapping and restart a new session.
            if self._last_host_est_ns and host_est_ns<=self._last_host_est_ns:
                host_est_ns=self._last_host_est_ns+max(1,int(max(dt,0)*1e9))
            self._last_host_est_ns=host_est_ns
            a=list(s['acc']);g=list(s['gyro']);is_cal=bool(self.cal_mode!='none' and self.cal and self.cal.get('acc') and self.cal.get('gyro'))
            ca=cg=None
            if is_cal:
                try:
                    ca=apply(a,self.cal['acc'],s.get('temp'))
                    cg=apply(g,self.cal['gyro'],s.get('temp'))
                    if self.cal_runtime_error:
                        self.log('补偿恢复：当前温度与参数有效')
                        # after-chain state must restart after an invalid interval.
                        self.reset_corrected_filters()
                    self.cal_runtime_error=''
                except (ValueError,TypeError,ArithmeticError) as exc:
                    # Never present a clamped or extrapolated thermal reading as valid.
                    reason=str(exc)
                    if reason!=self.cal_runtime_error:
                        self.cal_runtime_error=reason
                        self.log('补偿暂停（原始融合继续）：'+reason)
                    ca=cg=None
                    # Prevent stale corrected integrator state after a gap.
                    if not getattr(self,'_comp_invalid',False):
                        self.reset_corrected_filters()
                    self._comp_invalid=True
            if ca is not None:self._comp_invalid=False
            outputs={};actions={}
            offline_capture=self.source=='serial' and self.pipeline_mode=='offline'
            for key,(before,after) in self.pipes.items():
                # V8.2: in offline mode do NO fusion, only calibrated 6-axis capture.
                if offline_capture:break
                if self.source=='serial' and self.pipeline_mode=='realtime' and key not in (self.active,'accel'):continue
                before,raw,raw_action=advance(key,before,self.params,False,a,g,dt,protect=protect)
                cal=None;cal_action='normal'
                if ca is not None and cg is not None:
                    after,cal,cal_action=advance(key,after,self.params,True,ca,cg,dt,protect=protect)
                self.pipes[key]=(before,after)
                actions[key]='reset' if 'reset' in (raw_action,cal_action) else 'gyro_bridge' if 'gyro_bridge' in (raw_action,cal_action) else 'normal'
                factory_cal=cal
                if cal is not None and self.static_alignment is not None:cal=align_pose(cal,self.static_alignment)
                outputs[key]={'raw':raw,'cal':cal,'cal_factory':factory_cal}
            if protect:
                if original_dt>LONG_GAP_S:self._continuity_degraded=True
                gap_action=actions.get(self.active,'offline_no_fusion');gap_reset=gap_action=='reset';gap_bridge=gap_action=='gyro_bridge'
                if offline_capture and original_dt>LONG_GAP_S:
                    gap_action='offline_gap_detected';gap_reset=True
                if gap_reset:
                    self._gap_resets+=1
                    if not offline_capture:dt=0.
                    self.log('估算时间间隔出现长缺口：'+('离线数据质量不合格' if offline_capture else '姿态重置，连续精度不可验收'))
                if gap_bridge:
                    self._gap_bridges+=1
                    if original_dt>LONG_GAP_S:self._long_gap_bridges+=1
            chosen=outputs.get(self.active,{'raw':None,'cal':None,'cal_factory':None})
            record={'t':t,'sequence':self.counter+1,'host_est_ns':host_est_ns,'pc_observed_ns':observed_ns,'acc':a,'gyro':g,'acc_cal':ca,'gyro_cal':cg,'temp':s.get('temp'),
                    'ref':s.get('ref'),'source':self.source,'uid':self.uid,
                    'calibration_state':self.cal_status,'calibration_mode':self.cal_mode,'calibration_runtime_error':self.cal_runtime_error,'static_alignment_active':self.static_alignment is not None,'algo':self.active,
                    'raw':chosen['raw'],'cal':chosen['cal'],'cal_factory':chosen['cal_factory'],'outputs':outputs,'dt':dt,
                    'odr':s.get('odr'),'fifo_state':s.get('fifo_state'),
                    'timestamp_quality':s.get('timestamp_quality','unknown'),
                    'estimated_batch_seam_gap':bool(original_dt>.01),'device_t_original':s.get('device_t_original',t),
                    'fusion_dt':dt,'original_dt':original_dt,'gap_reset':gap_reset,'gap_bridge':gap_bridge,'gap_action':gap_action,'timing_degraded':bool(protect and original_dt>.01),
                    'request_pc_ns':s.get('request_pc_ns'),'serial_read_ms':s.get('serial_read_ms'),'poll_id':s.get('poll_id'),
                    'sample_age_ms':(time.monotonic_ns()-host_est_ns)/1e6,'continuity_degraded_since_connect':self._continuity_degraded,'batch_id':s.get('batch_id'),'batch_index':s.get('batch_index'),
                    'batch_shift_ms':s.get('batch_shift_ms'),'reported_odr':s.get('reported_odr'),
                    'processing_age_ms':max(0.,(time.monotonic_ns()-observed_ns)/1e6)}
            self.latest=record;self.counter+=1;self.last_wall=time.time()
            now_mono=time.perf_counter()
            if now_mono-self._rate_clock>=0.8:
                self.actual_rate_hz=(self.counter-self._rate_count)/(now_mono-self._rate_clock)
                self._rate_count=self.counter;self._rate_clock=now_mono
            self.recent.append(record)
            if self.counter%4==0:
                self.history_seq+=1
                curves={name:{channel:({axis:pose[axis] for axis in ('roll','pitch','yaw')} if (pose:=pair[channel]) else None)
                              for channel in ('raw','cal')} for name,pair in outputs.items()}
                self.history.append({'seq':self.history_seq,'t':t,'raw':record['raw'],'cal':record['cal'],
                    'ref':record['ref'],'curves':curves})
            if self.stability and self.stability.state=='running':
                if self.stability.add(record):
                    self.stability.save(ROOT/'data'/'reports')
                    self.log('静态稳定性对比已完成，报告：'+self.stability.report_path)
            if self.record_writer:
                row={'t_s':t,'source':self.source,'uid':self.uid,'calibration_state':self.cal_status,'calibration_mode':self.cal_mode,'calibration_runtime_error':self.cal_runtime_error,
                     **{f'acc_{v}_g':a[i] for i,v in enumerate('xyz')},
                     **{f'gyro_{v}_dps':g[i] for i,v in enumerate('xyz')},
                     **{f'acc_cal_{v}_g':ca[i] if ca else '' for i,v in enumerate('xyz')},
                     **{f'gyro_cal_{v}_dps':cg[i] if cg else '' for i,v in enumerate('xyz')},
                     **{f'{v}_raw_deg':chosen['raw'].get(v,'') if chosen['raw'] else '' for v in ('roll','pitch','yaw')},
                     **{f'{v}_cal_deg':chosen['cal'][v] if chosen['cal'] else '' for v in ('roll','pitch','yaw')},
                     'roll_cal_factory_deg':chosen['cal_factory']['roll'] if chosen['cal_factory'] else '',
                     'pitch_cal_factory_deg':chosen['cal_factory']['pitch'] if chosen['cal_factory'] else '',
                     'alignment_active':int(self.static_alignment is not None),
                     'ref_roll_deg':(s.get('ref') or {}).get('roll',''),
                     'ref_pitch_deg':(s.get('ref') or {}).get('pitch',''),
                     'temperature_c':s.get('temp'),'dt_s':dt,'algorithm':self.active,
                     'device_t_s':s.get('device_t_original',t),'host_est_ns':host_est_ns,'pc_observed_ns':observed_ns,
                     'imu_nominal_odr_hz':s.get('odr'),'imu_fifo_state':s.get('fifo_state'),
                     'timestamp_quality':s.get('timestamp_quality','unknown'),
                     'estimated_batch_seam_gap':int(original_dt>.01),'fusion_t_s':t,'fusion_dt_s':dt,'gap_reset':int(gap_reset),
                     'batch_id':s.get('batch_id'),'batch_index':s.get('batch_index'),'batch_shift_ms':s.get('batch_shift_ms'),
                     'reported_odr':s.get('reported_odr'),'processing_age_ms':record['processing_age_ms'],
                     **{k:record.get(k) for k in ('sample_age_ms','gap_bridge','gap_action','timing_degraded','request_pc_ns','serial_read_ms','poll_id')}}
                self.record_writer.writerow(row);self.record_rows+=1
                if self.record_rows%200==0:self.record_fp.flush()
    def start_record(self):
        with self.lock:
            if not self.running:raise ValueError('采集尚未开始')
            if self.record_fp:raise ValueError('已经在录制')
            name=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            file=RECORD_DIR/f'{name}_{self.uid or "UNKNOWN"}.csv'
            self.record_fp=file.open('w',newline='',encoding='utf-8-sig');self.record_writer=csv.DictWriter(self.record_fp,fieldnames=CSV_KEYS)
            self.record_writer.writeheader();self.record_rows=0;self.record_path=file
            meta={'created':self.session_started,'source':self.source,'uid':self.uid,'uid_hex':self.uid_hex,
                  'calibration_status':self.cal_status,'calibration_mode':self.cal_mode,'calibration_runtime_error':self.cal_runtime_error,'calibration_files':self.cal.get('files',[]) if self.cal else [],
                  'algorithm':self.active if self.pipeline_mode=='realtime' else None,'pipeline_mode':self.pipeline_mode,'params':asdict(self.params),'coordinate':'R10 platform P; ZYX output',
                  'temperature_compensation':self.cal_mode=='thermal','reference_provenance':'synthetic' if self.source=='simulation' else 'none'}
            file.with_suffix('.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
            self.log('开始全采样率录制：'+file.name)
            return file.name
    def stop_record(self):
        with self.lock:
            if self.record_fp:self.record_fp.flush();self.record_fp.close();self.record_fp=None;self.record_writer=None
            return self.record_path.name if self.record_path else None
    def stream_history(self,after_seq=-1,display_stride=1):
        """UI-only: copy just new graph entries with short lock hold.

        Old history is not touched. Raw recording and fusion remain full-rate.
        """
        if display_stride<1:raise ValueError('display_stride必须>=1')
        with self.lock:
            latest_seq=self.history[-1]['seq'] if self.history else self.history_seq
            new=[]
            for row in reversed(self.history):
                if row['seq']<=after_seq:break
                new.append(row)
        new.reverse()
        if display_stride>1:
            new=[row for row in new if row['seq']%display_stride==0 or row['seq']==latest_seq]
        return new,latest_seq

    def start_stability(self,duration_s=30):
        with self.lock:
            if not(self.running and self.connected and self.source=='serial'):
                raise ValueError('静态稳定性测试必须连接并采集真实RS485设备')
            if self.stability and self.stability.state=='running':
                raise ValueError('已有静态稳定性测试正在运行')
            self.stability=StationaryEvaluation(float(duration_s),self.uid,self.cal_mode,asdict(self.params))
            self.log('启动真实PCB静态对比，时长'+str(duration_s)+'秒；请保持设备不动')
            return self.stability.summary(False)
    def stop_stability(self):
        with self.lock:
            if self.stability and self.stability.state=='running':
                self.stability.state='stopped'
                if self.stability.samples:self.stability.save(ROOT/'data'/'reports')
            return self.stability.summary() if self.stability else None
    def stability_status(self):
        with self.lock:
            return self.stability.summary() if self.stability else None
    def status(self,history=False):
        with self.lock:
            x=self.latest
            result={'source':self.source,'running':self.running,'connected':self.connected,
                    'uid':self.uid,'uid_hex':self.uid_hex,'cal_status':self.cal_status,'cal_mode':self.cal_mode,'cal_detail':self.cal_detail,'cal_issues':self.cal_issues,'cal_diagnostics':self.cal_diagnostics,'cal_runtime_error':self.cal_runtime_error,'cal_folder':self.cal_root,'cal_source':self.cal_source,
                    'cal_files':self.cal.get('files',[]) if self.cal else [],
                    'algorithm':self.active,'params':asdict(self.params),'static_alignment':self.static_alignment,'count':self.counter,
                    'elapsed':(x['t'] if x else 0),
                    'sample_rate_hz':round(self.actual_rate_hz,1) if self.running and self.last_wall and (time.time()-self.last_wall)<1 else 0,
                    'nominal_odr_hz':x.get('odr') if x else None,
                    'last_seen_s':round(time.time()-self.last_wall,2) if self.last_wall else None,
                    'recording':bool(self.record_fp),'record_rows':self.record_rows,'record_file':self.record_path.name if self.record_path else None,
                    'error':self.error,'events':list(self.events)[:16],
                    'stationary_test':self.stability.summary(False) if self.stability else None,
                    'turntable':'not_connected','temp_comp':('active_research' if self.cal_mode=='thermal' and self.cal_status=='matched' and not self.cal_runtime_error else 'inactive'),
                    'pipeline':self.pipeline_status(),'latest':x,'statistics':summarize(list(self.recent)[-1200:]) if x and x['ref'] else None}
            if history:result['history']=list(self.history)
            return result

ENGINE=Workstation()
