"""Offline run result: always render useful static plots, even if no sway occurred."""
from __future__ import annotations
import html,json,math
from pathlib import Path
from urllib.parse import quote

def esc(value):return html.escape(str(value or ''),quote=True)

def _path(name):return quote(Path(name).name,safe='')

def _plot(points,reference_sign,output,algorithm,mode='position'):
    n=len(points)
    if not n:return '<p>该阶段没有保存测量点。</p>'
    data=[]
    for x in points:
        try:
            v=float(x['angles']['cal'][algorithm][output]);r=reference_sign*float(x['actual_outer_deg'])
            if not(math.isfinite(v) and math.isfinite(r)):continue
            data.append((r,v,v-r))
        except (KeyError,TypeError,ValueError):continue
    if len(data)<2:return '<p>没有足够的有效静态测量样本绘图。</p>'
    sets=([('转台参考',[x[0] for x in data],'#617f70'),('融合输出',[x[1] for x in data],'#2b79a5')]
          if mode=='position' else [('绝对误差',[x[2] for x in data],'#bb614b')])
    vals=[v for _,ys,_ in sets for v in ys];low=min(vals);high=max(vals);diff=high-low
    if diff<.02:low-=.05;high+=.05
    else:low-=diff*.12;high+=diff*.12
    width=850;height=220;L=58;R=20;T=20;B=43
    def xy(i,v):return L+i*(width-L-R)/max(1,len(data)-1),T+(high-v)*(height-T-B)/(high-low)
    nodes=[f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="{esc(output)} 静态{esc(mode)}曲线" style="width:100%;height:auto">']
    for k in range(5):
        value=low+(high-low)*k/4;y=xy(0,value)[1]
        nodes.append(f'<line x1="{L}" x2="{width-R}" y1="{y:.1f}" y2="{y:.1f}" stroke="#e8eeea"/><text x="{L-8}" y="{y+4:.1f}" text-anchor="end" font-size="11" fill="#667a6d">{value:.2f}°</text>')
    for i in range(len(data)):
        x=xy(i,data[i][0])[0];
        if i in (0,3,6,9,12,len(data)-1):nodes.append(f'<text x="{x:.1f}" y="{height-16}" text-anchor="middle" font-size="11" fill="#667a6d">{i+1}</text>')
    for label,values,color in sets:
        coords=' '.join(f'{xy(i,v)[0]:.1f},{xy(i,v)[1]:.1f}' for i,v in enumerate(values))
        nodes.append(f'<polyline points="{coords}" fill="none" stroke="{color}" stroke-width="2.5" stroke-linejoin="round"/>')
        for i,v in enumerate(values):
            x,y=xy(i,v);nodes.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.6" fill="{color}"/>')
    nodes.append('</svg><p class="tiny">'+ '　'.join(f'<span style="color:{color}">● {esc(label)}</span>' for label,_,color in sets)+'　　横坐标：采样顺序</p>')
    return ''.join(nodes)

def write_run_ledger_html(folder,ledger_filename,ledger):
    folder=Path(folder);state=ledger.get('state','')
    success=ledger.get('all_requested_stages_completed',False)
    status='全部完成' if success else '部分结果 / 自动流程已中止'
    sections=[]
    for item in ledger.get('static_prechecks') or []:
        filename=item.get('report_file')
        if not filename:continue
        path=folder/Path(filename).name
        report={}
        if path.is_file():
            try:report=json.loads(path.read_text(encoding='utf-8'))
            except (OSError,ValueError):pass
        analysis=report.get('analysis') or item.get('analysis') or {}
        algo=analysis.get('chosen_algorithm') or report.get('algorithm_at_start','madgwick')
        sign=analysis.get('reference_sign',1)
        pol=report.get('polarity_detection') or item.get('polarity_detection') or {}
        changed=pol.get('changed',False)
        m=(analysis.get('algorithm_metrics') or {}).get('cal_'+algo,{})
        links=f'<a href="{_path(filename)}">静态JSON</a>'
        if item.get('interactive_html_file'):
            links+=f'　<a href="{_path(item["interactive_html_file"])}">完整14点交互HTML</a>'
        pol_note=(f"已自动核对参考方向：输入 {pol.get('requested_sign', '?'):+d}，实际使用 {pol.get('selected_sign', '?'):+d}" if pol.get('valid') else '方向未通过确认（按原始参考显示）') if pol else '未进行自动方向识别'
        sections.append(f'''<section><h2>{esc(item.get('output','').upper())} · 静态14点</h2>
          <p><strong>{esc(pol_note)}</strong> · 参考方向符号 {esc(sign)}</p>
          <p>当前算法：{esc(algo)}　｜　静态RMSE {esc(m.get('static_rmse_deg','—'))}°　｜　最大绝对误差 {esc(m.get('static_max_abs_deg','—'))}°</p>
          <h3>真实编码器角度与IMU输出</h3>{_plot(report.get('items') or [],sign,item.get('output','roll'),algo)}
          <h3>逐点绝对误差（未做事后消零）</h3>{_plot(report.get('items') or [],sign,item.get('output','roll'),algo,'error')}
          <p class="files">{links}</p></section>''')
    for item in ledger.get('completed_dynamic_stages') or []:
        name=item.get('report_file');sections.append(f'<section><h2>{esc(item.get("output","").upper())} · 动态结果</h2><a href="{_path(name)}">查看已完成动态JSON</a></section>')
    # A stage can have finished physical motion and stopped safely, yet be
    # unavailable for scientific RMSE because feedback quality failed. Expose
    # its raw files and report rather than presenting an empty AUTO report.
    last=ledger.get('last_dynamic_report_file')
    if last and not any(x.get('report_file')==last for x in ledger.get('completed_dynamic_stages') or []):
        path=folder/Path(last).name
        dyn={}
        if path.is_file():
            try:dyn=json.loads(path.read_text(encoding='utf-8'))
            except (OSError,ValueError):pass
        a=dyn.get('analysis') or {}
        html_name=dyn.get('html_report_file')
        links=f'<a href="{_path(last)}">本阶段动态JSON</a>'
        if html_name and (folder/Path(html_name).name).is_file():
            links+=f'　<a href="{_path(html_name)}">查看本阶段动态交互报告</a>'
        for key,label in [('raw_file_table','转台原始CSV'),('raw_file_imu','IMU原始CSV')]:
            if dyn.get(key):links+=f'　<a href="{_path(dyn[key])}">{label}</a>'
        q=a.get('reference_quality') or {}
        note=(f'转台最长间隔 {q.get("max_feedback_gap_ms", "—")}ms；稳定段参考覆盖率 {q.get("stable_coverage_pct", "—")}%.' if q else '')
        sections.append(f'<section><h2>未完成的动态阶段 · 数据已保留</h2><p>{esc(dyn.get("error") or ledger.get("error") or "分析未完成")}</p><p>{esc(note)} 本段不代表完成了Roll/Pitch联合实验，也不代表安全停车状态的验收。</p><p class="files">{links}</p></section>')
    al=ledger.get('static_alignment_file')
    if al:sections.append(f'<section><h2>静态对齐拟合与反向验证</h2><p>{esc((ledger.get("static_alignment") or {}).get("reason",""))}</p><a href="{_path(al)}">查看原始与补偿参数JSON</a></section>')
    if not sections:sections.append('<section><p>本次中止前未完成可报告的采样阶段，详见运行记录。</p></section>')
    html_text=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TiltLab · 自动实验阶段报告</title><style>
    *{{box-sizing:border-box}}body{{background:#f7f9f8;color:#263d31;font:14px/1.7 -apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;margin:0}}main{{max-width:1050px;margin:auto;padding:35px 20px 70px}}h1{{font-size:28px}}h2{{font-size:20px}}h3{{font-size:15px;margin-top:26px}}p{{color:#4b6456}}section{{background:white;border:1px solid #e3ebe5;border-radius:18px;padding:22px;margin:18px 0;box-shadow:0 9px 25px #15291d06}}.headline{{background:#fff9f4;border:1px solid #eadacb;border-radius:15px;padding:17px}}a{{color:#175c7b}}.tiny{{color:#789083;font-size:12px}}.files{{margin-top:14px}}@media(max-width:550px){{h1{{font-size:22px}}}}
    </style></head><body><main><p class="tiny">TILT LAB / AUTO RUN STAGE REPORT</p><h1>{esc(status)}</h1><p class="headline">流程状态：{esc(state)}<br>错误原因：{esc(ledger.get('error') or '无')}<br>双轴停止确认：{esc(ledger.get('stopped_verified'))}</p>
    <p>本报告只展示实际完成的静态/动态阶段。静态失败时没有执行动态摇摆，因此不会生成不存在的动态曲线。绝对静态误差不通过软件美化；停机确认与角度验收分别判断。</p>
    <p><a href="{_path(ledger_filename)}">完整运行日志JSON</a></p>{''.join(sections)}<p class="tiny">离线报告；用户须核验真实设备状态，不能将运行记录作为工业安全停机证明。</p></main></body></html>'''
    filename=Path(ledger_filename).with_suffix('.html').name
    (folder/filename).write_text(html_text,encoding='utf-8')
    return filename
