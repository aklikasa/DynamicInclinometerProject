"""Process-local, bounded, best-effort performance evidence.

Not a new clock source. Does not alter the 500 ms watchdog or IMU samples.
"""
import gc
import time
from collections import deque

_gc_starts = {}
_gc_events = deque(maxlen=12)
_gc_peak_ms = 0.0


def _gc_callback(phase, info):
    global _gc_peak_ms
    gen = info.get('generation', -1)
    now = time.monotonic_ns()
    if phase == 'start':
        _gc_starts[gen] = now
    elif phase == 'stop':
        begin = _gc_starts.pop(gen, now)
        duration_ms = (now - begin) / 1e6
        _gc_peak_ms = max(_gc_peak_ms, duration_ms)
        if duration_ms >= 5.0:
            _gc_events.append({'duration_ms': round(duration_ms, 3), 'generation': gen,
                               'end_monotonic_ns': now})


if _gc_callback not in gc.callbacks:
    gc.callbacks.append(_gc_callback)


class RuntimePerf:
    def __init__(self):
        self.phase = 'idle'
        self.phase_ns = time.monotonic_ns()
        self.batch_id = None
        self.batch_index = None
        self.max_duration = {name: 0.0 for name in ('lock', 'process', 'batch', 'ipc')}
        self.last_duration = dict(self.max_duration)
        self.slow_events = deque(maxlen=16)

    def phase_change(self, phase):
        self.phase = phase
        self.phase_ns = time.monotonic_ns()

    def observe(self, kind, ms):
        ms = max(0., float(ms))
        self.last_duration[kind] = ms
        self.max_duration[kind] = max(self.max_duration[kind], ms)
        if ms >= 20:
            self.slow_events.append({'kind': kind, 'ms': round(ms, 3),
                                     'batch_id': self.batch_id,
                                     'batch_index': self.batch_index,
                                     'monotonic_ns': time.monotonic_ns()})

    def snapshot(self):
        return {'phase': self.phase,
                'phase_age_ms': round((time.monotonic_ns() - self.phase_ns)/1e6, 3),
                'batch_id': self.batch_id, 'batch_index': self.batch_index,
                'last_ms': {k: round(v, 3) for k, v in self.last_duration.items()},
                'peak_ms': {k: round(v, 3) for k, v in self.max_duration.items()},
                'slow_events': list(self.slow_events),
                'gc_peak_ms': round(_gc_peak_ms, 3),
                'recent_gc_pauses': list(_gc_events)}
