"""Deterministic synthetic fixture only. Never represented as actual product measurement."""
import math,random
from .fusion import euler_to_q,gravity_body
from .calibration import Cal

SIM_SN='DTS672516'
# Known synthetic distortion and its inverse, *not* actual calibration.
DEMO_ACC=Cal([.013,-.009,.017],[[1/1.012,0,0],[0,1/.992,0],[0,0,1/1.006]],'DEMO_SYNTHETIC')
DEMO_GYRO=Cal([.19,-.14,.11],[[1/1.009,0,0],[0,1/.994,0],[0,0,1/1.004]],'DEMO_SYNTHETIC')

# Pose and angular rates of the programmed reference table in degrees & degrees/s.
def motion(t,mode='sine'):
    if mode=='static':
        points=[-30,-20,-10,-5,0,5,10,20,30]
        step=min(8,int(t/2));previous=points[max(0,step-1)];nxt=points[step]
        u=max(0,min(1,(t-step*2)/.45)) if step else 1
        roll=previous+(nxt-previous)*(.5-.5*math.cos(math.pi*u))
        rate=(nxt-previous)*math.pi/(.9)*math.sin(math.pi*u) if 0<u<1 else 0
        return (roll,0,0),(rate,0,0)
    if mode=='step':
        x=0 if t<1 else 18 if t<5 else -12 if t<9 else 0
        # smooth raised cosine transition over 0.55s
        def shift(start,amplitude):
            u=max(0,min(1,(t-start)/.55))
            angle=amplitude*(.5-.5*math.cos(math.pi*u))
            rate=amplitude*(.5*math.pi/.55*math.sin(math.pi*u)) if 0<u<1 else 0
            return angle,rate
        a1,r1=shift(1,18);a2,r2=shift(5,-30);a3,r3=shift(9,12)
        return (a1+a2+a3,0,0),(r1+r2+r3,0,0)
    if mode=='sweep':
        freq=.13 if t<8 else .28 if t<16 else .5 if t<24 else .85
        # phase continuous across segments
        phase=2*math.pi*(.13*min(t,8)+.28*max(0,min(t-8,8))+.5*max(0,min(t-16,8))+.85*max(0,t-24))
        return (13*math.sin(phase),4*math.sin(phase*.63),0),(13*2*math.pi*freq*math.cos(phase),4*.63*2*math.pi*freq*math.cos(phase*.63),0)
    if mode=='vibration':return (7,3,0),(0,0,0)
    if mode=='hold':return (12,-4,0),(0,0,0)
    if mode=='repeat':
        w=2*math.pi*.4
        return (15*math.sin(w*t),8*math.sin(w*t+.6),0),(15*w*math.cos(w*t),8*w*math.cos(w*t+.6),0)
    if mode=='rotation':
        w=2*math.pi*.18
        return (22*math.sin(w*t),0,0),(22*w*math.cos(w*t),0,0)
    w=2*math.pi*.34
    return (16*math.sin(w*t),7*math.sin(w*t*.7),0),(16*w*math.cos(w*t),7*w*.7*math.cos(w*t*.7),0)

class DemoDevice:
    def __init__(self,mode='sine',odr=200,seed=2026):self.mode=mode;self.odr=odr;self.i=0;self.rng=random.Random(seed)
    def next_batch(self,batch=4):
        rows=[]
        for _ in range(batch):
            t=self.i/self.odr;self.i+=1
            (roll,pitch,yaw),(gx,gy,gz)=motion(t,self.mode)
            # ZYX Euler derivatives -> sensor-body gyro in deg/s.
            rx,py,yz=gx,gy,gz
            sr,cr=math.sin(roll*math.pi/180),math.cos(roll*math.pi/180)
            sp,cp=math.sin(pitch*math.pi/180),math.cos(pitch*math.pi/180)
            gx,gy,gz=rx-yz*sp,py*cr+yz*sr*cp,-py*sr+yz*cr*cp
            g=gravity_body(euler_to_q(roll,pitch,yaw))
            if self.mode=='vibration':
                external=[.12*math.sin(t*2*math.pi*18),.09*math.sin(t*2*math.pi*27),.05*math.sin(t*2*math.pi*13)]
            elif self.mode in ('sweep','sine','repeat','rotation'):
                external=[.017*math.sin(2*math.pi*.8*t),.025*math.sin(2*math.pi*.6*t),0]
            else:external=[0,0,0]
            acc=[(g[j]+external[j])*[1.012,.992,1.006][j]+[.013,-.009,.017][j]+self.rng.gauss(0,.0026) for j in range(3)]
            gyro=[(v*[1.009,.994,1.004][j]+[.19,-.14,.11][j]+self.rng.gauss(0,.035)) for j,v in enumerate([gx,gy,gz])]
            rows.append(dict(t=t,acc=acc,gyro=gyro,temp=25.2+0.1*math.sin(t/40),
                             ref={'roll':roll,'pitch':pitch,'yaw':yaw},source='simulation',odr=self.odr))
        return rows
