"""Opt-in stationary initialization. Hardware feedback is a safety gate only;
all estimation uses calibrated IMU samples. No reference-angle correction."""
import csv, datetime, math, time
from pathlib import Path
import numpy as np
from .dynamic_experiment import _ok_axes
from .angles import angle_delta_deg
from .auto_research_report import write_json
from .table_diagnostics import DIAG


class StaticContinuityError(ValueError):
    def __init__(self, details):
        self.details=details
        self.retryable=details["retryable_batch_seams"]
        super().__init__(f"静止诊断采样不连续；不允许初始化：序号异常 {details['sequence_errors']}，时间倒退 {details['nonincreasing']}，超过10ms {details['gaps_over_10ms']}，最大间隔 {details['max_gap_ms']:.3f}ms")


def continuity_details(rows):
    t=np.asarray([r["host_est_ns"] for r in rows],dtype=np.int64)
    seq=np.asarray([r["sequence"] for r in rows],dtype=np.int64)
    d=np.diff(t)/1e6; seq_bad=int(np.sum(np.diff(seq)!=1)); backwards=int(np.sum(d<=0)); inds=np.flatnonzero(d>10)
    events=[]; all_seams=True
    for i in inds:
        a,b=rows[i],rows[i+1]; ba,bb=a.get("batch_id"),b.get("batch_id")
        seam=(isinstance(ba,(int,np.integer)) and isinstance(bb,(int,np.integer)) and bb==ba+1 and a.get("batch_index")==15 and b.get("batch_index")==0)
        all_seams=all_seams and seam
        if len(events)<100:events.append(dict(before_sequence=int(seq[i]),after_sequence=int(seq[i+1]),before_ns=int(t[i]),after_ns=int(t[i+1]),gap_ms=float(d[i]),before_batch=ba,after_batch=bb,batch_seam=bool(seam)))
    peak=float(np.max(d)) if len(d) else 0.
    return dict(sequence_errors=seq_bad,nonincreasing=backwards,gaps_over_10ms=int(len(inds)),max_gap_ms=peak,events=events,events_truncated=len(inds)>100,retryable_batch_seams=bool(len(inds) and not seq_bad and not backwards and all_seams and peak<=50))


def capture_with_retry(workflow, output, inner, seconds):
    """At most three complete windows; no motion or relaxation of gates."""
    for attempt in range(1,4):
        workflow.pre_research_attempt=attempt
        try:return capture(workflow,output,inner,seconds)
        except StaticContinuityError as exc:
            if not exc.retryable or attempt==3:raise
            workflow._watch()
            axes=_ok_axes(workflow.table.read_status(),2,inner_target_deg=inner)
            if abs(angle_delta_deg(axes['0']['position_deg'],inner))>.08 or abs(angle_delta_deg(axes['2']['position_deg'],0))>.08:raise RuntimeError('静止重采前转台位置异常')
            DIAG.record('pre_research_retry','静止批次间隔超限；保持停车并重新采集完整窗口',output=output,attempt=attempt,next_attempt=attempt+1,details=exc.details)
    raise AssertionError('unreachable')


def assess(rows, seconds):
    a=np.asarray([r['acc_cal'] for r in rows],dtype=float)
    g=np.asarray([r['gyro_cal'] for r in rows],dtype=float)
    t=np.asarray([r['host_est_ns'] for r in rows],dtype=np.int64)
    seq=np.asarray([r['sequence'] for r in rows],dtype=np.int64)
    x=(t-t[0])/1e9 if len(t) else np.array([])
    if len(t)<100 or x[-1]<seconds-.5 or not np.isfinite(a).all() or not np.isfinite(g).all():
        raise ValueError('静止诊断样本/时长不足或六轴数据无效')
    details=continuity_details(rows)
    if details["sequence_errors"] or details["nonincreasing"] or (details["gaps_over_10ms"] and not details["retryable_batch_seams"]):
        raise StaticContinuityError(details)
    n=np.linalg.norm(a,axis=1);gn=np.linalg.norm(g,axis=1)
    # Sustained block checks, not a single instantaneous rate-zero test.
    edges=np.searchsorted(x,np.arange(int(x[-1])+1));blocks=[(a[i:j],g[i:j]) for i,j in zip(edges[:-1],edges[1:])]
    if not blocks or any(len(aa)<100 for aa,gg in blocks):raise ValueError('静止诊断秒级覆盖不足')
    am=np.mean(a,axis=0);gm=np.mean(g,axis=0)
    direction=am/np.linalg.norm(am)
    dev=max(float(np.degrees(np.arccos(np.clip(np.dot(aa.mean(axis=0)/np.linalg.norm(aa.mean(axis=0)),direction),-1,1)))) for aa,gg in blocks)
    peak_mean=max(float(np.linalg.norm(gg.mean(axis=0))) for aa,gg in blocks)
    if np.max(abs(n-1))>.075 or np.max(gn)>1.05 or peak_mean>.10 or np.max(g.std(axis=0))>.35 or dev>.08:
        raise ValueError('静止诊断质量门禁未通过（运动/重力方向/陀螺噪声异常）')
    if details["gaps_over_10ms"]:raise StaticContinuityError(details)
    half=len(g)//2
    return {'state':'passed','samples':len(t),'duration_s':float(x[-1]),'sample_rate_hz':float((len(t)-1)/x[-1]),'max_gap_ms':float(np.max(np.diff(x))*1000),'gyro_bias_dps':gm.tolist(),'gyro_std_dps':g.std(axis=0).tolist(),'acc_mean_g':am.tolist(),'acc_std_g':a.std(axis=0).tolist(),'half_window_bias_change_dps':(g[half:].mean(axis=0)-g[:half].mean(axis=0)).tolist(),'max_block_gravity_direction_deviation_deg':dev,'max_block_gyro_mean_norm_dps':peak_mean,'gyro_1s_mean_std_dps':np.std([gg.mean(axis=0) for aa,gg in blocks],axis=0).tolist(),'gyro_1s_mean_min_dps':np.min([gg.mean(axis=0) for aa,gg in blocks],axis=0).tolist(),'gyro_1s_mean_max_dps':np.max([gg.mean(axis=0) for aa,gg in blocks],axis=0).tolist(),'note':'基于已标定IMU、PC估算时间；仅静止初始化，不是硬件采样或精度认证。'}


def capture(workflow, output, inner, seconds):
    e=workflow.engine;w=workflow;folder=Path(w.dynamic.dir);folder.mkdir(parents=True,exist_ok=True)
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f');uid=''.join(c for c in str(e.uid) if c.isalnum() or c in '-_')[:48]
    stem=f'{stamp}_{uid}_{output.upper()}_PRE_RESEARCH';csvpath=folder/(stem+'.csv');jp=folder/(stem+'.json')
    rows=[];summary={'state':'failed','output':output,'requested_s':seconds,'raw_csv':csvpath.name,'json_file':jp.name,'seed_applied':False,'attempt':getattr(w,'pre_research_attempt',1),'max_attempts':3}
    w._watch();_ok_axes(w.table.read_status(),2,inner_target_deg=inner)
    with e.lock:last=e.latest['sequence']
    start=time.monotonic();deadline=start+seconds;next_feedback=start
    try:
        with csvpath.open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.writer(f);writer.writerow(['sequence','host_est_ns','pc_observed_ns','device_t_s','batch_id','batch_index','temperature_c',*[f'cal_acc_{k}_g' for k in 'xyz'],*[f'cal_gyro_{k}_dps' for k in 'xyz']])
            while True:
                w._watch();now=time.monotonic()
                if now>=next_feedback:
                    axes=_ok_axes(w.table.read_status(),2,inner_target_deg=inner)
                    if abs(angle_delta_deg(axes['0']['position_deg'],inner))>.08 or abs(angle_delta_deg(axes['2']['position_deg'],0))>.08:raise RuntimeError('静止诊断期间转台离开目标位置')
                    next_feedback=now+.15
                with e.lock:
                    new=[]
                    for r in reversed(e.recent):
                        if r['sequence']<=last:break
                        new.append(r)
                    new.reverse()
                for r in new:
                    if r['sequence']!=last+1 or r.get('static_alignment_active') or r.get('calibration_state')!='matched' or not r.get('acc_cal') or not r.get('gyro_cal'):raise RuntimeError('静止诊断数据连续性或标定状态异常')
                    row={k:r.get(k) for k in ('sequence','host_est_ns','pc_observed_ns','device_t_original','batch_id','batch_index','temp','acc_cal','gyro_cal')}
                    rows.append(row);last=r['sequence'];writer.writerow([row[k] for k in ('sequence','host_est_ns','pc_observed_ns','device_t_original','batch_id','batch_index','temp')]+list(row['acc_cal'])+list(row['gyro_cal']))
                with w.lock:w.pre_research_progress={'output':output,'elapsed_s':round(min(seconds,now-start),1),'total_s':seconds,'samples':len(rows),'attempt':summary['attempt'],'max_attempts':3}
                if now>=deadline:break
                if w.cancel.wait(.05):raise RuntimeError('操作员已中止静止诊断')
        summary.update(assess(rows,seconds));w._watch();axes=_ok_axes(w.table.read_status(),2,inner_target_deg=inner)
        from .fusion import accel_tilt
        angle=accel_tilt(summary['acc_mean_g'])[output]
        sign=w.plan['sign'] if output=='roll' else w.plan['pitch_sign']
        error=abs(angle_delta_deg(angle,sign*angle_delta_deg(axes['2']['position_deg'],0)))
        summary['seed_static_reference_check_deg']=error
        if w.plan.get('static_before_dynamic') and w.plan.get('static_stop_on_fail') and error>w.plan['static_limit_deg']:
            raise RuntimeError('静止初始化角度未通过原静态阈值，禁止摇摆')
        # Do not persist changes to factory calibration or filter parameters.
        w._watch()
        e.seed_research_gyro_anchor(summary['acc_mean_g'],summary['gyro_bias_dps'],last)
        summary['seed_applied']=True
    except Exception as exc:
        summary.update(state='failed',error=str(exc))
        if isinstance(exc,StaticContinuityError):summary['continuity']=exc.details
        raise
    finally:
        summary['samples_captured']=len(rows)
        if rows:
            summary['first_host_est_ns']=int(rows[0]['host_est_ns']);summary['last_host_est_ns']=int(rows[-1]['host_est_ns'])
        write_json(jp,summary)
        with w.lock:w.pre_research_results.append(summary);w.pre_research_progress=None
    return summary
