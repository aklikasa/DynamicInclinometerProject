"""Operator-gated, guarded 2TD-600 commissioning workflow.

Hardware preparation commands can move axes. Only the user-controlled /start
endpoint runs them, and only after fresh precheck + explicit physical-area ACK.
Software STOP is not a hardware E-stop. Mechanical find-zero path is vendor-
defined and cannot be proven collision-free by software.
"""
import math,secrets,threading,time
from .angles import angle_delta_deg, zero_distance_deg
from .table_diagnostics import DIAG

class TablePreparation:
    # No arbitrary near-zero requirement for enabling. The route to 0 must
    # still be explicitly confirmed by the on-site operator.
    MAX_READY_ANGLE=.06
    MAX_SPEED=6.0
    def __init__(self, table, monitor=None, dynamic=None, static=None):
        self.table=table;self.monitor=monitor;self.dynamic=dynamic;self.static=static
        self.lock=threading.RLock();self.cancel=threading.Event();self.thread=None
        self.running=False;self.state='idle';self.error='';self.token=None;self.valid_until=0
        self.heartbeat_ns=0;self.last_feedback=None;self.verified=False
        self.completed_at=0;self.snapshot=None;self.stopped_verified=None
        self.only_enable=False
        self.zero_speed_dps=2.0
    def status(self):
        with self.lock:
            return {'running':self.running,'state':self.state,'error':self.error,
                    'ready':self.verified,'zero_speed_dps':self.zero_speed_dps,'feedback':self.last_feedback,'stopped_verified':self.stopped_verified,
                    'note':'真实使能/机械找零会导致实体运动；仅在现场监护、硬件急停可用时执行'}
    def _exclusive(self):
        if not self.table.connected:raise ValueError('先连接2TD-600转台')
        if self.monitor and self.monitor.running:raise ValueError('请先停止转台反馈记录')
        if self.dynamic and self.dynamic.running:raise ValueError('动态测试运行中禁止转台初始化')
        if self.static and self.static.running:raise ValueError('静态自动运动运行中禁止转台初始化')
    def _safety(self,st,allow_not_enabled=True,require_idle=True):
        axes=st.get('axes') or {}
        for ax in (0,2):
            x=axes.get(str(ax))
            if x is None:raise ValueError('转台缺少轴0/2状态')
            if not all(isinstance(x.get(k),(int,float)) and math.isfinite(x[k]) for k in ('position_deg','speed_dps')):
                raise ValueError('转台位置/速度反馈无效')
            if abs(x['speed_dps'])>.08:raise ValueError('轴仍在转动，禁止准备')
            if require_idle and x.get('mode') not in (0,2,20):raise ValueError('轴不在空闲/静止状态，禁止准备')
            if any(x.get(k) for k in ('driver_fault','upper_limit','lower_limit','over_speed')):
                raise ValueError(f'轴{ax}存在驱动故障、限位或超速告警；不能发送使能命令')
            # Some servos only assert NORMAL after enabling. Do not require it
            # beforehand; check the feedback rigorously AFTER enable.
            if x.get('enabled') and not x.get('healthy'):
                raise ValueError(f'轴{ax}已经使能，但正常状态反馈为否；请检查设备告警')
            if not allow_not_enabled and not x.get('enabled'):raise ValueError('轴尚未确认使能')
        return axes
    def preflight(self):
        with self.lock:
            if self.running:raise ValueError('转台准备正在进行')
            self._exclusive()
            st=self.table.read_status();DIAG.snapshot('prepare_preflight',st);axes=self._safety(st)
            self.token=secrets.token_urlsafe(18);self.valid_until=time.monotonic()+30
            self.verified=False;self.error='';self.state='checked'
            self.snapshot={str(a):axes[str(a)]['position_deg'] for a in (0,2)}
            movements=[{'axis':a,'current_deg':axes[str(a)]['position_deg'],
                        'action':('回到0°' if axes[str(a)].get('zeroed') else '机械找零（路径由厂家控制器决定）'),
                        'estimated_travel_deg':(zero_distance_deg(axes[str(a)]['position_deg']) if axes[str(a)].get('zeroed') else None)}
                       for a in (0,2)]
            return {'ready_for_operator':True,'token':self.token,'expires_in_s':30,'axes':axes,'movement_plan':movements,
                    'safety':'会发送真实使能和运动指令；请操作员核对实际位置到零位的全过程、负载/线缆、轴间干涉及实体急停'}
    def start(self,token,acknowledged,only_enable=False,zero_speed_dps=2.0):
        try: zero_speed_dps=float(zero_speed_dps)
        except (TypeError,ValueError): raise ValueError('普通回0°速度无效')
        if not math.isfinite(zero_speed_dps) or not .2<=zero_speed_dps<=5.0:
            raise ValueError('普通回0°速度必须为0.2–5.0°/s')
        with self.lock:
            if acknowledged is not True:raise ValueError('需要现场操作员确认机械运动安全条件')
            if self.running:raise ValueError('准备正在运行')
            if not token or self.token!=token or time.monotonic()>=self.valid_until:
                raise ValueError('准备预检查已失效，请重新预检查')
            self._exclusive();axes=self._safety(self.table.read_status())
            if not self.snapshot or any(abs(angle_delta_deg(axes[str(a)]['position_deg'],self.snapshot[str(a)]))>.1 for a in (0,2)):
                raise ValueError('预检查后转台位置发生变化，请重新预检查')
            self.token=None;self.cancel.clear();self.verified=False;self.running=True;self.only_enable=bool(only_enable);self.zero_speed_dps=zero_speed_dps
            self.state='enabling';self.error='';self.stopped_verified=None;self.heartbeat_ns=time.monotonic_ns()
            self.thread=threading.Thread(target=self._run,daemon=True,name='2TD600-guarded-preparation')
            DIAG.record('prepare_start','使能和回零准备任务开始',only_enable=self.only_enable,zero_speed_dps=zero_speed_dps)
            self.thread.start();return self.status()
    def heartbeat(self):
        with self.lock:
            if not self.running:raise ValueError('当前无准备任务')
            self.heartbeat_ns=time.monotonic_ns()
        return {'ok':True}
    def abort(self):
        self.cancel.set()
        if self.table.connected:self.table.stop()
        return self.status()
    def _guard(self,st=None):
        if self.cancel.is_set():raise RuntimeError('准备被操作员中止')
        if time.monotonic_ns()-self.heartbeat_ns>6_000_000_000:
            raise RuntimeError('控制页面心跳超时；尝试停车')
        if not self.table.connected:raise RuntimeError('转台失去连接')
        if st is None:st=self.table.read_status()
        axes=st.get('axes',{})
        for ax in (0,2):
            x=axes.get(str(ax),{})
            # Disconnected servo channels may report NORMAL=0 until enabled.
            # During transition to enable, rely on explicit fault bits;
            # afterward NORMAL must be confirmed by _wait().
            if any(x.get(k) for k in ('driver_fault','upper_limit','lower_limit','over_speed')):
                raise RuntimeError(f'轴{ax}发生驱动故障或触发限位')
            if x.get('enabled') and not x.get('healthy') and not str(self.state).startswith('enabling'):
                raise RuntimeError(f'轴{ax}已使能但正常状态丢失')
            if not all(isinstance(x.get(k),(int,float)) and math.isfinite(x[k]) for k in ('position_deg','speed_dps')):
                raise RuntimeError('反馈值无效')
            if abs(x['speed_dps'])>max(.8,self.zero_speed_dps+1.0):raise RuntimeError('自动准备出现超速')
        with self.lock:self.last_feedback=st
        return axes
    def _wait(self,axis,test,timeout,label):
        deadline=time.monotonic()+timeout;stable=0
        while time.monotonic()<deadline:
            axes=self._guard();x=axes[str(axis)]
            if test(x):
                stable+=1
                if stable>=3:return x
            else:stable=0
            if self.cancel.wait(.14):raise RuntimeError('准备被操作员中止')
        raise TimeoutError(f'轴{axis}{label}超时，未获得连续有效反馈')
    @classmethod
    def _readiness_reasons(cls,x):
        missing=[]
        if not x.get('enabled'):missing.append('使能位=0')
        if not x.get('zeroed'):missing.append('找零位=0')
        if not x.get('healthy'):missing.append('正常状态位=0')
        if not isinstance(x.get('position_deg'),(int,float)) or not math.isfinite(x['position_deg']):missing.append('角度反馈无效')
        elif zero_distance_deg(x['position_deg'])>cls.MAX_READY_ANGLE:missing.append(f'离零位 {zero_distance_deg(x["position_deg"]):.3f}°')
        if not isinstance(x.get('speed_dps'),(int,float)) or not math.isfinite(x['speed_dps']):missing.append('速度反馈无效')
        elif abs(x['speed_dps'])>=.06:missing.append(f'速度仍为{x["speed_dps"]:.3f}°/s')
        if x.get('mode') not in (0,2,20):missing.append(f'运行模式={x.get("mode")}（应为静止）')
        for flag in ('driver_fault','upper_limit','lower_limit','over_speed'):
            if x.get(flag):missing.append(flag+'=1')
        return missing
    def _run(self):
        try:
            for axis in (0,2):
                axes=self._guard();x=axes[str(axis)]
                DIAG.snapshot('enable_before',self.table.read_status(),f'轴{axis}使能前')
                if not x['enabled']:
                    with self.lock:self.state=f'enabling_{axis}'
                    self.table.enable_axis(axis)
                else:
                    DIAG.record('enable_skip',f'轴{axis}反馈已使能，跳过使能指令')
                # Original R10 delays briefly after each enable; then verify
                # the state rather than trusting SetAxisEnable's return value.
                if self.cancel.wait(.5):raise RuntimeError('准备被操作员中止')
                self._wait(axis,lambda x: x.get('enabled') and x.get('healthy'),8,'使能确认（若命令被接受但反馈仍未使能，请检查伺服电源、急停和驱动器告警）')
                DIAG.snapshot('enable_confirmed',self.table.read_status(),f'轴{axis}使能反馈确认')
            if self.only_enable:
                with self.lock:self.state='enabled_only';self.completed_at=time.time()
                return
            # both axes enabled; find zero sequentially to avoid concurrent axes motion
            for axis in (2,0):
                x=self._guard()[str(axis)]
                if not x['zeroed']:
                    with self.lock:self.state=f'finding_zero_{axis}'
                    DIAG.snapshot('find_zero_before',self.table.read_status(),f'轴{axis}机械找零前')
                    self.table.find_zero(axis,.5,.5)
                    self._wait(axis,lambda x: x.get('zeroed') and abs(x['speed_dps'])<.06 and x.get('mode') in (0,2,20),240,'机械找零')
                x=self._guard()[str(axis)]
                if zero_distance_deg(x['position_deg'])>self.MAX_READY_ANGLE:
                    with self.lock:self.state=f'moving_zero_{axis}'
                    start_angle=zero_distance_deg(x['position_deg'])
                    DIAG.snapshot('move_zero_before',self.table.read_status(),f'轴{axis}回到0°前')
                    self.table.move(axis,0.,self.zero_speed_dps)
                    # 39deg at .5deg/s needs >=78s, so fixed 30s is wrong.
                    # Includes generous acceleration/settling time and an upper bound.
                    wait_seconds=min(900,max(30,2.0*start_angle/self.zero_speed_dps+20))
                    self._wait(axis,lambda x: x.get('zeroed') and zero_distance_deg(x['position_deg'])<=self.MAX_READY_ANGLE and abs(x['speed_dps'])<.06 and x.get('mode') in (0,2,20),wait_seconds,'回到0°')
            # settle and confirm both axes on several consecutive feedback frames
            with self.lock:self.state='verifying'
            for _ in range(3):
                axes=self._guard()
                for ax in (0,2):
                    x=axes[str(ax)]
                    reasons=self._readiness_reasons(x)
                    if reasons:
                        DIAG.snapshot('prepare_verify_failed',self.table.read_status(),f'轴{ax}就绪失败')
                        raise RuntimeError(f'轴{ax}准备未通过：'+ '；'.join(reasons))
                if self.cancel.wait(.15):raise RuntimeError('准备中止')
            DIAG.snapshot('prepare_ready',self.table.read_status(),'双轴已通过准备条件核验')
            with self.lock:self.state='ready';self.verified=True;self.completed_at=time.time()
        except Exception as exc:
            DIAG.record('prepare_failed','转台准备失败',exception=type(exc).__name__,error_message=str(exc),current_phase=self.state)
            try:DIAG.snapshot('prepare_failed',self.table.read_status(),'准备失败时的两轴反馈')
            except Exception as re:DIAG.record('feedback_read_failed','失败后无法读取两轴反馈',exception=repr(re))
            with self.lock:self.error=f'{type(exc).__name__}: {exc}';self.state='failed';self.verified=False
            try:
                self.table.stop()
                confirmed=self.table.stopped_verified(timeout=5)
                with self.lock:self.stopped_verified=confirmed
                if not confirmed:
                    with self.lock:self.error+='；停车反馈未确认！立即使用实体急停并核查设备'
            except Exception as stop_exc:
                with self.lock:self.stopped_verified=False;self.error+='；软件停车失败，请立即使用硬件急停：'+str(stop_exc)
        finally:
            with self.lock:self.running=False;self.token=None
