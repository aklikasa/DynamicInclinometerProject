"""Streaming rigid-body lever-arm correction for six-axis gravity observations.

The optional physical model assumes the sensor is displaced along *product P*
+Z by lever_z_cm relative to the turntable's instant rotation axis. It removes
(alpha × r + omega × (omega × r))/g from measured specific force, then feeds the
corrected acceleration to an otherwise unchanged Madgwick six-axis filter.

This is an experimental filter: the lever arm must be measured or explicitly
entered as an empirical hypothesis, not inferred from a single waveform as a
certified physical dimension. Does not command turntable movement.
"""
from __future__ import annotations
import math
from .fusion import Madgwick, R, norm, cross, gravity_body, clamp

G0 = 9.80665

class LeverArmMadgwick(Madgwick):
    def __init__(self, p, calibrated=True):
        super().__init__(p)
        self._calibrated_frame = bool(calibrated)
        self._smoothed_gyro = None
        self._last_linear_accel_g = [0.,0.,0.]

    def correct_acceleration(self, a, g, dt):
        if self._smoothed_gyro is None:
            self._smoothed_gyro = list(g)
        if dt <= 0:
            return list(a)
        if not all(math.isfinite(float(x)) for x in (*a,*g,dt)):
            raise ValueError('六轴输入不包含有限数值')
        # Explicitly optional. Radius=0 reproduces original Madgwick exactly.
        r_z = (self.p.lever_z_cm if self._calibrated_frame else 0.0) / 100.0
        if abs(r_z)<1e-12:
            return list(a)
        # Streaming low-pass angular velocity derivative, no future frames.
        # Retain absolute gyro rate for Madgwick quaternion prediction.
        old=self._smoothed_gyro
        gain=1.0-math.exp(-min(dt,.5)/self.p.lever_tau_s)
        smoothed=[old[j]+gain*(g[j]-old[j]) for j in range(3)]
        alpha=[(smoothed[j]-old[j])*R/dt for j in range(3)]
        self._smoothed_gyro=smoothed
        omega=[x*R for x in smoothed]
        # alpha × (0,0,r) = (alpha_y*r, -alpha_x*r,0)
        # omega × (omega × (0,0,r)) = (wx*wz*r, wy*wz*r, -(wx²+wy²)*r)
        specific=[(alpha[1]+omega[0]*omega[2])*r_z/G0,
                  (-alpha[0]+omega[1]*omega[2])*r_z/G0,
                  -(omega[0]*omega[0]+omega[1]*omega[1])*r_z/G0]
        # Observability/geometry validity require physical mounting review.
        # Bound estimated linear specific force for numerical safety, not as a
        # claim that a clipped estimate is physically accurate.
        mag=math.sqrt(sum(x*x for x in specific))
        if mag>.3:
            specific=[v*(.3/mag) for v in specific]
        self._last_linear_accel_g=specific
        corrected=[a[j]-specific[j] for j in range(3)]
        return corrected

    def update(self,a,g,dt):
        corrected=self.correct_acceleration(a,g,dt)
        return super().update(corrected,g,dt)


class AdaptiveLeverArmMadgwick(LeverArmMadgwick):
    """Causal adaptive beta + optional rigid-body correction + stationary gyro bias.

    Does not use the turntable encoder, future data or offline-fitted lag in the
    attitude calculation. Feedback trust is NOT the percentage of gyro blending.
    """
    def __init__(self,p,calibrated=True):
        super().__init__(p,calibrated)
        self._prev_a=None
        self._trust_filtered=1.0
        self.gyro_bias=[0.,0.,0.]
        self._stationary_duration=0.
        self.effective_beta=p.beta
        self.last_innovation_gps=0.

    def _correction_trust(self,a,g,dt):
        n=norm(a)
        if n < .2:return self.p.adaptive_beta_floor
        expected=gravity_body(self.q)
        unit=[v/n for v in a]
        gravity_res=norm(cross(unit,expected))
        # Predicted body-frame derivative of gravity; only the innovation
        # (not total jerk due to real rotation) indicates unexpected accel.
        w=[v*R for v in g]
        derivative_prediction=[-v for v in cross(w,expected)]
        if self._prev_a is not None and .0002<dt<.09:
            observed=[(a[i]-self._prev_a[i])/dt for i in range(3)]
            innovation=norm([observed[i]-derivative_prediction[i] for i in range(3)])
        else:innovation=0.
        self.last_innovation_gps=innovation
        self._prev_a=list(a)
        mag_trust=math.exp(-((n-1)/self.p.acc_threshold)**2)
        inertial_trust=math.exp(-((innovation/self.p.adaptive_acc_innovation_gps)**2))
        orientation_trust=math.exp(-((gravity_res/.25)**2))
        target=clamp(mag_trust*inertial_trust*orientation_trust,0,1)
        smoothing=1-math.exp(-min(dt,.2)/.22) if dt>0 else 1.
        self._trust_filtered+=(target-self._trust_filtered)*smoothing
        trust=self.p.adaptive_beta_floor+(1-self.p.adaptive_beta_floor)*self._trust_filtered
        self.effective_beta=self.p.beta*trust
        return trust

    def update(self,a,g,dt):
        corrected=self.correct_acceleration(a,g,dt)
        # Only estimate gyro bias after a sustained stationary period. Merely
        # passing through a sinusoidal turning point is NOT stationary.
        quiet=(dt>0 and dt<.09 and norm(g)<.35 and abs(norm(corrected)-1)<.035 and
               (self._prev_a is None or norm([corrected[i]-self._prev_a[i] for i in range(3)])<.0015))
        self._stationary_duration=self._stationary_duration+dt if quiet else 0.
        if self._stationary_duration>1.5:
            k=1-math.exp(-dt/12.)
            self.gyro_bias=[clamp(v+k*(g[i]-v),-.30,.30) for i,v in enumerate(self.gyro_bias)]
        gyro_corrected=[g[i]-self.gyro_bias[i] for i in range(3)]
        output=Madgwick.update(self,corrected,gyro_corrected,dt)
        output.update(beta_eff=round(self.effective_beta,6),
                      accel_innovation_gps=round(self.last_innovation_gps,6),
                      gyro_bias_dps=[round(x,6) for x in self.gyro_bias],
                      stationary_bias_update=self._stationary_duration>1.5)
        return output
