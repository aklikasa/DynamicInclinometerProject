"""Offline fixed-axis lever identification. No hardware control, no time shift fitting.
Input: factory calibrated P-frame six-axis CSV, measured table feedback and report.
Identification uses gyro harmonics (not encoder as a real-time fusion input).
Separate held-out experiments evaluate repeatability and the actual causal correction.
"""
from __future__ import annotations
import csv, io, json, math, hashlib, zipfile
from pathlib import PurePosixPath
import numpy as np
from .steady_state import find_sway_steady_start
G=9.80665
MAX_BYTES=160*1024*1024


def bundles(files):
    """Read only matching JSON + raw CSV triples; no extraction to disk."""
    items={}; total=0
    for filename, data in files:
        if filename.lower().endswith('.zip'):
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                for i in z.infolist():
                    name=PurePosixPath(i.filename.replace('\\','/')).name
                    if not (name.endswith('_DYNAMIC.json') or name.endswith('_DYNAMIC_imu.csv') or name.endswith('_DYNAMIC_table.csv')):continue
                    total+=i.file_size
                    if total>MAX_BYTES:raise ValueError('解压数据超过160 MB，请分批处理')
                    if name in items:raise ValueError('重复文件名：'+name)
                    items[name]=z.read(i)
        else:
            name=PurePosixPath(filename.replace('\\','/')).name
            total+=len(data)
            if total>MAX_BYTES:raise ValueError('数据超过160 MB')
            if name in items:raise ValueError('重复文件名：'+name)
            items[name]=data
    result=[]
    for name,data in items.items():
        if not name.endswith('_DYNAMIC.json'):continue
        d=json.loads(data.decode('utf-8-sig'))
        if d.get('kind')!='REAL_2TD600_SINE_DIAGNOSTIC':raise ValueError('非原始实机动态报告：'+name)
        tn,an=d.get('raw_file_table'),d.get('raw_file_imu')
        if tn not in items or an not in items:raise ValueError('缺少同组原始CSV：'+name)
        result.append((name,d,items[tn],items[an]))
    if not result:raise ValueError('请选择原始动态实验ZIP，或同时选择同组JSON、table.csv、imu.csv')
    if len(result)>16:raise ValueError('最多16组实验')
    return result


def read_csv(blob, fields, uid=None):
    r=csv.DictReader(io.StringIO(blob.decode('utf-8-sig')))
    if uid is not None and 'uid' not in (r.fieldnames or []):raise ValueError('IMU CSV缺少UID')
    if not set(fields)<=set(r.fieldnames or []):raise ValueError('CSV缺少字段：'+str(set(fields)-set(r.fieldnames or [])))
    arr=[]
    for row in r:
        if uid is not None and row.get('uid')!=uid:raise ValueError('IMU CSV UID与JSON不一致')
        try: vals=[float(row[k]) for k in fields]
        except (TypeError,ValueError):raise ValueError('原始CSV含空值或非数值，不能无声删除')
        if not all(math.isfinite(x) for x in vals):raise ValueError('CSV含非有限数据')
        arr.append(vals)
    if len(arr)<30:raise ValueError('原始样本不足')
    return np.asarray(arr)


def harmonic(t, y, w):
    X=np.column_stack((np.ones(len(t)),np.sin(w*t),np.cos(w*t)))
    return np.linalg.lstsq(X,y,rcond=None)[0]


def skew(v):
    v=np.asarray(v); M=np.zeros((len(v),3,3))
    M[:,0,1]=-v[:,2];M[:,0,2]=v[:,1];M[:,1,0]=v[:,2];M[:,1,2]=-v[:,0];M[:,2,0]=-v[:,1];M[:,2,1]=v[:,0]
    return M


def solve(blocks):
    # Each run contributes equally, independent of nominal sample rate.
    A=np.concatenate([b['M']/math.sqrt(len(b['M'])) for b in blocks]); y=np.concatenate([b['y']/math.sqrt(len(b['M'])) for b in blocks])
    A=A.reshape(-1,3); y=y.reshape(-1)
    U,s,V=np.linalg.svd(A,full_matrices=False); rank=int(np.sum(s>s[0]*.03)) if s[0]>0 else 0
    if not rank:raise ValueError('旋转激励不足，杆臂不可辨识')
    r=np.linalg.lstsq(A,y,rcond=.03)[0]
    # Huber IRLS on physical acceleration residuals; keep original data for evaluation.
    for _ in range(5):
        err=y-A@r; scale=max(1e-6,1.4826*np.median(np.abs(err-np.median(err))))
        weights=np.minimum(1.,2.5*scale/np.maximum(abs(err),1e-12)); root=np.sqrt(weights)
        r=np.linalg.lstsq(A*root[:,None],y*root,rcond=.03)[0]
    observable=np.sum(V[:rank]**2,axis=0)>.98
    return r,rank,observable,float(s[0]/s[rank-1])


def block(t,a,g,base,w):
    c=harmonic(t,g,w); _,_,V=np.linalg.svd(c[1:],full_matrices=False); axis=V[0]
    # Orientation phase comes from gyro on the same IMU timebase, not a fitted table shift.
    coeff=c[1:]@axis
    if np.linalg.norm(coeff)<.005:raise ValueError('陀螺激励太小')
    th=(-coeff[0]*np.cos(w*t)+coeff[1]*np.sin(w*t))/w
    vel=np.sin(w*t)*coeff[0]+np.cos(w*t)*coeff[1]
    acc=w*(np.cos(w*t)*coeff[0]-np.sin(w*t)*coeff[1])
    # Body gravity rotates opposite to angular displacement; exact Rodrigues.
    grav=base*np.cos(th[:,None])-np.cross(axis,base)*np.sin(th[:,None])+axis*np.dot(axis,base)*(1-np.cos(th[:,None]))
    W=skew(vel[:,None]*axis); M=(skew(acc[:,None]*axis)+W@W)/G
    # Remove constant residual per block; no arbitrary angle scale or time shift.
    y=a-grav
    return {'M':M-M.mean(axis=0),'y':y-y.mean(axis=0),'axis':axis,'theta':th,'grav':grav,'M_full':M,'a':a,'g':g,'t':t}


def prepare(bundle):
    name,d,tb,ib=bundle; plan=d['plan']; direction=plan['output']; axis=int(plan['axis']); f=float(plan['frequency_hz']); amp=float(plan['amplitude_deg']); w=2*math.pi*f
    if axis!=2 or direction not in ('roll','pitch') or not (.05<=f<=.8 and .2<=amp<=15):raise ValueError('仅支持外轴2、ROLL/PITCH、0.05–0.8Hz、摆幅≤15°的固定轴辨识')
    expected_mode='x_outer' if direction=='roll' else 'y_inner_90'
    if plan.get('mounting_mode')!=expected_mode:raise ValueError('仅支持标准x_outer / y_inner_90安装模式')
    if not d.get('uid') or d.get('calibration_mode') not in ('ambient','thermal') or not d.get('calibration_files'):raise ValueError('缺少实际设备及厂标定信息')
    t0=int(d['motion_start_pc_monotonic_ns'])/1e9; end=int(d['motion_end_pc_monotonic_ns'])/1e9-t0
    table=read_csv(tb,['pc_mid_ns','axis_2_pos','axis_0_pos']); tt=table[:,0]/1e9-t0; pos=np.rad2deg(np.unwrap(np.deg2rad(table[:,1])))
    if np.any(np.diff(tt)<=0):raise ValueError('转台时间戳不递增')
    steady=find_sway_steady_start(tt,pos,0.,end,f,amp)
    if not steady['valid']:raise ValueError('无法由真实转台反馈确定稳态：'+steady['reason'])
    start=float(steady['steady_start_s']); end-=.3
    arr=read_csv(ib,['host_est_ns','device_t_s','imu_nominal_odr_hz']+[f'cal_acc_{j}_g' for j in 'xyz']+[f'cal_gyro_{j}_dps' for j in 'xyz'],uid=d['uid'])
    t=arr[:,0]/1e9-t0; dev=arr[:,1]; a=arr[:,3:6]; g=np.deg2rad(arr[:,6:9]); dt=np.diff(dev)
    if np.any(dt<=0) or np.any(np.diff(t)<=0):raise ValueError('IMU时间戳不递增')
    pre=(t>=-2.5)&(t<-.1)
    if pre.sum()<30:raise ValueError('缺少运动前静态六轴基线')
    base=np.median(a[pre],axis=0)
    if not .95<np.linalg.norm(base)<1.05 or np.linalg.norm(np.mean(g[pre],axis=0))>math.radians(.5):raise ValueError('静态基线异常')
    m=(t>=start)&(t<=end); mt=(tt>=start)&(tt<=end)
    if m.sum()<100 or mt.sum()<20 or end-start<1.8/f:raise ValueError('稳态数据不足两周期')
    # Fit measured table independently; no alignment by optimizing filter error.
    tc=harmonic(tt[mt],pos[mt],w); ref=float(np.linalg.norm(tc[1:]));
    if ref<=0:raise ValueError('转台实测幅值无效')
    b=block(t[m],a[m],g[m],base,w); gyamp=float(np.ptp(b['theta'])/2*180/math.pi)
    # full-cycle diagnostic fits, not independent tests
    per=[]
    for k in range(int((end-start)*f)):
        cm=(t>=start+k/f)&(t<start+(k+1)/f)
        if cm.sum()<60:continue
        bb=block(t[cm],a[cm],g[cm],base,w); rr,_,obs,_=solve([bb]); per.append([round(float(x)*100,3) if o else None for x,o in zip(rr,obs)])
    coverage=(m.sum()-1)/max(t[m][-1]-t[m][0],1e-6)/float(np.median(arr[m,2]))
    gap=float(np.max(np.diff(t[m]))); tablegap=float(np.max(np.diff(tt[mt])))
    ai=0 if direction=='roll' else 1; axis_match=abs(b['axis'][ai]); issues=[]
    expected_inner=0. if direction=='roll' else 90.
    inner_error=np.max(abs((table[mt,2]-expected_inner+180)%360-180))
    if inner_error>.1:issues.append('稳态内轴未固定在对应0°/90°')
    pre_table=(tt>=-2.5)&(tt<-.1)
    if pre_table.sum()<2 or abs(tc[0]-np.mean(pos[pre_table]))>.1:issues.append('摆动中心与运动前基线不一致或缺失')
    fitpos=tc[0]+tc[1]*np.sin(w*tt[mt])+tc[2]*np.cos(w*tt[mt])
    if np.sqrt(np.mean((pos[mt]-fitpos)**2))>.08:issues.append('转台实测波形偏离正弦模型')
    if coverage<.9 or gap>.05:issues.append('IMU记录覆盖不足90%或间隔>50ms')
    if tablegap>.15:issues.append('转台反馈间隔>150ms（研究门槛，非0.05°验收）')
    if len(per)<2 or any(max(v)-min(v)>6 for j in range(3) if len(v:=[p[j] for p in per if p[j] is not None])>=2):issues.append('逐周期候选杆臂波动>6cm或周期不足')
    if abs(gyamp/ref-1)>.02:issues.append('陀螺角度基波与转台幅值相差>2%')
    if axis_match<.995:issues.append('主运动轴方向不符合已标定P坐标')
    if d.get('stopped_verified') is not True or d.get('motion_period_collected') is not True:issues.append('原报告未确认完整采集与停车')
    if (d.get('analysis',{}).get('clock_diagnostics',{}).get('host_clock_error_p95_abs_s') is None or d.get('analysis',{}).get('clock_diagnostics',{}).get('host_clock_error_p95_abs_s',1)>.02):issues.append('时钟重建差异>20ms或缺失')
    r,rank,obs,_=solve([b]); b.update(name=name,uid=d['uid'],mode=d['calibration_mode'],files=sorted(d['calibration_files']),direction=direction,frequency=f,ref=ref,gyamp=gyamp,coverage=coverage,gap=gap,tablegap=tablegap,issues=issues,per=per,estimate=[round(float(x)*100,4) if o else None for x,o in zip(r,obs)],digest=hashlib.sha256(tb+ib).hexdigest(),all_t=t,all_a=a,all_g=g,all_dev=dev,mask=m,table_t=tt,table_pos=pos,sign=int(plan['sign']))
    return b


def score(b,r):
    # Model-fit score, plus actual causal ACC correction replay (no future samples).
    from .lever3d import RigidLever3D
    from .fusion import Madgwick, Params
    if np.any(abs(r)>.5):return {'score_unavailable':'超出研究范围，不执行补偿回放'}
    cor=RigidLever3D(r); corrected=[]; ready=[]; prev=None
    old=Madgwick(Params()); new=Madgwick(Params()); old_angles=[]; new_angles=[]
    for t,a,g in zip(b['all_dev'],b['all_a'],b['all_g']):
        dt=0 if prev is None else t-prev;prev=t
        dps=np.rad2deg(g); c=cor.update(a,dps,dt); corrected.append(c);ready.append(cor.ready)
        old_angles.append(old.update(a,dps,dt)[b['direction']]);new_angles.append(new.update(c,dps,dt)[b['direction']])
    a=b['all_a'][b['mask']]; c=np.asarray(corrected)[b['mask']]; t=b['t']; w=2*math.pi*b['frequency']; direction=b['direction']
    def tilt(v):return np.rad2deg(np.arctan2(v[:,1],v[:,2]) if direction=='roll' else np.arctan2(-v[:,0],np.hypot(v[:,1],v[:,2])))
    def amp(v):return float(np.linalg.norm(harmonic(t,tilt(v),w)[1:]))
    before=amp(a); after=amp(c); ref=b['ref']; rms=lambda v:float(np.sqrt(np.mean(v*v)))
    # Relative reference diagnostics on common measured brackets <=150ms; no shift.
    tt=b['table_t']; pos=b['table_pos']; pre_t=(tt>=-2.5)&(tt<-.1); pre_i=(b['all_t']>=-2.5)&(b['all_t']<-.1)
    bracket=np.searchsorted(tt,t); ix=np.clip(bracket,1,len(tt)-1); common=(bracket>0)&(bracket<len(tt))&((tt[ix]-tt[ix-1])<=.15)
    metrics={}
    if pre_t.sum()>=2 and pre_i.sum()>=30 and common.sum()>=100:
        refpos=b['sign']*(np.interp(t[common],tt,pos)-np.mean(pos[pre_t]))
        for label,values in [('acc_before',tilt(b['all_a'])),('acc_after',tilt(np.asarray(corrected))),('fusion_before',np.asarray(old_angles)),('fusion_after',np.asarray(new_angles))]:
            e=values[b['mask']][common]-np.mean(values[pre_i])-refpos
            metrics[label+'_relative_rmse_deg']=round(rms(e),6);metrics[label+'_relative_max_deg']=round(float(np.max(abs(e))),6)
        metrics['common_reference_pct']=round(100*np.mean(common),2)
    return {**metrics,'acc_amplitude_before_deg':round(before,5),'acc_amplitude_after_deg':round(after,5),'reference_amplitude_deg':round(ref,5),'amplitude_error_before_deg':round(abs(before-ref),5),'amplitude_error_after_deg':round(abs(after-ref),5),'model_residual_before_g':round(rms(b['y']),7),'model_residual_after_g':round(rms(b['y']-b['M']@r),7),'causal_ready_pct':round(100*np.mean(np.asarray(ready)[b['mask']]),2)}


def identify(train,validation=()):
    tr=[prepare(x) for x in train]; va=[prepare(x) for x in validation]; allb=tr+va
    if len({b['digest'] for b in allb})!=len(allb):raise ValueError('同一原始数据不能重复作为拟合或独立验证')
    if len({(b['uid'],b['mode'],tuple(b['files'])) for b in allb})!=1:raise ValueError('仅允许同UID、同厂标定文件和模式的同一固定装夹数据')
    r,rank,obs,cond=solve(tr); reasons=[]
    if rank!=3 or not np.all(obs):reasons.append('三维不可完整辨识，需ROLL及PITCH不同运动轴')
    if np.any(abs(r)>.5):reasons.append('候选距离超出±50cm研究范围')
    for d in ('roll','pitch'):
        fs={round(b['frequency'],5) for b in tr if b['direction']==d}
        if len(fs)<2:reasons.append(d.upper()+'至少需要两个不同拟合频率')
        if not any(b['direction']==d and round(b['frequency'],5) not in fs for b in va):reasons.append(d.upper()+'缺少不同频率独立验证实验')
    if any(b['issues'] for b in allb):reasons.append('有实验未通过数据质量检查')
    rows=[]
    for b in allb:
        # For rank-deficient data this is explicitly only a minimum-norm candidate; no apply.
        sc=score(b,r)
        role='fit' if any(b is x for x in tr) else 'validation'
        if role=='validation' and ('score_unavailable' in sc or sc['amplitude_error_after_deg']>max(.05,sc['amplitude_error_before_deg']*.9) or sc['model_residual_after_g']>sc['model_residual_before_g']*1.05 or sc['causal_ready_pct']<90 or sc.get('common_reference_pct',0)<90 or sc.get('fusion_after_relative_rmse_deg',float('inf'))>max(.05,sc.get('fusion_before_relative_rmse_deg',0)*1.05)):reasons.append(b['name']+'独立因果补偿验证未通过')
        for j in range(3):
            if b['estimate'][j] is not None and abs(b['estimate'][j]-r[j]*100)>3:reasons.append(b['name']+'单组杆臂与联合拟合差异>3cm');break
        rows.append({'name':b['name'],'role':role,'direction':b['direction'],'frequency_hz':b['frequency'],'single_run_cm':b['estimate'],'cycle_estimates_cm':b['per'],'gyro_amplitude_deg':round(b['gyamp'],5),'coverage_pct':round(b['coverage']*100,2),'max_imu_gap_ms':round(b['gap']*1000,2),'max_table_gap_ms':round(b['tablegap']*1000,2),'issues':b['issues'],**sc})
    return {'kind':'LEVER3D_RESEARCH_PROFILE','uid':tr[0]['uid'],'calibration_mode':tr[0]['mode'],'calibration_files':tr[0]['files'],'rank':rank,'condition':round(cond,4),'candidate_cm':[round(float(x)*100,4) if o else None for x,o in zip(r,obs)],'minimum_norm_cm':[round(float(x)*100,4) for x in r],'eligible_for_session_apply':not reasons,'reasons':list(dict.fromkeys(reasons)),'runs':rows,'note':'仅在固定共同旋转中心、同装夹、同P坐标成立时有效。离线谐波模型与实际因果ACC回放均仅研发；无硬件同步，不是最大绝对误差验收。'}
