"""Rigid-body specific-force correction. Units: g, deg/s, seconds, metres.
Assumes input axes are the calibrated IMU/body axes, accelerometer reports
+1g upward at rest, and r points FROM a fixed axis point TO the sensor.
For a moving pivot, its translational acceleration is NOT observable here.
No encoder, commanded angle, frequency, or amplitude enters this module.
"""
from collections import deque
import math
G0 = 9.80665
RAD = math.pi / 180.0

def cross(a,b):
    return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])

def norm(a):
    return math.sqrt(sum(x*x for x in a))

class RigidLever3D:
    """Causal, binned local-linear rate derivative (no future samples).
    A completed ~20 ms bin suppresses gyro noise without treating a missing
    sample as observed. Derivative is an estimate, with window delay.
    Invalid gaps reset the estimator and mark the correction unavailable.
    """
    def __init__(self, r_m=(0.,0.,0.), window_s=.20, bin_s=.020, max_gap_s=.050):
        self.r=tuple(float(v) for v in r_m)
        if len(self.r)!=3 or not all(math.isfinite(x) for x in self.r) or norm(self.r)>2:
            raise ValueError('rod vector must be finite, in metres, length <=2m')
        self.enabled=norm(self.r)>0
        self.window=max(.12,min(.6,float(window_s)))
        self.bin_s=float(bin_s); self.max_gap=float(max_gap_s)
        self.t=0.;self.bins=deque();self.cur=[];self.start=None
        self.alpha=(0.,0.,0.); self.ready=False;self.gaps=0;self.last_rotation=(0.,0.,0.)
    def reset_window(self):
        self.bins.clear();self.cur=[];self.start=None;self.ready=False;self.alpha=(0.,0.,0.)
    def update(self, a_g, gyro_dps, dt):
        a=tuple(float(x) for x in a_g);w=tuple(float(x)*RAD for x in gyro_dps)
        if len(a)!=3 or len(w)!=3 or not all(math.isfinite(x) for x in a+w):
            raise ValueError('finite 3-axis IMU data required')
        dt=float(dt)
        if not math.isfinite(dt) or dt<0: raise ValueError('invalid sample dt')
        self.t+=dt
        if not self.enabled:
            return a
        if dt>self.max_gap:
            self.gaps+=1;self.reset_window()
        if self.start is None: self.start=self.t
        if self.cur and self.t-self.start>=self.bin_s:
            n=len(self.cur);tm=sum(v[0] for v in self.cur)/n
            avg=tuple(sum(v[1][i] for v in self.cur)/n for i in range(3))
            self.bins.append((tm,avg));self.cur=[];self.start=self.t
        self.cur.append((self.t,w))
        # Only completed bins are used in derivative; never bridge a large gap.
        while self.bins and self.t-self.bins[0][0]>self.window+self.bin_s:
            self.bins.popleft()
        self.ready=False; self.alpha=(0.,0.,0.)
        if len(self.bins)>=4 and self.bins[-1][0]-self.bins[0][0]>=self.window*.5:
            n=len(self.bins);tm=sum(v[0] for v in self.bins)/n
            denom=sum((v[0]-tm)**2 for v in self.bins)
            if denom>1e-9:
                self.alpha=tuple(sum((v[0]-tm)*v[1][i] for v in self.bins)/denom for i in range(3))
                self.ready=all(math.isfinite(x) for x in self.alpha) and norm(self.alpha)<=10.
        if not self.ready:
            self.last_rotation=(0.,0.,0.)
            return a
        tangential=cross(self.alpha,self.r);centripetal=cross(w,cross(w,self.r))
        self.last_rotation=tuple((tangential[i]+centripetal[i])/G0 for i in range(3))
        # f = a_linear - g; the positive-up resting accelerometer convention
        # requires subtracting the rigid-body acceleration, NOT adding it.
        return tuple(a[i]-self.last_rotation[i] for i in range(3))


class Lever3DFusion:
    """Separate research branch; raw input never receives P-frame compensation."""
    def __init__(self,p,calibrated=True):
        from .fusion import Madgwick
        self.corrector=RigidLever3D(tuple(getattr(p,'lever3_'+j+'_cm')*.01 if calibrated else 0. for j in 'xyz'))
        # Keep the applied branch on the same beta as independent offline validation.
        from dataclasses import replace
        self.base=Madgwick(replace(p,beta=.075) if self.corrector.enabled else p)
    def update(self,a,g,dt):
        c=self.corrector.update(a,g,dt)
        out=self.base.update(c,g,dt)
        out.update(lever_compensation_enabled=self.corrector.enabled,lever_compensation_ready=self.corrector.ready,
                   lever_gap_count=self.corrector.gaps,lever_rot_acc_g=list(self.corrector.last_rotation))
        return out

class AdaptiveLever3DFusion(Lever3DFusion):
    """V7.14: same causal physical correction, adaptive Mahony instead of Madgwick.
    Zero vector is exactly ordinary adaptive Mahony. No frequency or reference.
    The geometry is a session-only research candidate until independently validated.
    """
    def __init__(self,p,calibrated=True):
        from .fusion import Mahony
        super().__init__(p,calibrated=calibrated)
        self.base=Mahony(p,True)


class GyroAnchorLever3DFusion(Lever3DFusion):
    """V7.15: causal RigidLever3D followed by gyro-anchor observer.
    Geometry is session-only, no reference, no frequency, no future sample.
    Disable the legacy single-Z correction to prevent double compensation.
    """
    def __init__(self,p,calibrated=True):
        from .gyro_anchor import GyroAnchor
        from dataclasses import replace
        self.corrector=RigidLever3D(tuple(getattr(p,'lever3_'+j+'_cm')*.01 if calibrated else 0. for j in 'xyz'))
        self.base=GyroAnchor(replace(p,lever_z_cm=0.))
