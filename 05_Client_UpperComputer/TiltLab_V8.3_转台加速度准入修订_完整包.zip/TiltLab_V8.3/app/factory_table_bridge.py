"""V7.18: R10 child borrows a guarded command channel, never owns the DLL/COM.
Local authenticated JSON only. No enable, disable, open, close, homing, or
arbitrary DLL dispatch. Software interlocks are not safety-rated hardware.
"""
import ctypes, hmac, json, math, secrets, socket, socketserver, threading

READ_FLOAT={'GetPosition','GetSpeed'}
READ_INT={'GetRunMode','GetAxisEnable','GetAxisFindZero','GetAxisMoveInPlace','GetAxisNormal','GetAxisLock','GetAxisUpLimit','GetAxisDownLimit','GetAxisOverSpeed','GetAxisOverDiff','GetAxisDriverFault','GetAxisOverVoltage'}
MOTION={'SetAxisPosition','SetAxisVelocity'}
# Exact original R10 C model static poses (fit + validation) and gyro orientations.
POSES={0,25,40,45,70,75,90,125,135,140,175,180,220,225,235,250,270,285,310,315}
OUTER_POSES={0,35,45,55,65,90,115,125,135,145,180,215,225,235,245,295,305,315,325}

class FactoryBridge:
    def __init__(self,table,alive,rates):
        self.table=table;self.alive=alive;self.rates=frozenset(float(x) for x in rates);self.revoked=False;self.token=secrets.token_hex(32)
        if not self.rates or not all(math.isfinite(x) and 0<x<=10 for x in self.rates):raise ValueError('R10速率配置无效')
        bridge=self
        class Handler(socketserver.StreamRequestHandler):
            def handle(self):
                self.connection.settimeout(8)
                while True:
                    try:line=self.rfile.readline(8193)
                    except OSError:return
                    if not line or len(line)>8192:return
                    try:
                        msg=json.loads(line)
                        if not hmac.compare_digest(str(msg.get('token','')),bridge.token):return
                        result=bridge.dispatch(msg['name'],msg['args']);out={'ok':True,'value':result}
                    except Exception as exc:out={'ok':False,'error':str(exc)}
                    try:self.wfile.write((json.dumps(out,allow_nan=False)+'\n').encode());self.wfile.flush()
                    except OSError:return
        class Server(socketserver.ThreadingTCPServer):
            daemon_threads=True
        self.server=Server(('127.0.0.1',0),Handler)
        self.thread=threading.Thread(target=self.server.serve_forever,kwargs={'poll_interval':.1},daemon=True);self.thread.start()
    @property
    def endpoint(self):return {'port':self.server.server_address[1],'token':self.token}
    def verify_holding(self):
        if not self.table.connected:raise RuntimeError('转台连接丢失')
        axes=self.table.read_status()['axes']
        if set(axes)!={'0','2'}:raise RuntimeError('双轴反馈不完整')
        for a,s in axes.items():
            if not (s['enabled'] and s['zeroed'] and s['healthy']) or any(s[k] for k in ('driver_fault','upper_limit','lower_limit','over_speed')):
                raise RuntimeError(f'轴{a}使能/机械零点/故障反馈不满足条件')
            if not math.isfinite(s['position_deg']) or not math.isfinite(s['speed_dps']) or abs(s['speed_dps'])>10:
                raise RuntimeError(f'轴{a}速度/位置反馈异常')
            for flag in ('GetAxisOverDiff','GetAxisOverVoltage'):
                if self.table._int(flag,int(a))!=0:raise RuntimeError(f'轴{a} {flag} 异常')
    def dispatch(self,name,args):
        # Read-only, authenticated lease check. Independent of DLL/axis locks.
        # Never refresh the browser lease from the worker itself.
        if name=='FactoryAuthorization' and args==[]:
            return not self.revoked and bool(self.alive())
        if not isinstance(args,list) or not args or type(args[0]) is not int or args[0] not in (0,2):raise ValueError('非法轴号')
        a=args[0]
        with self.table.lock:
            if name in READ_FLOAT|READ_INT and len(args)==1:
                v=self.table._float(name,a) if name in READ_FLOAT else self.table._int(name,a)
                if not math.isfinite(v) or (name in READ_INT-{'GetRunMode'} and v not in (0,1)):raise ValueError('DLL反馈无效')
                return v
            if name=='SetAxisStop' and len(args)==1:
                return self.table._call(name,[ctypes.c_int],ctypes.c_int,a)
            if self.revoked or not self.alive():raise RuntimeError('标定运动授权已撤销')
            if name not in MOTION or len(args)!=3:raise ValueError('标定桥禁止此DLL命令')
            if any(type(v) not in (int,float) or not math.isfinite(v) for v in args[1:]):raise ValueError('运动参数无效')
            x,y=map(float,args[1:]);self.verify_holding()
            if name=='SetAxisPosition' and (x not in (POSES if a==0 else OUTER_POSES) or y!=2.0):raise ValueError('定位参数不属于原R10 C工艺')
            if name=='SetAxisVelocity' and (abs(x) not in self.rates or y!=1.0):raise ValueError('速率参数不属于原R10 C工艺')
            if self.revoked or not self.alive():raise RuntimeError('标定运动授权已撤销')
            v=self.table._call(name,[ctypes.c_int,ctypes.c_double,ctypes.c_double],ctypes.c_int,a,x,y)
            if v!=1:raise RuntimeError('厂家DLL拒绝运动')
            return v
    def revoke(self):
        with self.table.lock:self.revoked=True
    def close(self):
        self.revoke();self.server.shutdown();self.server.server_close()

class FactoryAuthorization:
    """Fail-closed worker lease probe. No shared heartbeat file or disk rename.

    Separate short-lived connection: cannot be blocked by the DLL proxy lock.
    A false response, transport failure or malformed response latches denial.
    The parent's original six-second browser lease is still authoritative.
    """
    def __init__(self,endpoint,interval=.15):
        self.endpoint=endpoint;self.interval=interval;self.last_checked=None;self.denied=False
    def cancelled(self):
        import time
        if self.denied:return True
        now=time.monotonic()
        if self.last_checked is not None and now-self.last_checked<self.interval:return False
        try:
            with socket.create_connection(('127.0.0.1',self.endpoint['port']),timeout=.5) as sock:
                with sock.makefile('rwb') as stream:
                    request={'token':self.endpoint['token'],'name':'FactoryAuthorization','args':[]}
                    stream.write((json.dumps(request)+'\n').encode());stream.flush()
                    raw=stream.readline(8193)
                    response=json.loads(raw)
                    self.denied=not (response.get('ok') is True and response.get('value') is True)
        except (OSError,ValueError,TypeError,KeyError,AttributeError):self.denied=True
        self.last_checked=now
        return self.denied

class _RemoteFunction:
    def __init__(self,client,name):self.client=client;self.name=name;self.argtypes=None;self.restype=None
    def __call__(self,*args):return self.client.call(self.name,args)

class FactoryDLLProxy:
    """R10's existing ctypes wrapper can set argtypes/restype on these stubs."""
    def __init__(self,endpoint):
        self.token=endpoint['token'];self.sock=socket.create_connection(('127.0.0.1',endpoint['port']),timeout=4);self.stream=self.sock.makefile('rwb');self.lock=threading.RLock();self.functions={}
    def __getattr__(self,name):
        if name not in READ_FLOAT|READ_INT|MOTION|{'SetAxisStop'}:raise AttributeError('禁止标定子进程调用 '+name)
        return self.functions.setdefault(name,_RemoteFunction(self,name))
    def call(self,name,args):
        with self.lock:
            self.stream.write((json.dumps({'token':self.token,'name':name,'args':list(args)},allow_nan=False)+'\n').encode());self.stream.flush()
            line=self.stream.readline(8193)
            if not line:raise RuntimeError('转台标定桥已断开')
            data=json.loads(line)
            if not data.get('ok'):raise RuntimeError(data.get('error','转台标定桥拒绝命令'))
            return data['value']
    def close(self):
        try:self.stream.close()
        finally:self.sock.close()
