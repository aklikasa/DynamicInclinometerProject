"""Analysis on real or simulated reference only; metrics absent without reference."""
import math,statistics
from .fusion import FILTERS,Params,create_filter
from .calibration import apply

EXPERIMENTS={
 'static':('静态多角度','9个角度，每点2秒保持',18),
 'step':('阶跃响应','阶跃过程、超调与稳定误差',12),
 'sweep':('正弦扫频','0.13 / 0.28 / 0.50 / 0.85 Hz',32),
 'rotation':('匀速往复','周期性旋转与速度跟踪',16),
 'repeat':('动态重复性','双轴周期往复',16),
 'vibration':('振动抗扰','保持倾角叠加模拟运动加速度',12),
 'hold':('长时稳定性','静止状态与偏置观测（示意30秒）',30),
}

def calculate(values, refs):
    """Reference-based metrics for offline/simulated analysis only.

    Fail closed on invalid inputs instead of presenting NaN or partial data as
    a valid error. P95 uses the linear order-statistic convention used by the
    real-dynamic NumPy report, avoiding a downward step at small sample counts.
    This function is never used to command motion or apply device calibration.
    """
    if values is None or refs is None or len(values)==0 or len(values)!=len(refs):return None
    try:e=[float(v)-float(r) for v,r in zip(values,refs)]
    except (ValueError,TypeError,OverflowError):return None
    if not all(math.isfinite(x) for x in e):return None
    absolute=sorted(abs(x) for x in e)
    rank=.95*(len(absolute)-1)
    lo=int(rank);hi=min(lo+1,len(absolute)-1)
    p95=absolute[lo]+(absolute[hi]-absolute[lo])*(rank-lo)
    bias=statistics.fmean(e)
    return {'n':len(e),'rmse':math.sqrt(statistics.fmean(x*x for x in e)),
            'bias':bias,'std':statistics.pstdev(e),'mae':statistics.fmean(absolute),
            'max':absolute[-1],'p95':p95}

def summarize(rows,kind='live'):
    good=[r for r in rows if isinstance(r.get('ref'),dict)]
    if not good:return None
    out={}
    for axis in ['roll','pitch']:
        values=[r['cal'][axis] for r in good if r.get('cal') and r.get('ref')]
        reference=[r['ref'][axis] for r in good if r.get('cal') and r.get('ref')]
        raw=[r['raw'][axis] for r in good if r.get('cal') and r.get('ref')]
        out[axis]={'compensated':calculate(values,reference),'uncompensated':calculate(raw,reference)}
    return out

def _sine_fit(rows,key,frequency):
    """Least-squares fit v(t)=a sin(wt)+b cos(wt)+c using normal equations."""
    w=2*math.pi*frequency
    sxx=sxy=sxz=syy=syz=szz=sxv=syv=szv=0.
    for row in rows:
        t=row['t'];v=row[key];x=math.sin(w*t);y=math.cos(w*t)
        sxx+=x*x;sxy+=x*y;sxz+=x;syy+=y*y;syz+=y;szz+=1
        sxv+=x*v;syv+=y*v;szv+=v
    A=[[sxx,sxy,sxz,sxv],[sxy,syy,syz,syv],[sxz,syz,szz,szv]]
    for j in range(3):
        pivot=max(range(j,3),key=lambda i:abs(A[i][j]))
        A[j],A[pivot]=A[pivot],A[j]
        if abs(A[j][j])<1e-7:return None
        scale=A[j][j];A[j]=[q/scale for q in A[j]]
        for k in range(3):
            if k==j:continue
            ratio=A[k][j];A[k]=[a-ratio*b for a,b in zip(A[k],A[j])]
    a,b,c=[row[3] for row in A]
    return {'amplitude':math.hypot(a,b),'phase_rad':math.atan2(b,a),'offset':c}

def _sweep_diagnostics(chart):
    result=[]
    for segment,f in enumerate((.13,.28,.5,.85)):
        start=segment*8+1.3; end=segment*8+8
        rows=[r for r in chart if start<=r['t']<end]
        if len(rows)<20:continue
        ref=_sine_fit(rows,'reference',f); cal=_sine_fit(rows,'cal',f); raw=_sine_fit(rows,'raw',f)
        if not ref or not cal or ref['amplitude']<.1:continue
        phase=(cal['phase_rad']-ref['phase_rad']+math.pi)%(2*math.pi)-math.pi
        phase_raw=(raw['phase_rad']-ref['phase_rad']+math.pi)%(2*math.pi)-math.pi if raw else None
        result.append({'frequency_hz':f,'roll_gain':cal['amplitude']/ref['amplitude'],
                       'roll_lag_ms':-phase/(2*math.pi*f)*1000,
                       'raw_gain':raw['amplitude']/ref['amplitude'] if raw else None,
                       'raw_lag_ms':-phase_raw/(2*math.pi*f)*1000 if phase_raw is not None else None,
                       'definition':'sine-wave least-squares amplitude ratio & wrapped phase lag; synthetic fixture'})
    return result

def run_experiment(test_id,params,cal=None,fs=200,algorithms=None):
    """Full offline deterministic experiment. Not a command to physical 2TD600."""
    from .simulation import DemoDevice,DEMO_ACC,DEMO_GYRO
    if test_id not in EXPERIMENTS:raise ValueError('未知实验')
    if fs<50 or fs>1000:raise ValueError('fs 必须50..1000 Hz')
    title,desc,duration=EXPERIMENTS[test_id]
    dev=DemoDevice(mode=test_id,odr=fs)
    # For independent evaluation of all filters, each has two isolated filter states.
    names=algorithms or list(FILTERS)
    engines={n:(create_filter(n,params,calibrated=False),create_filter(n,params,calibrated=True)) for n in names}
    model=cal if cal is not None else {'acc':DEMO_ACC,'gyro':DEMO_GYRO}
    collected={n:{axis:{'cal':[],'raw':[],'ref':[]} for axis in ['roll','pitch']} for n in names}
    chart=[]; sample=[]
    for i in range(duration*fs):
        s=dev.next_batch(1)[0];dt=1/fs
        ca=apply(s['acc'],model['acc']) if model and model.get('acc') else s['acc']
        cg=apply(s['gyro'],model['gyro']) if model and model.get('gyro') else s['gyro']
        chosen=None
        for name,(raw_filter,cal_filter) in engines.items():
            un=raw_filter.update(s['acc'],s['gyro'],dt)
            co=cal_filter.update(ca,cg,dt)
            # Static jump intervals excluded from accuracy estimate; represent settled pose only.
            eligible=(s['t']%2>1.1) if test_id=='static' else s['t']>.8
            if eligible:
                for axis in ['roll','pitch']:
                    buf=collected[name][axis]
                    buf['raw'].append(un[axis]);buf['cal'].append(co[axis]);buf['ref'].append(s['ref'][axis])
            if name==('adaptive' if 'adaptive' in names else names[0]):chosen=(un,co)
        if i%max(1,fs//25)==0:
            un,co=chosen
            chart.append({'t':round(s['t'],3),'reference':s['ref']['roll'],'raw':un['roll'],'cal':co['roll'],
                          'refPitch':s['ref']['pitch'],'rawPitch':un['pitch'],'calPitch':co['pitch']})
        if i%max(1,fs//100)==0:
            un,co=chosen
            sample.append({'t_s':s['t'],'ref_roll_deg':s['ref']['roll'],'ref_pitch_deg':s['ref']['pitch'],
                           'acc_x_g':s['acc'][0],'acc_y_g':s['acc'][1],'acc_z_g':s['acc'][2],
                           'gyro_x_dps':s['gyro'][0],'gyro_y_dps':s['gyro'][1],'gyro_z_dps':s['gyro'][2],
                           'raw_roll_deg':un['roll'],'cal_roll_deg':co['roll'],'raw_pitch_deg':un['pitch'],'cal_pitch_deg':co['pitch']})
    rankings=[]
    for name in names:
        data=collected[name]
        rankings.append({'id':name,'name':FILTERS[name][0],
                         'roll_cal':calculate(data['roll']['cal'],data['roll']['ref']),
                         'roll_raw':calculate(data['roll']['raw'],data['roll']['ref']),
                         'pitch_cal':calculate(data['pitch']['cal'],data['pitch']['ref'])})
    rankings.sort(key=lambda x:x['roll_cal']['rmse'] if x['roll_cal'] else float('inf'))
    return {'id':test_id,'title':title,'description':desc,'duration_s':duration,'fs_hz':fs,
            'mode':'SIMULATED','reference':'ideal synthetic turntable','uid':'DTS672516' if cal is None else 'user-matched',
            'calibration':'SIMULATED_PARAMETERS' if cal is None else 'USER_FILES_ON_SYNTHETIC_INPUT',
            'rankings':rankings,'chart':chart,'samples':sample,
            'frequency_response':_sweep_diagnostics(chart) if test_id=='sweep' else None,
            'metric_definitions':{'rmse':'sqrt(mean((estimate-reference)^2)) [deg]',
                                  'p95':'95th percentile of absolute error [deg]',
                                  'std':'population standard deviation of signed error [deg]'},
            'warning':'软件合成数据，不是PCB实测或真实2TD-600编码器反馈；仅用于验证工作流、滤波计算、报告结构。'}
