"""Research sine admission envelope for the 2TD-600, NOT a safety interlock.

Manufacturer manual JC10468YS reports maximum angular *speed* 60 deg/s,
but states acceleration has no ACCURACY specification: it gives no maximum
permitted acceleration for a given load. Never infer unlimited acceleration.

Two separately labelled evidence paths can replace the conservative software
fallback: a manufacturer rating for the exact setup, or a documented local
commissioning test signed off for the exact serial/load/fixture. Neither
bypasses vendor limit/fault signals, STOP verification or E-stop.

Read configuration ONCE on process startup; never change it during motion.
"""
from __future__ import annotations
import json
import math
from pathlib import Path

PROFILE_PATH=Path(__file__).resolve().parents[1]/'data'/'2td600_motion_envelope.json'
DEFAULT_SPEED=20.0
DEFAULT_ACCEL=40.0
DOCUMENTED_MAX_SPEED=60.0  # JC10468YS, section 3.2(n), both axes


def _nonblank(value, length=3):
    return isinstance(value,str) and len(value.strip())>=length


def _positive_number(value):
    if value is None or isinstance(value,bool):
        raise ValueError('missing numeric value')
    result=float(value)
    if not math.isfinite(result) or result<=0:
        raise ValueError('non-positive or non-finite value')
    return result


def _as_limits(speed,accel,source,kind):
    if speed>DOCUMENTED_MAX_SPEED:
        raise ValueError('configured speed exceeds documented 60 deg/s')
    return {'speed_dps':speed,'accel_dps2':accel,
            'rating_verified':kind=='factory',
            'site_validation_recorded':kind=='site',
            'evidence_type':kind,'source':source}


def rated_sway_limits():
    fallback={'speed_dps':DEFAULT_SPEED,'accel_dps2':DEFAULT_ACCEL,
              'rating_verified':False,'site_validation_recorded':False,
              'evidence_type':'unverified',
              'source':'原软件保守准入（40°/s²不是厂家加速度额定值；本机负载尚无确认记录）'}
    try:
        c=json.loads(PROFILE_PATH.read_text(encoding='utf-8'))
        if c.get('factory_sway_model')!='2TD-600':
            return fallback
        # Original manufacturer-rating format remains backward-compatible.
        if (c.get('factory_sway_rating_verified') is True and
            _nonblank(c.get('factory_sway_serial')) and
            _nonblank(c.get('factory_sway_document'),8)):
            return _as_limits(
                _positive_number(c.get('factory_sway_max_speed_dps')),
                _positive_number(c.get('factory_sway_max_accel_dps2')),
                f"厂家书面额定值：设备 {c['factory_sway_serial']}；{c['factory_sway_document']}",
                'factory')
        # Separate ON-SITE acceptance path when factory does not publish an
        # acceleration number. This is a recorded engineering decision, NOT a
        # manufacturer rating. Requires exact equipment/fixture/load evidence.
        v=c.get('site_sway_validation')
        if not isinstance(v,dict) or v.get('approved') is not True or v.get('risk_acknowledged') is not True:
            return fallback
        if not all((_nonblank(v.get('device_serial')),
                    _nonblank(v.get('fixture_description'),5),
                    _nonblank(v.get('test_record'),8),
                    _nonblank(v.get('approver'),2),
                    _nonblank(v.get('date'),8))):
            return fallback
        load=_positive_number(v.get('load_kg'))
        # Manual section 3.2(b): 20kg inclusive of fixture and test unit.
        if load>20:
            return fallback
        speed=_positive_number(v.get('approved_max_speed_dps'))
        accel=_positive_number(v.get('approved_max_accel_dps2'))
        return _as_limits(speed,accel,
            f"现场工况验证记录（非厂家额定值）：设备 {v['device_serial']}；"
            f"负载及工装 {load:g} kg；{v['test_record']}；批准 {v['approver']}",
            'site')
    except (OSError, ValueError, TypeError, KeyError, OverflowError):
        return fallback
    return fallback


SWAY_LIMITS=rated_sway_limits()


def verify_sway_motion(amp:float, freq:float):
    if not (math.isfinite(amp) and math.isfinite(freq) and amp>0 and freq>0):
        raise ValueError('正弦幅值与频率必须为正的有限数值')
    peak_speed=2*math.pi*amp*freq
    peak_accel=(2*math.pi*freq)**2*amp
    lim=SWAY_LIMITS
    if peak_speed>lim['speed_dps']+1e-9 or peak_accel>lim['accel_dps2']+1e-9:
        raise ValueError(
            f'本工况需要峰速 {peak_speed:.2f}°/s、峰值角加速度 {peak_accel:.2f}°/s²；'
            f'当前软件准入值为 {lim["speed_dps"]:.2f}°/s、{lim["accel_dps2"]:.2f}°/s²。'
            f'依据：{lim["source"]}。'
            '厂家说明书只给出速度范围，未给出负载条件下的最大允许角加速度。'
            '请先获取厂家确认或完成针对本机负载的现场验证留档，再停机修改配置并重启；'
            '不得跳过实体急停、限位、驱动报警和停车反馈。')
    return peak_speed,peak_accel
