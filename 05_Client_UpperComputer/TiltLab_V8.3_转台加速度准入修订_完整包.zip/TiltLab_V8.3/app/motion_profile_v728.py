"""Single source of truth for operator-manual motion limits.

The manufacturer DLL currently exposes limit *flags*, not readable axis travel
endpoints or a maximum-speed getter. Until factory documentation and real
hardware prove a larger envelope, keep the previously tested travel windows.
Factory_verified settings must be edited OFFLINE after documented evaluation.
This is an engineering guard, not a safety-rated function.
"""
from __future__ import annotations
import json
import math
from pathlib import Path

PROFILE_FILE=Path(__file__).resolve().parent.parent/'data'/'2td600_motion_envelope.json'
FALLBACK={
    'axis_0_min_deg':0.0,'axis_0_max_deg':90.0,
    'axis_2_min_deg':-20.0,'axis_2_max_deg':20.0,
    'max_position_speed_dps':10.0,'max_velocity_speed_dps':10.0,
}


def _validated():
    # Do not trust a plain editable file to imply manufacturer approval.
    # If not confirmed, only factory-panel speed=10 is made accessible;
    # the existing research travel windows remain in force.
    try:
        cfg=json.loads(PROFILE_FILE.read_text(encoding='utf-8'))
    except (OSError,ValueError):
        return dict(FALLBACK)
    if cfg.get('factory_travel_confirmed') is not True:
        return dict(FALLBACK)
    try:
        selected={k:float(cfg[k]) for k in FALLBACK}
        if any(not math.isfinite(v) for v in selected.values()):raise ValueError('non finite')
        if not selected['axis_0_min_deg']<selected['axis_0_max_deg']:raise ValueError('axis0 travel')
        if not selected['axis_2_min_deg']<selected['axis_2_max_deg']:raise ValueError('axis2 travel')
        if not (0<selected['max_position_speed_dps'] and 0<selected['max_velocity_speed_dps']):
            raise ValueError('motor speed')
        return selected
    except (KeyError,TypeError,ValueError):
        return dict(FALLBACK)

# Loaded once per server process; changing envelope requires restart.
_PROFILE=_validated()

def position_limits(axis):
    axis=int(axis)
    if axis not in (0,2):raise ValueError('轴号必须为0或2')
    return (_PROFILE[f'axis_{axis}_min_deg'],_PROFILE[f'axis_{axis}_max_deg'])

def position_speed_max():return _PROFILE['max_position_speed_dps']
def velocity_speed_max():return _PROFILE['max_velocity_speed_dps']
