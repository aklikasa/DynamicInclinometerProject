# -*- coding: utf-8 -*-
"""Read-only TiltLab engineering diagnostics. No COM, table, or settings access."""
import argparse,csv,json,math,datetime,hashlib,zipfile,html,re,sys
from pathlib import Path
import numpy as np
AX='xyz'

def readcols(p, wanted):
    with p.open(encoding='utf-8-sig',newline='') as f:
        r=csv.DictReader(f); fields=set(r.fieldnames or []); keys=[k for k in wanted if k in fields]; data={k:[] for k in keys}
        for row in r:
            if None in row or any(row[k] is None for k in keys): raise ValueError(f'CSV有未写完的行: {p.name}。请使用完整副本。')
            for k in keys:
                v=row[k]; data[k].append(float(v) if v and v.lower() not in ('true','false') else (1. if v.lower()=='true' else 0. if v.lower()=='false' else np.nan))
    return {k:np.asarray(v,dtype=float) for k,v in data.items()}

def vec(d,keys):
    if not all(k in d for k in keys):raise ValueError('缺少列: '+str(keys))
    a=np.column_stack([d[k] for k in keys]);
    if len(a)<2 or not np.isfinite(a).all():raise ValueError('数据不足或含非有限值: '+str(keys))
    return a

def stats(v):
    v=np.asarray(v);v=v[np.isfinite(v)]
    if not len(v):return None
    return dict(n=len(v),mean=float(np.mean(v)),std=float(np.std(v)),min=float(np.min(v)),p50=float(np.median(v)),p95=float(np.percentile(v,95)),p99=float(np.percentile(v,99)),max=float(np.max(v)))

def clock(d,k='host_est_ns'):
    if k not in d or not np.isfinite(d[k]).all() or len(d[k])<2:raise ValueError('时间列不完整 '+k)
    t=d[k]/1e9;dt=np.diff(t)
    if np.any(dt<=0):raise ValueError('时间轴非严格递增；不排序、不修补，请保留原始数据排查')
    return t,dict(samples=len(t),span_s=float(t[-1]-t[0]),average_hz=float((len(t)-1)/(t[-1]-t[0])),step_ms=stats(dt*1000),gaps_gt_10ms=int(sum(dt>.010)),gaps_gt_50ms=int(sum(dt>.050)),gaps_gt_400ms=int(sum(dt>.400)))

def timing(d):
    t,out=clock(d);out['time_source']='host_est_ns: PC接收时刻反推，非真实硬件采样时钟';out['hardware_synchronized']=False
    for k in ['processing_age_ms','sample_age_ms','batch_shift_ms','serial_read_ms','imu_dt_s','fusion_dt_s','reported_odr','imu_nominal_odr_hz']:
        if k in d:out[k]=stats(d[k])
    if 'batch_id' in d:
        first=np.r_[True,np.diff(d['batch_id'])!=0];out['batch_count']=int(sum(first));out['batch_samples']=stats(np.diff(np.r_[np.flatnonzero(first),len(t)]));out['batch_id_gaps']=int(np.sum(np.maximum(0,np.diff(d['batch_id'][first])-1)))
        for k in ('device_tick_delta_s','pc_receipt_delta_s'):
            if k in d:out[k+'_per_batch']=stats(d[k][first])
    if 'batch_id' in d and 'device_t_s' in d and 'pc_observed_ns' in d:
        # Last sample in each complete batch carries an extrapolated device timestamp.
        # This measures batch publication cadence, NOT physical sample time.
        ends=np.r_[np.flatnonzero(np.diff(d['batch_id'])!=0),len(t)-1]
        if 'batch_index' in d:ends=ends[d['batch_index'][ends]==15]
        if len(ends)>1:
            dev=np.diff(d['device_t_s'][ends])*1000; pc=np.diff(d['pc_observed_ns'][ends])/1e6
            nominal=d.get('reported_odr',d.get('imu_nominal_odr_hz',np.full(len(t),np.nan)))[ends[1:]]
            valid=(dev>0)&(pc>0)&(np.diff(d['batch_id'][ends])==1)
            ideal=np.divide(16000,nominal,out=np.full(len(nominal),np.nan),where=nominal>0)
            out['batch_clock_diagnostic']={'complete_batch_tail_count':int(len(ends)),'consecutive_valid_pairs':int(valid.sum()),'mcu_batch_interval_ms':stats(dev[valid]),'pc_batch_interval_ms':stats(pc[valid]),'nominal_16_sample_interval_ms':stats(ideal[valid]),'mcu_minus_nominal_ms':stats((dev-ideal)[valid]),'pc_minus_mcu_interval_ms':stats((pc-dev)[valid]),'note':'MCU批尾来源是通信后缓存更新时间反推；统计批次节拍，不是实际采样时间。不能据此恢复丢失样本或判定时钟漂移。'}
    if 'seq' in d:out['seq_gaps']=int(np.sum(np.maximum(0,np.diff(d['seq'])-1)));out['seq_nonincreasing']=int(sum(np.diff(d['seq'])<=0))
    if 'pc_observed_ns' in d:
        obs=d['pc_observed_ns'];out['pc_receipt_minus_est_sample_ms']=stats((obs-d['host_est_ns'])/1e6);out['receipt_batch_interval_ms']=stats(np.diff(obs)[np.diff(obs)>0]/1e6)
    return t,out

def poll_stats(p):
    d=readcols(p,['poll_id','request_pc_ns','received_pc_ns','serial_read_ms','previous_idle_ms','accepted_samples','reported_dropped_batches','ipc_delivery_ms','device_tick_ms'])
    o={k:stats(v) for k,v in d.items() if k not in ('request_pc_ns','received_pc_ns','device_tick_ms','poll_id')}
    if 'accepted_samples' in d:o['empty_polls']=int(sum(d['accepted_samples']==0));o['sum_accepted_samples']=int(np.nansum(d['accepted_samples']))
    if 'reported_dropped_batches' in d:
        v=d['reported_dropped_batches'];v=v[np.isfinite(v)];o['dropped_counter_first_last']=[float(v[0]),float(v[-1])] if len(v) else None
    if 'received_pc_ns' in d:o['receipt_interval_ms']=stats(np.diff(d['received_pc_ns'])/1e6)
    if 'poll_id' in d:o['poll_id_gaps']=int(np.nansum(np.maximum(0,np.diff(d['poll_id'])-1)))
    return o

def static(t,a,g,temp,assumed=True):
    # Caller selects a verified stationary segment. No automatic deletion of samples.
    dur=t[-1]-t[0];x=t-t[0];n=np.linalg.norm(a,axis=1);gn=np.linalg.norm(g,axis=1)
    o={'samples':len(t),'duration_s':float(dur),'operator_assumed_stationary':assumed,'absolute_tilt_accuracy_available':False,'gyro_mean_dps':g.mean(axis=0).tolist(),'gyro_std_dps':g.std(axis=0).tolist(),'acc_mean_g':a.mean(axis=0).tolist(),'acc_std_g':a.std(axis=0).tolist(),'acc_norm_g':stats(n),'gyro_norm_dps':stats(gn),'temperature_c':stats(temp),'warnings':[]}
    if np.max(gn)>1 or np.max(abs(n-1))>.075:o['warnings'].append('存在较大角速度/加速度模长异常：不能确认全程静止；原样保留，不作为静止零偏验收')
    if dur<120:o['warnings'].append('静止时长不足120秒，长期稳定性证据不足')
    o['uncompensated_constant_mean_bias_angle_deg']={str(s): (g.mean(axis=0)*s).tolist() for s in (33.333,75,300)}
    rows=[]
    for s in range(int(dur)):
        i,j=np.searchsorted(x,[s,s+1]);
        if j-i<2:continue
        v=g[i:j];u=a[i:j];mn=u.mean(axis=0);mnn=np.linalg.norm(mn)
        rows.append(dict(second=s,samples=j-i,span_s=float(x[j-1]-x[i]),max_dt_ms=float(np.max(np.diff(x[i:j]))*1000),temp_c=float(np.mean(temp[i:j])) if np.isfinite(temp[i:j]).all() else None,**{f'g{k}_mean_dps':float(v[:,q].mean()) for q,k in enumerate(AX)},**{f'g{k}_std_dps':float(v[:,q].std()) for q,k in enumerate(AX)},**{f'a{k}_mean_g':float(mn[q]) for q,k in enumerate(AX)},acc_roll_deg=float(np.degrees(np.arctan2(mn[1],mn[2]))),acc_pitch_deg=float(np.degrees(np.arctan2(-mn[0],np.hypot(mn[1],mn[2])))),acc_norm_g=float(mnn)))
    o['one_second_bins']=len(rows);o['bias_initialization_holdout']=[]
    if len(rows)>=60:
        first=rows[:30];last=rows[-30:];o['first_last_30s_mean_change_dps']=(np.mean([[r[f'g{k}_mean_dps'] for k in AX] for r in last],axis=0)-np.mean([[r[f'g{k}_mean_dps'] for k in AX] for r in first],axis=0)).tolist()
    good=[r for r in rows if r['temp_c'] is not None and r['max_dt_ms']<=10 and r['span_s']>=.95]
    if len(good)>=60 and np.ptp([r['temp_c'] for r in good])>=.5:
        xx=np.array([r['temp_c'] for r in good]);o['descriptive_gyro_temp_slope_dps_per_c']=[float(np.polyfit(xx,[r[f'g{k}_mean_dps'] for r in good],1)[0]) for k in AX]
    o['temperature_note']='芯片温度；温差不足0.5°C不拟合；单姿态相关性不等于温漂因果。'
    for init in (1,3,10,30,60):
        m=x<init
        if m.sum()<2 or dur<init+33.333:continue
        b=g[m].mean(axis=0);e=[];spans=[]
        # Use only subsequent non-overlapping intervals. Estimated drift proxy, not Euler-angle error.
        for start in np.arange(init,dur-33.333,33.333):
            sel=(x>=start)&(x<=start+33.333);tt=x[sel];gg=g[sel]
            if len(tt)<2 or tt[-1]-tt[0]<33.30 or np.max(np.diff(tt))>.010:continue
            e.append(np.sum((gg[:-1]+gg[1:]-2*b)*.5*np.diff(tt)[:,None],axis=0));spans.append(float(tt[-1]-tt[0]))
        o['bias_initialization_holdout'].append(dict(initial_seconds=init,estimated_bias_dps=b.tolist(),subsequent_33s_windows=len(e),max_abs_integrated_rate_residual_deg=np.max(abs(np.array(e)),axis=0).tolist() if e else None,window_span_s=stats(spans)))
    # Allan-like nonoverlapping block means from complete contiguous 1s bins, not a certified Allan test.
    o['allan_approx_dps']=[];rowmap={r['second']:r for r in rows};fs=(len(t)-1)/dur
    for tau in (1,2,5,10,20,30,60,100):
        blocks=[]
        for start in range(0,int(dur)-tau+1,tau):
            q=[rowmap.get(k) for k in range(start,start+tau)]
            if any(r is None or r['samples']<.85*fs or r['max_dt_ms']>10 or r['span_s']<.95 for r in q):blocks.append(None);continue
            blocks.append(np.mean([[r[f'g{k}_mean_dps'] for k in AX] for r in q],axis=0))
        dif=[b-a for a,b in zip(blocks,blocks[1:]) if a is not None and b is not None]
        if len(dif)>=3:o['allan_approx_dps'].append(dict(tau_s=tau,pairs=len(dif),deviation=np.sqrt(np.mean(np.array(dif)**2,axis=0)/2).tolist()))
    o['allan_note']='基于完整1秒均值的非重叠近似 Allan deviation，非硬件等间隔采样认证；无效块不跨越连接。'
    return o,rows

def reports(p):
    s=p.read_text(encoding='utf-8-sig');r=json.JSONDecoder().raw_decode(s.split('const DATA=',1)[1])[0]['report'] if p.suffix.lower()=='.html' else json.loads(s)
    if 'tests' in r:return [v['report'] for v in r['tests']]
    return [r]

def dynamic(p,r,table):
    plan=r['plan'];direction=plan['output'];sgn=plan['sign'];axis=plan['axis'];
    if direction not in ('roll','pitch') or sgn not in (-1,1):raise ValueError('报告轴/符号无效')
    ac=[f'cal_acc_{k}_g' for k in AX];gy=[f'cal_gyro_{k}_dps' for k in AX];algs=list(dict.fromkeys([r.get('imu_algorithm_at_start','gyro_anchor'),'gyro_anchor','accel']));cols=[f'cal_{k}_{direction}' for k in algs];bias=[f'gyro_anchor_gyro_bias_{k}_dps' for k in AX]
    d=readcols(p,['seq','host_est_ns','pc_observed_ns','temp_c','alignment_active','processing_age_ms','sample_age_ms','batch_shift_ms','serial_read_ms','imu_dt_s','fusion_dt_s','reported_odr','imu_nominal_odr_hz','batch_id','batch_index','device_t_s','device_tick_delta_s','pc_receipt_delta_s','gyro_anchor_bias_ready','gyro_anchor_motion_detected','gyro_anchor_trust',*ac,*gy,*cols,*bias]); t,tm=timing(d);a=vec(d,ac);g=vec(d,gy)
    if 'alignment_active' not in d or np.any(d['alignment_active']!=0):raise ValueError('静态经验对齐开启或不明，不适用无对齐诊断')
    q=readcols(table,['pc_mid_ns',f'axis_{axis}_pos',f'axis_{axis}_speed','read_ms','position_read_ms','poll_lag_ms']);tt,qt=clock(q,'pc_mid_ns');enc=vec(q,[f'axis_{axis}_pos'])[:,0];enc=np.rad2deg(np.unwrap(np.deg2rad(enc)));enc=(enc-360*round(enc[0]/360))*sgn
    start=r['motion_start_pc_monotonic_ns']/1e9;end=r['motion_end_pc_monotonic_ns']/1e9;motion=(t>=start)&(t<=end);pre=(t>=start-2.5)&(t<start-.1)
    j=np.clip(np.searchsorted(tt,t,side='right'),1,len(tt)-1);ok=(t>=tt[0])&(t<=tt[-1])&((tt[j]-tt[j-1])<=.4);ok|=(t==tt[j])|(t==tt[j-1]);ref=np.interp(t,tt,enc);m=motion&ok
    if m.sum()<2:raise ValueError('无参考覆盖')
    o=dict(kind='dynamic',file=p.name,table=table.name,axis=direction,reference_sign=sgn,plan=plan,timing=tm,table_timing=qt,motion_samples=int(motion.sum()),comparable_samples=int(m.sum()),excluded_reference=int(sum(motion&~ok)),certified=False,note='使用host_est_ns直接对比；不平移、不扣零位、不跨>400ms参考缺口；不是硬件同步验收，也不保证与旧报告恢复时间轴完全一致。',temperature_c=stats(d['temp_c'][motion]),acc_norm_g=stats(np.linalg.norm(a[motion],axis=1)),gyro_norm_dps=stats(np.linalg.norm(g[motion],axis=1)),metrics={})
    # Pure gyro increment sensitivity, not a fused attitude or calibrated reference.
    # All branches use the same captured values, no encoder input or timestamp shifting.
    # Restrict to adjacent samples inside the commanded motion interval, never bridge missing rows silently.
    pair=motion[:-1]&motion[1:];v=(g[:-1]+g[1:])*.5
    base=np.diff(t)[pair];vel=v[pair]
    hypotheses={'pc_estimated_dt':base}
    if 'device_t_s' in d:hypotheses['mcu_publication_reconstructed_dt']=np.diff(d['device_t_s'])[pair]
    odr=d.get('imu_nominal_odr_hz',d.get('reported_odr'))
    if odr is not None:
        hz=odr[1:][pair];hypotheses['nominal_dt_ignore_gaps']=np.divide(1.,hz,out=np.full(len(hz),np.nan),where=hz>0)
    integrated=np.cumsum(vel*base[:,None],axis=0) if len(base) else np.empty((0,3))
    sensitivity={'note':'仅三轴角速度增量积分敏感性，不是姿态角或精度评价。MCU和名义时间均非采样真值；不采用其结果改变实时算法。','branches':{}}
    for name,h in hypotheses.items():
        if not len(h) or not np.isfinite(h).all() or np.any(h<=0) or np.any(h>.05):
            sensitivity['branches'][name]={'valid':False,'reason':'时间间隔非正、缺失或存在>50ms缺口'};continue
        z=np.cumsum(vel*h[:,None],axis=0)
        sensitivity['branches'][name]={'valid':True,'duration_s':float(np.sum(h)),'net_axis_increment_deg':z[-1].tolist(),'max_abs_difference_from_pc_increment_deg':np.max(abs(z-integrated),axis=0).tolist()}
    o['gyro_increment_time_sensitivity']=sensitivity
    if pre.sum()>2:
        o['pre_motion_bias_proxy_dps']=g[pre].mean(axis=0).tolist();o['pre_motion_gyro_std_dps']=g[pre].std(axis=0).tolist();o['pre_motion_duration_s']=float(t[pre][-1]-t[pre][0]);o['pre_motion_note']='运动前2.5秒窗口，需确认静止；不是独立零偏标定'
    if all(k in d for k in bias):o['online_bias_dps']={k:stats(d[k][motion]) for k in bias}
    if 'gyro_anchor_motion_detected' in d:o['motion_flag_fraction']=stats(d['gyro_anchor_motion_detected'][motion])
    if 'gyro_anchor_trust' in d:o['gravity_trust']=stats(d['gyro_anchor_trust'][motion])
    qt['poll_lag_ms']=stats(q.get('poll_lag_ms',[]));qt['position_read_ms']=stats(q.get('position_read_ms',[]));qt['read_ms']=stats(q.get('read_ms',[]))
    # Reference interpolation sensitivity, not a claim of true reference error.
    v=2*math.pi*plan['amplitude_deg']*plan['frequency_hz'];o['ideal_sine_time_budget_ms_0p05deg']=.05/v*1000;o['ideal_sine_time_budget_ms_0p01deg']=.01/v*1000
    o['ideal_sine_interp_bound_deg_at_max_gap']=((2*math.pi*plan['frequency_hz'])**2*plan['amplitude_deg'])*(qt['step_ms']['max']/1000)**2/8
    rows=[]
    for alg,col in zip(algs,cols):
        if col not in d:continue
        u=m&np.isfinite(d[col]);idx=np.flatnonzero(u)
        if len(idx)<2:continue
        e=(d[col][u]-ref[u]+180)%360-180;ae=abs(e);worst=idx[np.argmax(ae)];over=ae>.05;sp=np.split(np.arange(len(idx)),np.flatnonzero((np.diff(idx)!=1)|(np.diff(t[idx])>.010))+1);runs=[]
        for seg in sp:
            oo=seg[over[seg]]
            for run in np.split(oo,np.flatnonzero(np.diff(oo)!=1)+1):
                if len(run):runs.append(t[idx[run[-1]]]-t[idx[run[0]]])
        at=(tt>=start)&(tt<=end)&(tt>=t[0])&(tt<=t[-1]);k=np.clip(np.searchsorted(t,tt),1,len(t)-1);at&=(t[k]-t[k-1]<=.010)
        val=np.interp(tt[at],t,d[col]);ee=(val-enc[at]+180)%360-180;ee=ee[np.isfinite(ee)]
        o['metrics'][alg]=dict(samples=len(idx),excluded_output=int(m.sum()-len(idx)),max_abs_deg=float(ae.max()),rmse_deg=float(np.sqrt(np.mean(e**2))),p95_deg=float(np.percentile(ae,95)),signed_mean_deg=float(e.mean()),over_0p05_count=int(sum(over)),over_0p05_pct=float(100*np.mean(over)),longest_contiguous_over_s=float(max(runs,default=0)),peak_time_s=float(t[worst]-start),at_actual_table_samples_count=len(ee),at_actual_table_samples_max_deg=float(max(abs(ee))) if len(ee) else None)
        for c in range(int(plan['cycles'])):
            w=(t[idx]-start>=c/plan['frequency_hz'])&(t[idx]-start<(c+1)/plan['frequency_hz']);
            if w.any():rows.append(dict(algorithm=alg,cycle=c+1,samples=int(sum(w)),max_abs_deg=float(ae[w].max()),over_0p05_pct=float(100*np.mean(over[w]))))
    return o,rows

def writecsv(p,rows):
    if rows:
        with p.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

