"""Pre-sway, gyro-only mounting-axis diagnostic from existing low-speed static moves.

This is deliberately READ ONLY: no new movement, no IMU factory-calibration
changes, no guessed 3-D rotation applied to the fusion state. Uses calibrated
3-axis gyro samples collected during turntable static positioning and measured
stationary baselines. All angles in the factory-calibrated P frame.
"""
from __future__ import annotations
import math
import numpy as np


def diagnose_mount_axis(output, stationary, moving, max_axis_error_deg=2.0):
    """Return a pass/fail mounting-axis direction check; never claim metrology accuracy.

    stationary: each entry {mean:[x,y,z], std:[x,y,z], count:int},
        derived only after verified static table standstill.
    moving: calibrated gyro xyz lists from static repositioning intervals.

    Rotation-vector PCA is sign invariant; the direction and magnitude of
    encoder motion are not needed to identify the shaft orientation. Gyro bias
    is estimated ONLY from known stationary windows, not from moving samples.
    """
    target={'roll':0,'pitch':1}.get(output)
    result={'kind':'PRE_SWAY_MOUNTING_AXIS_CHECK','output':output,
            'expected_gyro_axis':'X' if target==0 else 'Y' if target==1 else None,
            'valid':False,'pass_for_dynamic':False,'correction_applied':False,
            'max_axis_error_deg':float(max_axis_error_deg),
            'note':'静态低速定位的三轴陀螺主方向诊断；与外轴转动方向的符号无关。不替代3D安装标定，也不更改ACC/GYRO厂标定。'}
    if target is None:
        result['reason']='未知倾角方向';return result
    try:
        usable=[]
        for item in stationary:
            m=np.asarray(item.get('mean'),dtype=float)
            s=np.asarray(item.get('std'),dtype=float)
            n=int(item.get('count',0))
            if m.shape==(3,) and s.shape==(3,) and np.isfinite(m).all() and np.isfinite(s).all() and n>=100:
                usable.append((m,s,n))
        if len(usable)<7:
            result['reason']='静止陀螺校准基线不足（至少7个停稳采样点）';return result
        total=sum(n for _,_,n in usable)
        bias=sum(m*n for m,_,n in usable)/total
        noise_sq=sum(n*float(np.sum(s**2)) for _,s,n in usable)/total
        noise_rms=math.sqrt(noise_sq)
        motion=np.asarray(moving,dtype=float)
        if motion.ndim!=2 or motion.shape[1]!=3 or not np.isfinite(motion).all():
            result['reason']='运动三轴陀螺数据格式无效';return result
        if len(motion)<350:
            result['reason']='低速转动样本不足（至少350条）';return result
        residual=motion-bias
        speeds=np.linalg.norm(residual,axis=1)
        threshold=max(.35,5*noise_rms)
        selected=residual[speeds>threshold]
        result.update(stationary_samples=total,motion_samples=int(len(motion)),
                      selected_samples=int(len(selected)),
                      gyro_stationary_bias_dps=[round(float(v),6) for v in bias],
                      gyro_stationary_noise_rms_dps=round(noise_rms,6),
                      movement_threshold_dps=round(threshold,6))
        if len(selected)<250:
            result['reason']='低速运动有效陀螺样本不足；无法可靠识别安装方向';return result
        scatter=selected.T@selected
        vals,vecs=np.linalg.eigh(scatter)
        dominant=int(np.argmax(vals));axis=vecs[:,dominant]
        if axis[target]<0:axis=-axis
        axis/=np.linalg.norm(axis)
        coherence=float(vals[dominant]/np.sum(vals))
        error=math.degrees(math.acos(min(1.,max(0.,abs(float(axis[target]))))))
        other=math.degrees(math.atan2(float(axis[1-target]),float(axis[target])))
        out_of_plane=math.degrees(math.atan2(float(axis[2]),float(np.linalg.norm(axis[:2]))))
        strength=float(np.sqrt(np.mean(speeds[speeds>threshold]**2)))
        result.update(gyro_axis_coherence=round(coherence,7),
                      estimated_shaft_axis_p=[round(float(v),7) for v in axis],
                      misalignment_deg=round(error,5),
                      in_plane_deviation_deg=round(other,5),
                      out_of_plane_deviation_deg=round(out_of_plane,5),
                      moving_gyro_rms_dps=round(strength,5),
                      required_motion_rms_dps=round(max(0.8,8*noise_rms),6),
                      motion_to_noise_ratio=round(strength/noise_rms,5) if noise_rms>0 else None)
        if coherence<.96:
            result['reason']='转轴方向一致性不足；可能是定位采样异常、振动、静止基线不稳定或复杂运动';return result
        if strength<max(0.8,8*noise_rms):
            result['reason']='运动角速度信噪比不足，不能证明装夹对齐';return result
        result['valid']=True
        result['pass_for_dynamic']=error<=max_axis_error_deg
        result['reason']=('安装轴方向预检通过' if result['pass_for_dynamic']
                          else '安装轴偏差超过预检阈值；请检查工装、内轴90°位置和标定坐标映射，禁止自动动态摇摆')
        return result
    except (ValueError,TypeError,ArithmeticError,np.linalg.LinAlgError) as exc:
        result['reason']='安装轴诊断计算失败：'+str(exc)
        return result
