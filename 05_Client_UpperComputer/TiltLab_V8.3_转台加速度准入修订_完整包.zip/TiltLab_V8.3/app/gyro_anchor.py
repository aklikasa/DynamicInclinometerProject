"""V7.8 experimental motion-adaptive gravity/gyro observer.

Causal, IMU-only: no turntable commands/encoder, future samples or post-fit gain.
We do NOT infer that |acc| ~= 1g implies gravity *direction* is correct.
A continuously stationary baseline is necessary for gyro bias initialization.
Frame-end timestamps of the current MCU are estimates, not hardware sample stamps.
"""
from __future__ import annotations
import math
from collections import deque
from .fusion import R, D, norm, cross, gravity_body, initial_q, integrate, clamp, emit


class GyroAnchor:
    """Gyro propagation + guarded gravity correction + robust static bias.

    Design choices:
      * Bootstrap gyro bias from >=0.85s of quiet samples, not a differentiated
        sample-to-sample gyro signal (too noisy at 833Hz).
      * Hold motion state 0.75s after a detected motion; rate-zero turning points
        during sinusoidal oscillation must not be labelled stationary.
      * Use gyro as the short-term propagator while moving, and taper ACC
        correction to a small nonzero gain, not an arbitrary blended angle.
      * Optional lever_z_cm compensation uses a measured offset ONLY; default 0.
      * No angle/gain/clock fit to a turntable reference inside this filter.
    """
    def __init__(self,p):
        self.p=p
        self.q=None
        self.bias=[0.,0.,0.]
        self.bias_ready=False
        self.research_bias_locked=False
        self.static_elapsed=0.
        self.stationary=False
        self.moving=False
        self.motion_hold_s=0.
        self._sum=[0.,0.,0.];self._sum2=[0.,0.,0.]
        self._samples=deque()  # tuples (time, gyro vector) for a quiet interval
        self._clock=0.
        self._gyro_lp=None
        self._last_gyro=None
        self._last_a=None
        self._omega_lp=None
        self._trust=0.
        self._motion_acc_gain=.20
        self._rejected_gaps=0
        self._last_gap_s=0.
        self._acc_direction_error_deg=0.

    def _clear_samples(self):
        self._samples.clear();self._sum=[0.,0.,0.];self._sum2=[0.,0.,0.]

    def _output(self):
        return {**emit(self.q,self._trust),
                'stationary_bias_ready':self.bias_ready,
                'stationary_detected':self.stationary,
                'motion_detected':self.moving,
                'gyro_bias_dps':[round(x,6) for x in self.bias],
                'imu_gaps_over_50ms':self._rejected_gaps,
                'latest_gap_s':round(self._last_gap_s,5),
                'accel_direction_error_deg':round(self._acc_direction_error_deg,4)}

    def _quiet_gate(self,a,g,dt):
        return True

    def _average_rate(self,dt):
        return dt>.003

    def _gravity_trust(self,na,residual,dt):
        magnitude=math.exp(-((na-1.)/max(.03,self.p.acc_threshold))**2)
        moving_factor=self._motion_acc_gain if self.moving else 1.
        innovation=math.exp(-((max(0.,residual-.06)/.23)**2))
        return clamp(magnitude*moving_factor*innovation,0.,1.)

    def update(self,a,g,dt):
        if self.q is None:self.q=initial_q(a)
        if not (math.isfinite(dt) and all(math.isfinite(float(v)) for v in (*a,*g))):
            return self._output()
        if dt<=0:
            self._last_gyro=list(g);self._last_a=list(a)
            return self._output()
        # The MCU may stop sampling between batches. Preserve actual elapsed
        # time as diagnostics; never pretend missing samples were received.
        if dt>.05:
            self._rejected_gaps+=1
            self._last_gap_s=dt
        if dt>.4:
            # No reliable extrapolation over such a stale input period.
            self.motion_hold_s=max(.8,self.motion_hold_s)
            self.stationary=False;self.static_elapsed=0.;self._clear_samples()
            self._last_gyro=list(g);self._last_a=list(a)
            return self._output()
        self._clock+=dt
        n=norm(a)
        # The measured calibrated gyro noise is ~0.1-0.15 dps per axis.
        # Filter rate before motion detection; do NOT differentiate noisy rate.
        k=1-math.exp(-dt/.07)
        if self._gyro_lp is None:self._gyro_lp=list(g)
        else:self._gyro_lp=[v+k*(g[i]-v) for i,v in enumerate(self._gyro_lp)]
        lp_rate=norm(self._gyro_lp)
        # Hysteresis + holdoff rejects sinusoidal angular-rate zero crossings.
        moving_now=(lp_rate>.65 or norm(g)>1.05 or abs(n-1.)>.075)
        self.motion_hold_s=.75 if moving_now else max(0.,self.motion_hold_s-dt)
        self.moving=self.motion_hold_s>0.
        quiet=(not self.moving and lp_rate<.35 and norm(g)<.8
               and .94<n<1.06 and self._quiet_gate(a,g,dt))
        self.stationary=quiet
        if quiet and not self.research_bias_locked:
            self.static_elapsed+=dt
            self._samples.append((self._clock,list(g)))
            for i in range(3):
                self._sum[i]+=g[i];self._sum2[i]+=g[i]*g[i]
            cutoff=self._clock-1.2
            while self._samples and self._samples[0][0]<cutoff:
                _,old=self._samples.popleft()
                for i in range(3):
                    self._sum[i]-=old[i];self._sum2[i]-=old[i]*old[i]
            # Require enough independent readings and sustained physical time.
            if self.static_elapsed>=.85 and len(self._samples)>=35:
                count=len(self._samples)
                mean=[v/count for v in self._sum]
                spreads=[math.sqrt(max(0.,self._sum2[i]/count-mean[i]**2)) for i in range(3)]
                if max(spreads)<.35 and max(abs(x) for x in mean)<.5:
                    if not self.bias_ready:
                        self.bias=mean;self.bias_ready=True
                    else:
                        # Bias can change slowly with temperature, but never
                        # adapt from turning points or verified motion.
                        eta=clamp(dt/.7,0.,.02)
                        self.bias=[(1-eta)*self.bias[i]+eta*mean[i] for i in range(3)]
        else:
            self.static_elapsed=0.;self._clear_samples()

        corrected=[g[i]-self.bias[i] for i in range(3)]
        # Trapezoidal prediction across short nonuniform intervals. It is an
        # approximation, not reconstructed FIFO data, and long gaps remain
        # explicitly flagged in output/CSV.
        rate_to_integrate=corrected
        if self._last_gyro is not None and self._average_rate(dt):
            last_corrected=[self._last_gyro[i]-self.bias[i] for i in range(3)]
            rate_to_integrate=[.5*(corrected[i]+last_corrected[i]) for i in range(3)]
        predicted=integrate(self.q,rate_to_integrate,dt)
        a_gravity=list(a)
        # Optional, conservatively smoothed single-axis lever correction.
        # Units: rad/s, rad/s^2, metres; output is in units of g.
        lever_m=self.p.lever_z_cm*.01
        if abs(lever_m)>1e-10:
            omega=[v*R for v in corrected]
            if self._omega_lp is None:self._omega_lp=omega
            prev=self._omega_lp
            tau=max(.02,self.p.lever_tau_s)
            b=1-math.exp(-dt/tau)
            self._omega_lp=[prev[i]+b*(omega[i]-prev[i]) for i in range(3)]
            # Bound derivative update during missing-data intervals.
            alpha=[clamp((self._omega_lp[i]-prev[i])/max(dt,.001),-5.,5.) for i in range(3)]
            radius=[0.,0.,lever_m]
            tangent=cross(alpha,radius)
            centripetal=cross(self._omega_lp,cross(self._omega_lp,radius))
            a_gravity=[a[i]-(tangent[i]+centripetal[i])/9.80665 for i in range(3)]
        na=norm(a_gravity)
        trust=0.
        if na>.25:
            unit=[v/na for v in a_gravity]
            expected=gravity_body(predicted)
            err=cross(unit,expected)
            residual=clamp(norm(err),0.,1.)
            self._acc_direction_error_deg=math.degrees(math.asin(residual))
            trust=self._gravity_trust(na,residual,dt)
            corr=[corrected[i]+self.p.kp*trust*err[i]*D for i in range(3)]
            # Use same propagation interval and a causal gravity correction.
            # On a gap, never magnify a single unreliable ACC correction.
            corr_dt=min(dt,.035) if dt>.05 else dt
            if corr_dt<dt:
                self.q=integrate(predicted,[self.p.kp*trust*err[i]*D for i in range(3)],corr_dt)
            else:
                self.q=integrate(self.q,[rate_to_integrate[i]+self.p.kp*trust*err[i]*D for i in range(3)],dt)
        else:
            self.q=predicted
        self._trust=trust
        self._last_gyro=list(g);self._last_a=list(a)
        return self._output()


class AdaptiveGravityObserver(GyroAnchor):
    """V7.16 research candidate: causal, geometry-independent six-axis observer.

    Conservative residual-dependent gravity gain during motion. The direction
    residual cannot distinguish arbitrary linear acceleration from tilt error.
    No learned turntable gain, radius, frequency or time advance.
    """
    def __init__(self,p):
        from dataclasses import replace
        super().__init__(replace(p,lever_z_cm=0.,lever3_x_cm=0.,lever3_y_cm=0.,lever3_z_cm=0.))
        self._residual_lp=None
        self._quiet_gravity=None
        self._quiet_ref=None
        self._quiet_time=0.

    def _average_rate(self,dt):
        return True

    def _clear_samples(self):
        super()._clear_samples()
        self._quiet_ref=None;self._quiet_time=0.

    def _quiet_gate(self,a,g,dt):
        n=norm(a)
        unit=[v/n for v in a]
        k=1-math.exp(-dt/.15)
        if self._quiet_gravity is None:self._quiet_gravity=unit
        else:self._quiet_gravity=[v+k*(unit[i]-v) for i,v in enumerate(self._quiet_gravity)]
        if self._quiet_ref is None:self._quiet_ref=list(self._quiet_gravity)
        self._quiet_time+=dt
        # A slow change in gravity over the quiet interval is evidence against rest.
        if norm(cross(self._quiet_ref,self._quiet_gravity))>math.sin(.20*R):
            self._quiet_ref=None;self._quiet_time=0.
            return False
        return True

    def _gravity_trust(self,na,residual,dt):
        if not self.moving:
            self._residual_lp=None
            return super()._gravity_trust(na,residual,dt)
        deg=math.asin(clamp(residual,0.,1.))*D
        k=1-math.exp(-dt/.12)
        if self._residual_lp is None:self._residual_lp=deg
        else:self._residual_lp+=k*(deg-self._residual_lp)
        # Smooth residual-dependent gain, bounded to avoid indefinite free drift.
        # Constants are provisional research settings, not a certified calibration.
        r=max(deg,self._residual_lp)
        gain=.025+.095/(1+(r/.30)**2)
        magnitude=math.exp(-((na-1.)/.035)**2)
        return clamp(gain*magnitude,0.,1.)

    def _output(self):
        out=super()._output()
        out.update(lever_compensation_enabled=False,observer_mode='adaptive_gravity_no_lever',
                   gravity_residual_lp_deg=self._residual_lp)
        return out
