"""Official VQF (Laidig & Seel) 6D wrapper, OPTIONAL research baseline.

Requires the author's compiled PyPI `vqf` package. This file does NOT claim
that a Mahony variant is VQF or copy/modify the VQF source. Reference:
https://github.com/dlaidig/vqf ; https://arxiv.org/abs/2203.17024

Gyr from TiltLab: deg/s; VQF: rad/s. Acc from TiltLab: g;
VQF: m/s^2. No magnetometer: yaw is relative, never absolute.

IMPORTANT: VQF requires an approximately fixed sample period. Firmware's
16-sample bursts are interrupted by real acquisition gaps. We process ONLY
actual samples with the selected nominal ODR (do NOT synthesize missing IMU
samples). During short gaps, gyro-only HOLD predictions approximate elapsed
time; they are explicitly counted as model steps, not observed sensor readings.
Gap statistics are returned for report quality; results across gaps are experimental and NOT a dynamic accuracy certificate.
"""
from __future__ import annotations
import math
import numpy as np
R = math.pi/180.0
D = 180.0/math.pi

def cross(a,b):
    return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]

def clamp(x,lo,hi):
    return max(lo,min(hi,x))

def emit(q,trust):
    w,x,y,z=q
    return {'roll':math.atan2(2*(w*x+y*z),1-2*(x*x+y*y))*D,
            'pitch':math.asin(clamp(2*(w*y-z*x),-1,1))*D,
            'yaw':math.atan2(2*(w*z+x*y),1-2*(y*y+z*z))*D,
            'q':list(q),'trust':round(trust,5)}

try:
    from vqf import VQF as OfficialVQF
except ImportError:
    OfficialVQF = None

VQF_AVAILABLE = OfficialVQF is not None


class VQF6D:
    def __init__(self, p, lever_compensate=False):
        if OfficialVQF is None:
            raise RuntimeError('缺少官方 VQF；请运行 安装依赖.bat 安装 vqf 后重新启动')
        self.p = p
        self.lever_compensate = bool(lever_compensate)
        self.nominal_dt = 1.0 / float(p.vqf_nominal_hz)
        self.core = OfficialVQF(self.nominal_dt)
        self.core.setTauAcc(float(p.vqf_tau_acc_s))
        self.q = [1.0, 0.0, 0.0, 0.0]
        self.gaps = 0
        self.max_gap_s = 0.0
        self.lost_coverage_s = 0.0
        self.last_dt = 0.0
        self.rest = False
        self.bias = [0.0, 0.0, 0.0]
        self.bias_sigma_dps = None
        self._gyro_smoothed = None
        self._last_omega = None
        self.prediction_only_steps = 0
        self.unmodelled_gap_s = 0.0

    def update(self, a, g, dt):
        if not all(math.isfinite(float(v)) for v in (*a, *g)):
            raise ValueError('VQF input must be finite')
        if not (math.isfinite(dt) and dt >= 0):
            raise ValueError('VQF input dt must be non-negative and finite')
        if dt > max(0.012, 5 * self.nominal_dt):
            self.gaps += 1
            self.max_gap_s = max(self.max_gap_s, dt)
            self.lost_coverage_s += max(0.0, dt - self.nominal_dt)
        self.last_dt = dt
        # Data are raw IMU samples; never extrapolate phantom samples across a gap.
        omega = np.asarray(g, dtype=np.float64) * R
        grav = np.asarray(a, dtype=np.float64) * 9.80665
        if self.lever_compensate and self.p.lever_z_cm:
            # Optional *single-axis* physical installation model in P coordinates.
            # r=(0,0,r_z); r is entered from a measured fixture, NOT a sine fit.
            lever = float(self.p.lever_z_cm) * .01
            tau = max(.02, float(self.p.lever_tau_s))
            if self._gyro_smoothed is None:
                self._gyro_smoothed = list(omega)
                alpha = [0.,0.,0.]
            else:
                old = self._gyro_smoothed
                # Large / missing time interval: do not infer angular acceleration.
                if dt > max(.012, 5 * self.nominal_dt):
                    alpha = [0.,0.,0.]
                    self._gyro_smoothed = list(omega)
                else:
                    k = 1 - math.exp(-max(dt, self.nominal_dt)/tau)
                    self._gyro_smoothed = [old[i] + k*(omega[i]-old[i]) for i in range(3)]
                    alpha = [clamp((self._gyro_smoothed[i]-old[i])/max(dt,self.nominal_dt),-8,8) for i in range(3)]
            r = [0.,0.,lever]
            a_rot = cross(alpha,r)
            centripetal = cross(self._gyro_smoothed,cross(self._gyro_smoothed,r))
            grav -= np.asarray([a_rot[i]+centripetal[i] for i in range(3)])
        # VQF's gyro integrator has FIXED gyrTs. If a real FIFO interval is
        # missing, merely running one update per received sample compresses the
        # time axis and destroys oscillation amplitude. Perform explicitly
        # labelled GYRO-ONLY model prediction steps using the *last measured*
        # gyro. These are NOT new sensor samples. Never synthesize ACC values.
        if self._last_omega is not None and dt > 1.5 * self.nominal_dt:
            extrapolate_s = min(max(0.,dt-self.nominal_dt), .10)
            nsteps = min(1000, round(extrapolate_s/self.nominal_dt))
            if nsteps:
                old_rate = np.ascontiguousarray(self._last_omega)
                for _ in range(nsteps):
                    self.core.updateGyr(old_rate)
                self.prediction_only_steps += nsteps
            self.unmodelled_gap_s += max(0.,dt - (1+nsteps)*self.nominal_dt)
        self.core.update(np.ascontiguousarray(omega), np.ascontiguousarray(grav))
        self._last_omega = omega.copy()
        self.q = [float(x) for x in self.core.getQuat6D()]
        self.rest = bool(self.core.getRestDetected())
        bias, sigma = self.core.getBiasEstimate()
        self.bias = [float(v)*D for v in bias]
        self.bias_sigma_dps = float(sigma)*D
        return {**emit(self.q, 1.0 if self.rest else 0.0),
                'trust_available': False,  # not an ACC percentage: internal VQF gain
                'stationary_detected': self.rest,
                'gyro_bias_dps': [round(v,6) for v in self.bias],
                'bias_sigma_dps': round(self.bias_sigma_dps,6),
                'imu_gaps_over_threshold': self.gaps,
                'max_gap_s': round(self.max_gap_s,6),
                'missing_coverage_s': round(self.lost_coverage_s,6),
                'model_prediction_only_steps': self.prediction_only_steps,
                'unmodelled_gap_s': round(self.unmodelled_gap_s,6),
                'timing_warning': self.gaps > 0,
                'vqf_nominal_hz': self.p.vqf_nominal_hz,
                'lever_compensation_enabled': bool(self.lever_compensate and self.p.lever_z_cm)}
