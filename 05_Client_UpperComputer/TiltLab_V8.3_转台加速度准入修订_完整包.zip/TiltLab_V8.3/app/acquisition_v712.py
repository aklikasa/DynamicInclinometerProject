"""Causal batch timing and bounded queues. PC timestamps are estimates, not sample truth."""
import time, csv, json
from pathlib import Path

class BatchClock:
    def __init__(self):
        self.last_ns=None; self.origin=None; self.last_device_end=None; self.previous_receipt=None
        self.batch_id=0; self.repairs=0; self.max_repair_ms=0.; self.long_gaps=0
    def stamp(self,batch,received_ns):
        if not batch:return []
        self.batch_id+=1
        hz=float(batch[-1].get('odr') or 833.)
        step=max(1,round(1e9/hz)); n=len(batch)
        first=received_ns-(n-1)*step
        repair=max(0,(self.last_ns+step-first) if self.last_ns is not None else 0)
        if repair:
            self.repairs+=1;self.max_repair_ms=max(self.max_repair_ms,repair/1e6)
        first+=repair
        if self.last_ns is not None and first-self.last_ns>50_000_000:self.long_gaps+=1
        if self.origin is None:self.origin=first
        dev_end=float(batch[-1]['t']); receipt_delta=(received_ns-self.previous_receipt)/1e9 if self.previous_receipt is not None else None
        tick_delta=dev_end-self.last_device_end if self.last_device_end is not None else None
        rows=[]
        for i,s in enumerate(batch):
            ns=first+i*step
            rows.append(({**s,'device_t_original':float(s['t']),'t':(ns-self.origin)/1e9,
                         'batch_id':self.batch_id,'batch_index':i,'batch_shift_ms':repair/1e6,
                         'device_tick_delta_s':tick_delta,'pc_receipt_delta_s':receipt_delta,
                         'timestamp_quality':'pc_receipt_nominal_odr_estimate_NOT_SYNC'},ns,received_ns))
        self.last_ns=first+(n-1)*step;self.previous_receipt=received_ns;self.last_device_end=dev_end
        return rows

RAW_FIELDS=['batch_id','batch_index','device_t_original','t','host_est_ns','pc_observed_ns','batch_shift_ms','device_tick_delta_s','pc_receipt_delta_s','odr','reported_odr','fifo_state','temp','ax','ay','az','gx','gy','gz']
def raw_row(item):
    s,ns,observed=item
    return {**{k:s.get(k) for k in RAW_FIELDS if k in s},'host_est_ns':ns,'pc_observed_ns':observed,
            **dict(zip(('ax','ay','az'),s['acc'])),**dict(zip(('gx','gy','gz'),s['gyro']))}

# Per-request instrumentation distinguishes host scheduling delay, serial
# transaction time and empty responses. It is not a sample clock measurement.
POLL_FIELDS=['poll_id','request_pc_ns','received_pc_ns','serial_read_ms','previous_idle_ms','accepted_samples','device_tick_ms','fifo_state','reported_dropped_batches','parent_dequeue_pc_ns','ipc_delivery_ms']
RAW_FIELDS += ['request_pc_ns','serial_read_ms','poll_id']

from contextlib import contextmanager
import os
@contextmanager
def windows_timer_resolution():
    """Request 1 ms Windows timer resolution only during serial acquisition.
    Fall back silently on unsupported systems; restore in all exit paths.
    """
    mm=None;started=False
    if os.name=='nt':
        try:
            import ctypes
            mm=ctypes.WinDLL('winmm');started=mm.timeBeginPeriod(1)==0
        except (OSError,AttributeError):pass
    try:yield
    finally:
        if started:mm.timeEndPeriod(1)
