"""R10 calibration loader: strict UID matching and mutually exclusive ambient/thermal modes.

No calibration is ever inferred from temperature values or from an unrelated device.
All transformations are into R10 platform-P frame. Research use only.
"""
import hashlib,json,math,re
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class Cal:
    bias:list
    matrix:list
    path:str

@dataclass(frozen=True)
class ThermalCal:
    bias_coeff:list
    forward_coeff:list
    input_transform:dict
    temperature_range:list
    path:str
    model_id:str


def uid_to_serial(uid:bytes)->str:
    if len(uid)!=12 or uid in (b'\0'*12,b'\xff'*12):
        raise ValueError('UID应为有效的12字节')
    return 'DTS%06d'%(int.from_bytes(hashlib.sha256(uid).digest()[:8],'big')%1000000)

def is_vec(v):return isinstance(v,(list,tuple)) and len(v)==3 and all(_number(x) for x in v)
def _number(x):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)
def is_matrix(m):return isinstance(m,(list,tuple)) and len(m)==3 and all(is_vec(r) for r in m)
def det3(m):return m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])-m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])+m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0])
def matrix_diagnostic(matrix):
    """R10-compatible scale-invariant condition check (not a determinant cutoff)."""
    import numpy as np
    a=np.asarray(matrix,dtype=float)
    if a.shape!=(3,3) or not np.isfinite(a).all():
        raise ValueError('补偿矩阵不是有效的3×3有限实数矩阵')
    singular=np.linalg.svd(a, compute_uv=False)
    scale=float(singular[0]); smallest=float(singular[-1])
    determinant=float(np.linalg.det(a))
    condition=scale/smallest if smallest>0 else float('inf')
    return {'determinant':determinant,'condition':condition,
            'singular_values':singular.tolist(),'scale':scale,
            'rank3':smallest>scale*1e-10 and scale>0}


def validate_matrix(matrix, path=''):
    diagnostic=matrix_diagnostic(matrix)
    label=Path(path).name if path else '标定文件'
    det=diagnostic['determinant']; cond=diagnostic['condition']
    summary=f'{label}: det={det:.6g}, cond={cond:.6g}'
    if not diagnostic['rank3']:
        raise ValueError(f'{summary}；矩阵不可逆（最小奇异值过小），禁止补偿')
    # Follow R10's condition-number limit. Do not reject merely because |det|<.02.
    if cond>100:
        raise ValueError(f'{summary}；矩阵条件数超过R10校验阈值100，禁止补偿')
    return diagnostic


def _get(root,keys):
    for k in keys:
        if k in root and root[k] is not None:return root[k]
    return None

def _identity(data,p):
    meta=data.get('metadata') if isinstance(data.get('metadata'),dict) else {}
    uid=_get(data,['uid_hex','raw_uid_hex','mcu_uid_hex']) or meta.get('uid_hex')
    if uid is not None:
        uid=re.sub('[^0-9a-f]','',str(uid).lower())
        if len(uid)!=24:raise ValueError('UID HEX不是12字节')
    sn=_get(data,['device_serial','device_sn','serial','sn']) or meta.get('device_serial')
    if sn is None:
        match=re.search(r'DTS\d{6}',str(p),re.I)
        sn=match.group(0) if match else None
    if sn is not None:
        sn=str(sn).upper()
        if not re.fullmatch(r'DTS\d{6}',sn):
            raise ValueError('设备编号不是DTS+6位数字')
    if not sn and not uid:raise ValueError('缺少UID/SN，禁止自动匹配')
    return sn,uid

def _fit_model(data,sensor):
    if 'models' in data and isinstance(data['models'],dict):
        c=data['models'].get('C',{})
        if c and isinstance(c,dict):
            if c.get('quality_gate',{}).get('metric_pass') is False:
                raise ValueError('C模型质量门禁未通过')
            return c.get('fit',{})
    return data

def _ambient_from(data,sensor,path):
    fit=_fit_model(data,sensor)
    bias_keys=(['raw_accel_bias_g','raw_bias_g','bias'] if sensor=='acc'
               else ['raw_gyro_bias_dps','raw_bias_dps','bias'])
    b=_get(fit,bias_keys)
    mat=_get(fit,['raw_to_platform_matrix','correction_matrix','matrix'])
    if b is None and mat is None:return None
    if not is_vec(b) or not is_matrix(mat):raise ValueError('常温参数必须是3轴bias和3×3矩阵')
    validate_matrix(mat,path)
    return Cal(list(map(float,b)),[list(map(float,row)) for row in mat],str(path))

def parse_file(path):
    """Parse ONLY ambient R10 outputs; never interpret thermal candidates as ambient."""
    p=Path(path);d=json.loads(p.read_text(encoding='utf-8-sig'))
    if not isinstance(d,dict):raise ValueError('标定JSON必须为对象')
    name=p.name.lower();typ=str(d.get('calibration_type','')).lower()
    if name.startswith('thermal_') or 'thermal' in typ or '温补' in typ:
        raise ValueError('温补研究文件不能作为常温标定')
    if d.get('production_release') is False:
        # R10 research status is not product release; a valid research candidate
        # may still be used for workstation-only preview if it passed validation.
        pass
    gate=d.get('quality_gate',{})
    if isinstance(gate,dict) and gate.get('metric_pass') is False:
        raise ValueError('常温标定未通过独立验证')
    if 'FAIL' in str(d.get('status','')).upper():raise ValueError('常温标定失败状态')
    sn,uid=_identity(d,p)
    acc=gyro=None
    if d.get('combined_calibration'):
        z=d['combined_calibration']
        if isinstance(z,dict):
            acc=_ambient_from(z.get('accelerometer',{}),'acc',p)
            gyro=_ambient_from(z.get('gyroscope',{}),'gyro',p)
    if 'raw_accel_bias_g' in d:acc=_ambient_from(d,'acc',p)
    if 'raw_gyro_bias_dps' in d:gyro=_ambient_from(d,'gyro',p)
    if acc is None and gyro is None:
        subject=str(_get(d,['sensor','calibration_type']) or name).lower()
        if 'gyro' in subject or '陀螺' in subject:gyro=_ambient_from(d,'gyro',p)
        elif 'acc' in subject or '加速度' in subject:acc=_ambient_from(d,'acc',p)
        else:raise ValueError('ACC/GYRO类型不明确')
    if not acc and not gyro:raise ValueError('没有可用的常温补偿矩阵')
    temperature=_get(d,['wk_single_temperature_c','temperature_c'])
    if temperature is None and isinstance(d.get('metadata'),dict):temperature=d['metadata'].get('temperature_c')
    return {'serial':sn,'uid':uid,'acc':acc,'gyro':gyro,'temp':temperature,
            'path':str(p),'mode':'ambient',
            'quality':str(d.get('status') or (gate.get('verdict') if isinstance(gate,dict) else '') or '未提供质量结论'),
            'axis_model':d.get('axis_model'),'gravity_sign':d.get('gravity_sign')}

def _poly_coeff(v,outer):
    if not isinstance(v,list) or len(v)!=outer:raise ValueError('温补系数外层维度错误')
    if outer==3 and all(isinstance(a,list) and len(a)>0 and all(_number(t) for t in a) for a in v):
        n=len(v[0]);
        if any(len(a)!=n for a in v):raise ValueError('温补系数阶数不一致')
        return n
    raise ValueError('温补系数无效')

def parse_thermal(path):
    p=Path(path);d=json.loads(p.read_text(encoding='utf-8-sig'))
    if not isinstance(d,dict):raise ValueError('温补JSON格式错误')
    if p.name.lower() not in ('thermal_acc_selected_candidate.json','thermal_gyro_selected_candidate.json'):
        raise ValueError('只加载R10选中的温补模型，不加载研究候选全集')
    kind='acc' if p.name.lower().startswith('thermal_acc_') else 'gyro'
    if d.get('sensor')!=kind:raise ValueError('温补传感器类型不一致')
    if d.get('selection_status')!='INDEPENDENT_TEMPERATURE_IMPROVEMENT_CONFIRMED_RESEARCH_ONLY':
        raise ValueError('未通过独立温度改善验证，不自动应用')
    if d.get('production_release') is True:raise ValueError('不接受未知的量产释放格式')
    sn,uid=_identity(d,p)
    bc=d.get('bias_coeff');fc=d.get('forward_coeff')
    deg=_poly_coeff(bc,3)
    if not isinstance(fc,list) or len(fc)!=3 or any(not isinstance(row,list) or len(row)!=3 for row in fc):
        raise ValueError('forward_coeff必须是3×3×N')
    if any(not isinstance(v,list) or len(v)!=deg or not all(_number(t) for t in v) for row in fc for v in row):
        raise ValueError('温补矩阵系数阶数与零偏不一致')
    t=d.get('fit_temperature_range_c')
    if not isinstance(t,list) or len(t)!=2 or not all(_number(z) for z in t) or t[0]>=t[1]:
        raise ValueError('温补拟合温度范围不合法')
    transform=d.get('temperature_input')
    if transform is not None and not isinstance(transform,dict):raise ValueError('温度变换必须是对象')
    m=ThermalCal(bc,fc,transform or {'id':'T0'},t,str(p),str(d.get('id','UNKNOWN')))
    # Validate edges and several internal temperatures for matrix invertibility.
    for tt in (t[0],(t[0]+t[1])/2,t[1]):_thermal_matrix(m,tt)
    return {'serial':sn,'uid':uid,kind:m,'temp':t,'path':str(p),'mode':'thermal',
            'quality':d['selection_status'],'axis_model':d.get('axis_model'),'gravity_sign':d.get('gravity_sign')}

def _polynomial(coeff,t):
    x=t-25.
    return sum(c*(x**i) for i,c in enumerate(coeff))

def _effective_temp(transform,chip):
    if not transform or transform.get('id','T0')=='T0':return chip
    if transform.get('id') not in ('T1','T2'):raise ValueError('未知温度映射类型')
    low,high=transform.get('chip_temperature_fit_range_c',[-math.inf,math.inf])
    if not low<=chip<=high:raise ValueError('芯片温度超出温度映射范围')
    coeff=transform.get('coefficients_c')
    if not isinstance(coeff,list) or not coeff or not all(_number(x) for x in coeff):raise ValueError('温度映射系数错误')
    center=transform.get('temperature_center_c',25.);scale=transform.get('temperature_scale_c',50.)
    if not _number(scale) or scale==0:raise ValueError('温度变换尺度异常')
    u=(chip-center)/scale
    return 25.+sum(c*(u**i) for i,c in enumerate(coeff))

def _thermal_matrix(cal,chip):
    if not _number(chip):raise ValueError('温度无效')
    low,high=cal.temperature_range
    if not low<=chip<=high:raise ValueError('温度超出温补有效范围，禁止外推')
    t=_effective_temp(cal.input_transform,chip)
    bias=[_polynomial(v,t) for v in cal.bias_coeff]
    f=[[_polynomial(v,t) for v in row] for row in cal.forward_coeff]
    if not is_matrix(f) or not is_vec(bias) or abs(det3(f))<1e-7:
        raise ValueError('温补矩阵病态或奇异')
    import numpy as np
    if float(np.linalg.cond(np.asarray(f,float)))>100:raise ValueError('温补矩阵条件数过大')
    return bias,f

def apply(v,cal,temperature=None):
    if isinstance(cal,ThermalCal):
        bias,f=_thermal_matrix(cal,temperature)
        import numpy as np
        return np.linalg.solve(np.asarray(f,float),np.asarray(v,float)-np.asarray(bias,float)).tolist()
    b=[v[i]-cal.bias[i] for i in range(3)]
    return [sum(cal.matrix[i][j]*b[j] for j in range(3)) for i in range(3)]

def _matches(m,serial,uid):
    if not serial and not uid:return False
    if m['serial'] is None and m['uid'] is None:return False
    if serial and m['serial'] and m['serial']!=serial:return False
    if uid and m['uid'] and m['uid']!=uid.lower():return False
    # If only UID is known, do not trust a file whose sole identity is a six-digit SN.
    if not serial and m['serial'] and not m['uid']:return False
    # If only serial is known, don't trust a file whose sole identity is UID.
    if not uid and m['uid'] and not m['serial']:return False
    return True

def scan(root,serial=None,uid=None,mode='ambient'):
    if mode not in ('ambient','thermal'):raise ValueError('不支持的标定模式')
    base=Path(root).expanduser().resolve()
    if not base.is_dir():raise ValueError('标定目录不存在')
    paths=list(base.rglob('*.json'))
    if len(paths)>20000:raise ValueError('标定目录JSON过多（最多20000个）')
    issues=[];parsed=0;matched=[];same_device_invalid=[];diagnostics=[]
    for p in paths:
        name=p.name.lower()
        if mode=='ambient' and (name.startswith('thermal_') or 'temperature' in name):continue
        if mode=='thermal' and name not in ('thermal_acc_selected_candidate.json','thermal_gyro_selected_candidate.json'):continue
        try:
            m=parse_file(p) if mode=='ambient' else parse_thermal(p)
            parsed+=1
            if _matches(m,serial,uid):
                matched.append(m)
                for sensor in ('acc','gyro'):
                    cal=m.get(sensor)
                    if isinstance(cal,Cal):
                        diag=matrix_diagnostic(cal.matrix)
                        diagnostics.append({'file':p.name,'sensor':sensor,'status':'valid',
                            'determinant':diag['determinant'],'condition':diag['condition']})
        except (OSError,ValueError,TypeError,KeyError,OverflowError,json.JSONDecodeError) as e:
            # The directory can contain thousands of devices. An unrelated
            # device's broken file must NOT mark the current UID as invalid.
            belongs=False
            if serial and serial.lower() in str(p).lower():
                belongs=True
            if uid and str(uid).lower() in str(p).lower():
                belongs=True
            if not belongs:
                try:
                    data=json.loads(p.read_text(encoding='utf-8-sig'))
                    meta=data.get('metadata',{}) if isinstance(data.get('metadata'),dict) else {}
                    claimed=str(_get(data,['device_serial','device_sn','serial','sn']) or meta.get('device_serial') or '').upper()
                    raw_uid=str(_get(data,['uid_hex','raw_uid_hex','mcu_uid_hex']) or meta.get('uid_hex') or '').lower()
                    belongs=bool((serial and claimed==serial.upper()) or (uid and raw_uid==uid.lower()))
                except (OSError,ValueError,TypeError,AttributeError,json.JSONDecodeError):
                    pass
            if belongs:
                if len(issues)<30:issues.append(f'{p.name}: {str(e)[:250]}')
                if len(diagnostics)<30:diagnostics.append({'file':p.name,'status':'invalid','reason':str(e)[:300]})

    acc=[m['acc'] for m in matched if m.get('acc')]
    gyro=[m['gyro'] for m in matched if m.get('gyro')]
    out={'root':str(base),'mode':mode,'files_scanned':len(paths),'calibrations_parsed':parsed,
         'issues':issues,'matrix_diagnostics':diagnostics,'matched_files':[{'name':Path(m['path']).name,'serial':m['serial'],'uid':m['uid'],
           'has_acc':bool(m.get('acc')),'has_gyro':bool(m.get('gyro')),'quality':m.get('quality'),'mode':m['mode']} for m in matched]}
    if len(acc)!=1 or len(gyro)!=1:
        status='ambiguous' if len(acc)>1 or len(gyro)>1 else ('invalid' if any(x.get('status')=='invalid' for x in diagnostics) else 'missing')
        error_detail=('。文件校验问题：'+issues[0]) if issues else ''
        out.update(status=status,
                   detail=f'未获得唯一有效的{mode} ACC/GYRO配对：ACC {len(acc)}、GYRO {len(gyro)}'+error_detail)
        return out
    # Same reference frame and pose axis convention for both sensors.
    aa=next(m for m in matched if m.get('acc'))
    gg=next(m for m in matched if m.get('gyro'))
    for k in ('axis_model','gravity_sign'):
        if aa.get(k) is not None and gg.get(k) is not None and aa[k]!=gg[k]:
            out.update(status='incompatible',detail=f'ACC/GYRO {k}不一致，拒绝混用');return out
    if (aa.get('uid') and gg.get('uid') and aa['uid']!=gg['uid']) or (aa.get('serial') and gg.get('serial') and aa['serial']!=gg['serial']):
        out.update(status='incompatible',detail='ACC/GYRO所属设备不一致');return out
    out.update(status='matched',acc=acc[0],gyro=gyro[0],files=[acc[0].path,gyro[0].path],
               temperature=aa.get('temp') or gg.get('temp'),
               quality={'acc':aa.get('quality'),'gyro':gg.get('quality')},
               detail=('全温研究候选，已确认独立温度改善；非量产放行' if mode=='thermal' else '常温标定文件已匹配（研发用途）'))
    return out
