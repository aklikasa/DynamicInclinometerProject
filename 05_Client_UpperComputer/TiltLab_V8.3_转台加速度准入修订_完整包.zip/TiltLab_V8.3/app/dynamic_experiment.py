"""Guarded, single-axis REAL 2TD-600 sway experiment.

IMPORTANT: Both hardware clocks and transport delays are not synchronized.
Analysis is RELATIVE TRACKING DIAGNOSTIC, never certified dynamic accuracy.
No implicit homing or enabling. Requires fresh one-time preflight token and on-site
operator acknowledgement. A local hardware emergency stop is indispensable.
"""
from __future__ import annotations
import csv, datetime as dt, json, math, secrets, threading, time
from pathlib import Path
from dataclasses import asdict
import numpy as np
from .fusion import FILTERS
from .angles import angle_delta_deg, zero_distance_deg, unwrap_encoder_deg
from .steady_state import find_sway_steady_start
from .sway_envelope import verify_sway_motion

ALGORITHMS=tuple(FILTERS)
IMU_COLS=(['seq','device_t_s','host_est_ns','pc_observed_ns','uid','temp_c','alignment_active',
          'adaptive_lever_trust','adaptive_lever_beta_eff','adaptive_lever_innovation_gps',
          'adaptive_lever_gyro_bias_x_dps','adaptive_lever_gyro_bias_y_dps','adaptive_lever_gyro_bias_z_dps',
          'fusion_t_s','fusion_dt_s','gap_reset','batch_id','batch_index','batch_shift_ms','reported_odr','processing_age_ms','sample_age_ms','gap_bridge','gap_action','timing_degraded','request_pc_ns','serial_read_ms','poll_id','imu_dt_s','imu_nominal_odr_hz','imu_timestamp_quality','imu_gap_over_50ms',
          'gyro_anchor_trust','gyro_anchor_bias_ready','gyro_anchor_motion_detected',
          'gyro_anchor_gyro_bias_x_dps','gyro_anchor_gyro_bias_y_dps','gyro_anchor_gyro_bias_z_dps',
          'lever3d_ready','lever3d_gap_count','lever3d_rot_acc_x_g','lever3d_rot_acc_y_g','lever3d_rot_acc_z_g',
          'vqf6d_rest_detected','vqf6d_gap_count','vqf6d_max_gap_s',
          'vqf6d_bias_x_dps','vqf6d_bias_y_dps','vqf6d_bias_z_dps']+
          [f'{ch}_{kind}_{axis}_{unit}' for ch in ('raw','cal')
           for kind,unit in (('acc','g'),('gyro','dps')) for axis in 'xyz']+
          [f'{ch}_{algo}_{angle}' for ch in ('raw','cal','cal_factory') for algo in ALGORITHMS for angle in ('roll','pitch')])
TABLE_COLS=['pc_mid_ns','read_ms','axis_0_pos','axis_0_speed','axis_0_mode','axis_2_pos','axis_2_speed','axis_2_mode',
            'status_pc_mid_ns','position_read_ms','poll_lag_ms','feedback_interval_ms','previous_table_csv_write_ms','previous_loop_work_ms']


def limits(amp:float,freq:float,cycles:int):
    if not all(math.isfinite(float(v)) for v in (amp,freq,cycles)):
        raise ValueError('幅度/频率/周期必须是有限数值')
    if not (0.2<=amp<=20.0):raise ValueError('摆幅允许设置为±0.2–20°，必须核对安装/线缆行程')
    if not (.01<=freq<=.80):raise ValueError('频率允许0.01–0.80Hz')
    if type(cycles) is not int or not 2<=cycles<=60:raise ValueError('周期数允许2–60个')
    speed=2*math.pi*amp*freq;accel=(2*math.pi*freq)**2*amp
    # A single verified envelope is enforced again by the vendor-DLL wrapper.
    # Never raise this from an experiment option without local rating evidence.
    verify_sway_motion(amp,freq)
    if not 5<=cycles/freq<=900:raise ValueError('实验运动时长必须在5–900秒之间')
    return {'peak_speed_dps':round(speed,4),'peak_accel_dps2':round(accel,4),'duration_s':round(cycles/freq,2)}


def _ok_axes(st,axis,require_zero=True,inner_target_deg=0):
    axes=st.get('axes') or {}
    if not all(str(a) in axes for a in (0,2)):raise ValueError('转台反馈缺少内轴或外轴')
    for a in (0,2):
        x=axes[str(a)]
        for key in ('position_deg','speed_dps'):
            if not isinstance(x.get(key),(int,float)) or not math.isfinite(x[key]):raise ValueError('转台实际位置/速度反馈异常')
        if not(x.get('enabled') and x.get('zeroed') and x.get('healthy')):
            raise ValueError('转台未使能、未找零或设备健康状态异常；请先在本页执行步骤02“使能并自动回零”，如预检查仍报故障请现场排查')
        if x.get('upper_limit') or x.get('lower_limit') or x.get('driver_fault') or x.get('over_speed'):
            raise ValueError('转台限位、驱动或超速报警；禁止运动')
        if x.get('mode') not in (0,2,20):
            raise ValueError('当前转台不在静止/空闲模式，不能启动新运动')
        if abs(x['speed_dps'])>.06:raise ValueError('转台仍在运动；请先停车并确认')
    if require_zero and (abs(angle_delta_deg(axes['0']['position_deg'],inner_target_deg))>.35 or zero_distance_deg(axes['2']['position_deg'])>.35):
        raise ValueError(f'外轴必须在0°，内轴必须在{inner_target_deg}°（误差≤0.35°）并静止；先执行对应测试方向自动定位')
    return axes


def recover_imu_timebase(imu_rows, reference_start_ns=None, reference_end_ns=None):
    """Choose a strictly increasing *research-only* time axis for comparison.

    Do not accept a host estimate only because its *median* offset is small:
    clock re-anchoring half-way through an experiment can make it jump backwards.
    Original timestamps and input rows remain unchanged, and any recovered
    timeline is explicitly marked as unsynchronized. A small cross-batch PC
    receipt jitter is repaired only within a bounded window; large clock
    inconsistencies are reported as invalid rather than silently hidden.
    """
    host=np.asarray([float(r['host_est_ns'])/1e9 for r in imu_rows],dtype=float)
    info={'time_source':'session_host_estimate','recovered':False,'hardware_synchronized':False,
          'imu_samples':int(len(host))}
    if len(host)<2:
        return host,info
    if not np.isfinite(host).all():
        info['clock_warning']='原始IMU时间戳出现非数值/无穷值'
        return host,info
    host_step=np.diff(host)
    bad_host=host_step<=0
    info['host_nonmonotonic_steps']=int(np.count_nonzero(bad_host))
    info['host_largest_backward_ms']=round(max(0.,-float(np.min(host_step)))*1000,3)
    info['host_large_gaps_over_400ms']=int(np.count_nonzero(host_step>.4))
    if all(r.get('imu_timestamp_quality')=='pc_receipt_nominal_odr_estimate_NOT_SYNC' for r in imu_rows):
        repairs=[float(r.get('batch_shift_ms') or 0) for r in imu_rows]
        info.update(time_source='v712_causal_pc_receipt_estimate',recovered=True,
            pc_batch_max_shift_ms=max(repairs,default=0.),
            clock_warning='实时使用收包时间反推名义ODR；设备原始批尾时间保留，未硬件同步；禁止正式精度验收。')
        return host,info
    if not all('pc_observed_ns' in r and 'device_t_s' in r for r in imu_rows):
        return host,info
    try:
        observed=np.asarray([float(r['pc_observed_ns'])/1e9 for r in imu_rows],dtype=float)
        device=np.asarray([float(r['device_t_s']) for r in imu_rows],dtype=float)
    except (ValueError,TypeError,KeyError):
        info['clock_warning']='FIFO时间字段无法读取，不能建立PC采集时间轴'
        return host,info
    if not (np.isfinite(observed).all() and np.isfinite(device).all()):
        info['clock_warning']='FIFO时间存在非有限数值，不能建立PC采集时间轴'
        return host,info
    device_diff=np.diff(device)
    info['device_nonmonotonic_steps']=int(np.count_nonzero(device_diff<=0))
    info['pc_receipt_backward_steps']=int(np.count_nonzero(np.diff(observed)<0))
    if info['device_nonmonotonic_steps'] or info['pc_receipt_backward_steps']:
        info['clock_warning']='设备采样时钟或PC接收时钟发生倒退，不允许根据异常时间戳生成动态精度'
        return host,info
    # Common reception timestamp indicates members of one FIFO read batch.
    ends=np.r_[np.flatnonzero(np.diff(observed)!=0),len(observed)-1]
    begins=np.r_[0,ends[:-1]+1]
    reconstructed=np.empty_like(host)
    for begin,end in zip(begins,ends):
        reconstructed[begin:end+1]=observed[end]-(device[end]-device[begin:end+1])
    raw_diff=np.diff(reconstructed)
    info['pc_reconstructed_backsteps_before_repair']=int(np.count_nonzero(raw_diff<=0))
    info['pc_reconstructed_largest_backward_ms']=round(max(0.,-float(np.min(raw_diff)))*1000,3)

    # Reception timestamps can jitter between FIFO batches. Do not synthesize
    # additional samples: shift only a whole existing batch so intra-batch
    # device-measured spacing is preserved. Reject >50ms required corrections.
    repair_count=0;max_shift=0.;max_legal_shift=.050
    for begin,end in zip(begins,ends):
        if begin and reconstructed[begin]<=reconstructed[begin-1]:
            # A positive minimum seam separation is based on the real device dt.
            # It cannot make a timestamp *more* accurate, only order the samples.
            min_separation=min(.002,max(.00001,float(device[begin]-device[begin-1])*.25))
            shift=reconstructed[begin-1]+min_separation-reconstructed[begin]
            if shift>max_legal_shift:
                info['pc_reconstruction_invalid_reason']=(
                    f'FIFO批次接收时间重叠{shift*1000:.2f}ms，超过50ms修复边界')
                break
            reconstructed[begin:end+1]+=shift
            repair_count+=1;max_shift=max(max_shift,float(shift))
    pc_monotonic=bool(np.all(np.diff(reconstructed)>0)) and 'pc_reconstruction_invalid_reason' not in info
    info['pc_fifo_batches']=int(len(ends))
    info['pc_batch_seam_repairs']=int(repair_count)
    info['pc_batch_max_shift_ms']=round(max_shift*1000,3)
    info['pc_reconstruction_strictly_monotonic']=pc_monotonic
    offset=host-reconstructed
    drift=float(np.median(offset))
    info['host_clock_error_median_s']=round(drift,6)
    info['host_clock_error_p95_abs_s']=round(float(np.percentile(np.abs(offset),95)),6)
    have_reference=reference_start_ns is not None and reference_end_ns is not None
    if have_reference:
        a,b=reference_start_ns/1e9,reference_end_ns/1e9
        host_overlap=int(np.count_nonzero((host>=a)&(host<=b)))
        pc_overlap=int(np.count_nonzero((reconstructed>=a)&(reconstructed<=b)))
    else:
        host_overlap=pc_overlap=len(host)
    info['host_samples_in_reference_window']=host_overlap
    info['pc_reconstructed_samples_in_reference_window']=pc_overlap
    # A mid-experiment reset is a decisive reason to reject host_est_ns,
    # even if its median error is nearly zero and samples overlap the table.
    host_invalid=bool(np.any(bad_host) or np.any(host_step>.4))
    need_recovery=host_invalid or abs(drift)>.5 or host_overlap<100
    if need_recovery and pc_monotonic and pc_overlap>=100:
        info.update(time_source='pc_fifo_reception_backprojection',recovered=True,
            clock_warning=('IMU原会话时间戳倒退/跳变或与转台时间不匹配；使用FIFO批次PC接收时间重建。'
            '批次间可能存在通信抖动，未硬件同步，不用于正式动态精度验收'))
        return reconstructed,info
    if need_recovery:
        info['clock_warning']=(info.get('pc_reconstruction_invalid_reason') or
            'IMU原时间戳不可用，FIFO重建时间又无法可靠覆盖转台实验窗口；请查看两路原始CSV')
        return host,info
    if repair_count:
        info['clock_warning']='原会话时间轴有效；FIFO接收时刻存在小幅抖动，仅保留诊断，不修改原时间轴'
    return host,info


def imu_sample_quality(imu_rows):
    """Visibility only: do not claim observed timestamp gaps prove FIFO loss."""
    try:
        t=np.asarray([float(r['device_t_s']) for r in imu_rows],dtype=float)
        odrs=np.asarray([float(r.get('imu_nominal_odr_hz') or 0) for r in imu_rows],dtype=float)
    except (ValueError,KeyError,TypeError):
        return {'available':False,'reason':'旧版原始CSV缺少采样时间/ODR信息'}
    if len(t)<2 or not np.isfinite(t).all():return {'available':False,'reason':'IMU时间轴无效'}
    step=np.diff(t)
    backward_or_duplicate=int(np.count_nonzero(step<=0))
    if backward_or_duplicate:
        return {'available':False,'samples':len(t),
                'device_nonmonotonic_steps':backward_or_duplicate,
                'reason':'IMU设备时间戳倒退或重复，不能计算采样率及覆盖率；请核查原始CSV'}
    hz=float(np.median(odrs[(odrs>10)&(odrs<10000)])) if np.any((odrs>10)&(odrs<10000)) else None
    elapsed=float(t[-1]-t[0]);observed=float((len(t)-1)/elapsed) if elapsed>0 else 0
    return {'available':True,'samples':len(t),'reported_odr_hz':round(hz,2) if hz else None,
        'recorded_average_hz':round(observed,2),'time_span_s':round(elapsed,4),
        'batch_seams_over_10ms':int(np.count_nonzero(step>.010)),
        'seams_over_50ms':int(np.count_nonzero(step>.050)),
        'largest_step_ms':round(float(np.max(step))*1000,3),
        'nominal_sample_coverage_pct':round(100*observed/hz,2) if hz else None,
        'warning':'当前固件批尾时间戳可能是在通信后写入；名义ODR与记录覆盖差异仅证明时间/吞吐不一致，不能据此单独证明传感器FIFO丢样。'}


def _diagnostic_preview_for_invalid_steady(table_rows, imu_rows, axis, output, sign,
                                           motion_start_ns, motion_end_ns, steady_info,
                                           original_timeline, clock_info):
    """Plot real recorded data even when no qualified steady interval exists.

    NO numerical accuracy metrics, NO use of commanded sine as reference, NO
    synthesized IMU samples or interpolation across stale table feedback.
    The research comparison gate remains failed and auto continuation blocked.
    """
    reason='未识别到足够的真实转台稳态数据：'+steady_info['reason']
    info={'valid':False,'diagnostic_preview_only':True,
          'reason':reason+'；已保留原始CSV并绘制非验收诊断曲线',
          'reference_steady_state':steady_info,'clock_diagnostics':clock_info,
          'imu_sampling_diagnostics':imu_sample_quality(imu_rows),
          'certified_dynamic_accuracy':False,'comparison':[],
          'quality_warning':'稳态识别失败；曲线只用于判断起振、波形及时间缺口，禁止由此计算或宣称有效精度。',
          'chart':[],'reference_gaps_masked':False,
          'reference_frame':'真实转台位置与IMU运动前零位的相对运动；仅诊断预览',
          'timing_method':'转台PC读取中点＋未硬件同步的IMU估算PC时间'}
    try:
        ts=np.asarray([float(r['pc_mid_ns'])/1e9 for r in table_rows],dtype=float)
        pos=unwrap_encoder_deg([float(r[f'axis_{axis}_pos']) for r in table_rows])
        ix=np.asarray(original_timeline,dtype=float)
        if len(ts)<3 or len(ix)!=len(imu_rows) or not np.isfinite(ts).all() or not np.isfinite(ix).all():
            info['preview_reason']='反馈和IMU时间字段不足，无法叠加两路曲线';return info
        if not (np.all(np.diff(ts)>0) and np.all(np.diff(ix)>0)):
            info['preview_reason']='时间戳非严格递增，已拒绝不可靠的曲线拼接';return info
        gaps=np.diff(ts);maxgap=float(np.max(gaps))
        before=(ts>=motion_start_ns/1e9-2.5)&(ts<motion_start_ns/1e9-.1)
        baseline=float(np.mean(pos[before])) if np.count_nonzero(before)>=2 else float(pos[0])
        info['preview_reference_baseline']='pre_motion_feedback_mean' if np.count_nonzero(before)>=2 else 'first_feedback_sample_fallback'
        info['max_feedback_gap_ms']=round(maxgap*1000,3)
        info['feedback_rate_hz']=round(float((len(ts)-1)/(ts[-1]-ts[0])),2)
        info['reference_quality']={'max_feedback_gap_ms':round(maxgap*1000,3),
            'gaps_over_400ms_total':int(np.count_nonzero(gaps>.4)),
            'raw_feedback_preserved':True,'hardware_synchronized':False,
            'policy':'缺口>400ms不插值；稳态未通过，禁止统计动态RMSE'}
        mask=(ix>=max(ts[0],motion_start_ns/1e9)) & (ix<=min(ts[-1],motion_end_ns/1e9))
        idx=np.flatnonzero(mask)
        if len(idx)<2:
            info['preview_reason']='转台与IMU时间段不重叠，无法绘制叠加曲线';return info
        brackets=np.clip(np.searchsorted(ts,ix[idx],side='right'),1,len(ts)-1)
        fresh=(ts[brackets]-ts[brackets-1])<=.4000000001
        good=idx[fresh]
        info['preview_samples']=int(len(good))
        info['preview_reference_samples_excluded']=int(len(idx)-len(good))
        info['reference_gaps_masked']=bool(np.any(~fresh))
        if not len(good):
            info['preview_reason']='参考反馈缺口过大，所有重叠样本被剔除';return info
        pre=(ix>=max(ix[0],motion_start_ns/1e9-2.5))&(ix<motion_start_ns/1e9-.1)
        vals={}
        for ch in ('cal','raw','cal_factory'):
            for algo in ALGORITHMS:
                key=f'{ch}_{algo}'
                col=f'{key}_{output}'
                try:
                    vector=np.asarray([float(r.get(col)) if r.get(col) not in ('',None) else np.nan for r in imu_rows])
                except (ValueError,TypeError,KeyError):continue
                if np.count_nonzero(np.isfinite(vector[pre]))<15:continue
                vals[key]=vector-float(np.nanmean(vector[pre]))
        stride=max(1,int(math.ceil(len(good)/550)))
        selected=good[::stride]
        previous=None
        for j in selected:
            ti=float(ix[j]);ref=sign*(float(np.interp(ti,ts,pos))-baseline)
            if previous is not None and ti-previous>.4000000001:
                info['chart'].append({'t_s':round((ti+previous)/2-motion_start_ns/1e9,4),
                                      'reference_deg':None,'angles':{},'errors':{},'missing_reference':True})
            ang={};err={}
            for key,v in vals.items():
                z=float(v[j])
                if math.isfinite(z):ang[key]=round(z,6);err[key]=round(z-ref,6)
            info['chart'].append({'t_s':round(ti-motion_start_ns/1e9,4),
                                  'reference_deg':round(ref,6),'angles':ang,'errors':err})
            previous=ti
        info['preview_algorithm_keys']=list(vals)
        return info
    except (TypeError,ValueError,KeyError,IndexError) as exc:
        info['preview_reason']='诊断曲线构建失败：'+str(exc)
        return info


def _analyze_tracking_core(table_rows,imu_rows,axis,output,sign,amp,freq,motion_start_ns,motion_end_ns,gate_algorithm=None):
    """Interpolate PC-timestamped table feedback onto *estimated* IMU host times.
    Both signals are baseline-referenced; no re-time-alignment or fitted offset.
    Returns diagnostic metrics only, not absolute precision or synchronized phase.
    """
    if not table_rows or not imu_rows:return {'valid':False,'reason':'反馈或六轴数据不足'}
    ts=np.asarray([float(r['pc_mid_ns'])/1e9 for r in table_rows]);p=unwrap_encoder_deg([float(r[f'axis_{axis}_pos']) for r in table_rows]);
    ix,clock_info=recover_imu_timebase(imu_rows,int(ts[0]*1e9),int(ts[-1]*1e9));
    # clock interpolation must not extrapolate, and stale segments must be rejected
    table_bad=int(np.count_nonzero(np.diff(ts)<=0))
    imu_bad=int(np.count_nonzero(np.diff(ix)<=0))
    if len(ts)<12 or len(ix)<100 or table_bad or imu_bad or not (np.isfinite(ts).all() and np.isfinite(ix).all()):
        return {'valid':False,
                'reason':(f'时间轴/采样检查未通过：转台{len(ts)}条(异常间隔{table_bad})；'
                          f'IMU{len(ix)}条(异常间隔{imu_bad})；'
                          f'当前使用时间轴{clock_info.get("time_source","未知")}'),
                'clock_diagnostics':clock_info}

    # Reference quality policy: NEVER interpolate across a stale DLL feedback
    # bracket (>400ms). A *single modest* gap may be censored for RESEARCH ONLY,
    # provided stable-motion reference coverage remains >=97% and no stable
    # gap exceeds 750ms. The missing interval is not filled, extrapolated or
    # counted in RMS/P95/max. CSV originals remain unchanged.
    gaps=np.diff(ts);maxgap=float(np.max(gaps))
    pre=(ix>=max(ts[0],motion_start_ns/1e9-2.5))&(ix<motion_start_ns/1e9-.1)
    trpre=(ts>=max(ts[0],motion_start_ns/1e9-2.5))&(ts<motion_start_ns/1e9-.1)
    steady_info=find_sway_steady_start(ts,p,motion_start_ns/1e9,motion_end_ns/1e9,freq,amp)
    if not steady_info['valid']:
        if gate_algorithm is not None:return {'valid':False,'reason':steady_info.get('reason','稳态未通过')}
        return _diagnostic_preview_for_invalid_steady(table_rows,imu_rows,axis,output,sign,
                    motion_start_ns,motion_end_ns,steady_info,ix,clock_info)
    steady_start=float(steady_info['steady_start_s'])
    steady_end=float(steady_info.get('steady_end_s',motion_end_ns/1e9-.3))
    full_mask=(ix>=steady_start)&(ix<=steady_end)&(ix>=ts[0])&(ix<=ts[-1])
    # The bracket width is computed before interpolation so an IMU timestamp
    # that lands inside a missing feedback interval cannot generate false data.
    right=np.clip(np.searchsorted(ts,ix,side='right'),1,len(ts)-1)
    bracket_width=ts[right]-ts[right-1]
    reference_valid=bracket_width<=.4+1e-10
    mask=full_mask & reference_valid
    bad_indices=np.flatnonzero(gaps>.4+1e-10)
    stable_gaps=[]
    for i in bad_indices:
        left=max(float(ts[i]),float(steady_start))
        right_edge=min(float(ts[i+1]),float(steady_end))
        if right_edge>left:
            stable_gaps.append((int(i),float(gaps[i]),right_edge-left))
    missing_seconds=sum(g[2] for g in stable_gaps)
    stable_seconds=max(.001,float(steady_end-steady_start))
    missing_pct=100*missing_seconds/stable_seconds
    q={
       'policy':'研究级：缺口>400ms禁止内插；稳定段单次缺口≤750ms且累计缺失≤3%时可删去缺口区间继续计算',
       'max_feedback_gap_ms':round(maxgap*1000,1),
       'gaps_over_400ms_total':int(len(bad_indices)),
       'gaps_over_400ms_stable':int(len(stable_gaps)),
       'largest_stable_gap_ms':round(max((g[1] for g in stable_gaps),default=0.)*1000,1),
       'stable_missing_reference_s':round(missing_seconds,4),
       'stable_missing_reference_pct':round(missing_pct,3),
       'stable_coverage_pct':round(100-missing_pct,3),
       'imu_stable_samples_excluded':int(np.count_nonzero(full_mask&~reference_valid)),
       'gap_intervals_relative_s':[
           {'start_s':round(float(ts[i]-motion_start_ns/1e9),4),
            'end_s':round(float(ts[i+1]-motion_start_ns/1e9),4),
            'duration_ms':round(width*1000,1)} for i,width,_ in stable_gaps],
       'raw_feedback_preserved':True,'hardware_synchronized':False,
    }
    # This is a GATE for full-interval research quality, not a GATE for
    # showing the measurements.  Do not discard all algorithms' results just
    # because the table has several isolated missing feedback brackets.
    reference_bad=bool(any(width>.750 for _,width,_ in stable_gaps) or missing_pct>3.0)
    reference_bad_reason=('稳定段转台参考缺失严重：最大缺口'
                f'{max((g[1] for g in stable_gaps),default=0):.3f}s，缺失{missing_pct:.2f}%；'
                '整段精度评价无效，原始CSV保留；缺口内数据绝不插值；仅计算剩余真实连续片段的研究性对照') if reference_bad else ''
    qualified_segments=[]
    left=float(steady_start)
    for idx,_,_ in stable_gaps:
        edge=max(left,min(float(ts[idx]),float(steady_end)))
        if edge-left >= max(1.,.7/freq):qualified_segments.append((left,edge))
        left=max(left,float(ts[idx+1]))
    if steady_end-left >= max(1.,.7/freq):qualified_segments.append((left,float(steady_end)))
    segment_mask=np.zeros_like(ix,dtype=bool)
    for first,last in qualified_segments:
        segment_mask |= (ix>=first)&(ix<=last)
    if reference_bad:
        # A fragment narrower than 70% of a measured sway period is unsuitable
        # for phase/gain/RMSE comparisons.  The plot can still show these points.
        metric_mask=mask & segment_mask
        q['research_contiguous_segments_s']=[[round(a-motion_start_ns/1e9,3),round(b-motion_start_ns/1e9,3)] for a,b in qualified_segments]
        q['research_metric_samples']=int(np.count_nonzero(metric_mask))
    else:
        metric_mask=mask
    if np.count_nonzero(pre)<20 or np.count_nonzero(trpre)<2 or np.count_nonzero(metric_mask)<100:
        if gate_algorithm is not None:return {'valid':False,'reason':'连续片段/基线不足','reference_quality':q}
        return _diagnostic_preview_for_invalid_steady(table_rows,imu_rows,axis,output,sign,
                    motion_start_ns,motion_end_ns,steady_info,ix,clock_info) | {
                   'reason':'连续片段/基线不足，无法安全计算相对误差；保留实际曲线',
                   'reference_quality':q}
    base_pos=float(np.mean(p[trpre]));t=ix[metric_mask];ref=sign*(np.interp(t,ts,p)-base_pos)
    table_tmask=(ts>=steady_start)&(ts<=steady_end)
    if np.count_nonzero(table_tmask)<12:return {'valid':False,'reason':'稳定运动段转台反馈过少'}
    ref_amp=(np.percentile(p[table_tmask],95)-np.percentile(p[table_tmask],5))/2
    if ref_amp<amp*.65 or ref_amp>amp*1.4:return {'valid':False,'reason':f'实际转台摆幅约{ref_amp:.3f}°，与指令±{amp}°不符'}
    if gate_algorithm is not None:
        # Use actual captured calibrated realtime output only. No replay, plots or fitting.
        if gate_algorithm=='__capture_only__':
            # Offline mode: check actual calibrated six-axis samples and table
            # reference quality; never require an angle that was not computed.
            required=['cal_acc_'+a+'_g' for a in 'xyz']+['cal_gyro_'+a+'_dps' for a in 'xyz']
            if all(k in imu_rows[0] for k in required):
                good=np.asarray([all(r.get(k) not in ('',None) and math.isfinite(float(r[k])) for k in required) for r in imu_rows],dtype=bool)
                valid=not reference_bad and int(np.count_nonzero(good[pre]))>=20 and int(np.count_nonzero(good[metric_mask]))>=100
                return {'valid':bool(valid),'reason':'原始六轴、校正六轴及转台参考采集质量通过，角度待停车后回放（非精度验收）' if valid else (reference_bad_reason or '离线采集数据不完整'),
                        'calibrated_samples':int(np.count_nonzero(good)),'gate_mode':'offline_six_axis_only','reference_quality':q}
            # Historical V7.24 test fixtures (and already archived captures) had
            # only a selected calibrated angle and no six-axis columns. This is
            # compatibility for report recovery, never used by V8.2 new captures.
            legacy_col=f'cal_{result_algo}_{output}' if (result_algo:=next((c[len('cal_'):-len('_'+output)] for c in imu_rows[0] if c.startswith('cal_') and c.endswith('_'+output)),None)) else None
            if legacy_col:
                legacy=np.asarray([float(r[legacy_col]) if r.get(legacy_col) not in ('',None) else np.nan for r in imu_rows])
                valid=not reference_bad and np.isfinite(legacy[pre]).sum()>=20 and np.isfinite(legacy[metric_mask]).sum()>=100
                return {'valid':bool(valid),'reason':'历史角度记录参考质量已核对（不是V8.2离线原始六轴采集）',
                        'gate_mode':'legacy_angle_recovery','reference_quality':q}
            return {'valid':False,'reason':'离线采集缺少校正六轴数据','gate_mode':'offline_missing_calibrated_six_axis','reference_quality':q}
        col=f'cal_{gate_algorithm}_{output}'
        vals=np.asarray([float(r[col]) if r.get(col) not in ('',None) else np.nan for r in imu_rows])
        valid=not reference_bad and np.count_nonzero(np.isfinite(vals[pre]))>=20 and np.count_nonzero(np.isfinite(vals[metric_mask]))>=100
        return {'valid':bool(valid),'reason':'采集质量门禁通过（非精度验收）' if valid else (reference_bad_reason or '实时融合数据不足'),'reference_quality':q}
    ranking=[]
    compare_channels=('cal','raw')+ (('cal_factory',) if any(str(r.get('alignment_active','')).lower() in ('1','true') for r in imu_rows) else ())
    for ch in compare_channels:
        for algo in ALGORITHMS:
            col=f'{ch}_{algo}_{output}'
            vals=np.asarray([float(r.get(col)) if r.get(col) not in (None,'') else np.nan for r in imu_rows])
            baseline=vals[pre];meas=vals[metric_mask]
            if np.count_nonzero(np.isfinite(baseline))<20 or np.count_nonzero(np.isfinite(meas))<100:continue
            y=meas-np.nanmean(baseline);valid=np.isfinite(y)&np.isfinite(ref)
            if np.count_nonzero(valid)<100:continue
            err=y[valid]-ref[valid]
            rms=float(np.sqrt(np.mean(err**2))); mx=float(np.max(np.abs(err)))
            # phase/gain are only diagnostic because hardware time bases aren't synchronized.
            x=t[valid]-motion_start_ns/1e9;om=2*math.pi*freq
            X=np.column_stack((np.sin(om*x),np.cos(om*x),np.ones(len(x))))
            a=np.linalg.lstsq(X,y[valid],rcond=None)[0];b=np.linalg.lstsq(X,ref[valid],rcond=None)[0]
            gain=float(np.hypot(a[0],a[1])/max(1e-9,np.hypot(b[0],b[1])))
            phase=(math.atan2(b[1],b[0])-math.atan2(a[1],a[0])+math.pi)%(2*math.pi)-math.pi
            ranking.append({'channel':ch,'algorithm':algo,'samples':int(np.count_nonzero(valid)),
                'relative_tracking_rmse_deg':round(rms,6),'relative_max_error_deg':round(mx,6),
                'relative_p95_error_deg':round(float(np.percentile(np.abs(err),95)),6),
                'amplitude_ratio':round(gain,5),'apparent_phase_lag_ms':round(phase/om*1000,2)})
    ranking.sort(key=lambda x:x['relative_tracking_rmse_deg'])
    # Plot the same clock-aligned, baseline-referenced samples for EVERY method.
    # The reference series is the real turntable's reported angle, not the commanded sinusoid.
    # No temporal smoothing, alignment shift, or synthetic IMU samples are introduced.
    stride=max(1,int(math.ceil(len(t)/550)))
    indices=np.arange(0,len(t),stride,dtype=int)
    chart=[]
    measured={}
    for ch in compare_channels:
        for algo in ALGORITHMS:
            key=f'{ch}_{algo}'
            col=f'{key}_{output}'
            all_values=np.asarray([float(r.get(col)) if r.get(col) not in ('',None) else np.nan for r in imu_rows])
            base=all_values[pre]
            if np.count_nonzero(np.isfinite(base))<20:continue
            measured[key]=all_values[metric_mask]-float(np.nanmean(base))
    for k,j in enumerate(indices):
        # Blank row splits the rendered polyline across a reference gap; do not
        # imply a measured continuous path through the missing interval.
        if k and float(t[j]-t[indices[k-1]])>.4:
            chart.append({'t_s':round(float((t[j]+t[indices[k-1]])/2-motion_start_ns/1e9),4),
                          'reference_deg':None,'angles':{},'errors':{},'missing_reference':True})
        row={'t_s':round(float(t[j]-motion_start_ns/1e9),4),
             'reference_deg':round(float(ref[j]),6), 'angles':{},'errors':{}}
        for key,curve in measured.items():
            y=float(curve[j])
            if math.isfinite(y):
                row['angles'][key]=round(y,6)
                row['errors'][key]=round(y-float(ref[j]),6)
        chart.append(row)
    return {'valid':bool(ranking) and not reference_bad,
        'diagnostic_preview_only':bool(reference_bad),
        'partial_research_only':bool(reference_bad and ranking),
        'analysis_metrics_scope':('qualified_continuous_fragments_only' if reference_bad else 'measured_sine_full_cycles_only'),
        'reason':reference_bad_reason if reference_bad else '转台和IMU未进行硬件时钟同步，仅可比较相对跟踪',
        'reference_amplitude_est_deg':round(float(ref_amp),5),
        'feedback_rate_hz':round((len(ts)-1)/(ts[-1]-ts[0]),2),
        'max_feedback_gap_ms':round(maxgap*1000,1),
        'reference_quality':q,
        'reference_steady_state':steady_info,
        'reference_gaps_masked':bool(stable_gaps),
        'quality_warning':(reference_bad_reason if reference_bad else 
                          '已排除参考缺口内的IMU样本：只代表剩余可比较时段的研究性RMSE；不能将其作为完整试验或±0.1°精度验收' if stable_gaps else ''),
        'imu_rate_hz_approx':round(len(ix)/(ix[-1]-ix[0]),1),
        'imu_sampling_diagnostics':imu_sample_quality(imu_rows),
        'comparison':ranking,'chart':chart,
        'plotted_algorithms':list(ALGORITHMS),
        'reference_frame':'相对运动增量：试验开始前静止均值作零位；不等于绝对倾角精度',
        'channels_explained':{'cal':'厂标定后＋可选本次静态对齐','cal_factory':'仅厂标定，不含本次静态对齐','raw':'原始六轴融合，未厂标定'},
        'timing_method':('PC转台DLL读取中点 + 基于每批FIFO接收时间反推样本时刻' if clock_info.get('recovered') else 'PC转台DLL读取中点 + 原IMU会话估算主机时刻'),
        'clock_diagnostics':clock_info,
        'certified_dynamic_accuracy':False,
        'hardware_sync_note':'转台与IMU硬件时钟及固定传输延迟尚未标定，禁止用本结果宣称±0.1°精度'}


def analyze_axis_alignment(imu_rows, output, minimum_samples=100):
    """Estimate the physical outer-axis direction in IMU coordinates from gyro data.

    The gyro vector is expressed in the sensor frame. During the outer-axis sway,
    its dominant direction is the actual rotation axis. We compare that direction
    with the fixture's expected IMU X (Roll / inner 0°) or Y (Pitch / inner 90°).
    This is an installation diagnostic, not an absolute-angle accuracy test.
    """
    import numpy as np
    target = 'x' if output == 'roll' else 'y' if output == 'pitch' else None
    if target is None:
        return {'valid': False, 'reason': '输出通道不是Roll或Pitch，无法确定目标IMU轴'}
    if len(imu_rows) < minimum_samples:
        return {'valid': False, 'reason': f'IMU样本不足：至少需要{minimum_samples}条'}

    def vector(row, prefix):
        vals=[]
        for axis in 'xyz':
            value=row.get(f'{prefix}_{axis}_dps')
            try:
                value=float(value)
            except (TypeError,ValueError):
                return None
            if not math.isfinite(value):
                return None
            vals.append(value)
        return vals

    # Prefer calibrated gyro, but fall back to raw only when corrected vector
    # fields are absent. Do not mix channels within a single estimate.
    cal_vectors=[vector(row,'cal_gyro') for row in imu_rows]
    if sum(v is not None for v in cal_vectors) >= max(minimum_samples, int(.8*len(imu_rows))):
        channel='calibrated_gyro'
        vectors=cal_vectors
    else:
        channel='raw_gyro'
        vectors=[vector(row,'raw_gyro') for row in imu_rows]
    valid_indices=[i for i,v in enumerate(vectors) if v is not None]
    if len(valid_indices)<minimum_samples:
        return {'valid':False,'reason':'原始CSV没有完整三轴陀螺仪数据；请使用新版重新采集',
                'target_sensor_axis':target.upper(),'channel':channel}

    # Device timestamps identify the initial stationary baseline. The physical
    # sway command is issued after a 2 s baseline in DynamicExperiment._run.
    device_times=[]
    for row in imu_rows:
        try: device_times.append(float(row.get('device_t_s')))
        except (TypeError,ValueError): device_times.append(float('nan'))
    device_times=np.asarray(device_times,dtype=float)
    have_time=np.isfinite(device_times).all() and len(device_times)>1 and np.all(np.diff(device_times)>0)
    if have_time:
        t0=float(device_times[0])
        baseline_mask=device_times <= t0+1.5
        motion_mask=device_times >= t0+2.15
    else:
        # Legacy CSVs may lack a monotonic device clock. Use row order only as a
        # conservative fallback; this remains an estimate, not a synced clock.
        n=len(imu_rows)
        baseline_mask=np.arange(n)<max(20,int(.12*n))
        motion_mask=np.arange(n)>=max(30,int(.20*n))

    arr=np.asarray([v if v is not None else [np.nan]*3 for v in vectors],dtype=float)
    baseline=arr[baseline_mask & np.isfinite(arr).all(axis=1)]
    moving=arr[motion_mask & np.isfinite(arr).all(axis=1)]
    if len(baseline)<20 or len(moving)<minimum_samples:
        return {'valid':False,'reason':f'基线/运动陀螺样本不足：基线{len(baseline)}条，运动{len(moving)}条',
                'target_sensor_axis':target.upper(),'channel':channel}

    bias=np.median(baseline,axis=0)
    residual=moving-bias
    baseline_residual=np.linalg.norm(baseline-bias,axis=1)
    noise_med=float(np.median(baseline_residual))
    noise_mad=float(np.median(np.abs(baseline_residual-noise_med)))
    threshold=max(.08, noise_med+6*1.4826*noise_mad)
    speeds=np.linalg.norm(residual,axis=1)
    selected=residual[speeds>=threshold]
    if len(selected)<minimum_samples:
        return {'valid':False,'reason':f'有效转动陀螺样本不足：{len(selected)}条（阈值{threshold:.3f}°/s）',
                'target_sensor_axis':target.upper(),'channel':channel,
                'gyro_threshold_dps':round(threshold,4),'baseline_bias_dps':[round(float(x),6) for x in bias]}

    # PCA on the uncentered angular-rate vectors is intentional: sinusoidal
    # reversals cancel the mean, while their common rotation axis remains the
    # principal eigenvector of G^T G.
    scatter=selected.T @ selected
    eigenvalues,eigenvectors=np.linalg.eigh(scatter)
    order=np.argsort(eigenvalues)[::-1]
    eigenvalues=eigenvalues[order]
    axis_vec=eigenvectors[:,order[0]]
    target_index='xyz'.index(target)
    if axis_vec[target_index] < 0:
        axis_vec=-axis_vec
    axis_vec=axis_vec/(np.linalg.norm(axis_vec)+1e-15)
    dot=float(np.clip(axis_vec[target_index],-1,1))
    misalignment=math.degrees(math.acos(abs(dot)))
    x,y,z=[float(v) for v in axis_vec]
    if target=='x':
        signed_xy=math.degrees(math.atan2(y,x))
    else:
        signed_xy=math.degrees(math.atan2(x,y))
    out_of_plane=math.degrees(math.atan2(z,math.hypot(x,y)))
    projection=selected @ axis_vec
    perpendicular=selected-np.outer(projection,axis_vec)
    residual_ratio=float(np.sqrt(np.sum(perpendicular**2)/max(np.sum(projection**2),1e-15)))
    coherence=float(eigenvalues[0]/max(np.sum(eigenvalues),1e-15))
    gyro_rms=float(np.sqrt(np.mean(np.sum(selected**2,axis=1))))
    # Sign convention is tied to the selected target axis. It tells which IMU
    # cross-axis component the measured shaft leans toward; it does not command
    # a motor correction because the fixture's positive inner-angle convention
    # must first be confirmed physically.
    if target=='x':
        lean='IMU +Y' if signed_xy>0 else 'IMU -Y'
    else:
        lean='IMU +X' if signed_xy>0 else 'IMU -X'
    if abs(out_of_plane)>=1.0:
        lean += ('，并偏向IMU +Z' if out_of_plane>0 else '，并偏向IMU -Z')
    if misalignment<1.0:
        interpretation='估计方向接近目标轴；该数值仅为本次装夹/运动下的研究诊断'
    elif misalignment<3.0:
        interpretation='存在小幅轴向偏差；建议检查内轴定位角和传感器装夹'
    else:
        interpretation='轴向偏差较明显；建议先复核装夹、坐标映射和内轴零位，再比较动态精度'
    return {
        'valid':True,
        'method':'三轴陀螺仪角速度向量主方向（PCA）',
        'channel':channel,
        'target_sensor_axis':target.upper(),
        'estimated_outer_axis_sensor':[round(x,7),round(y,7),round(z,7)],
        'misalignment_deg':round(misalignment,5),
        'signed_xy_deviation_deg':round(signed_xy,5),
        'out_of_plane_deg':round(out_of_plane,5),
        'lean_direction':lean,
        'gyro_axis_coherence':round(coherence,6),
        'cross_axis_ratio_pct':round(residual_ratio*100,3),
        'gyro_rms_dps':round(gyro_rms,5),
        'gyro_threshold_dps':round(threshold,5),
        'baseline_bias_dps':[round(float(v),6) for v in bias],
        'sample_count':int(len(selected)),
        'interpretation':interpretation,
        'adjustment_note':'仅给出IMU坐标系中的偏差方向，不自动修正内轴；内轴正方向与传感器坐标的关系须现场小角度核验。',
        'qualification':'研究级安装对齐诊断，不是转台角度精度验收'
    }


def analyze_time_shift(table_rows,imu_rows,axis,output,sign,amp,freq,motion_start_ns,motion_end_ns):
    """Research-only common lag estimate (60% fit, 40% holdout).

    This does NOT correct the officially displayed RMSE, does not certify time
    synchronization, and cannot separate true sensor filter phase from
    transport latency. Use actual table feedback, never a synthesized sine.
    """
    info={'available':False,'method':'common reference timeline shift, fit 60% / validate 40%',
          'correction_applied_to_official_rmse':False,'hardware_synchronized':False,
          'search_ms':[-250,250],'step_ms':2,
          'note':'参考角时间平移是诊断性曲线拟合，不能把较小的拟合RMSE当作设备真实动态精度；可吸收滤波响应的相位延迟。'}
    if len(table_rows)<25 or len(imu_rows)<300:return info
    try:
        ts=np.array([float(x['pc_mid_ns'])/1e9 for x in table_rows]);
        pos=unwrap_encoder_deg([float(x[f'axis_{axis}_pos']) for x in table_rows]);
        times,clk=recover_imu_timebase(imu_rows,int(ts[0]*1e9),int(ts[-1]*1e9))
        col=f'cal_accel_{output}'
        measure=np.array([float(x.get(col)) if x.get(col) not in (None,'') else np.nan for x in imu_rows])
    except (ValueError,KeyError,TypeError):return info
    if (not np.all(np.diff(ts)>0) or not np.all(np.diff(times)>0) or not np.all(np.isfinite(pos))):return info
    start=motion_start_ns/1e9;end=motion_end_ns/1e9
    pre=(times>=max(ts[0],start-2.5))&(times<start-.1)
    table_pre=(ts>=max(ts[0],start-2.5))&(ts<start-.1)
    use=(times>=start+1/freq)&(times<=end-.3)&(times>=ts[0]+.30)&(times<=ts[-1]-.30)
    if np.count_nonzero(pre & np.isfinite(measure))<30 or np.count_nonzero(table_pre)<2 or np.count_nonzero(use & np.isfinite(measure))<300:return info
    base=float(np.nanmean(measure[pre]));base_pos=float(np.mean(pos[table_pre]))
    t=times[use&np.isfinite(measure)];y=measure[use&np.isfinite(measure)]-base
    # Fixed temporal split, no leakage from the holdout into time-lag fitting.
    split=int(.6*len(t));train=np.arange(0,split,max(1,split//1600));test=np.arange(split,len(t),max(1,(len(t)-split)//1400))
    candidates=np.arange(-.250,.2501,.002);loss=[]
    for shift in candidates:
        x=t[train]+shift
        valid=(x>=ts[0])&(x<=ts[-1])
        if np.count_nonzero(valid)<100:loss.append(np.inf);continue
        r=sign*(np.interp(x[valid],ts,pos)-base_pos)
        loss.append(float(np.mean((y[train][valid]-r)**2)))
    index=int(np.argmin(loss));best=float(candidates[index])
    if not np.isfinite(loss[index]):return info
    x=t[test]+best;valid=(x>=ts[0])&(x<=ts[-1])
    if np.count_nonzero(valid)<100:return info
    before=sign*(np.interp(t[test][valid],ts,pos)-base_pos)
    after=sign*(np.interp(x[valid],ts,pos)-base_pos)
    raw_rmse=float(np.sqrt(np.mean((y[test][valid]-before)**2)))
    shifted_rmse=float(np.sqrt(np.mean((y[test][valid]-after)**2)))
    info.update(available=True,fit_channel=col,shift_reference_by_ms=round(best*1000,2),
                test_raw_rmse_deg=round(raw_rmse,6),test_shifted_rmse_deg=round(shifted_rmse,6),
                test_samples=int(np.count_nonzero(valid)),
                training_fit_rmse_deg=round(float(np.sqrt(loss[index])),6),
                at_search_boundary=abs(best)>.245,time_source=clk.get('time_source'))
    return info


def analyze_tracking(table_rows,imu_rows,axis,output,sign,amp,freq,motion_start_ns,motion_end_ns):
    """Tracking metrics plus a separate gyro-vector installation-alignment diagnostic."""
    result=_analyze_tracking_core(table_rows,imu_rows,axis,output,sign,amp,freq,motion_start_ns,motion_end_ns)
    from .absolute_accuracy import absolute_metrics
    try:
        result['absolute_accuracy']=absolute_metrics(table_rows,imu_rows,axis,output,sign,motion_start_ns,motion_end_ns,result,ALGORITHMS,recover_imu_timebase)
    except (ValueError,TypeError,KeyError,IndexError,ArithmeticError) as exc:
        result['absolute_accuracy']={'available':False,'reason':str(exc),'certified_dynamic_accuracy':False}
    result['axis_alignment']=analyze_axis_alignment(imu_rows,output)
    from .dynamic_diagnostics import diagnose_dynamic_components
    result['root_cause_diagnostics']=diagnose_dynamic_components(
        table_rows,imu_rows,result,axis,output,sign,amp,freq,motion_start_ns,motion_end_ns)
    result['time_shift_diagnostics']=(
        {'available':False,'reason':'参考反馈有>400ms缺口，已关闭时差拟合，避免缺口附近产生虚假拟合结果'}
        if (result.get('reference_quality') or {}).get('gaps_over_400ms_total',0)>0 else
        analyze_time_shift(table_rows,imu_rows,axis,output,sign,amp,freq,motion_start_ns,motion_end_ns)
        if result.get('valid') else {'available':False,'reason':'原始数据未通过有效性检查'})
    if result.get('valid') and result['time_shift_diagnostics'].get('available'):
        diag=result['time_shift_diagnostics'];shift=diag['shift_reference_by_ms']/1000
        # Chart-only diagnostics: all algorithms share the SAME shift and
        # the original errors and RMSE are never overwritten.
        try:
            ts=np.asarray([float(x['pc_mid_ns'])/1e9 for x in table_rows]);pos=unwrap_encoder_deg([float(x[f'axis_{axis}_pos']) for x in table_rows])
            baseline_mask=(ts>=max(ts[0],motion_start_ns/1e9-2.5))&(ts<motion_start_ns/1e9-.1)
            baseline=float(np.mean(pos[baseline_mask]))
            for row in result.get('chart',[]):
                current=motion_start_ns/1e9+float(row['t_s'])
                absolute=current+shift
                if ts[0]<=absolute<=ts[-1]:
                    corrected_ref=sign*(np.interp(absolute,ts,pos)-baseline)
                    row['diagnostic_shifted_errors']={k:round(float(v)-corrected_ref,6) for k,v in row['angles'].items()}
        except (KeyError,ValueError):pass
    return result

class DynamicExperiment:
    def __init__(self,table,engine,reports_dir:Path):
        self.table=table;self.engine=engine;self.dir=Path(reports_dir)
        self.lock=threading.RLock();self.thread=None;self.cancel_event=threading.Event();self.token=None;self.token_until=0;self.heartbeat_ns=0
        self.running=False;self.state='idle';self.error='';self.report_file=None;self.table_file=None;self.imu_file=None;self.table_count=0;self.imu_count=0
        self.deferred_reports=[];self.pending_report_file=None;self.plan=None;self.uid=None;self.finished=False;self.stopped_verified=None;self.started_ns=None;self.latest_feedback=None;self.native_feedback=None
    def status(self):
        with self.lock:return {'running':self.running,'state':self.state,'error':self.error,'uid':self.uid,
            'plan':self.plan,'table_samples':self.table_count,'imu_samples':self.imu_count,
            'report_file':self.report_file,'pending_report_file':self.pending_report_file,'table_file':self.table_file,'imu_file':self.imu_file,
            'stopped_verified':self.stopped_verified,'latest_feedback':self.latest_feedback,
            'timing_warning':'只具备PC时间戳，尚不支持绝对动态精度验收'}
    def _preconditions(self,axis,inner_target_deg=0):
        e=self.engine
        if not (e.running and e.connected and e.source=='serial' and e.latest):raise ValueError('请先连接并实时采集真实RS485倾角仪')
        if not(e.cal_status=='matched' and e.cal_mode in ('ambient','thermal') and e.cal and ((e.latest.get('acc_cal') is not None and e.latest.get('gyro_cal') is not None) or (getattr(e,'pipeline_mode','realtime')=='realtime' and e.latest.get('cal') is not None))):
            raise ValueError('请先确认当前PCB的常温或全温标定文件完整且已实际应用')
        if time.time()-e.last_wall>.75:raise ValueError('IMU数据已停止更新')
        if e.stability and e.stability.state=='running':raise ValueError('请先结束静态稳定性实验')
        if not self.table.connected:raise ValueError('请先连接真实2TD-600')
        return _ok_axes(self.table.read_status(),axis,inner_target_deg=inner_target_deg)
    def preflight(self,axis:int,output:str,sign:int,amplitude_deg:float,frequency_hz:float,cycles:int,mounting_mode:str='x_outer',fixture_confirmed:bool=False):
        if axis not in (0,2) or output not in ('roll','pitch') or sign not in (-1,1):raise ValueError('运动轴、输出轴或方向无效')
        # In the actual U-T installation the IMU Z-axis is parallel to inner
        # shaft 0, X parallel to outer shaft 2 at inner=0°. Rotating inner 90°
        # aligns IMU Y to the same outer shaft, without refixturing.
        if axis != 2:raise ValueError('动态摆动只能使用外轴2；内轴0仅负责0°/90°测试方向定位')
        if mounting_mode == 'x_outer' and output == 'roll':inner_target=0
        elif mounting_mode == 'y_inner_90' and output == 'pitch' and fixture_confirmed:inner_target=90
        else:raise ValueError('Pitch必须将内轴定位90°并确认其运动路径；Roll需要内轴0°')
        metrics=limits(amplitude_deg,frequency_hz,cycles)
        with self.lock:
            if self.running:raise ValueError('动态实验正在运行')
            axes=self._preconditions(axis,inner_target)
            self.plan={'axis':axis,'output':output,'sign':sign,'amplitude_deg':amplitude_deg,
                'frequency_hz':frequency_hz,'cycles':cycles,'mounting_mode':mounting_mode,
                'fixture_confirmed':bool(fixture_confirmed),'inner_target_deg':inner_target,**metrics,
                'initial_position_deg':axes[str(axis)]['position_deg']}
            self.uid=self.engine.uid
            self.token=secrets.token_urlsafe(24);self.token_until=time.monotonic()+30
            return {'ready':True,'token':self.token,'expires_in_s':30,'plan':self.plan,'uid':self.uid,
                'safety':'须现场确认已锁紧工装、独立硬件急停可用、轴向映射及运行空间无干涉；本软件不是安全控制器'}
    def start(self,token,acknowledged:bool,defer_report=False):
        if acknowledged is not True:raise ValueError('必须由现场操作员确认全部安全条件')
        with self.lock:
            if self.running:raise ValueError('实验正在运行')
            if not token or token!=self.token or time.monotonic()>=self.token_until:raise ValueError('安全预检查已过期，请重新检查')
            self.token=None
            plan=self.plan.copy();self._preconditions(plan['axis'],plan.get('inner_target_deg',0))
            if self.engine.uid!=self.uid:raise ValueError('设备UID已变化，请重新检查')
            if abs(angle_delta_deg(self.table.read_status()['axes'][str(plan['axis'])]['position_deg'],plan['initial_position_deg']))>.15:raise ValueError('预检查后转台位置发生变化')
            self.dir.mkdir(parents=True,exist_ok=True)
            self.cancel_event.clear();self.running=True;self.state='baseline';self.error='';self.finished=False
            self.stopped_verified=None;self.table_count=0;self.imu_count=0;self.started_ns=time.monotonic_ns();self.heartbeat_ns=self.started_ns
            self.report_file=self.table_file=self.imu_file=None;self.pending_report_file=None;self.latest_feedback=None
            self.thread=threading.Thread(target=self._run,args=(plan,bool(defer_report)),daemon=True,name='2TD600-dynamic-experiment')
            self.thread.start()
            return self.status()
    def heartbeat(self):
        with self.lock:
            if not self.running:raise ValueError('没有运行中的实验')
            self.heartbeat_ns=time.monotonic_ns()
        return {'ok':True}
    def abort(self):
        self.cancel_event.set()
        if self.table.connected:
            self.table.stop()  # immediate STOP request. Physical E-stop is independent.
        return self.status()
    def _watch(self,uid,params,axis,initial_other_pos,plan=None):
        if self.cancel_event.is_set():raise RuntimeError('操作员已请求停止')
        if time.monotonic_ns()-self.heartbeat_ns>6_000_000_000:raise RuntimeError('浏览器控制心跳超过6秒未更新，自动停车')
        e=self.engine
        health=e.link_watchdog_status() if hasattr(e,'link_watchdog_status') else {}
        stale=any(health.get(k) is not None and health[k]>700 for k in ('child_receipt_age_ms','fusion_receipt_age_ms'))
        if not(e.running and e.connected and e.source=='serial') or e.uid!=uid or time.time()-e.last_wall>.7 or stale or health.get('pipeline_error'):
            from .table_diagnostics import DIAG
            DIAG.record('imu_watchdog_failure','原始收包/融合数据新鲜度不合格；停止运动',**health)
            raise RuntimeError('IMU数据丢失、设备断开或UID变化')
        if (asdict(e.params)!=params or e.cal_status!='matched' or
                not ((e.latest.get('acc_cal') is not None and e.latest.get('gyro_cal') is not None) or
                     (getattr(e,'pipeline_mode','realtime')=='realtime' and e.latest.get('cal') is not None))):
            raise RuntimeError('标定或滤波参数发生变化')
        if not self.table.connected:raise RuntimeError('转台通信已断开')
        start=time.monotonic_ns(); st=self.table.read_status();end=time.monotonic_ns()
        if end-start>600_000_000:raise RuntimeError('DLL反馈读取阻塞超过600ms，立即停车')
        axes=st['axes'];other=2 if axis==0 else 0
        amp=(plan or {}).get('amplitude_deg',2.0)
        speed_limit=max(2.5,(plan or {}).get('peak_speed_dps',1.0)*1.35+0.8)
        position_limit=amp+1.2
        for ax in (0,2):
            s=axes[str(ax)]
            if s['driver_fault'] or s['upper_limit'] or s['lower_limit'] or s['over_speed'] or not s['healthy'] or not s['enabled'] or not s['zeroed']:
                raise RuntimeError('转台故障、限位、超速、未使能或未找零；执行停车')
            if abs(s['speed_dps'])>speed_limit:raise RuntimeError(f'角速度超过本次实验监控阈值{speed_limit:.2f}°/s，执行停车')
        if zero_distance_deg(axes[str(axis)]['position_deg'])>position_limit:raise RuntimeError(f'运动轴超出本次摆幅包络±{position_limit:.2f}°，立即停车')
        if abs(angle_delta_deg(axes[str(other)]['position_deg'],initial_other_pos))>.2:raise RuntimeError('非测试轴发生意外位移，立即停车')
        return {'pc_mid_ns':axes[str(axis)].get('position_pc_mid_ns',(start+end)//2),'status_pc_mid_ns':(start+end)//2,'position_read_ms':axes[str(axis)].get('position_read_ms'),'read_ms':(end-start)/1e6,
            **{f'axis_{a}_{k}':axes[str(a)][v] for a in (0,2) for k,v in [('pos','position_deg'),('speed','speed_dps'),('mode','mode')]}}
    def _run(self,plan,defer_report=False):
        e=self.engine;t=self.table;axis=plan['axis'];other=2 if axis==0 else 0
        uid=self.uid;params=asdict(e.params);current_algo=e.active;calmode=e.cal_mode;calfiles=list(e.cal.get('files',[]));
        pipeline_start=e.pipeline_status() if hasattr(e,'pipeline_status') else None
        alignment_snapshot=getattr(e,'static_alignment',None)
        cal_snapshot={}
        for name in calfiles:
            try:
                f=Path(name)
                if f.is_file() and f.suffix.lower()=='.json' and f.stat().st_size<=4_000_000:
                    cal_snapshot[f.name]=f.read_bytes()
            except OSError:pass
        starting_dropped=getattr(getattr(e,'device',None),'dropped_batches',None)
        native=getattr(self,'native_feedback',None)
        native_before=native.status() if native and native.running else None
        trace=dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+f'_{uid}_DYNAMIC'
        path_table=self.dir/(trace+'_table.csv');path_imu=self.dir/(trace+'_imu.csv');path_report=self.dir/(trace+'.json')
        table_rows=[];imu_rows=[];last_seq=0;table_f=imu_f=None;reason='';completed=False;motion_ns=None;motion_end_ns=None
        try:
            st=t.read_status();other_pos=st['axes'][str(other)]['position_deg']
            table_f=path_table.open('w',encoding='utf-8-sig',newline='');imu_f=path_imu.open('w',encoding='utf-8-sig',newline='')
            tw=csv.DictWriter(table_f,fieldnames=TABLE_COLS);iw=csv.DictWriter(imu_f,fieldnames=IMU_COLS);tw.writeheader();iw.writeheader()
            baseline_start=time.monotonic()
            next_poll=baseline_start
            with e.lock:
                last_seq=e.counter # capture only after test begins
            capture_stop=threading.Event()
            capture_error=[]
            capture_thread=None
            collector_info={'polls':0,'max_copy_ms':0.0,'max_convert_ms':0.0,
                            'max_queued_samples':0,'last_sequence':last_seq}
            def write_sample(r):
                out={'seq':r['sequence'],'device_t_s':r.get('device_t_original',r['t']),'host_est_ns':r['host_est_ns'],'pc_observed_ns':r['pc_observed_ns'],'uid':r.get('uid'),'temp_c':r.get('temp'),'alignment_active':int(bool(r.get('static_alignment_active'))),
                     'fusion_t_s':r['t'],'fusion_dt_s':r.get('fusion_dt',r.get('dt')),'gap_reset':int(bool(r.get('gap_reset'))),'batch_id':r.get('batch_id'),'batch_index':r.get('batch_index'),'batch_shift_ms':r.get('batch_shift_ms'),'reported_odr':r.get('reported_odr'),'processing_age_ms':r.get('processing_age_ms'),
                     **{k:r.get(k) for k in ('sample_age_ms','gap_bridge','gap_action','timing_degraded','request_pc_ns','serial_read_ms','poll_id')},
                     'imu_dt_s':r.get('original_dt',r.get('dt')),'imu_nominal_odr_hz':r.get('odr'),
                     'imu_timestamp_quality':r.get('timestamp_quality'),
                     'imu_gap_over_50ms':int(r.get('original_dt',r.get('dt',0))>.05)}
                for channel,source in (('raw_acc','acc'),('cal_acc','acc_cal'),('raw_gyro','gyro'),('cal_gyro','gyro_cal')):
                    vector=r.get(source)
                    for j,axis_name in enumerate('xyz'):
                        out[f'{channel}_{axis_name}_'+('g' if 'acc' in channel else 'dps')]=(vector[j] if vector is not None and len(vector)>j else '')
                adaptive_cal=r['outputs'].get('adaptive_lever',{}).get('cal') or {}
                out['adaptive_lever_trust']=adaptive_cal.get('trust','')
                out['adaptive_lever_beta_eff']=adaptive_cal.get('beta_eff','')
                out['adaptive_lever_innovation_gps']=adaptive_cal.get('accel_innovation_gps','')
                anchor=r['outputs'].get('gravity_observer',r['outputs'].get('gyro_anchor3d',r['outputs'].get('gyro_anchor',{}))).get('cal') or {}
                out['gyro_anchor_trust']=anchor.get('trust','')
                out['gyro_anchor_bias_ready']=int(bool(anchor.get('stationary_bias_ready')))
                out['gyro_anchor_motion_detected']=int(bool(anchor.get('motion_detected')))
                anchor_bias=anchor.get('gyro_bias_dps') or ('','','')
                for j,axis_name in enumerate('xyz'):
                    out[f'gyro_anchor_gyro_bias_{axis_name}_dps']=anchor_bias[j]
                vqf_cal=r['outputs'].get('vqf6d',{}).get('cal') or {}
                out['vqf6d_rest_detected']=int(bool(vqf_cal.get('stationary_detected'))) if vqf_cal else ''
                out['vqf6d_gap_count']=vqf_cal.get('imu_gaps_over_threshold','')
                out['vqf6d_max_gap_s']=vqf_cal.get('max_gap_s','')
                for j,axis_name in enumerate('xyz'):
                    out[f'vqf6d_bias_{axis_name}_dps']=(vqf_cal.get('gyro_bias_dps') or ('','',''))[j]
                gyro_bias=adaptive_cal.get('gyro_bias_dps') or ('','','')
                for j,axis_name in enumerate('xyz'):
                    out[f'adaptive_lever_gyro_bias_{axis_name}_dps']=gyro_bias[j]
                l3=(r['outputs'].get('gyro_anchor3d',r['outputs'].get('adaptive3d',r['outputs'].get('lever3d',{}))).get('cal_factory') or {})
                out['lever3d_ready']=int(bool(l3.get('lever_compensation_ready'))) if l3 else ''
                out['lever3d_gap_count']=l3.get('lever_gap_count','')
                for j,ax in enumerate('xyz'):out['lever3d_rot_acc_'+ax+'_g']=(l3.get('lever_rot_acc_g') or ('','',''))[j]
                for ch in ('raw','cal','cal_factory'):
                    for algo in ALGORITHMS:
                        pose=r['outputs'].get(algo,{}).get(ch)
                        for angle in ('roll','pitch'):
                            out[f'{ch}_{algo}_{angle}']=pose.get(angle) if pose else ''
                iw.writerow(out);imu_rows.append(out)
            def capture_imu_worker():
                nonlocal last_seq
                try:
                    while True:
                        copy_start=time.monotonic_ns()
                        with e.lock:
                            new=[]
                            for r in reversed(e.recent):
                                if r.get('sequence',-1)<=last_seq:break
                                new.append(r)
                            new.reverse()
                        collector_info['polls']+=1
                        collector_info['max_copy_ms']=max(collector_info['max_copy_ms'],(time.monotonic_ns()-copy_start)/1e6)
                        collector_info['max_queued_samples']=max(collector_info['max_queued_samples'],len(new))
                        if new and new[0]['sequence']>last_seq+1:
                            raise RuntimeError('IMU历史队列发生覆盖，原始样本不连续；停止实验')
                        process_start=time.monotonic_ns()
                        for item in new:
                            write_sample(item)
                            last_seq=item['sequence']
                        collector_info['last_sequence']=last_seq
                        collector_info['max_convert_ms']=max(collector_info['max_convert_ms'],(time.monotonic_ns()-process_start)/1e6)
                        with self.lock:self.imu_count=len(imu_rows)
                        if capture_stop.wait(.012):
                            # Drain the remaining samples before closing, without
                            # inventing samples absent from the engine history.
                            with e.lock:
                                tail=[]
                                for r in reversed(e.recent):
                                    if r.get('sequence',-1)<=last_seq:break
                                    tail.append(r)
                                tail.reverse()
                            if tail and tail[0]['sequence']>last_seq+1:
                                raise RuntimeError('停止阶段IMU历史队列覆盖')
                            for item in tail:
                                write_sample(item)
                                last_seq=item['sequence']
                            collector_info['last_sequence']=last_seq
                            with self.lock:self.imu_count=len(imu_rows)
                            return
                except Exception as exc:
                    capture_error.append(f'{type(exc).__name__}: {exc}')
            capture_thread=threading.Thread(target=capture_imu_worker,daemon=True,name='2TD600-imu-csv-worker')
            capture_thread.start()
            last_feedback_ns=None
            max_poll_lag_ms=0.0
            max_table_write_ms=0.0
            max_loop_work_ms=0.0
            feedback_over_400ms=0
            previous_table_write_ms=0.0
            previous_loop_work_ms=0.0
            while True:
                poll_start_ns=time.monotonic_ns()
                elapsed=time.monotonic()-baseline_start
                if self.cancel_event.is_set():raise RuntimeError('操作员中止')
                poll_lag_ms=max(0.,(time.monotonic()-next_poll)*1000)
                max_poll_lag_ms=max(max_poll_lag_ms,poll_lag_ms)
                row=self._watch(uid,params,axis,other_pos,plan)
                row['poll_lag_ms']=round(poll_lag_ms,4)
                gap_ms=(row['pc_mid_ns']-last_feedback_ns)/1e6 if last_feedback_ns is not None else 0.0
                row['feedback_interval_ms']=round(gap_ms,3)
                if gap_ms>400:feedback_over_400ms+=1
                last_feedback_ns=row['pc_mid_ns']
                row['previous_table_csv_write_ms']=round(previous_table_write_ms,4)
                row['previous_loop_work_ms']=round(previous_loop_work_ms,4)
                write_start=time.monotonic_ns()
                tw.writerow(row);table_rows.append(row)
                previous_table_write_ms=(time.monotonic_ns()-write_start)/1e6
                max_table_write_ms=max(max_table_write_ms,previous_table_write_ms)
                with self.lock:self.latest_feedback={'position_deg':row[f'axis_{axis}_pos'],'speed_dps':row[f'axis_{axis}_speed'],'age_ms':0}
                if capture_error:
                    raise RuntimeError('IMU后台采集失败：'+capture_error[0])
                poll_finish=time.monotonic_ns()
                previous_loop_work_ms=(poll_finish-poll_start_ns)/1e6
                max_loop_work_ms=max(max_loop_work_ms,previous_loop_work_ms)
                with self.lock:self.table_count=len(table_rows)
                if motion_ns is None and elapsed>=2.0:
                    # Do not command automatic homing/positioning; initial axis is near zero.
                    self.state='commanding_sway'
                    t.sway(axis,plan['amplitude_deg'],plan['frequency_hz'])
                    motion_ns=time.monotonic_ns()
                    with self.lock:self.state='swaying'
                if motion_ns is not None:
                    # Reject a DLL command that appears to be accepted but never moves.
                    if time.monotonic_ns()-motion_ns>int((.5/plan['frequency_hz']+3)*1e9):
                        recent_positions=[angle_delta_deg(r[f'axis_{axis}_pos']) for r in table_rows if r['pc_mid_ns']>=motion_ns]
                        if recent_positions and max(recent_positions)-min(recent_positions)<plan['amplitude_deg']*.45:
                            raise RuntimeError('摇摆命令未产生足够的实际运动；停止实验')
                    if time.monotonic_ns()-motion_ns>int((plan['duration_s']+5)*1e9):raise RuntimeError('摇摆运动超时')
                    if time.monotonic_ns()-motion_ns>=int(plan['duration_s']*1e9):
                        motion_end_ns=time.monotonic_ns();completed=True;break
                next_poll+=.08
                pause=next_poll-time.monotonic()
                if pause>0:self.cancel_event.wait(pause)
                else:next_poll=time.monotonic()
            with self.lock:self.state='stopping'
        except Exception as exc:
            reason=f'{type(exc).__name__}: {exc}'
            with self.lock:self.state='aborting';self.error=reason
        finally:
            # Always issue stop on all axes, on success or failure; software stop
            # cannot replace the hardware emergency-stop.
            try:
                t.stop()
                verified=t.stopped_verified(timeout=20)
            except Exception as exc:
                verified=False;reason+='; STOP失败：'+str(exc)
            with self.lock:self.stopped_verified=verified
            if not verified:reason+='; 停车未获双轴状态确认，现场立即核查硬件急停'
            if 'capture_stop' in locals():capture_stop.set()
            if 'capture_thread' in locals() and capture_thread is not None:
                capture_thread.join(timeout=12)
                if capture_thread.is_alive():
                    reason+='; IMU后台保存线程未按时结束，不能确认CSV已完整保存'
                if capture_error:
                    reason+='; IMU后台采集失败：'+capture_error[0]
            for f in (table_f,imu_f):
                if f:
                    try:f.flush();f.close()
                    except Exception:pass
            result={'kind':'REAL_2TD600_SINE_DIAGNOSTIC','uid':uid,'plan':plan,
                'table_samples':len(table_rows),'imu_samples':len(imu_rows),'finished_at':dt.datetime.now().astimezone().isoformat(),
                'state':'completed' if completed and verified and not reason else 'invalid',
                'error':reason,'stopped_verified':verified,'motion_commands_sent':bool(motion_ns),
                'motion_period_collected':bool(completed and motion_ns and motion_end_ns),
                'motion_capture_state':('completed' if completed and verified and not reason else 'incomplete_or_unverified'),
                'stop_feedback_diagnostics':getattr(t,'last_stop_check',None),
                'imu_algorithm_at_start':(current_algo if pipeline_start and pipeline_start.get('mode')=='realtime' else None),
                'capture_mode':pipeline_start.get('mode') if pipeline_start else None,
                'pipeline_start':pipeline_start,'pipeline_end':e.pipeline_status() if hasattr(e,'pipeline_status') else None,'calibration_mode':calmode,'calibration_files':calfiles,
                'static_alignment':getattr(e,'static_alignment',None),
                'fusion_parameters_used':params,
                'rotation_compensation_note':'Z轴偏心模型仅用于已标定产品P坐标；未标定分支保持原Madgwick对照。需实际测量偏心距离并进行其他频率/方向验证。',
                'raw_file_table':path_table.name,'raw_file_imu':path_imu.name,
                'motion_start_pc_monotonic_ns':motion_ns,'motion_end_pc_monotonic_ns':motion_end_ns,
                'reference_provenance':'REAL 2TD-600 DLL reported position, PC timestamp',
                'manufacturer_sway_command':'SetAxisSway(axis=2, amplitude_deg, frequency_hz)',
                'native_high_rate_capture':({'file':native_before['file'],
                    'samples_at_test_start':native_before['samples'],
                    'samples_at_test_end':native.status().get('samples'),
                    'hardware_clock_synchronized':False,
                    'use_in_official_rmse':False,
                    'note':'独立厂家0xA0状态流，未校验与DLL及IMU硬件时钟关系；仅作为附加原始参考数据'} if native_before else None),
                'quality':'RESEARCH_ONLY_UNSYNCHRONIZED','certified_dynamic_accuracy':False,
                'feedback_loop_diagnostics':{'design':'independent_imu_csv_worker_table_poll_same_safety_thread',
                    'maximum_poll_lateness_ms':round(locals().get('max_poll_lag_ms',0),3),
                    'maximum_table_csv_write_ms':round(locals().get('max_table_write_ms',0),3),
                    'maximum_loop_work_ms':round(locals().get('max_loop_work_ms',0),3),
                    'feedback_intervals_over_400ms':locals().get('feedback_over_400ms',0),
                    'imu_worker':locals().get('collector_info',{})},
                'imu_fifo_dropped_batch_counter_start':starting_dropped,
                'imu_fifo_dropped_batch_counter_end':getattr(getattr(e,'device',None),'dropped_batches',None),
                'imu_fifo_dropped_delta':(getattr(getattr(e,'device',None),'dropped_batches',0)-starting_dropped) if starting_dropped is not None else None}
            # Verified STOP and all capture writers closed before spawning analysis.
            # Keep motion watchdogs and browser heartbeats active in the parent.
            # Only filenames and small metadata cross IPC; no pickling huge sample arrays.
            try:
                if verified and completed and not reason:
                    with self.lock:self.state='reporting_stopped';self.pending_report_file=path_report.name
                args=(str(path_report),str(path_imu),str(path_table),result,alignment_snapshot,cal_snapshot,completed,verified,reason,trace)
                deferred=bool(defer_report and verified and completed and not reason)
                receipt=_spawn_report(args,deferred)
                if deferred:
                    # Small durable capture ledger and per-stage gate already written.
                    # Full report computation is explicitly postponed until no more motion.
                    self.deferred_reports.append(args)
                result.update(receipt)
                reason=result.get('error','')
                from .table_diagnostics import DIAG
                DIAG.record('dynamic_capture_gate_complete' if deferred else 'dynamic_report_worker_complete','采集质量检查完成（完整分析待停车后）' if deferred else '独立报告进程完成',report_file=path_report.name,**(e.link_watchdog_status() if hasattr(e,'link_watchdog_status') else {}))
            except Exception as exc:
                reason+='; 报告计算失败 '+repr(exc)
                result.update(state='invalid',error=reason,data_analysis_state='invalid',certified_dynamic_accuracy=False,
                              report_compute_mode='isolated_process_failed',diagnostic_bundle_available=True)
                try:path_report.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
                except Exception:pass
            with self.lock:
                self.state=result['state'] if result['state'] in ('completed','analysis_invalid','capture_complete') else 'invalid'
                self.error=reason;self.running=False;self.finished=True;self.pending_report_file=None
                self.report_file=path_report.name if path_report.exists() else None
                self.table_file=path_table.name if path_table.exists() else None
                self.imu_file=path_imu.name if path_imu.exists() else None


    def finalize_deferred_reports(self):
        """Called only by AutoDynamicWorkflow after final verified STOP.
        No motion commands, no clearing of pipeline faults, no automatic resume.
        Pending ledgers/CSV remain recoverable if analysis fails.
        """
        jobs=list(self.deferred_reports)
        self.deferred_reports.clear()
        results={}
        for args in jobs:
            path=Path(args[0]);ledger=json.loads(path.read_text(encoding='utf-8'))
            original=dict(args[3]);original['static_before_dynamic']=ledger.get('static_before_dynamic')
            original['pre_research']=ledger.get('pre_research')
            original['deferred_capture_gate']=ledger.get('deferred_capture_gate')
            r=_spawn_report((*args[:3],original,*args[4:]),False)
            results[path.name]={'state':r['state'],'error':r.get('error') or ('' if r['state']=='completed' else '离线报告返回状态='+str(r['state'])+'；请检查动态JSON的analysis/deferred_capture_gate')} 
            with self.lock:
                if self.report_file==path.name:
                    self.state=r['state'];self.error=r.get('error','')
        return results


def _spawn_report(args,defer_analysis=False):
    import multiprocessing as mp
    path=Path(args[0])
    receipt=path.with_suffix('.worker_receipt.json')
    if receipt.exists():receipt.unlink()
    process=mp.get_context('spawn').Process(target=_report_process_receipt,
        args=(args,defer_analysis,str(receipt)),name='TiltLab-capture-gate' if defer_analysis else 'TiltLab-dynamic-report',daemon=True)
    process.start()
    try:
        deadline=time.monotonic()+900
        while process.is_alive() and time.monotonic()<deadline:process.join(.15)
        if process.is_alive():raise TimeoutError('离线报告计算超时')
        if process.exitcode!=0 or not path.is_file() or not receipt.is_file():raise RuntimeError(f'报告进程异常退出：{process.exitcode}')
        return json.loads(receipt.read_text(encoding='utf-8'))
    finally:
        if process.is_alive():process.terminate();process.join(2)
        process.close()
        if receipt.exists():receipt.unlink()

def _report_process_receipt(args,defer_analysis,receipt):
    _report_process(*args,defer_analysis)
    result=args[3]
    Path(receipt).write_text(json.dumps({'state':result['state'],'error':result.get('error','')},ensure_ascii=False),encoding='utf-8')


def _read_closed_csv(path,fields=None):
    """Read immutable capture files; preserve nanosecond integers and flags."""
    ints={'seq','host_est_ns','pc_observed_ns','pc_mid_ns','status_pc_mid_ns','request_pc_ns','batch_id','batch_index','poll_id','alignment_active','gap_reset','gap_bridge','timing_degraded','imu_gap_over_50ms'}
    with Path(path).open(encoding='utf-8-sig',newline='') as fp:
        for row in csv.DictReader(fp):
            if fields is not None:row={k:row[k] for k in fields if k in row}
            for key in ints.intersection(row):
                value=row[key]
                if value not in ('',None):
                    row[key]=int(value.lower()=='true') if value.lower() in ('true','false') else int(value)
            yield row


def _report_process(path_report, path_imu, path_table, result, alignment_snapshot, cal_snapshot, completed, verified, reason, trace, defer_analysis=False):
    """Spawn target. No engine/table handles, no motion, no parent GIL workload."""
    import os
    report_started=time.monotonic()
    # Best-effort lower priority for non-safety analytical work; never change
    # acquisition or control process priority. No platform dependency required.
    try:
        if os.name=='nt':
            import ctypes
            k=ctypes.windll.kernel32;k.SetPriorityClass(k.GetCurrentProcess(),0x4000)
        else:os.nice(5)
    except (OSError,AttributeError):pass
    path_report=Path(path_report)
    plan=result['plan'];params=result['fusion_parameters_used'];axis=plan['axis'];current_algo=result['imu_algorithm_at_start']
    # The offline capture gate reads calibrated six-axis columns, not nonexistent angle columns.
    fields=({'host_est_ns','pc_observed_ns','device_t_s','imu_timestamp_quality','batch_shift_ms','gap_reset','imu_dt_s',f'cal_{current_algo}_{plan["output"]}'}
            if defer_analysis and (result.get('pipeline_start') or {}).get('mode')=='realtime' else None)
    imu_rows=list(_read_closed_csv(path_imu,fields));table_rows=list(_read_closed_csv(path_table))
    if len(imu_rows)!=result['imu_samples'] or len(table_rows)!=result['table_samples']:
        raise RuntimeError('关闭后的CSV行数不匹配；拒绝生成精度结果')
    pipeline_start=result.get('pipeline_start');motion_ns=result.get('motion_start_pc_monotonic_ns');motion_end_ns=result.get('motion_end_pc_monotonic_ns')
    if defer_analysis:
        # Same reference coverage/steady-state rules as full analysis, plus
        # continuity and selected realtime channel. Never approve a failed STOP.
        if not (completed and verified and not reason and motion_ns and motion_end_ns):
            raise RuntimeError('不可推迟未完成或未确认停车的采集')
        gate=_analyze_tracking_core(table_rows,imu_rows,axis,plan['output'],plan['sign'],plan['amplitude_deg'],plan['frequency_hz'],motion_ns,motion_end_ns,gate_algorithm=('__capture_only__' if pipeline_start and pipeline_start.get('mode')=='offline' else current_algo))
        resets=sum(int(bool(r.get('gap_reset'))) for r in imu_rows)
        long_gaps=sum(float(r.get('imu_dt_s') or 0)>.05 for r in imu_rows)
        if resets or long_gaps:gate.update(valid=False,reason='IMU存在未知长缺口或重置，禁止继续下一方向')
        result.update(state='capture_complete' if gate['valid'] else 'analysis_invalid',
                      error='' if gate['valid'] else gate['reason'],
                      deferred_capture_gate=gate,data_analysis_state='pending_offline_analysis',
                      certified_dynamic_accuracy=False,report_compute_mode='deferred_until_final_stop')
        # Preserve exact calibration snapshot even if process or GUI exits before final analysis.
        if cal_snapshot:
            import zipfile
            snap_path=path_report.parent/(trace+'_calibration_snapshot.zip')
            with zipfile.ZipFile(snap_path,'w',zipfile.ZIP_DEFLATED) as snap:
                for name,content in cal_snapshot.items():snap.writestr(name,content)
            result['calibration_snapshot_file']=snap_path.name
        path_report.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        return
    temperatures=[float(r['temp_c']) for r in imu_rows if r.get('temp_c') not in ('',None) and math.isfinite(float(r['temp_c']))]
    result['temperature_diagnostics']={'samples':len(temperatures),'min_c':min(temperatures) if temperatures else None,
        'max_c':max(temperatures) if temperatures else None,'mean_c':sum(temperatures)/len(temperatures) if temperatures else None,
        'note':'记录芯片温度；静止零偏估计不等于温度补偿。'}
    # Data analysis is independent from *safety* stop confirmation.
    # A completed acquisition can be analyzed, but MUST NOT be marked as
    # a successfully completed hardware experiment when STOP is unverified.
    analysis_rows=imu_rows
    if completed and verified and pipeline_start and pipeline_start.get('mode') in ('realtime','offline') and imu_rows:
        try:
            from .replay_v712 import replay_missing
            replayed_rows,replay_info=replay_missing(imu_rows,params,alignment_snapshot,current_algo if pipeline_start.get('mode')=='realtime' else None)
            replay_path=path_report.parent/(trace+'_offline_replay.csv')
            with replay_path.open('w',encoding='utf-8-sig',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(dict.fromkeys([*IMU_COLS,*imu_rows[0]])));w.writeheader();w.writerows(replayed_rows)
            analysis_rows=replayed_rows
            result['offline_replay']={**replay_info,'file':replay_path.name}
        except Exception as exc:
            result['offline_replay']={'error':repr(exc),'note':'保留实时CSV；离线对照未完成'}
    if completed and motion_ns and motion_end_ns:
        # Reference polarity is purely a post-stop, read-only report-coordinate
        # check. The requested motion plan, raw CSV and motor command never change.
        from .dynamic_reference_polarity import infer_dynamic_reference_polarity
        requested_sign=plan['sign']
        polarity=infer_dynamic_reference_polarity(table_rows,analysis_rows,axis,
            plan['output'],requested_sign,motion_ns,motion_end_ns,recover_imu_timebase)
        result['dynamic_reference_polarity']=polarity
        if polarity['valid']:
            plan['sign']=polarity['selected_sign']  # report comparison only
            result['reference_sign_requested']=requested_sign
            result['reference_sign_used']=plan['sign']
            result['reference_sign_source']='verified_dynamic_accel_and_gyro'
        else:
            result['reference_sign_requested']=requested_sign
            result['reference_sign_used']=requested_sign
            result['reference_sign_source']='unverified_operator_input'
        try:
            result['analysis']=analyze_tracking(table_rows,analysis_rows,axis,plan['output'],plan['sign'],plan['amplitude_deg'],plan['frequency_hz'],motion_ns,motion_end_ns)
        except Exception as exc:
            result['analysis']={'valid':False,'reason':'分析异常：'+repr(exc)}
        result['analysis']['realtime_algorithm']=current_algo if pipeline_start and pipeline_start.get('mode')=='realtime' else None
        result['analysis']['capture_mode']=pipeline_start.get('mode') if pipeline_start else None
        result['analysis']['dynamic_reference_polarity']=polarity
        if not polarity['valid']:
            result['analysis']['quality_warning']=(result['analysis'].get('quality_warning') or '')+'；参考比较方向未可靠核验；当前误差仅按操作者选择符号展示，不可用于动态精度判定。'
        if current_algo in ('adaptive3d','gyro_anchor3d'):
            result['analysis']['lever_research_note']='三维杆臂研究分支；当前参数未经过该算法的跨工况独立验证，不可作精度验收。'
            result['analysis']['certified_dynamic_accuracy']=False
        result['analysis']['offline_replay']=result.get('offline_replay')
        replay_algos=set((result.get('offline_replay') or {}).get('offline_algorithms',[]))
        from .absolute_accuracy import lever_status
        for metric in [*result['analysis'].get('comparison',[]),*(result['analysis'].get('absolute_accuracy') or {}).get('comparison',[])]:
            metric['execution_mode']='offline_replay' if metric.get('algorithm') in replay_algos else 'realtime_capture' if pipeline_start and pipeline_start.get('mode')=='realtime' else 'not_computed'
            metric['lever_status']=lever_status(metric['algorithm'],params)
        absolute=result['analysis'].get('absolute_accuracy') or {}
        absolute['primary_policy']='离线数据为研究级对照，不可作为实时绝对精度声明；如选实时，仍只认证实际捕获通道'
        absolute['primary_eligible']=bool(pipeline_start and pipeline_start.get('mode')=='realtime') and current_algo not in replay_algos and lever_status(current_algo,params)=='no_lever' and not (alignment_snapshot or {}).get('applied') and all(abs(float(params.get(k,0.)))<1e-10 for k in ('lever_z_cm','lever3_x_cm','lever3_y_cm','lever3_z_cm'))
        absolute['primary']=[m for m in absolute.get('comparison',[]) if absolute['primary_eligible'] and m['channel']=='cal_factory' and m['algorithm']==current_algo and m['execution_mode']=='realtime_capture']
        absolute['lever_parameters_cm']={k:params.get(k,0.) for k in ('lever_z_cm','lever3_x_cm','lever3_y_cm','lever3_z_cm')}
        resets=sum(int(bool(r.get('gap_reset'))) for r in imu_rows)
        bridges=sum(int(bool(r.get('gap_bridge'))) for r in imu_rows)
        long_gaps=sum(float(r.get('imu_dt_s') or 0)>.05 for r in imu_rows)
        result['analysis']['fusion_gap_resets']=resets
        result['analysis']['fusion_gap_bridges']=bridges
        result['analysis']['estimated_gaps_over_50ms']=long_gaps
        from .continuity_diagnostics import gap_summary
        result['analysis']['continuity_diagnostics']=gap_summary(imu_rows,motion_ns,motion_end_ns)
        result['analysis']['continuity_policy']='V7.13：10–400ms支持算法仅陀螺端点预测，禁用该间隔ACC校正；未知长缺口仍不得验收'
        if resets or long_gaps:
            result['analysis']['quality_warning']=(result['analysis'].get('quality_warning') or '')+f'；估算长缺口 {long_gaps} 次、预测 {bridges} 次、重置 {resets} 次；全部误差仅供研究，连续跟踪不合格。'
            if completed and verified and not reason:
                result['state']='analysis_invalid'
                reason+='; IMU存在未知长缺口或重置，连续动态精度评价无效';result['error']=reason
        if current_algo=='adaptive' and completed and verified:
            try:
                from .continuity_diagnostics import compare_adaptive
                result['analysis']['continuity_ab']=compare_adaptive(imu_rows,table_rows,params,alignment_snapshot,plan,motion_ns,motion_end_ns)
            except Exception as exc:result['analysis']['continuity_ab']={'available':False,'reason':repr(exc)}
        result['data_analysis_state']=('available_research_only' if result['analysis'].get('valid') and not (resets or long_gaps)
                                       else 'invalid')
        if result['analysis'].get('reference_gaps_masked'):
            result['data_analysis_quality']='REFERENCE_GAPS_EXCLUDED_RESEARCH_ONLY'
        if not result['analysis'].get('valid'):
            if completed and verified and not reason and len(imu_rows)>=20 and len(table_rows)>=20:
                result['state']='analysis_invalid'
            else:
                result['state']='invalid'
            reason+='; 动态精度分析未通过：'+result['analysis'].get('reason','无有效分析')
            result['error']=reason
    else:
        result['data_analysis_state']='not_collected_full_motion'
    if (result.get('deferred_capture_gate') or {}).get('valid') is False and verified:
        result['state']='analysis_invalid'
        result['data_analysis_state']='invalid'
        result['error']=(result.get('error') or '')+'; 原采集质量门禁未通过：'+str(result['deferred_capture_gate'].get('reason',''))
    if not verified:
        result['state']='invalid'
        result['safety_note']='停车状态未通过DLL反馈确认。数据分析成功也不表示实验安全闭环完成，禁止自动继续下一轴。'
    # V7.24.1: the deferred capture-gate leaves state=capture_complete.
    # Full offline analysis MUST transition this to completed *only* if the
    # independent analysis is valid, the original gate passed, and real STOP
    # was confirmed. Otherwise fail closed with a meaningful reason. A
    # completed report is RESEARCH_ONLY, not a 0.05/0.1 degree certification.
    if result.get('state') == 'capture_complete':
        valid_analysis = bool((result.get('analysis') or {}).get('valid'))
        quality_good = result.get('data_analysis_state') == 'available_research_only'
        gate_good = (result.get('deferred_capture_gate') or {}).get('valid') is True
        if completed and verified and not reason and valid_analysis and quality_good and gate_good:
            result['state'] = 'completed'
            result['error'] = ''
        else:
            result['state'] = 'analysis_invalid'
            result['data_analysis_state'] = 'invalid'
            result['error'] = (result.get('error') or
                '完整离线分析质量不足；检查analysis、deferred_capture_gate、停车反馈和数据连续性')
    try:
        if cal_snapshot:
            try:
                import zipfile
                snap_path=path_report.parent/(trace+'_calibration_snapshot.zip')
                with zipfile.ZipFile(snap_path,'w',zipfile.ZIP_DEFLATED) as snap:
                    for name,content in cal_snapshot.items():snap.writestr(name,content)
                result['calibration_snapshot_file']=snap_path.name
            except OSError as exc:
                result['calibration_snapshot_error']=str(exc)
        result['diagnostic_bundle_available']=True
        result['report_compute_mode']='isolated_spawn_process'
        result['report_worker_pid']=os.getpid()
        result['report_compute_elapsed_s']=round(time.monotonic()-report_started,3)
        result['report_completed_at']=dt.datetime.now().astimezone().isoformat()
        path_report.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        try:
            from .html_report import write_interactive_report
            html_path=write_interactive_report(path_report)
            result['html_report_file']=html_path.name
            path_report.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        except Exception as html_exc:
            result['html_report_error']=str(html_exc)
            path_report.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    except Exception as exc:raise RuntimeError('报告保存失败：'+str(exc)) from exc
    if not path_report.is_file():raise RuntimeError(reason or "报告未保存")
