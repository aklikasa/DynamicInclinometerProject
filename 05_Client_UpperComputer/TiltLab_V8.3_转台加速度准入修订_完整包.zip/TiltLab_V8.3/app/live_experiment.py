"""Physically gated low-speed static sweep. Real encoder/IMU samples; unverified without hardware.
Preconditions require on-site operator confirmation and homed/enabled healthy axes.
"""
import csv,json,threading,time,datetime,math,statistics
from .turntable import TABLE,TableError
from .angles import angle_delta_deg
from .engine import ENGINE,ROOT
from .analysis import calculate

class HardwareExperiment:
    def __init__(self):
        self.lock=threading.RLock();self.running=False;self.abort=False;self.state='idle';self.problem='';self.samples=[];self.file=None;self.thread=None
    def status(self):
        with self.lock:return dict(running=self.running,state=self.state,error=self.problem,samples=len(self.samples),file=self.file)
    def start(self,axis=0,output='roll',acknowledged=False):
        if acknowledged is not True:raise ValueError('必须由现场人员确认限位、方向、急停和转台周边安全')
        if axis not in (0,2) or output not in ('roll','pitch'):raise ValueError('轴号或输出角不合法')
        if ENGINE.source!='serial' or not ENGINE.running or not ENGINE.connected or ENGINE.cal_status!='matched':raise ValueError('必须连接实机IMU，并已匹配完整常温标定')
        if not TABLE.connected:raise ValueError('必须连接真实2TD600转台')
        status=TABLE.read_status()
        for a in (0,2):
            s=status['axes'][str(a)]
            if not(s['enabled'] and s['zeroed'] and s['healthy']) or s['upper_limit'] or s['lower_limit'] or s['driver_fault']:
                raise ValueError('转台至少一轴不健康/未找零/未使能/触限，拒绝自动运行')
        with self.lock:
            if self.running:raise ValueError('自动实验正在执行')
            self.running=True;self.abort=False;self.state='checking';self.problem='';self.samples=[];self.file=None
        self.thread=threading.Thread(target=self._run,args=(axis,output),daemon=True)
        self.thread.start();return self.status()
    def cancel(self):
        self.abort=True
        try:TABLE.stop()
        except Exception as e:self.problem+='; 停止指令失败：'+str(e)
    def _check(self):
        if self.abort:raise RuntimeError('操作员中止')
        if not ENGINE.running or not ENGINE.connected or ENGINE.cal_status!='matched':raise RuntimeError('IMU连接/标定丢失')
        if not TABLE.connected:raise RuntimeError('转台连接丢失')
        status=TABLE.read_status()
        for a in (0,2):
            s=status['axes'][str(a)]
            if s['driver_fault'] or s['upper_limit'] or s['lower_limit'] or not s['healthy'] or s['over_speed']:
                raise RuntimeError('转台反馈故障/限位，立即停车')
        return status
    def _run(self,axis,output):
        try:
            # Limited low-speed static test; no implicit homing or axis enabling.
            points=(-10,-5,0,5,10,0)
            old_uid=ENGINE.uid;old_algo=ENGINE.active
            for target in points:
                self.state=f'运动到 {target:+.0f}°'
                initial=self._check()['axes'][str(axis)]['position_deg']
                TABLE.move(axis,target,1.)
                deadline=time.monotonic()+max(15,abs(target-initial)*3+10)
                while time.monotonic()<deadline:
                    v=self._check()['axes'][str(axis)]
                    if v['in_place'] and abs(angle_delta_deg(v['position_deg'],target))<.08 and abs(v['speed_dps'])<.08:break
                    time.sleep(.10)
                else:raise RuntimeError('转台定位超时/位置不符')
                self.state=f'静置 {target:+.0f}°'
                for _ in range(15):self._check();time.sleep(.1)
                self.state=f'采样 {target:+.0f}°'
                at=time.monotonic();sample_values=[];encoder=[]
                while time.monotonic()-at<2:
                    v=self._check()['axes'][str(axis)]
                    if abs(angle_delta_deg(v['position_deg'],target))>.12 or abs(v['speed_dps'])>.08:raise RuntimeError('采样期间转台未稳定')
                    if ENGINE.uid!=old_uid or ENGINE.active!=old_algo:raise RuntimeError('实验时UID或算法配置改变')
                    with ENGINE.lock:
                        cur=ENGINE.latest
                        if cur and cur.get('cal') and cur.get('source')=='serial':
                            sample_values.append((cur['cal'][output],cur['raw'][output],cur['t']))
                            encoder.append(v['position_deg'])
                    time.sleep(.05)
                if len(sample_values)<8:raise RuntimeError('有效IMU样本不足')
                # Basic static axis reference assumes verified one-to-one mounting between table axis and output.
                cal=statistics.fmean(x[0] for x in sample_values)
                raw=statistics.fmean(x[1] for x in sample_values)
                ref=statistics.fmean(encoder)
                self.samples.append({'target_deg':target,'reference_encoder_deg':ref,'calibrated_angle_deg':cal,
                                     'uncalibrated_angle_deg':raw,'static_error_deg':cal-ref,
                                     'samples':len(sample_values),'imu_t_start':sample_values[0][2],
                                     'imu_t_end':sample_values[-1][2]})
            self.state='completed'
        except Exception as e:
            self.problem=str(e);self.state='failed'
        finally:
            try:
                TABLE.stop()
                if not TABLE.stopped_verified():
                    self.problem+='; 停车未完成反馈确认（请使用硬件急停）'
                    self.state='failed'
            except Exception as e:
                self.problem+='; 停车失败：'+str(e)
                self.state='failed'
            report={'source':'REAL_PCB_AND_2TD600','status':self.state,'error':self.problem,
                    'uid':ENGINE.uid,'algorithm':ENGINE.active,'output_axis':output,
                    'turntable_axis':axis,'angle_mapping_condition':'operator-confirmed 1:1 static mapping',
                    'sync':'static stable-window mean; NOT dynamic phase accuracy',
                    'steps':self.samples,'created':datetime.datetime.now().astimezone().isoformat()}
            if self.samples:
                folder=ROOT/'data'/'reports';name=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_HARDWARE_STATIC'
                (folder/(name+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
                self.file=name+'.json'
            with self.lock:self.running=False

HARDWARE_TEST=HardwareExperiment()
