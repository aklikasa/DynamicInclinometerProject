"""Verified fixture-alignment artifacts. NEVER overwrites factory ACC/GYRO JSON.

Files are device-/calibration-mode-scoped, and mount-specific: saving does not
imply safe automatic reuse after remount or on a different machine.
"""
from __future__ import annotations
import datetime as dt,json,math,os,re,tempfile
from pathlib import Path


def _atomic_json(path, document):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.'+path.stem+'_',suffix='.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as out:
            json.dump(document,out,ensure_ascii=False,indent=2,allow_nan=False)
            out.write('\n');out.flush();os.fsync(out.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def store_verified_mount_alignment(root, candidate, *, uid, mode, factory_files, stop_confirmed, disable_results=None, holding_results=None):
    if not (candidate.get('valid') is True and candidate.get('active_statically_pass') is True and
            candidate.get('gravity_statically_pass') is True):
        raise ValueError('静态拟合或独立反向验证未通过，不生成可用安装标定文件')
    if stop_confirmed is not True:
        raise ValueError('未确认物理停车，拒绝签发安装标定结果')
    held=(isinstance(holding_results,list) and len(holding_results)==2 and
          {x.get('axis') for x in holding_results}=={0,2} and
          all(x.get('confirmed_enabled') is True for x in holding_results))
    disabled=(isinstance(disable_results,list) and len(disable_results)==2 and
              all(x.get('confirmed_disabled') is True for x in disable_results))
    if not (held or disabled):raise ValueError('未确认双轴使能保持或安全断使能')
    if not re.fullmatch(r'[A-Za-z0-9_-]{3,64}',str(uid)) or mode not in ('ambient','thermal'):
        raise ValueError('设备UID或原厂补偿模式无效')
    if candidate.get('uid')!=uid or candidate.get('calibration_mode')!=mode:
        raise ValueError('拟合结果对应其他设备或补偿模式，禁止保存为本设备可用参数')
    if not isinstance(factory_files,(list,tuple)) or len(factory_files)<2:
        raise ValueError('缺少原厂ACC/GYRO文件来源记录')
    stamp=dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    folder=Path(root)/'data'/'mount_calibrations'
    filename=f'{stamp}_{uid}_{mode}_MOUNT_ALIGNMENT.json'
    record={**candidate,'schema':'TILTLAB_MOUNT_ALIGNMENT_V1','saved_at':dt.datetime.now().astimezone().isoformat(),
            'calibration_type':'FIXTURE_MOUNT_ALIGNMENT_NOT_FACTORY_ACC_GYRO',
            'factory_calibration_files':[str(f) for f in factory_files],
            'stop_confirmed':True,'disable_results':disable_results or [],'holding_results':holding_results or [],
            'servos_held_after_calibration':bool(held),
            'automatic_reuse_allowed':False,
            'note':'本次装夹静态小角度对齐；原厂ACC/GYRO标定文件未改写。拆装/换设备后不可自动套用。'}
    _atomic_json(folder/filename,record)
    # A stable latest path is useful for finding the result. Write only after
    # the immutable, stamped result is fully committed.
    _atomic_json(folder/f'{uid}_{mode}_LATEST_MOUNT_ALIGNMENT.json',record)
    return filename
