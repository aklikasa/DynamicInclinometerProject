"""R10-style one-click turntable connection; fail-closed hardware lifecycle.

Explicit operator acknowledgement at connection grants this connection's later
safe servo-off permission. No automatic homing/motion or emergency-stop bypass.
Do not treat an accepted DLL command as physical movement/stop proof.
"""
from __future__ import annotations
import math
from contextlib import contextmanager
import threading
import time
from .table_diagnostics import DIAG
from .angles import angle_delta_deg


class TableConnectionLifecycle:
    def __init__(self, table, disable_supervisor, busy):
        self.table = table
        self.disable_supervisor = disable_supervisor
        self.busy = busy
        self.lock = threading.RLock()
        self.consent_to_servo_off = False
        self.in_progress = False

    @contextmanager
    def _operation(self):
        with self.lock:
            if self.in_progress:
                raise RuntimeError('连接/关闭转台操作尚未完成，禁止并发操作')
            self._not_busy()
            self.in_progress=True
            try:
                yield
            finally:
                self.in_progress=False

    def _not_busy(self):
        if self.busy() or self.disable_supervisor.in_progress:
            raise RuntimeError('有转台任务/记录或伺服操作正在运行，请先结束任务并确认停车')

    @staticmethod
    def _fault_free(axes):
        for axis in (0, 2):
            s = axes[str(axis)]
            if any(s.get(f) for f in ('driver_fault','upper_limit','lower_limit','over_speed')):
                raise RuntimeError(f'轴{axis}存在告警/限位，拒绝自动使能或断使能')
            if s.get('enabled') and not s.get('healthy'):
                raise RuntimeError(f'轴{axis}使能状态与健康状态矛盾，请现场排查')
            if not math.isfinite(float(s['position_deg'])) or not math.isfinite(float(s['speed_dps'])):
                raise RuntimeError(f'轴{axis}位置/速度反馈无效')

    def _stationary_observed(self, seconds=.7):
        # Observe actual encoder changes, not just a mode/in-place bit.
        evidence = self.disable_supervisor._sample_stop(0,seconds)
        self._fault_free(evidence['axes'])
        return evidence

    def connect(self,port,baudrate=115200,*,operator_confirmed=False,load_secured=False):
        if operator_confirmed is not True or load_secured is not True:
            raise RuntimeError('连接并自动使能前，须确认现场有人监护且负载在断使能后有独立机械支撑')
        with self._operation():
            if self.table.connected:
                raise RuntimeError('转台已经连接；要更换串口请先点击「关闭转台」')
            # Bind prior consent BEFORE OpenPort: if DLL opens the port but
            # initial feedback fails, connection is retained for safe recovery.
            self.consent_to_servo_off=True
            try:
                self.table.connect(port,baudrate)
                # Initial DLL reads may be all zeros while feedback initializes.
                # Wait for real health/zero/enable evidence; never infer it from 0°.
                deadline=time.monotonic()+5
                while True:
                    feedback=self.table.read_status();self._fault_free(feedback['axes'])
                    if all(any(feedback['axes'][str(a)].get(k) for k in ('healthy','zeroed','enabled')) for a in (0,2)):break
                    if time.monotonic()>=deadline:raise RuntimeError('DLL反馈未就绪，保持连接且未发送使能')
                    time.sleep(.15)
                self._stationary_observed(.6)
                for axis in (0,2):
                    self._not_busy()
                    status=self.table.read_status();self._fault_free(status['axes'])
                    s=status['axes'][str(axis)]
                    if not s['enabled']:
                        DIAG.record('connect_auto_enable',f'连接后自动使能轴{axis}',axis=axis)
                        self.table.enable_axis(axis)
                        time.sleep(.15)
                    deadline=time.monotonic()+8.0
                    while True:
                        feedback=self.table.read_status();self._fault_free(feedback['axes'])
                        s=feedback['axes'][str(axis)]
                        if s['enabled'] and s['healthy']:break
                        if time.monotonic()>=deadline:
                            raise RuntimeError(f'轴{axis}自动使能未获得使能位和健康反馈（8秒）')
                        time.sleep(.2)
                time.sleep(.25)
                verified=self.table.read_status()
                self._fault_free(verified['axes'])
                if not all(verified['axes'][str(a)]['enabled'] and verified['axes'][str(a)]['healthy'] for a in (0,2)):
                    raise RuntimeError('连接后双轴使能反馈验证失败')
                DIAG.record('connect_auto_enable_confirmed','通信打开且内外轴自动使能均已确认',port=port)
                return {**verified,'auto_enabled_confirmed':True,'lifecycle':'connected_enabled'}
            except Exception as exc:
                # KEEP port open and preserve servo holding torque. Never
                # silently close/disenable on partial enable or failed feedback.
                if not self.table.connected:self.consent_to_servo_off=False
                DIAG.record('connect_enable_failed','自动使能失败；若COM已打开则保持通信以便安全排查',error=str(exc))
                detail=('连接已打开，但自动使能未完成；通信保留、未断使能。' if self.table.connected else '串口未能打开，未执行任何使能。')
                raise RuntimeError(detail+str(exc)) from exc

    def disconnect(self):
        with self._operation():
            if not self.table.connected:
                self.consent_to_servo_off=False
                return {'connected':False,'already_disconnected':True}
            if not self.consent_to_servo_off:
                raise RuntimeError('该连接未取得安全断使能授权；不能直接断开通信。请使用原控制器现场安全处置')
            # Read before sending any control commands. Faults and bad feedback
            # must fail closed; never lose the serial connection prematurely.
            state=self.table.read_status();self._fault_free(state['axes'])
            enabled=[a for a in (0,2) if state['axes'][str(a)]['enabled']]
            if enabled:
                DIAG.record('disconnect_stop','关闭转台前先发送双轴STOP并检查实际位置',enabled_axes=enabled)
                self.table.stop()
                if len(enabled)==2:
                    if self.table.stopped_verified(timeout=20) is not True:
                        raise RuntimeError('双轴STOP后没有得到20秒内物理停车确认；禁止断使能和关闭COM，请使用实体急停')
                else:
                    # Table.stopped_verified expects both servos healthy; if
                    # already partially disabled, sample both axes directly.
                    self._stationary_observed(1.4)
            else:
                DIAG.record('disconnect_already_disabled','两轴未使能，核查静止后关闭通信')
            self._stationary_observed(1.0)
            # Vendor DLL only supplies per-axis SetAxisDisable(axis). To
            # satisfy one-click dual-axis shutdown, issue the two commands
            # back-to-back with NO intervening per-axis confirmation waits.
            # This is nearly simultaneous in SOFTWARE, not a hardware-atomic
            # broadcast; mechanical support is required before starting.
            statuses=self.table.read_status();self._fault_free(statuses['axes'])
            to_disable=[axis for axis in (0,2) if statuses['axes'][str(axis)]['enabled']]
            for axis in to_disable:
                self.table.disable_axis(axis)
            # Both commands have been issued; now VERIFY each actual flag.
            deadline=time.monotonic()+4.0
            confirmed={axis:False for axis in (0,2)}
            while True:
                feedback=self.table.read_status()
                self._fault_free(feedback['axes'])
                for axis in (0,2):
                    confirmed[axis]=not feedback['axes'][str(axis)]['enabled']
                if all(confirmed.values()):break
                if time.monotonic()>=deadline:
                    raise RuntimeError('关闭已发双轴断使能命令，但未能同时确认两轴使能位清零；保留通信并请现场检查')
                time.sleep(.12)
            results=[{'axis':axis,'command_sent':axis in to_disable,'confirmed_disabled':True} for axis in (0,2)]
            # After disable, also check for drift rather than assuming the
            # safety of loads that have lost motor holding torque.
            before=self.table.read_status();self._fault_free(before['axes'])
            time.sleep(.35)
            after=self.table.read_status();self._fault_free(after['axes'])
            for axis in (0,2):
                b=before['axes'][str(axis)];a=after['axes'][str(axis)]
                if a['enabled']:
                    raise RuntimeError(f'轴{axis}反馈仍使能，禁止断开通信')
                if abs(angle_delta_deg(a['position_deg'],b['position_deg']))>.02 or abs(a['speed_dps'])>.06:
                    raise RuntimeError(f'断使能后轴{axis}出现位置漂移或速度异常；通信保留，请现场检查支撑')
            self.table.disconnect()
            self.consent_to_servo_off=False
            DIAG.record('disconnect_complete','两轴STOP、反馈静止、断使能、断使能反馈、位置复查后关闭COM')
            return {'connected':False,'stopped_verified':True,'disabled_verified':True,'disable_results':results}
