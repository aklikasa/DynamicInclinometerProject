"""Causal gap handling for measured (but imperfectly timestamped) samples.
No fabricated samples, no reference, no future beyond the newly received sample.
Prediction across missing data remains degraded and cannot qualify accuracy.
"""
import math
from .fusion import AccelOnly, GyroOnly, Mahony, Madgwick, integrate, emit, create_filter
from .lever3d import Lever3DFusion
from .gyro_anchor import GyroAnchor

SHORT_GAP_S = .010
LONG_GAP_S = .050
MAX_BRIDGE_S = .400


def advance(name, filt, params, calibrated, a, g, dt, *, protect=True):
    """Return (filter, output, action). For an unknown gap, propagate gyro only
    using the two *received* endpoint rates. Skip all ACC corrections on that
    interval, preserving attitude and bias. This is not an observed trajectory.
    Unsupported algorithms retain conservative long-gap reset behavior.
    """
    action='normal'
    base=filt.base if isinstance(filt, Lever3DFusion) else filt
    prev=getattr(filt,'_v713_previous_g',None)
    if protect and dt>SHORT_GAP_S and not isinstance(filt,AccelOnly):
        supported=isinstance(base,(GyroOnly,Mahony,Madgwick,GyroAnchor))
        if supported and prev is not None and getattr(base,'q',None) is not None and dt<=MAX_BRIDGE_S and all(math.isfinite(x) for x in (*g,*prev)):
            # Mahony bias is stored as additive correction in rad/s. Preserve
            # the learned bias, but do not integrate ACC innovation across gaps.
            from .fusion import D
            bias=getattr(base,'bias',[0.,0.,0.])
            if isinstance(base,GyroAnchor):
                rate=[.5*(p+c)-b for p,c,b in zip(prev,g,bias)]
                base._clock+=dt
                base.static_elapsed=0.;base._clear_samples();base.stationary=False
                base.motion_hold_s=max(.75,base.motion_hold_s);base.moving=True
                base._last_gyro=list(g);base._last_a=list(a);base._omega_lp=None
                base._trust=0.;base._last_gap_s=dt
                if dt>LONG_GAP_S:base._rejected_gaps+=1
            else:rate=[.5*(p+c)+b*D for p,c,b in zip(prev,g,bias)]
            base.q=integrate(base.q,rate,dt)
            if isinstance(base,Mahony):base.previous=list(a)
            if isinstance(filt,Lever3DFusion):
                filt.corrector.t+=dt
                filt.corrector.reset_window()
                filt.corrector.gaps+=1
                filt.corrector.last_rotation=(0.,0.,0.)
                out=base._output() if isinstance(base,GyroAnchor) else emit(base.q,0.)
                out.update(lever_compensation_enabled=filt.corrector.enabled,lever_compensation_ready=False,
                           lever_gap_count=filt.corrector.gaps,lever_rot_acc_g=[0.,0.,0.])
            else:out=base._output() if isinstance(base,GyroAnchor) else emit(base.q,0.)
            filt._v713_previous_g=list(g)
            return filt,out,'gyro_bridge'
        if dt>LONG_GAP_S:
            filt=create_filter(name,params,calibrated=calibrated)
            dt=0.;action='reset'
    out=filt.update(a,g,dt)
    filt._v713_previous_g=list(g)
    return filt,out,action
