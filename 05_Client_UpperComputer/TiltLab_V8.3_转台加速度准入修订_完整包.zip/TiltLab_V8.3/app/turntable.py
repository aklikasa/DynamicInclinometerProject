"""Windows 2TD-600 DLL adapter, signatures from user's R10 project.
Motion commands are ONLY called from explicit operator-gated experiments.
Non-safety-rated software guards are not a substitute for hardware E-stop.
"""
import ctypes,math,os,threading,time
from pathlib import Path
from .table_diagnostics import DIAG
from .sway_envelope import verify_sway_motion
from .motion_profile_v728 import position_limits,position_speed_max,velocity_speed_max

class TableError(RuntimeError):pass

class Table2TD600:
    AXES=(0,2)  # R10 inner, outer.
    def __init__(self,dll=None):
        self.dll_path=Path(dll or Path(__file__).resolve().parent.parent/'drivers'/'2TD600.dll')
        self.dll=None;self.connected=False;self.lock=threading.RLock();self.port=None;self.last_stop_check=None;self.cached_status=None
    def _call(self,name,argtypes,restype,*args):
        if self.dll is None:raise TableError('2TD-600 DLL未加载')
        f=getattr(self.dll,name);f.argtypes=argtypes;f.restype=restype
        try:
            result=f(*args)
        except Exception as exc:
            DIAG.record('dll_exception',f'{name} 调用异常',function=name,args=[str(x) for x in args],exception=repr(exc))
            raise
        if not name.startswith('Get'):
            DIAG.record('dll_command',f'{name} 返回 {result}',function=name,args=[str(x) for x in args],return_value=str(result))
        return result
    def connect(self,port,baudrate=115200):
        if os.name!='nt':raise TableError('真实2TD600 DLL仅能在Windows上连接')
        if not 1<=int(port)<=256:raise TableError('请提供合法COM端口号（整数）')
        if not self.dll_path.is_file():raise TableError('未找到2TD600.dll')
        with self.lock:
            if self.connected:raise TableError("转台已经连接，须经过安全关闭流程才能重新连接")
            try:self.dll=ctypes.CDLL(str(self.dll_path))
            except Exception as e:raise TableError('DLL加载失败，请检查32/64位匹配：'+str(e))
            DIAG.record('connection','尝试连接转台',port=int(port),baudrate=int(baudrate))
            if self._call('OpenPort',[ctypes.c_int,ctypes.c_int],ctypes.c_int,int(port),int(baudrate))!=1:
                self.dll=None;raise TableError('2TD600 OpenPort返回失败')
            self.connected=True;self.port=int(port)
            try:
                DIAG.snapshot('connection',self.read_status(),'连接后的首帧DLL状态')
            except Exception as exc:
                # Keep COM connected: controller could already be enabled externally.
                raise TableError('已打开COM但读取状态失败；为避免误断使能保留连接：'+str(exc)) from exc
            return self.read_status()
    def disconnect(self):
        with self.lock:
            if self.dll:
                self._call('ClosePort',[],None)
            self.connected=False;self.port=None;self.dll=None;self.cached_status=None
            DIAG.record('connection','转台断开连接')
    def _int(self,name,axis):return int(self._call(name,[ctypes.c_int],ctypes.c_int,axis))
    def _float(self,name,axis):return float(self._call(name,[ctypes.c_int],ctypes.c_double,axis))
    def read_status(self):
        if not self.connected:raise TableError('转台未连接')
        with self.lock:
            axes={}
            for a in self.AXES:
                # Keep R10 read order (position/speed/mode first), while also
                # preserving each vendor status integer for diagnostics.
                pos_start=time.monotonic_ns();position=self._float('GetPosition',a);pos_end=time.monotonic_ns()
                speed=self._float('GetSpeed',a)
                mode=self._int('GetRunMode',a)
                # Retain all vendor DLL status bits so a zero/default response
                # can be diagnosed rather than hidden behind boolean labels.
                raw={
                    'enabled':self._int('GetAxisEnable',a),
                    'zeroed':self._int('GetAxisFindZero',a),
                    'healthy':self._int('GetAxisNormal',a),
                    'in_place':self._int('GetAxisMoveInPlace',a),
                    'upper_limit':self._int('GetAxisUpLimit',a),
                    'lower_limit':self._int('GetAxisDownLimit',a),
                    'driver_fault':self._int('GetAxisDriverFault',a),
                    'over_speed':self._int('GetAxisOverSpeed',a),
                }
                if any(v not in (0,1) for v in raw.values()):
                    DIAG.record('feedback_invalid',f'轴{a} DLL状态位非0/1',raw_flags=raw)
                    raise TableError(f'轴{a} DLL状态返回异常值：{raw}；禁止自动运动')
                axes[str(a)]={
                    'position_deg':position,'position_pc_mid_ns':(pos_start+pos_end)//2,'position_read_ms':(pos_end-pos_start)/1e6,
                    'speed_dps':speed,
                    'mode':mode,
                    **{k:bool(v) for k,v in raw.items()},
                    'raw_flags':raw,
                }
            result={'connected':True,'port':self.port,'axes':axes,'time_monotonic_ns':time.monotonic_ns()}
            self.cached_status=result
            return result
    def _ensure(self,axis):
        if axis not in self.AXES:raise TableError('只能使用R10双轴编号 0/2')
        status=self.read_status()
        s=status['axes'][str(axis)]
        if not s['enabled'] or not s['zeroed'] or not s['healthy'] or s['driver_fault'] or s['upper_limit'] or s['lower_limit'] or s['over_speed']:
            raise TableError('转台未通过就绪/回零/使能/限位/故障检查；禁止运动')
        return s
    def enable_axis(self,axis):
        """Original R10 DLL entry: SetAxisEnable(axis).  Return is not status proof."""
        with self.lock:
            if axis not in self.AXES or not self.connected:raise TableError('转台未连接或轴号无效')
            if self._call('SetAxisEnable',[ctypes.c_int],ctypes.c_int,axis)!=1:
                raise TableError(f'轴{axis}使能指令未被DLL接受')

    def disable_axis(self,axis):
        with self.lock:
            if axis not in self.AXES or not self.connected:raise TableError('转台未连接或轴号无效')
            if self._call('SetAxisDisable',[ctypes.c_int],ctypes.c_int,axis)!=1:
                raise TableError(f'轴{axis}断使能指令未被DLL接受')

    def find_zero(self,axis,speed=.5,accel=.5):
        """Mechanical finding zero, NOT the same as absolute-position move(0)."""
        if axis not in self.AXES or not(.1<=speed<=.5) or not(.1<=accel<=.5):
            raise TableError('首次联调找零限速0.1–0.5°/s，角加速度0.1–0.5°/s²')
        with self.lock:
            st=self.read_status()['axes'][str(axis)]
            if not st['enabled'] or not st['healthy'] or any(st[k] for k in ('driver_fault','upper_limit','lower_limit','over_speed')):
                raise TableError('转台找零前安全状态检查失败')
            if self._call('SetAxisFindZero',[ctypes.c_int,ctypes.c_double,ctypes.c_double],ctypes.c_int,axis,float(speed),float(accel))!=1:
                raise TableError(f'轴{axis}机械找零指令未被DLL接受')

    def move(self,axis,position,speed):
        with self.lock:
            self._ensure(axis)
            # Conservative research SOFTWARE boundaries, NOT certified safety limits.
            lo,hi=position_limits(axis)
            if not math.isfinite(position) or not lo<=position<=hi:
                raise TableError(f'轴{axis}目标超出已核验运动区间[{lo:g}, {hi:g}]°')
            if not math.isfinite(speed) or not .2<=speed<=position_speed_max():
                raise TableError(f'定位速度须在0.2–{position_speed_max():g}°/s')
            ok=self._call('SetAxisPosition',[ctypes.c_int,ctypes.c_double,ctypes.c_double],ctypes.c_int,axis,float(position),float(speed))
            if ok!=1:raise TableError('2TD600 SetAxisPosition未接受指令')
    def manual_position(self, axis, position, speed, mode='absolute'):
        """Operator-only motion: pass exact finite signed degrees to the vendor DLL.

        SetAxisPosition is ABSOLUTE. SetAxisOpposition is RELATIVE: a signed
        -800 means command an -800 degree displacement, not an -80 degree
        orientation. The DLL/controller decides whether it can execute it.
        No modulo or shortest-path transformation is applied to the command.
        Factory limit/fault flags are still checked; this is NOT safety-rated.
        """
        if mode not in ('absolute', 'relative'):
            raise TableError('手动位置模式必须为绝对或相对')
        if axis not in self.AXES:
            raise TableError('非法轴号')
        if not (math.isfinite(float(position)) and math.isfinite(float(speed))):
            raise TableError('角度和速度必须为有限数值')
        if float(speed) <= 0:
            raise TableError('位置运动速度必须大于0')
        name='SetAxisPosition' if mode=='absolute' else 'SetAxisOpposition'
        with self.lock:
            self._ensure(axis)
            code=self._call(name,[ctypes.c_int,ctypes.c_double,ctypes.c_double],
                            ctypes.c_int,axis,float(position),float(speed))
            if code!=1:
                raise TableError(f'{name} 未被厂家控制器接受')

    def move_inner_test_orientation(self, target_deg, speed):
        """Special controlled inner-axis 0°/90° orientation for X/Y tests.

        This is NOT mechanical homing. Never rotate the inner axis unless the
        outer axis is at its established 0° and both servos are at rest.
        The on-site operator must have approved clearance for the full 0↔90° path.
        """
        from .angles import zero_distance_deg
        with self.lock:
            if target_deg not in (0,90):
                raise TableError('内轴只允许定位测试方向0°或90°')
            if not math.isfinite(speed) or not .2<=speed<=position_speed_max():
                raise TableError(f'测试方向定位速度需在0.2–{position_speed_max():g}°/s内')
            inner=self._ensure(0)
            outer=self._ensure(2)
            if zero_distance_deg(outer['position_deg'])>.12 or abs(outer['speed_dps'])>.06:
                raise TableError('改变内轴方向前，外轴必须先回到0°并完全停止')
            if abs(inner['speed_dps'])>.06 or inner['mode'] not in (0,2,20) or outer['mode'] not in (0,2,20):
                raise TableError('两轴未静止，不能改变测试方向')
            ok=self._call('SetAxisPosition',[ctypes.c_int,ctypes.c_double,ctypes.c_double],ctypes.c_int,
                          0,float(target_deg),float(speed))
            if ok!=1:raise TableError('内轴0°/90°方向定位指令未被转台DLL接受')

    def move_inner_manual(self,target_deg,speed):
        """Inner axis positioning along the previously verified 0 to 90 degree test arc.

        Requires outer axis zero and BOTH axes healthy, homed and stationary.
        Do not infer unrestricted factory travel from this research installation.
        """
        from .angles import zero_distance_deg
        with self.lock:
            lo,hi=position_limits(0)
            if not (math.isfinite(target_deg) and lo<=target_deg<=hi):
                raise TableError(f'内轴手动目标超出已核验的运动区间[{lo:g}, {hi:g}]°')
            if not (math.isfinite(speed) and .2<=speed<=position_speed_max()):
                raise TableError(f'手动定位速度须为0.2–{position_speed_max():g}°/s')
            inner=self._ensure(0);outer=self._ensure(2)
            if zero_distance_deg(outer['position_deg'])>.12 or abs(outer['speed_dps'])>.06:
                raise TableError('内轴定位前外轴必须在0度静止')
            if abs(inner['speed_dps'])>.06 or inner['mode'] not in (0,2,20) or outer['mode'] not in (0,2,20):
                raise TableError('两轴必须静止后才能改变内轴角度')
            ok=self._call('SetAxisPosition',[ctypes.c_int,ctypes.c_double,ctypes.c_double],ctypes.c_int,0,float(target_deg),float(speed))
            if ok!=1:raise TableError('厂家DLL拒绝内轴定位命令')

    def velocity(self,axis,speed,accel):
        """Factory SetAxisVelocity(axis, signed_speed, accel), supervised by caller."""
        with self.lock:
            self._ensure(axis)
            if not (math.isfinite(speed) and speed != 0 and math.isfinite(accel) and .1<=accel<=5.):
                raise TableError('手动角速度须为非零有限数值，角加速度须在0.1–5°/s²；额定速度由厂家控制器核验')
            ok=self._call('SetAxisVelocity',[ctypes.c_int,ctypes.c_double,ctypes.c_double],ctypes.c_int,
                          axis,float(speed),float(accel))
            if ok!=1:raise TableError('2TD600 SetAxisVelocity未接受指令')

    def stop_axis(self,axis):
        """Single-axis vendor stop; active managed experiments use dual-axis STOP."""
        if axis not in self.AXES:raise TableError('非法轴号')
        with self.lock:
            if not self.connected:return
            if self._call('SetAxisStop',[ctypes.c_int],ctypes.c_int,axis)!=1:
                raise TableError(f'轴{axis}厂家STOP未接受；请使用实体急停')

    def sway(self,axis,amp,freq):
        with self.lock:
            self._ensure(axis)
            if not (math.isfinite(amp) and math.isfinite(freq) and .2<=amp<=20 and .01<=freq<=.8):
                raise TableError('摇摆指令幅度或频率无效（±0.2–20°，0.01–0.80Hz）')
            try:
                verify_sway_motion(amp,freq)
            except ValueError as exc:
                raise TableError(str(exc)) from exc
            ok=self._call('SetAxisSway',[ctypes.c_int,ctypes.c_double,ctypes.c_double],ctypes.c_int,axis,float(amp),float(freq))
            if ok!=1:raise TableError('2TD600 SetAxisSway未接受指令')
    def stop(self):
        if not self.connected:return
        with self.lock:
            faults=[]
            for a in self.AXES:
                try:
                    if self._call('SetAxisStop',[ctypes.c_int],ctypes.c_int,a)!=1:faults.append(a)
                except Exception:faults.append(a)
            if faults:raise TableError(f'向轴{faults}发送停止指令失败，请立即使用硬件急停')
    def stopped_verified(self,timeout=20):
        """Fail-closed position/speed/mode verification after vendor STOP.

        An accepted SetAxisStop is not a proof of stopping: on a real device
        we observed mode=20 while the encoder continued +/-5 degree oscillation.
        Record every feedback frame. If physical encoder motion persists after
        2.5 seconds, issue ONE additional normal vendor STOP, then keep observing
        up to 20 seconds. Never send a new motion, home or disable command here.
        """
        if not self.connected:raise TableError('转台未连接，无法确认已停止')
        timeout=float(timeout)
        if not math.isfinite(timeout) or timeout<=0 or timeout>120:
            raise ValueError('停车确认时间必须介于0与120秒之间')
        start=time.monotonic();deadline=start+timeout
        records=[];retries=0;stable=0;last_positions=None
        try:
            while time.monotonic()<deadline:
                status=self.read_status();axes=status['axes']
                record={'elapsed_s':round(time.monotonic()-start,3),
                        'axes':{str(a):{k:axes[str(a)].get(k) for k in (
                          'position_deg','speed_dps','mode','in_place','healthy',
                          'driver_fault','upper_limit','lower_limit','over_speed')}
                          for a in self.AXES}}
                records.append(record)
                # Never trust mode=20 or an in-place flag alone. A good stop
                # needs position stability across multiple consecutive reads.
                positions={a:float(axes[str(a)]['position_deg']) for a in self.AXES}
                position_stable=(last_positions is not None and
                    all(abs((positions[a]-last_positions[a]+180)%360-180)<.015
                        for a in self.AXES))
                last_positions=positions
                feedback_ok=all(
                    math.isfinite(float(axes[str(a)]['speed_dps'])) and
                    abs(float(axes[str(a)]['speed_dps']))<.06 and
                    int(axes[str(a)]['mode']) in (0,2,20) and
                    axes[str(a)].get('healthy',False) and
                    not any(axes[str(a)].get(k) for k in (
                        'driver_fault','upper_limit','lower_limit','over_speed'))
                    for a in self.AXES)
                stable=stable+1 if position_stable and feedback_ok else 0
                if stable>=3:
                    self.last_stop_check={'verified':True,'samples':records,
                        'stop_retries':retries,'reason':'双轴位置连续稳定，DLL速度与模式满足停止条件'}
                    DIAG.record('stop_verification','DLL反馈确认双轴已停止',**self.last_stop_check)
                    return True
                # A single retry only if the encoder demonstrably keeps moving.
                # A stale non-zero DLL speed with a static encoder does NOT
                # trigger repeated motion/control commands.
                elapsed=time.monotonic()-start
                if retries==0 and timeout>=3.5 and elapsed>=2.5 and len(records)>=5:
                    recent=records[-7:]
                    moved={a:sum(abs((float(b['axes'][str(a)]['position_deg'])-
                                     float(c['axes'][str(a)]['position_deg'])+180)%360-180)
                             for c,b in zip(recent,recent[1:])) for a in self.AXES}
                    if any(moved[a]>.30 for a in self.AXES):
                        DIAG.record('stop_retry','首次停车后外轴/内轴位置仍在变化，重发厂家STOP一次',
                                    elapsed_s=round(elapsed,3),
                                    position_travel_deg={str(a):round(moved[a],4) for a in self.AXES},
                                    feedback=record['axes'])
                        self.stop()  # normal vendor SetAxisStop on both axes
                        retries=1;stable=0
                time.sleep(.15)
        except Exception as exc:
            self.last_stop_check={'verified':False,'samples':records,'stop_retries':retries,
                'reason':'停车确认期间DLL反馈或停车重试失败：'+repr(exc)}
            DIAG.record('stop_verification_failed','停车确认期间反馈读取或停车重试失败',**self.last_stop_check)
            raise
        self.last_stop_check={'verified':False,'samples':records,'stop_retries':retries,
                              'reason':f'{timeout:g}秒超时：速度/位置稳定性/运行模式未全部满足；不得自动继续实验'}
        DIAG.record('stop_verification_failed','停车未获DLL双轴状态确认',**self.last_stop_check)
        return False

TABLE=Table2TD600()
