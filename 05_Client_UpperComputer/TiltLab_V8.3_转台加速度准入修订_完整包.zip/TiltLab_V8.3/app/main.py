"""Localhost-only FastAPI host for dynamic inclinometer research workstation."""
import csv,io,json,os,datetime,asyncio,re,uuid,threading,zipfile,time,hashlib
from dataclasses import asdict
from pathlib import Path
from fastapi import FastAPI,HTTPException,WebSocket,WebSocketDisconnect,UploadFile,File
from fastapi.responses import FileResponse,HTMLResponse,Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel,Field
from .engine import ENGINE,ROOT,RECORD_DIR,SETTINGS_FILE
from .devices import list_ports
from .analysis import EXPERIMENTS,run_experiment,calculate
from .fusion import FILTERS,Params
from .lever_identification import bundles,identify,MAX_BYTES
from .calibration import scan
from .turntable import TABLE
from .sway_envelope import SWAY_LIMITS
from .manual_axis_control import GuardedManualAxis
from .native_axis_console_v727 import NativeAxisConsole
from .table_diagnostics import DIAG
from .table_prepare import TablePreparation
from .auto_dynamic import AutoDynamicWorkflow
from .table_monitor import TableMonitor
from .live_experiment import HARDWARE_TEST
from .dynamic_experiment import DynamicExperiment
from .rs422_feedback import ReadOnlyFeedback422
from .axis_static import StaticThreePoint
from .disable_supervisor import DisableSupervisor
from .table_connection_lifecycle import TableConnectionLifecycle

WEB=ROOT/'web';REPORT_DIR=ROOT/'data'/'reports';REPORT_DIR.mkdir(exist_ok=True,parents=True)
app=FastAPI(title='Dynamic Tilt Lab',version='8.3.0',docs_url='/api/docs',redoc_url=None)
app.mount('/assets',StaticFiles(directory=WEB),name='assets')
class SourceArgs(BaseModel):
    source:str='serial';port:str='';baudrate:int=1500000;address:int=1;mode:str='sine'
class ConfigArgs(BaseModel):
    algorithm:str|None=None;params:dict|None=None
class PipelineArgs(BaseModel):
    mode:str
class StabilityArgs(BaseModel):
    duration_s:int=30
class FolderArgs(BaseModel):path:str;source_kind:str='local'
class ModeArgs(BaseModel):mode:str
class InspectArgs(BaseModel):path:str;serial:str;mode:str='ambient'
class TestArgs(BaseModel):id:str;fs:int=200
class TableConnectArgs(BaseModel):
    port:int;baudrate:int=115200;operator_confirmed:bool=False;load_secured:bool=False
class TableMonitorArgs(BaseModel):interval_ms:int=100
class ManualPreflightArgs(BaseModel):
    axis:int
    target_deg:float
    speed_dps:float=10.0
    position_mode:str='absolute' 
class NativeAxisCommandArgs(BaseModel):
    axis:int
    mode:str
    speed_dps:float=10.0
    accel_dps2:float=.5
    amplitude_deg:float=5.0
    frequency_hz:float=.3
    duration_s:float=10.0
class NativeAxisArgs(BaseModel):axis:int
class NativeAxisDisableArgs(BaseModel):
    axis:int
    load_secured:bool=False
class ManualStartArgs(BaseModel):
    token:str
    operator_confirmed:bool=False
class PrepareStartArgs(BaseModel):token:str;acknowledged:bool=False;zero_speed_dps:float=2.0
class AutoSpeedArgs(BaseModel):zero_speed_dps:float
class MountCalibrationArgs(BaseModel):
    zero_speed_dps:float=2.0;static_limit_deg:float=.1
    sign:int=1;pitch_sign:int=1
    acknowledged:bool=False;fixture_confirmed:bool=False;load_secured:bool=False
class OneClickArgs(BaseModel):
    axis:int=2;output:str='roll';sign:int=1
    amplitude_deg:float=2.0;frequency_hz:float=.05;cycles:int=3
    zero_speed_dps:float=2.0;acknowledged:bool=False
    mounting_mode:str='x_outer';fixture_confirmed:bool=False;pitch_sign:int=1
    static_before_dynamic:bool=False;static_limit_deg:float=.1;static_stop_on_fail:bool=True
    auto_static_align:bool=False;pre_sway_axis_check:bool=False
    research_diagnostics:bool=False
    pre_research:bool=False;pre_research_seconds:int=60;research_optimize:bool=False
    static_position_speed_dps:float|None=None
TABLE_MONITOR=TableMonitor(TABLE,ENGINE,REPORT_DIR)
DYNAMIC_TEST=DynamicExperiment(TABLE,ENGINE,REPORT_DIR)
TABLE_PREP=TablePreparation(TABLE,TABLE_MONITOR,DYNAMIC_TEST,HARDWARE_TEST)
AUTO_TEST=AutoDynamicWorkflow(TABLE,ENGINE,TABLE_PREP,DYNAMIC_TEST,TABLE_MONITOR,HARDWARE_TEST)
NATIVE_FEEDBACK=ReadOnlyFeedback422(REPORT_DIR,TABLE)
DYNAMIC_TEST.native_feedback=NATIVE_FEEDBACK
STATIC_AXIS=StaticThreePoint(TABLE,ENGINE,REPORT_DIR)
DISABLE_MANAGER=DisableSupervisor(TABLE,lambda: AUTO_TEST.running or TABLE_PREP.running or DYNAMIC_TEST.running or HARDWARE_TEST.running or TABLE_MONITOR.running or MANUAL.running or CONSOLE.running)
AUTO_TEST.disable_supervisor=DISABLE_MANAGER
TABLE_LIFECYCLE=TableConnectionLifecycle(TABLE,DISABLE_MANAGER,
    lambda: AUTO_TEST.running or TABLE_PREP.running or DYNAMIC_TEST.running or
            HARDWARE_TEST.running or TABLE_MONITOR.running or NATIVE_FEEDBACK.running or MANUAL.running or CONSOLE.running)
MANUAL=GuardedManualAxis(TABLE,lambda: AUTO_TEST.running or TABLE_PREP.running or
    DYNAMIC_TEST.running or HARDWARE_TEST.running or TABLE_MONITOR.running or
    TABLE_LIFECYCLE.in_progress or DISABLE_MANAGER.in_progress or
    FACTORY.active or FACTORY.safety_latched or CONSOLE.running or CONSOLE.safety_latched)
CONSOLE=NativeAxisConsole(TABLE,lambda: AUTO_TEST.running or TABLE_PREP.running or
    DYNAMIC_TEST.running or HARDWARE_TEST.running or TABLE_MONITOR.running or
    TABLE_LIFECYCLE.in_progress or DISABLE_MANAGER.in_progress or MANUAL.running or
    MANUAL.safety_latched or FACTORY.active or FACTORY.safety_latched,
    admission_locks=(MANUAL.lock,DISABLE_MANAGER.lock))

def auto_busy():return AUTO_TEST.running or TABLE_LIFECYCLE.in_progress or FACTORY.active or FACTORY.safety_latched or MANUAL.running or MANUAL.safety_latched or CONSOLE.running or CONSOLE.safety_latched
class HardwareTestArgs(BaseModel):axis:int=0;output:str='roll';acknowledged:bool=False
class DynamicArgs(BaseModel):
    axis:int=2;output:str='roll';sign:int=1;amplitude_deg:float=2.;frequency_hz:float=.05;cycles:int=3
    mounting_mode:str='x_outer';fixture_confirmed:bool=False
class DynamicStartArgs(BaseModel):token:str;acknowledged:bool=False
class NativeFeedbackStartArgs(BaseModel):port:str;baudrate:int=921600;byte_order:str='little'
class AxisResetArgs(BaseModel):direction:str='roll'
class AxisCaptureArgs(BaseModel):point:int;confirmed:bool=False
class DisablePreviewArgs(BaseModel):axis:int
class DisableConfirmArgs(BaseModel):axis:int;token:str;operator_confirmed:bool=False;load_secured:bool=False

@app.get('/')
def home():return FileResponse(WEB/'index.html',headers={'Cache-Control':'no-store, max-age=0'})
@app.get('/api/meta')
def meta():return {'version':'8.3.0','algorithms':[{'id':k,'name':v[0]}for k,v in FILTERS.items()],
                   'experiments':[],
                   'ports':list_ports(),'hardware_available':False,'default_connection':{'transport':'RS485','baudrate':1500000,'address':1},'simulation_enabled':False,'sway_envelope':SWAY_LIMITS,'ui_revision':'V8.3.0 offline-first, selected realtime, independent accordion, native COM'}
@app.get('/api/status')
def status(history:bool=False):return ENGINE.status(history)

@app.get('/api/timebase/health')
def timebase_health():
    """Lightweight read-only hardware pipeline snapshot for supervised diagnosis.

    No serial or DLL reads, no curve analysis, no motion, and no reference input.
    Does not change timebase/queues/watchdog thresholds.
    """
    return {'read_pc_monotonic_ns':time.monotonic_ns(),
            'running':ENGINE.running,'connected':ENGINE.connected,
            'uid':ENGINE.uid,'cal_status':ENGINE.cal_status,
            'algorithm':ENGINE.active,'sample_rate_hz':ENGINE.actual_rate_hz,
            'pipeline':ENGINE.pipeline_status()}

@app.get('/api/pcb/link-diagnostics')
def pcb_link_diagnostics():
    """Read-only server-vs-serial evidence; no reconnect and no hardware reads."""
    p=ENGINE.pipeline_status()
    return {'server_alive':True,'pcb_connected':ENGINE.connected,
            'acquisition_running':ENGINE.running,'uid':ENGINE.uid,
            'pipeline_error':p.get('error'),'watchdog':p.get('watchdog'),
            'poll_count':p.get('poll_count'),'empty_polls':p.get('empty_polls'),
            'raw_file':p.get('raw_file'),'poll_file':p.get('poll_file'),
            'note':'网页WebSocket断开不代表PCB串口掉线。此接口只读，不自动重连或改变看门狗门槛。'}

@app.get('/api/ports')
def ports():return {'ports':list_ports()}
@app.post('/api/start')
def start(p:SourceArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线杆臂辨识正在执行，请先完成')
    if DYNAMIC_TEST.running or auto_busy():raise HTTPException(409,'动态测试中禁止重连IMU，请先停车')
    if p.source!='serial':raise HTTPException(403,'实机版已禁用模拟数据源，请连接RS485设备或使用CSV回放')
    try:return ENGINE.start(p.source,p.port,p.baudrate,p.address,p.mode)
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/stop')
def stop():
    if DYNAMIC_TEST.running or auto_busy():raise HTTPException(409,'动态测试中请先按“立即停车”，不能直接断开IMU')
    ENGINE.stop();return ENGINE.status()
@app.post('/api/pipeline')
def pipeline(p:PipelineArgs):
    if DYNAMIC_TEST.running or auto_busy() or TABLE_PREP.running or HARDWARE_TEST.running or TABLE_MONITOR.running:
        raise HTTPException(409,'实验期间不能切换采集模式')
    try:return ENGINE.set_pipeline_mode(p.mode)
    except ValueError as e:raise HTTPException(400,str(e))
@app.post('/api/config')
def configure(p:ConfigArgs):
    if DYNAMIC_TEST.running or auto_busy():raise HTTPException(409,'动态测试进行中，参数与算法配置锁定')
    if p.params and any(k.startswith('lever3_') and v!=getattr(ENGINE.params,k,None) for k,v in p.params.items()):
        raise HTTPException(400,'三维杆臂仅能通过独立验证后的标定模块应用或清除')
    try:ENGINE.configure(p.algorithm,p.params);return ENGINE.status()
    except Exception as e:raise HTTPException(400,str(e))
# Only one research fit at a time; no motor commands or DLL imports in solver.
LEVER_FIT_LOCK=threading.Lock()
LEVER_RESULT=None
class LeverApplyArgs(BaseModel):
    profile_id:str
    same_fixture_confirmed:bool=False

def lever_idle(require_imu_off=False):
    if (TABLE.connected or DYNAMIC_TEST.running or TABLE_PREP.running or HARDWARE_TEST.running
            or TABLE_MONITOR.running or NATIVE_FEEDBACK.running or auto_busy() or ENGINE.record_fp
            or (ENGINE.stability and ENGINE.stability.state=='running')):
        raise HTTPException(409,'请先安全关闭转台、停止录制及实验，再使用杆臂模块')
    if require_imu_off and ENGINE.running:raise HTTPException(409,'离线辨识请先停止IMU采集，避免影响实时线程')

@app.post('/api/lever-identify/fit')
def lever_fit(files:list[UploadFile]=File(...), validation:list[UploadFile]=File(default=[])):
    global LEVER_RESULT
    lever_idle(True)
    if not LEVER_FIT_LOCK.acquire(False):raise HTTPException(409,'已有杆臂辨识任务正在执行')
    try:
        lever_idle(True)
        LEVER_RESULT=None
        total=0
        def read_uploads(uploads):
            nonlocal total
            result=[]
            for f in uploads:
                data=f.file.read(MAX_BYTES-total+1);total+=len(data)
                if total>MAX_BYTES:raise ValueError('上传数据超过160MB，请缩小本次文件范围')
                result.append((f.filename or '',data))
            return result
        train=bundles(read_uploads(files));holdout=bundles(read_uploads(validation)) if validation else []
        result=identify(train,holdout);result['profile_id']=uuid.uuid4().hex
        result['created_at']=datetime.datetime.now().astimezone().isoformat()
        directory=ROOT/'data'/'lever_profiles';directory.mkdir(parents=True,exist_ok=True)
        path=directory/('lever_'+result['profile_id']+'.json')
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        LEVER_RESULT=result
        return result
    except (ValueError,KeyError,TypeError,ArithmeticError,OSError,RuntimeError,zipfile.BadZipFile) as e:
        raise HTTPException(400,'杆臂辨识失败：'+str(e))
    finally:LEVER_FIT_LOCK.release()

@app.post('/api/lever-identify/apply')
def lever_apply(p:LeverApplyArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'辨识计算尚未结束')
    lever_idle()
    with ENGINE.lock:
        r=LEVER_RESULT
        if not r or p.profile_id!=r['profile_id'] or not r['eligible_for_session_apply']:
            raise HTTPException(400,'当前候选未通过独立验证，禁止应用')
        if not p.same_fixture_confirmed:raise HTTPException(400,'须确认同一刚性装夹及共同旋转中心')
        if not ENGINE.connected or ENGINE.source!='serial' or ENGINE.cal_status!='matched' or ENGINE.cal_runtime_error:
            raise HTTPException(409,'请先连接UID匹配的真实IMU及有效厂标定，转台保持关闭')
        if ENGINE.uid!=r['uid'] or ENGINE.cal_mode!=r['calibration_mode'] or sorted((ENGINE.cal or {}).get('files',[]))!=r['calibration_files']:
            raise HTTPException(400,'当前UID、标定模式或标定文件与辨识数据不一致')
        params={**asdict(ENGINE.params),**{'lever3_'+j+'_cm':r['candidate_cm'][i] for i,j in enumerate('xyz')}}
        ENGINE.configure('lever3d',params)
        return ENGINE.status()

class LeverResearchArgs(BaseModel):
    same_fixture_confirmed:bool=False
    research_only_confirmed:bool=False

@app.post('/api/lever-identify/research-z')
def lever_research_z(p:LeverResearchArgs):
    lever_idle()
    with ENGINE.lock:
        if not p.same_fixture_confirmed or not p.research_only_confirmed:
            raise HTTPException(400,'需确认装夹未改变，并知悉该值只是研究候选')
        if not ENGINE.running or not ENGINE.connected or ENGINE.source!='serial' or ENGINE.uid!='DTS672516' or ENGINE.cal_mode!='ambient' or ENGINE.cal_status!='matched' or ENGINE.cal_runtime_error:
            raise HTTPException(400,'仅限 DTS672516 常温厂标定匹配的实际连接；转台须关闭')
        # Require the exact calibration snapshots from the successful ROLL replay.
        expected={'DTS672516_ACC_AMBIENT.json':'30573a1ac13841d017a2d7e9655365c7a52c4381cd9d51b2ee4be45e735e3cdf',
                  'DTS672516_GYRO_AMBIENT.json':'f3cc213950f864a204aa323d5de14446497992625d36f891f05d996f61abe5de'}
        try:actual={Path(f).name:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in (ENGINE.cal or {}).get('files',[])}
        except OSError:actual={}
        if actual!=expected:raise HTTPException(400,'厂标定文件与22:13 ROLL诊断包快照不同，禁止直接套用历史候选；可使用原独立辨识模块')
        ENGINE.configure('gyro_anchor3d',{'lever3_x_cm':0.,'lever3_y_cm':0.,'lever3_z_cm':19.51})
        ENGINE.log('V7.15研究候选：Z=19.51cm，X/Y未知暂置0；非独立三维标定，非验收')
        return ENGINE.status()


@app.post('/api/general-observer/prepare')
def general_observer_prepare(p:ConfigArgs):
    lever_idle()
    if p.algorithm not in ('gyro_anchor','gravity_observer'):raise HTTPException(400,'仅允许无杆臂基准或新研究观测器')
    with ENGINE.lock:
        if not ENGINE.running or ENGINE.source!='serial' or ENGINE.cal_status!='matched' or ENGINE.cal_runtime_error:
            raise HTTPException(409,'请先连接真实IMU并匹配厂标定；保持转台安全断开')
        ENGINE.clear_static_alignment()
        ENGINE.configure(p.algorithm,{'lever_z_cm':0.,**{'lever3_'+j+'_cm':0. for j in 'xyz'}})
        return ENGINE.status()

@app.post('/api/lever-identify/clear')
def lever_clear():
    lever_idle()
    ENGINE.configure({'adaptive3d':'adaptive','gyro_anchor3d':'gyro_anchor','lever3d':'madgwick'}.get(ENGINE.active),{'lever3_'+j+'_cm':0. for j in 'xyz'})
    return ENGINE.status()

@app.post('/api/stability/start')
def stability_start(p:StabilityArgs):
    if DYNAMIC_TEST.running or TABLE_PREP.running or auto_busy():raise HTTPException(409,'请先结束转台自动操作')
    try:return ENGINE.start_stability(p.duration_s)
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/stability/stop')
def stability_stop():return ENGINE.stop_stability()
@app.get('/api/stability/status')
def stability_status():return ENGINE.stability_status()

@app.get('/api/settings')
def read_settings():
    '''Persisted library source; a shared folder is a filesystem mount/UNC path, not an HTTP API.'''
    return {'calibration_folder':ENGINE.cal_root,'calibration_source':ENGINE.cal_source,
            'calibration_mode':ENGINE.cal_mode,'saved_in':str(SETTINGS_FILE),
            'supported_sources':['local','shared']}

@app.get('/api/calibration/paths')
def calibration_file_paths():
    """Read-only file-location aid. Never infer missing factory files or create substitutes."""
    matched=ENGINE.cal.get('files',[]) if ENGINE.cal and ENGINE.cal_status=='matched' else []
    return {'settings_file':str(SETTINGS_FILE),
            'calibration_folder':ENGINE.cal_root,
            'calibration_mode':ENGINE.cal_mode,
            'calibration_status':ENGINE.cal_status,
            'calibration_detail':ENGINE.cal_detail,
            'matched_factory_files':[str(x) for x in matched],
            'fixture_report_folder':str(REPORT_DIR),
            'mount_calibration_folder':str(ROOT/'data'/'mount_calibrations'),
            'message':('文件已按UID匹配，安装轴对齐另存在报告目录，绝不改写厂标定文件。'
                       if matched else '未匹配厂标定文件，请在原R10标定输出目录中定位ACC/GYRO JSON；本程序不生成伪造的厂标定。')}

# Exclusive R10 ambient worker; the parent does not own either COM during calibration.
from .automatic_factory import AutomaticFactory
FACTORY=AutomaticFactory(ENGINE,TABLE,TABLE_LIFECYCLE,AUTO_TEST,ROOT)
class FactoryHandoffArgs(BaseModel):
    acknowledged:bool=False
    load_secured:bool=False
    manual:bool=False

@app.middleware('http')
async def factory_exclusive(request,call_next):
    if (FACTORY.active or FACTORY.safety_latched) and request.method not in ('GET','HEAD','OPTIONS') and request.url.path not in ('/api/auto-dynamic/heartbeat','/api/auto-dynamic/abort','/api/turntable/stop','/api/turntable/manual/abort','/api/turntable/console/heartbeat','/api/turntable/console/stop-axis','/api/calibration/factory-handoff/cancel'):
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=409,content={'detail':'R10标定独占或停车未验证锁定；禁止新运动和断使能，现场核查后处理'})
    return await call_next(request)

@app.get('/api/calibration/factory-handoff')
def factory_handoff_status():return FACTORY.status()

@app.get('/api/calibration/factory-handoff/readiness')
def factory_handoff_readiness():
    return FACTORY.readiness()

@app.post('/api/calibration/factory-handoff/prepare')
def factory_handoff_prepare(p:FactoryHandoffArgs):
    if auto_busy() or DYNAMIC_TEST.running or TABLE_PREP.running or HARDWARE_TEST.running or TABLE_MONITOR.running or NATIVE_FEEDBACK.running or DISABLE_MANAGER.in_progress or LEVER_FIT_LOCK.locked():
        raise HTTPException(409,'请等待所有设备任务结束并确认停车')
    try:return FACTORY.start(p.acknowledged,p.load_secured,p.manual)
    except Exception as e:raise HTTPException(400,str(e))

@app.post('/api/calibration/factory-handoff/cancel')
def factory_handoff_cancel(p:FactoryHandoffArgs):
    if not p.acknowledged:raise HTTPException(400,'请确认中止标定')
    return FACTORY.abort()

@app.post('/api/calibration/folder')
def folder(p:FolderArgs):
    if DYNAMIC_TEST.running or auto_busy():raise HTTPException(409,'动态测试期间禁止切换标定目录')
    try:return ENGINE.set_folder(p.path,p.source_kind)
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/calibration/refresh')
def refresh():
    if DYNAMIC_TEST.running or auto_busy():raise HTTPException(409,'动态测试中禁止重载标定参数')
    try:return ENGINE.lookup_calibration()
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/calibration/mode')
def calibration_mode(p:ModeArgs):
    if DYNAMIC_TEST.running or auto_busy():raise HTTPException(409,'动态测试期间禁止改变补偿模式')
    try:return ENGINE.set_mode(p.mode)
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/calibration/inspect')
def calibration_inspect(p:InspectArgs):
    """Offline, read-only UID/SN preview; never applies calibration to a device."""
    sn=p.serial.upper().strip()
    if not re.fullmatch(r'DTS\d{6}',sn):raise HTTPException(400,'请输入DTS加六位数字的设备编号')
    if p.mode not in ('ambient','thermal'):raise HTTPException(400,'模式错误')
    try:
        result=scan(p.path,sn,mode=p.mode)
        return {**{k:v for k,v in result.items() if k not in ('acc','gyro')},'applied':False,
                'note':'此处仅预检查文件，并未连接实机或实际应用参数'}
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/calibration/browse')
def calibration_browse():
    """Native folder picker on same Windows PC as localhost service.
    Can fail on headless/noninteractive installations; manual path always works.
    """
    try:
        import tkinter as tk
        from tkinter import filedialog
        root=tk.Tk();root.withdraw();root.attributes('-topmost',True)
        try:
            selected=filedialog.askdirectory(parent=root,title='选择常温或温补标定文件夹',initialdir=ENGINE.cal_root or str(ROOT))
        finally:root.destroy()
        return {'path':selected or None}
    except Exception as e:raise HTTPException(400,'系统无法打开文件夹选择窗口，请直接输入路径：'+str(e))
@app.post('/api/record/start')
def record_start():
    if DYNAMIC_TEST.running or auto_busy():raise HTTPException(409,'动态测试有独立逐样本记录，请不要重复开启录制')
    try:return {'file':ENGINE.start_record()}
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/record/stop')
def record_stop():return {'file':ENGINE.stop_record()}
@app.get('/api/files')
def files():
    def info(root):return [{'name':p.name,'size':p.stat().st_size,'modified':datetime.datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec='seconds')}for p in sorted(root.glob('*'),key=lambda p:p.stat().st_mtime,reverse=True) if p.is_file()]
    return {'recordings':info(RECORD_DIR),'reports':info(REPORT_DIR)}
@app.get('/api/file/{kind}/{name}')
def download(kind:str,name:str):
    if kind not in ('recordings','reports') or Path(name).name!=name:raise HTTPException(400,'文件名不合法')
    p=(RECORD_DIR if kind=='recordings' else REPORT_DIR)/name
    if not p.is_file():raise HTTPException(404,'文件不存在')
    return FileResponse(p,filename=p.name,content_disposition_type='inline' if p.suffix.lower()=='.html' else 'attachment')
@app.get('/api/dynamic/bundle/{name}')
def dynamic_bundle(name:str):
    if DYNAMIC_TEST.running or auto_busy() or TABLE_PREP.running or HARDWARE_TEST.running or TABLE_MONITOR.running:
        raise HTTPException(409,'请在实验及停车流程结束后导出，避免干扰采集')
    from .diagnostic_bundle import make_bundle
    try:payload=make_bundle(REPORT_DIR,RECORD_DIR,name)
    except (ValueError,OSError,zipfile.BadZipFile) as exc:raise HTTPException(400,str(exc))
    from urllib.parse import quote
    return Response(payload,media_type='application/zip',headers={'Content-Disposition':"attachment; filename*=UTF-8''"+quote(Path(name).stem+'_DIAG.zip')})
@app.get('/api/dynamic/light-bundle/{name}')
def dynamic_light_bundle(name:str):
    _factory_idle()
    from .diagnostic_bundle import make_light_bundle
    try:payload=make_light_bundle(REPORT_DIR,name)
    except (ValueError,OSError,zipfile.BadZipFile) as exc:raise HTTPException(400,str(exc))
    from urllib.parse import quote
    return Response(payload,media_type='application/zip',headers={'Content-Disposition':"attachment; filename*=UTF-8''"+quote(Path(name).stem+'_LIGHT_DIAG.zip')})

@app.post('/api/experiment')
def experiment(p:TestArgs):
    raise HTTPException(403,'实机版已禁用合成实验。请使用真实2TD-600实验或CSV回放')
    try:
        # This is deliberately a synthetic offline test, NEVER physical table motion.
        result=run_experiment(p.id,ENGINE.params,fs=p.fs)
        ts=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        name=f'{ts}_{p.id}_SIMULATED'
        samples=result.pop('samples')
        (REPORT_DIR/(name+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        with (REPORT_DIR/(name+'.csv')).open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.DictWriter(f,fieldnames=samples[0].keys());w.writeheader();w.writerows(samples)
        ENGINE.log('模拟实验完成：'+result['title']+' / 非实机数据')
        return {'result':result,'report_file':name+'.json','data_file':name+'.csv'}
    except Exception as e:raise HTTPException(400,str(e))

@app.post('/api/calibration/mount/start')
def mount_calibration_start(p:MountCalibrationArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线杆臂辨识正在执行，请先完成')
    """One operator-authorized click; no sine sway, no factory ACC/GYRO overwrite."""
    if DISABLE_MANAGER.in_progress or TABLE_MONITOR.running or HARDWARE_TEST.running:
        raise HTTPException(409,'正在执行断使能或其他转台任务，请先结束')
    if p.acknowledged is not True or p.fixture_confirmed is not True or p.load_secured is not True:
        raise HTTPException(400,'请现场确认全行程、实体急停以及取消使能后的负载机械支撑')
    try:
        return AUTO_TEST.start(2,'both',p.sign,5.,.1,3,p.zero_speed_dps,True,
            mounting_mode='xy_sequential',fixture_confirmed=True,pitch_sign=p.pitch_sign,
            static_before_dynamic=True,static_limit_deg=p.static_limit_deg,static_stop_on_fail=True,
            auto_static_align=True,pre_sway_axis_check=True,calibration_only=True,load_secured=True)
    except Exception as exc:raise HTTPException(400,str(exc))

@app.get('/api/calibration/mount-file/{name}')
def mount_calibration_download(name:str):
    if Path(name).name!=name or not name.endswith('_MOUNT_ALIGNMENT.json'):
        raise HTTPException(400,'安装标定文件名不合法')
    p=ROOT/'data'/'mount_calibrations'/name
    if not p.is_file():raise HTTPException(404,'安装标定文件不存在')
    return FileResponse(p,filename=p.name)

@app.get('/api/auto-dynamic/settings')
def auto_settings():
    from .turntable_defaults import load_speed
    return {'zero_speed_dps':load_speed(),'speed_range_dps':[.2,5.]}

@app.post('/api/auto-dynamic/settings')
def auto_save_settings(p:AutoSpeedArgs):
    if auto_busy():raise HTTPException(409,'运行中不可更改回零速度')
    try:
        from .turntable_defaults import save_speed
        save_speed(p.zero_speed_dps)
        return {'zero_speed_dps':p.zero_speed_dps,'saved':True}
    except Exception as e:raise HTTPException(400,str(e))

@app.get('/api/auto-dynamic/status')
def auto_status():
    r=AUTO_TEST.status()
    if FACTORY.active:return {**r,'running':True,'state':'factory_calibration','error':'','factory':FACTORY.status()}
    return r

@app.post('/api/auto-dynamic/start')
def auto_start(p:OneClickArgs):
    if FACTORY.active:raise HTTPException(409,'常温自动标定正在执行')
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线杆臂辨识正在执行，请先完成')
    if DISABLE_MANAGER.in_progress:raise HTTPException(409,'伺服断使能过程中禁止启动运动')
    if TABLE_MONITOR.running or HARDWARE_TEST.running:
        raise HTTPException(409,'请先停止转台其他采集/实验任务')
    try:
        if not p.acknowledged:raise ValueError('需要先由现场操作人员确认运动安全')
        from .turntable_defaults import save_speed
        # Persist before creating a worker; a settings write failure must
        # never look like a failed command while the machine is already moving.
        save_speed(p.zero_speed_dps)
        return AUTO_TEST.start(p.axis,p.output,p.sign,p.amplitude_deg,p.frequency_hz,
                               p.cycles,p.zero_speed_dps,p.acknowledged,p.mounting_mode,p.fixture_confirmed,p.pitch_sign,
                               p.static_before_dynamic,p.static_limit_deg,p.static_stop_on_fail,p.auto_static_align,p.pre_sway_axis_check,
                               research_diagnostics=p.research_diagnostics,pre_research=p.pre_research,pre_research_seconds=p.pre_research_seconds,research_optimize=p.research_optimize,static_position_speed_dps=p.static_position_speed_dps)
    except Exception as e:raise HTTPException(400,str(e))

@app.post('/api/auto-dynamic/heartbeat')
def auto_heartbeat():
    if FACTORY.active:return FACTORY.heartbeat()
    try:return AUTO_TEST.heartbeat()
    except Exception as e:raise HTTPException(409,str(e))

@app.post('/api/auto-dynamic/abort')
def auto_abort():
    if FACTORY.active:return FACTORY.abort()
    try:return AUTO_TEST.abort()
    except Exception as e:raise HTTPException(500,'软件停车异常，立即使用实体急停：'+str(e))

@app.get('/api/turntable/native/status')
def native_status():return NATIVE_FEEDBACK.status()

@app.post('/api/turntable/native/start')
def native_start(p:NativeFeedbackStartArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线杆臂辨识正在执行，请先完成')
    if auto_busy() or DYNAMIC_TEST.running or TABLE_PREP.running or HARDWARE_TEST.running:
        raise HTTPException(409,'请在运动任务开始前连接厂家状态只读串口')
    # The same COM port must not be shared by the IMU or motion-control DLL.
    imu_port=getattr(getattr(ENGINE,'device',None),'port',None)
    if imu_port and str(imu_port).upper()==p.port.upper():
        raise HTTPException(400,'该串口已经被IMU占用，必须使用独立状态串口')
    try:return NATIVE_FEEDBACK.start(p.port,p.baudrate,p.byte_order)
    except Exception as exc:raise HTTPException(400,str(exc))

@app.get('/api/turntable/native/compare')
def native_compare():
    if auto_busy() or DYNAMIC_TEST.running or TABLE_PREP.running:
        raise HTTPException(409,'运动任务进行中，暂不额外读取DLL位置核对高速帧')
    r=NATIVE_FEEDBACK.status()
    if not TABLE.connected:raise HTTPException(400,'请先连接DLL转台，才能核对厂家原始状态帧')
    if not r['running'] or not r['latest'] or r['latest_age_ms'] is None or r['latest_age_ms']>300:
        raise HTTPException(400,'独立状态流未接收到300ms以内的新鲜帧，无法与DLL核对')
    dll=TABLE.read_status()['axes'];raw=r['latest']
    outer_error=raw['outer_position_deg']-dll['2']['position_deg']
    inner_error=raw['inner_position_deg']-dll['0']['position_deg']
    # Do not allow this read-only comparison to enable or authorize movement.
    return {'raw_outer_position_deg':raw['outer_position_deg'],
            'dll_outer_position_deg':dll['2']['position_deg'],
            'raw_inner_position_deg':raw['inner_position_deg'],
            'dll_inner_position_deg':dll['0']['position_deg'],
            'outer_disagreement_deg':round(outer_error,5),
            'inner_disagreement_deg':round(inner_error,5),
            'agreement_within_0_1deg':abs(outer_error)<.1 and abs(inner_error)<.1,
            'raw_frame_age_ms':r['latest_age_ms'],
            'status':'仅对比观察，不自动更改控制、安全状态或正式RMSE'}

@app.post('/api/turntable/native/stop')
def native_stop():
    # Independent read-only recorder is safe to stop even when a test is running.
    return NATIVE_FEEDBACK.stop()

@app.get('/api/axis-static/status')
def axis_static_status():return STATIC_AXIS.status()

@app.post('/api/axis-static/reset')
def axis_static_reset(p:AxisResetArgs):
    if auto_busy() or DYNAMIC_TEST.running or TABLE_PREP.running or HARDWARE_TEST.running:
        raise HTTPException(409,'转台运动任务进行中，无法启动静态检查')
    try:return STATIC_AXIS.reset(p.direction)
    except ValueError as exc:raise HTTPException(400,str(exc))

@app.post('/api/axis-static/capture')
def axis_static_capture(p:AxisCaptureArgs):
    if auto_busy() or DYNAMIC_TEST.running or TABLE_PREP.running or HARDWARE_TEST.running or TABLE_MONITOR.running:
        raise HTTPException(409,'其他运动或监控任务正在进行')
    try:return STATIC_AXIS.capture(p.point,p.confirmed)
    except Exception as exc:raise HTTPException(400,str(exc))

@app.get('/api/turntable/diagnostics')
def turntable_diagnostics(limit:int=80):
    return DIAG.recent(limit)
@app.get('/api/turntable/diagnostics/download')
def turntable_download_log():
    p=DIAG.file()
    if not p or not p.is_file():raise HTTPException(404,'本次服务还没有可用日志')
    return FileResponse(p,filename=p.name,media_type='application/x-ndjson')

@app.get('/api/turntable/prepare/status')
def table_prepare_status():return TABLE_PREP.status()
@app.post('/api/turntable/prepare/preflight')
def table_prepare_preflight():
    if auto_busy():raise HTTPException(409,'一键自动实验正在执行')
    try:return TABLE_PREP.preflight()
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/turntable/prepare/start')
def table_prepare_start(p:PrepareStartArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线杆臂辨识正在执行，请先完成')
    if DISABLE_MANAGER.in_progress:raise HTTPException(409,'伺服断使能过程中禁止发送使能/回零')
    if auto_busy():raise HTTPException(409,'一键自动实验正在执行')
    try:return TABLE_PREP.start(p.token,p.acknowledged,zero_speed_dps=p.zero_speed_dps)
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/turntable/prepare/enable')
def table_prepare_enable(p:PrepareStartArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线杆臂辨识正在执行，请先完成')
    if DISABLE_MANAGER.in_progress:raise HTTPException(409,'伺服断使能过程中禁止重新使能')
    if auto_busy():raise HTTPException(409,'一键自动实验正在执行')
    try:return TABLE_PREP.start(p.token,p.acknowledged,only_enable=True)
    except Exception as e:raise HTTPException(400,str(e))

class DirectPrepareArgs(BaseModel):
    zero_speed_dps:float=1.0

@app.post('/api/turntable/prepare/command')
def table_prepare_direct(p:DirectPrepareArgs):
    """One explicit maintenance click; original precheck, checks and worker retained."""
    if LEVER_FIT_LOCK.locked() or DISABLE_MANAGER.in_progress or auto_busy():
        raise HTTPException(409,'其他转台或离线任务正在执行')
    try:
        plan=TABLE_PREP.preflight()
        return TABLE_PREP.start(plan['token'],True,zero_speed_dps=p.zero_speed_dps)
    except Exception as e:raise HTTPException(409,str(e))

@app.post('/api/turntable/prepare/heartbeat')
def table_prepare_heartbeat():
    try:return TABLE_PREP.heartbeat()
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/turntable/prepare/abort')
def table_prepare_abort():
    if auto_busy():raise HTTPException(409,'请使用自动实验的统一停车按钮')
    try:return TABLE_PREP.abort()
    except Exception as e:raise HTTPException(500,'软件停止不可靠，请使用实体急停：'+str(e))

@app.post('/api/timebase/diagnose/latest')
def timebase_diagnose_latest():
    """Offline-only research phase comparison; never moves motors or changes captured CSV."""
    if auto_busy() or TABLE_PREP.running or DYNAMIC_TEST.running or HARDWARE_TEST.running or TABLE_MONITOR.running:
        raise HTTPException(409,'先结束所有运动并确认停车，再生成离线诊断报告')
    pairs=sorted(REPORT_DIR.glob('*_DYNAMIC_imu.csv'),key=lambda x:x.stat().st_mtime,reverse=True)
    pairs=[x for x in pairs if x.with_name(x.name.replace('_imu.csv','_table.csv')).is_file()]
    if not pairs:raise HTTPException(404,'报告目录中没有成对的动态IMU/转台CSV')
    import subprocess,sys
    script=ROOT/'tools'/'auto_timebase'/'diagnose.py'
    if not script.is_file():raise HTTPException(500,'自动诊断脚本未安装')
    dest=ROOT/'data'/'timebase_diagnostic'
    dest.mkdir(parents=True,exist_ok=True)
    try:
        result=subprocess.run([sys.executable,str(script),str(pairs[0]),'--out',str(dest)],
                              capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180)
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout)[-1600:])
        reports=sorted(dest.glob('同次采集_算法时间诊断_*.json'),key=lambda x:x.stat().st_mtime,reverse=True)
        if not reports:raise RuntimeError('脚本没有生成报告')
        doc=json.loads(reports[0].read_text(encoding='utf-8'))
        return {'ok':True,'source':pairs[0].name,'report_json':reports[0].name,
                'report_txt':reports[0].with_suffix('.txt').name,
                'results':doc.get('results',[]),
                'warning':'表观相位研究诊断；未做时间移位，非硬件同步证明、非第三方验收'}
    except Exception as e:raise HTTPException(500,'离线诊断失败：'+str(e))

@app.get('/api/timebase/diagnose/download/{filename}')
def timebase_diagnose_download(filename:str):
    if Path(filename).name!=filename or not filename.startswith('同次采集_算法时间诊断_') or not filename.endswith(('.txt','.json')):
        raise HTTPException(400,'不允许的报告文件名')
    p=ROOT/'data'/'timebase_diagnostic'/filename
    if not p.is_file():raise HTTPException(404,'报告不存在')
    return FileResponse(p,filename=p.name)

@app.get('/api/turntable/console/status')
def native_axis_console_status():return CONSOLE.status()

@app.post('/api/turntable/console/enable')
def native_axis_console_enable(p:NativeAxisArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线分析任务正在执行')
    try:return CONSOLE.enable_axis(p.axis)
    except Exception as exc:raise HTTPException(409,str(exc))

@app.post('/api/turntable/console/disable')
def native_axis_console_disable(p:NativeAxisDisableArgs):
    if LEVER_FIT_LOCK.locked() or TABLE_LIFECYCLE.in_progress or CONSOLE.running or CONSOLE.safety_latched:
        raise HTTPException(409,'运动/关闭/故障状态下不能断使能')
    if p.load_secured is not True:
        raise HTTPException(400,'断使能前需确认负载有独立机械支撑')
    try:
        plan=DISABLE_MANAGER.preflight(p.axis)
        return DISABLE_MANAGER.disable(p.axis,plan['token'],operator_confirmed=True,load_secured=True)
    except Exception as exc:raise HTTPException(409,str(exc))

@app.post('/api/turntable/console/start')
def native_axis_console_start(p:NativeAxisCommandArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线分析任务正在执行')
    try:return CONSOLE.start(p.axis,p.mode,speed=p.speed_dps,accel=p.accel_dps2,
                amp=p.amplitude_deg,freq=p.frequency_hz,duration=p.duration_s)
    except Exception as exc:raise HTTPException(409,str(exc))

@app.post('/api/turntable/console/heartbeat')
def native_axis_console_heartbeat():
    try:return CONSOLE.heartbeat()
    except Exception as exc:raise HTTPException(409,str(exc))

@app.post('/api/turntable/console/stop-axis')
def native_axis_console_stop_axis(p:NativeAxisArgs):
    if p.axis not in (0,2):raise HTTPException(400,'轴号无效')
    if FACTORY.active or AUTO_TEST.running or HARDWARE_TEST.running or DYNAMIC_TEST.running or TABLE_PREP.running or MANUAL.running or CONSOLE.running:
        return table_stop()  # Managed tasks require unified dual-axis STOP.
    try:
        TABLE.stop_axis(p.axis)
        verified=TABLE.stopped_verified(timeout=20)
        return {'axis':p.axis,'command_sent':True,'stopped_verified':verified,
                'scope':'axis_only_stop_command_dual_axis_stop_feedback'}
    except Exception as exc:raise HTTPException(500,'停止命令失败，请使用实体急停：'+str(exc))

@app.get('/api/turntable/manual/status')
def manual_axis_status():return MANUAL.status()

@app.post('/api/turntable/manual/preflight')
def manual_axis_preflight(p:ManualPreflightArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线分析任务正在执行')
    try:return MANUAL.preflight(p.axis,p.target_deg,p.speed_dps,p.position_mode)
    except Exception as e:raise HTTPException(409,str(e))

@app.post('/api/turntable/manual/start')
def manual_axis_start(p:ManualStartArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线分析任务正在执行')
    try:return MANUAL.start(p.token,p.operator_confirmed)
    except Exception as e:raise HTTPException(409,str(e))

@app.post('/api/turntable/manual/command')
def manual_axis_direct_position(p:ManualPreflightArgs):
    """One explicit Run click; checks and 30s token verification remain atomic server-side."""
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线分析任务正在执行')
    try:
        plan=MANUAL.preflight(p.axis,p.target_deg,p.speed_dps,p.position_mode)
        return MANUAL.start(plan['token'],True)
    except Exception as e:raise HTTPException(409,str(e))

@app.post('/api/turntable/manual/heartbeat')
def manual_axis_heartbeat():
    try:return MANUAL.heartbeat()
    except Exception as e:raise HTTPException(409,str(e))

@app.post('/api/turntable/manual/abort')
def manual_axis_abort():
    try:return MANUAL.abort()
    except Exception as e:raise HTTPException(500,'停车指令故障，使用实体急停：'+str(e))

@app.get('/api/turntable/status')
def table_status(diagnose:bool=False):
    if not TABLE.connected:
        if diagnose:DIAG.record('manual_status','操作员尝试读取转台，但设备未连接')
        return {'connected':False,'hardware_test':HARDWARE_TEST.status(),'monitor':TABLE_MONITOR.status(False)}
    # Browser reads a cache while an authorized experiment owns fresh feedback.
    # Motion safety, STOP and preflight still call the DLL directly.
    if auto_busy() or DYNAMIC_TEST.running or TABLE_PREP.running or HARDWARE_TEST.running or TABLE_MONITOR.running or TABLE_LIFECYCLE.in_progress or MANUAL.running or CONSOLE.running:
        st=TABLE.cached_status or {'connected':True,'port':TABLE.port,'axes':{}}
        age=(time.monotonic_ns()-st['time_monotonic_ns'])/1e6 if st.get('time_monotonic_ns') else None
        return {**st,'display_cache_only':True,'display_cache_age_ms':age,'hardware_test':HARDWARE_TEST.status(),'monitor':TABLE_MONITOR.status(False)}
    try:
        st=TABLE.read_status()
        if diagnose:DIAG.snapshot('manual_status',st,'操作员手动读取转台DLL反馈')
        return {**st,'hardware_test':HARDWARE_TEST.status(),'monitor':TABLE_MONITOR.status(False)}
    except Exception as e:
        DIAG.record('feedback_read_failed','手动读取转台状态失败',exception=repr(e))
        raise HTTPException(400,str(e))
@app.post('/api/turntable/connect')
def table_connect(p:TableConnectArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线杆臂辨识正在执行，请先完成')
    native=NATIVE_FEEDBACK.status()
    if native['running'] and native.get('port','').upper().startswith('COM') and native['port'][3:].isdigit() and int(native['port'][3:])==p.port:
        raise HTTPException(409,'该COM端口已用于独立只读状态流，DLL控制串口必须另选')
    if DYNAMIC_TEST.running or TABLE_PREP.running or auto_busy():raise HTTPException(409,'转台自动操作期间禁止重连')
    if TABLE_MONITOR.running:raise HTTPException(409,'请先结束反馈记录再重新连接转台')
    try:return TABLE_LIFECYCLE.connect(p.port,p.baudrate,
        operator_confirmed=p.operator_confirmed,load_secured=p.load_secured)
    except Exception as e:raise HTTPException(409,str(e))
@app.post('/api/turntable/monitor/start')
def monitor_start(p:TableMonitorArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线杆臂辨识正在执行，请先完成')
    if DYNAMIC_TEST.running or TABLE_PREP.running or auto_busy():raise HTTPException(409,'转台自动操作期间不可开启记录')
    if HARDWARE_TEST.running:raise HTTPException(409,'自动运动实验期间不可开启本次只读采集')
    try:return TABLE_MONITOR.start(p.interval_ms)
    except Exception as e:raise HTTPException(400,str(e))

@app.post('/api/turntable/monitor/stop')
def monitor_stop():
    return TABLE_MONITOR.stop()

@app.get('/api/turntable/monitor/status')
def monitor_status():
    return TABLE_MONITOR.status()

@app.post('/api/turntable/stop')
def table_stop():
    if FACTORY.active:return FACTORY.abort()
    try:
        if AUTO_TEST.running:AUTO_TEST.abort()
        HARDWARE_TEST.cancel()
        if DYNAMIC_TEST.running:DYNAMIC_TEST.abort()
        if TABLE_PREP.running:TABLE_PREP.abort()
        if MANUAL.running:MANUAL.cancel.set()
        if CONSOLE.running:CONSOLE.cancel.set()
        TABLE.stop()
        return {'command_sent':True,'stopped_verified':TABLE.stopped_verified(timeout=20)}
    except Exception as e:raise HTTPException(400,'STOP FAILED，请使用硬件急停: '+str(e))
@app.post('/api/turntable/disable/preflight')
def turntable_disable_preflight(p:DisablePreviewArgs):
    if TABLE_LIFECYCLE.in_progress:raise HTTPException(409,'正在连接/关闭转台，禁止逐轴断使能')
    try:return DISABLE_MANAGER.preflight(p.axis)
    except Exception as e:raise HTTPException(409,str(e))

@app.post('/api/turntable/disable/confirm')
def turntable_disable_confirm(p:DisableConfirmArgs):
    if TABLE_LIFECYCLE.in_progress:raise HTTPException(409,'正在连接/关闭转台，禁止逐轴断使能')
    try:return DISABLE_MANAGER.disable(p.axis,p.token,p.operator_confirmed,p.load_secured)
    except Exception as e:raise HTTPException(409,str(e))

@app.post('/api/turntable/disconnect')
def table_disconnect(p:FactoryHandoffArgs):
    if p.acknowledged is not True or p.load_secured is not True:
        raise HTTPException(409,'必须本次重新确认独立机械支撑和现场安全；不能仅凭之前的连接授权断使能')
    if DYNAMIC_TEST.running or TABLE_PREP.running or auto_busy():raise HTTPException(409,'转台自动操作期间必须先停车并确认再断开')
    if TABLE_MONITOR.running:raise HTTPException(409,'请先停止转台反馈记录后断开')
    if HARDWARE_TEST.running:raise HTTPException(400,'自动实验运行中，请先停止并确认停车')
    try:return TABLE_LIFECYCLE.disconnect()
    except Exception as e:raise HTTPException(409,str(e))
@app.post('/api/hardware-test/start')
def hardware_test_start(p:HardwareTestArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线杆臂辨识正在执行，请先完成')
    if DISABLE_MANAGER.in_progress:raise HTTPException(409,'伺服断使能过程中禁止定位')
    if TABLE_PREP.running or auto_busy():raise HTTPException(409,'转台正在准备中，请先完成')
    if DYNAMIC_TEST.running or auto_busy():raise HTTPException(409,'动态测试运行中禁止启动静态运动实验')
    if TABLE_MONITOR.running:raise HTTPException(409,'请先结束转台反馈记录，避免在只读联调时启动运动实验')
    try:return HARDWARE_TEST.start(p.axis,p.output,p.acknowledged)
    except Exception as e:raise HTTPException(400,str(e))
@app.get('/api/hardware-test/status')
def hardware_test_status():return HARDWARE_TEST.status()
@app.post('/api/hardware-test/abort')
def hardware_test_abort():HARDWARE_TEST.cancel();return HARDWARE_TEST.status()
# Automatic dynamic test is a real motion API. Preflight alone sends NO commands.
@app.post('/api/dynamic/preflight')
def dynamic_preflight(p:DynamicArgs):
    if auto_busy():raise HTTPException(409,'一键自动实验正在执行')
    if TABLE_PREP.running or auto_busy():raise HTTPException(409,'转台正在使能/回零，请等待反馈确认')
    if TABLE_MONITOR.running or HARDWARE_TEST.running:
        raise HTTPException(409,'请先结束转台只读采集或静态运动测试')
    if ENGINE.record_fp:raise HTTPException(409,'请先结束常规IMU录制，动态实验使用独立数据文件')
    try:return DYNAMIC_TEST.preflight(p.axis,p.output,p.sign,p.amplitude_deg,p.frequency_hz,p.cycles,p.mounting_mode,p.fixture_confirmed)
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/dynamic/start')
def dynamic_start(p:DynamicStartArgs):
    if LEVER_FIT_LOCK.locked():raise HTTPException(409,'离线杆臂辨识正在执行，请先完成')
    if DISABLE_MANAGER.in_progress:raise HTTPException(409,'伺服断使能过程中禁止启动摇摆')
    if auto_busy():raise HTTPException(409,'一键自动实验正在执行')
    if TABLE_PREP.running or auto_busy():raise HTTPException(409,'转台正在准备中，禁止启动动态测试')
    if TABLE_MONITOR.running or HARDWARE_TEST.running:raise HTTPException(409,'转台已有其他任务')
    try:return DYNAMIC_TEST.start(p.token,p.acknowledged)
    except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/dynamic/heartbeat')
def dynamic_heartbeat():
    try:return DYNAMIC_TEST.heartbeat()
    except Exception as e:raise HTTPException(409,str(e))
@app.get('/api/dynamic/sst810-cases')
def dynamic_sst810_cases():
    from .sst810_plan import cases
    return {'source':'SST810用户提供的第三方测试报告，第3页，10组正弦测试条件',
            'cases':cases(), 'safety_note':'只读测试菜单。摇摆峰值角加速度由本机厂家已核验参数决定；未核验时沿用保守40°/s²，不可直接绕过；所有工况仍须现场安全确认。'}

@app.get('/api/dynamic/live-snapshot')
def dynamic_live_snapshot():
    # Lightweight observation only, not a synchronized accuracy measurement.
    with DYNAMIC_TEST.lock:
        running=DYNAMIC_TEST.running
        stage=DYNAMIC_TEST.state
        plan=dict(DYNAMIC_TEST.plan or {})
        feedback=dict(DYNAMIC_TEST.latest_feedback or {})
    with ENGINE.lock:
        mode=ENGINE.pipeline_mode
        latest=ENGINE.latest or {}
        imu_pose=latest.get('cal_factory') if mode=='realtime' else None
        imu_time=latest.get('host_est_ns')
        algorithm=ENGINE.active if mode=='realtime' else None
    return {'running':running,'state':stage,'mode':mode,'output':plan.get('output'),
            'reference_angle_deg':feedback.get('position_deg'),
            'reference_sign':plan.get('sign',1),
            'reference_speed_dps':feedback.get('speed_dps'),
            'imu_roll_deg':imu_pose.get('roll') if imu_pose else None,
            'imu_pitch_deg':imu_pose.get('pitch') if imu_pose else None,
            'reference_time_estimate':'PC DLL反馈（不与IMU硬件同步）',
            'imu_host_est_ns':imu_time,'algorithm':algorithm,
            'time_pc_ns':time.monotonic_ns(),
            'note':'实时曲线仅供现场观察；不用于0.05°精度验收。'}

@app.get('/api/dynamic/status')
def dynamic_status():return DYNAMIC_TEST.status()
@app.post('/api/dynamic/abort')
def dynamic_abort():
    if auto_busy():raise HTTPException(409,'请使用自动实验的统一停车按钮')
    try:return DYNAMIC_TEST.abort()
    except Exception as e:raise HTTPException(500,'软件停车未获确认，请使用现场硬件急停: '+str(e))

@app.post('/api/replay')
async def replay(file:UploadFile=File(...)):
    """Reprocess a CSV recording; no fake reference when column absent."""
    try:
        content=await file.read()
        if len(content)>35_000_000:raise ValueError('CSV超过35MB限制')
        from .fusion import create_filter
        from .calibration import apply
        text=content.decode('utf-8-sig')
        records=list(csv.DictReader(io.StringIO(text)))
        if not records:raise ValueError('CSV无行')
        raw_filter=create_filter(ENGINE.active,ENGINE.params,calibrated=False)
        cal_filter=create_filter(ENGINE.active,ENGINE.params,calibrated=True)
        recorded_uids={r.get('uid','').strip() for r in records if r.get('uid','').strip()}
        cal=ENGINE.cal if ENGINE.cal_status=='matched' and len(recorded_uids)==1 and ENGINE.uid in recorded_uids else None
        result=[];previous=None
        for i,r in enumerate(records[:250000]):
            t=float(r.get('t_s',r.get('t','nan')))
            acc=[float(r[f'acc_{v}_g']) for v in 'xyz']
            gyro=[float(r[f'gyro_{v}_dps']) for v in 'xyz']
            if not all(map(__import__('math').isfinite,[t,*acc,*gyro])):continue
            dt=0 if previous is None else t-previous;previous=t
            if dt<0 or dt>.5:raw_filter=create_filter(ENGINE.active,ENGINE.params,calibrated=False);cal_filter=create_filter(ENGINE.active,ENGINE.params,calibrated=True);dt=0
            raw=raw_filter.update(acc,gyro,dt)
            compensated=None
            if cal:
                try:
                    temp=float(r['temperature_c']) if r.get('temperature_c') else None
                    ca=apply(acc,cal['acc'],temp)
                    cg=apply(gyro,cal['gyro'],temp)
                    compensated=cal_filter.update(ca,cg,dt)
                except (ValueError,TypeError,ArithmeticError):
                    # Out-of-range temperature: keep raw result; do not extrapolate.
                    cal_filter=create_filter(ENGINE.active,ENGINE.params,calibrated=True)
            else:
                # Corrected columns can be replayed as recorded, but provenance is explicit.
                try:
                    ca=[float(r[f'acc_cal_{v}_g']) for v in 'xyz']
                    cg=[float(r[f'gyro_cal_{v}_dps']) for v in 'xyz']
                    compensated=cal_filter.update(ca,cg,dt)
                except (KeyError,ValueError):pass
            ref=None
            try:ref={'roll':float(r['ref_roll_deg']),'pitch':float(r['ref_pitch_deg'])}
            except (KeyError,ValueError):pass
            result.append({'t':t,'raw':raw,'cal':compensated,'ref':ref})
        good=[r for r in result if r['cal'] and r['ref']]
        metric={axis:calculate([r['cal'][axis] for r in good],[r['ref'][axis] for r in good]) for axis in ('roll','pitch')} if good else None
        # sample to keep response compact.
        stride=max(1,len(result)//1300)
        return {'name':file.filename,'rows':len(result),'algorithm':ENGINE.active,'calibration':ENGINE.cal_status,'calibration_mode':ENGINE.cal_mode,
                'reference_available':bool(good),'metrics':metric,'chart':result[::stride],
                'note':'对上传文件重新按逐样本时间差融合；只有文件含有参考角度时才计算绝对误差。'}
    except Exception as e:raise HTTPException(400,f'CSV回放失败: {e}')
@app.on_event('shutdown')
def shutdown_park_turntable():
    try:NATIVE_FEEDBACK.stop()
    except Exception:pass
    if FACTORY.active:FACTORY.abort()
    if AUTO_TEST.running:
        try:AUTO_TEST.abort()
        except Exception:pass
    # Best effort only; hardware E-stop must not depend on software lifecycle.
    if DYNAMIC_TEST.running or auto_busy():
        try:DYNAMIC_TEST.abort()
        except Exception:pass
    if TABLE_PREP.running:
        try:TABLE_PREP.abort()
        except Exception:pass

@app.websocket('/ws')
async def websocket(ws:WebSocket):
    await ws.accept()
    last_seq=-1
    try:
        while True:
            status=ENGINE.status(history=False)
            busy=DYNAMIC_TEST.running or auto_busy()
            delta,last_seq=ENGINE.stream_history(last_seq,display_stride=4 if busy else 1)
            status['chart_delta']=delta
            status['history_seq']=last_seq
            await ws.send_json(status)
            await asyncio.sleep(.25 if busy else .05)  # UI only; full-rate fusion and safety heartbeats unchanged.
    except WebSocketDisconnect:
        pass  # Browser closed normally; the PCB serial link is independent.
    except Exception as exc:
        # Diagnostics only. No motion or serial action is attempted here.
        print('[UI WebSocket] Closed: '+type(exc).__name__+': '+str(exc),flush=True)
