"""Post-STOP only, read-only diagnostics and combined report in a spawned process.
No table, engine or serial objects passed to the child. No time shifts or calibration changes.
"""
from __future__ import annotations
import datetime as dt
import html,json,os,time,zipfile
from pathlib import Path


def lower_priority():
    try:
        if os.name=='nt':
            import ctypes
            k=ctypes.windll.kernel32
            k.SetPriorityClass(k.GetCurrentProcess(),0x4000)
        else:os.nice(5)
    except (OSError,AttributeError):pass


def write_json(path,value):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');tmp.replace(path)


def local_file(folder,name):
    if not isinstance(name,str) or Path(name).name!=name:raise ValueError('报告文件名无效')
    p=folder/name
    if not p.is_file():raise FileNotFoundError(name)
    return p


def diagnostic(folder,reports,stem):
    from .research_diagnostic import dynamic,writecsv
    summary={'version':'2.0-auto','read_only':True,'certified':False,'reports':[], 'errors':[],
        'note':'使用原始PC估算时间轴。未硬件同步，未做时间平移或补偿。运动前短窗口不等于10分钟静止零偏/Allan实验。未改动固件、算法或标定。'}
    csvs=[]
    for r in reports:
        axis=r.get('plan',{}).get('output','unknown')
        try:
            p=local_file(folder,r['raw_file_imu']);q=local_file(folder,r['raw_file_table'])
            o,rows=dynamic(p,r,q)
            o['static_precheck']=r.get('static_before_dynamic')
            o['pipeline_start']=r.get('pipeline_start');o['pipeline_end']=r.get('pipeline_end')
            o['fifo_dropped_delta']=r.get('imu_fifo_dropped_delta')
            o['reference_quality']=(r.get('analysis') or {}).get('reference_quality')
            o['firmware_timing_note']='MCU通信缓存时间戳和PC接收反推时间轴均非真实采样时刻。软件序号连续不能证明芯片无丢样。'
            summary['reports'].append(o)
            if rows:
                fn=folder/f'{stem}_{axis}_cycles.csv';writecsv(fn,rows);csvs.append(fn)
        except Exception as exc:summary['errors'].append({'axis':axis,'error':str(exc)})
    summary['state']='completed' if summary['reports'] and not summary['errors'] else ('partial' if summary['reports'] else 'failed')
    jp=folder/f'{stem}.json';hp=folder/f'{stem}.html';zp=folder/f'{stem}.zip'
    write_json(jp,summary)
    esc=lambda x:html.escape(str(x))
    cards=[]
    for r in summary['reports']:
        t=r['timing'];q=r['table_timing'];b=t.get('batch_clock_diagnostic') or {}
        def median(k):return (b.get(k) or {}).get('p50','—')
        rows=''.join(f'<tr><td>{esc(k)}</td><td>{v["max_abs_deg"]:.6f}°</td><td>{v["over_0p05_pct"]:.2f}%</td><td>{v["longest_contiguous_over_s"]:.3f}s</td><td>{v["rmse_deg"]:.6f}°</td></tr>' for k,v in r['metrics'].items())
        cards.append(f'<section><h2>{esc(r["axis"].upper())}</h2><p>IMU {t["average_hz"]:.2f}Hz · 转台 {q["average_hz"]:.2f}Hz · 最大反馈间隔 {q["step_ms"]["max"]:.2f}ms · 未覆盖 {r["excluded_reference"]} 点</p><p>MCU批次间隔中位数 {esc(median("mcu_batch_interval_ms"))}ms · PC批次间隔中位数 {esc(median("pc_batch_interval_ms"))}ms · 名义批次间隔 {esc(median("nominal_16_sample_interval_ms"))}ms</p><p>运动前短窗口三轴角速度均值（°/s）：{esc(r.get("pre_motion_bias_proxy_dps","无有效数据"))}；不是独立静止零偏验收。</p><table><tr><th>记录输出</th><th>最大绝对误差</th><th>超0.05°比例</th><th>最长连续超差</th><th>RMSE</th></tr>{rows}</table><details><summary>完整时间、零偏、静态与动态诊断</summary><pre>{esc(json.dumps(r,ensure_ascii=False,indent=2))}</pre></details></section>')
    hp.write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>TiltLab V7.24 自动研发诊断</title><style>body{font:15px/1.65 "Microsoft YaHei",sans-serif;max-width:1100px;margin:36px auto;padding:0 20px;background:#f4f7f7;color:#173c40}section{background:white;border:1px solid #ccdcdc;border-radius:12px;padding:20px;margin:20px 0}table{border-collapse:collapse;width:100%}td,th{text-align:left;padding:10px;border-bottom:1px solid #dce6e6}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}summary{cursor:pointer;margin-top:20px}</style><h1>TiltLab V7.24 · 自动研发诊断</h1><p>'+esc(summary['note'])+'</p><p>状态：'+esc(summary['state'])+'；错误：'+esc(summary['errors'])+'</p>'+''.join(cards)+'</html>',encoding='utf-8')
    with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
        for p in [jp,hp,*csvs]:z.write(p,p.name)
    return {'state':summary['state'],'json_file':jp.name,'html_file':hp.name,'zip_file':zp.name,'errors':summary['errors']}


def postprocess(folder,stages,metadata,combined_name,diagnostic_stem,receipt):
    """Runs without live hardware access. Only small result receipt returns to caller."""
    lower_priority();folder=Path(folder);reports=[];tests=[]
    for stage in stages:
        filename=stage['report_file'];r=json.loads(local_file(folder,filename).read_text(encoding='utf-8'))
        reports.append(r);tests.append({'direction':stage['output'],'inner_target_deg':stage['inner_target_deg'],'reference_axis':2,'report_file':filename,'report':r})
    report_file=stages[0]['report_file'];diagnosis={'state':'not_requested'};optimization={'state':'not_requested'}
    if diagnostic_stem:
        try:diagnosis=diagnostic(folder,reports,diagnostic_stem)
        except Exception as exc:diagnosis={'state':'failed','error':str(exc)}
    if metadata.get('plan',{}).get('research_optimize'):
        try:
            from .research_optimizer import optimize
            optimization=optimize(folder,reports,combined_name.replace('_XY_DYNAMIC_COMBINED.json','_RESEARCH_OPTIMIZER'))
        except Exception as exc:optimization={'state':'failed','error':str(exc)}
    if diagnosis.get('zip_file'):
        try:
            with zipfile.ZipFile(local_file(folder,diagnosis['zip_file']),'a',zipfile.ZIP_DEFLATED) as z:
                for p in metadata.get('pre_research_results',[]):
                    if p.get('json_file'):z.write(local_file(folder,p['json_file']),p['json_file'])
                for key in ('json_file','html_file'):
                    if optimization.get(key):z.write(local_file(folder,optimization[key]),optimization[key])
        except Exception as exc:diagnosis['bundle_append_warning']=str(exc)
    if len(stages)==2:
        from .html_report import write_interactive_report
        out={**metadata,'tests':tests,'research_diagnosis':diagnosis,'optimization':optimization};path=folder/combined_name
        write_json(path,out)
        try:out['html_report_file']=write_interactive_report(path).name
        except Exception as exc:out['html_report_error']=str(exc)
        write_json(path,out);report_file=path.name
    write_json(receipt,{'report_file':report_file,'diagnosis':diagnosis,'optimization':optimization})


def run_postprocess(folder,stages,metadata,combined_name,diagnostic_stem,cancel=None):
    import multiprocessing as mp
    folder=Path(folder);receipt=folder/(combined_name+'.postprocess_receipt.json')
    if receipt.exists():receipt.unlink()
    p=mp.get_context('spawn').Process(target=postprocess,args=(str(folder),stages,metadata,combined_name,diagnostic_stem,str(receipt)),name='TiltLab-post-stop-report',daemon=True)
    p.start()
    try:
        deadline=time.monotonic()+900
        while p.is_alive() and time.monotonic()<deadline:
            if cancel is not None and cancel.is_set():raise RuntimeError('操作员已中止报告处理；原始数据保留')
            p.join(.15)
        if p.is_alive():raise TimeoutError('联合报告/自动诊断进程超时；原始数据保留')
        if p.exitcode!=0 or not receipt.is_file():raise RuntimeError(f'联合报告进程异常退出：{p.exitcode}')
        return json.loads(receipt.read_text(encoding='utf-8'))
    finally:
        if p.is_alive():p.terminate();p.join(2)
        p.close()
        if receipt.exists():receipt.unlink()
