"""Only causal replay from captured six-axis values. No reference input, no future samples.
Never overwrite actual realtime outputs; start state is the captured baseline, not prior session.
"""
from .fusion import FILTERS,Params,create_filter
from .static_alignment import align_pose
from .continuity_v713 import advance

def replay_missing(rows,params,alignment,active):
    p=Params(**params).validate()
    offline_capture=active is None
    names=list(FILTERS) if offline_capture else [n for n in FILTERS if n not in (active,'accel')]
    def pair(n):return (create_filter(n,p,calibrated=False),create_filter(n,p,calibrated=True))
    pipes={n:pair(n) for n in names};out=[];invalid=False
    for i,r in enumerate(rows):
        row=dict(r);new_policy='gap_action' in r and r.get('gap_action') not in ('',None)
        dt=float(r.get('imu_dt_s') or 0) if new_policy else float(r.get('fusion_dt_s') or 0)
        if i==0 or (not new_policy and str(r.get('gap_reset',0)).lower() in ('1','true')):
            pipes={n:pair(n) for n in names};dt=0
        def vec(ch,k,u):
            try:return [float(row[f'{ch}_{k}_{j}_{u}']) for j in 'xyz']
            except (ValueError,TypeError,KeyError):return None
        a,g=vec('raw','acc','g'),vec('raw','gyro','dps');ca,cg=vec('cal','acc','g'),vec('cal','gyro','dps')
        if a is None or g is None:raise ValueError('原始六轴缺失')
        good=ca is not None and cg is not None
        if good and invalid:pipes={n:(v[0],pair(n)[1]) for n,v in pipes.items()}
        invalid=not good
        for n,(b,c) in pipes.items():
            if new_policy:
                b,raw,_=advance(n,b,p,False,a,g,dt)
                factory=None
                if good:c,factory,_=advance(n,c,p,True,ca,cg,dt)
                pipes[n]=(b,c)
            else:raw=b.update(a,g,dt);factory=c.update(ca,cg,dt) if good else None
            cal=align_pose(factory,alignment) if factory and alignment and str(row.get('alignment_active')).lower() in ('1','true') else factory
            for ch,pose in [('raw',raw),('cal',cal),('cal_factory',factory)]:
                for axis in ('roll','pitch'):row[f'{ch}_{n}_{axis}']=pose[axis] if pose else ''
        out.append(row)
    return out,{'realtime_algorithms':([] if offline_capture else [active,'accel'] if active!='accel' else ['accel']), 'offline_algorithms':names,
                'note':'只使用已采集六轴及估算采样间隔，逐算法独立缺口保护；从本次运动前基线初始化。离线采集不计算任何Roll/Pitch，停车后全部算法回放；离线结果不得宣称实时性能。'}
