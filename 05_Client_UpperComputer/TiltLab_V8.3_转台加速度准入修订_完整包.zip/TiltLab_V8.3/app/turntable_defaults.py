"""Operator-selected home-position speed, persisted between workstation upgrades."""
from __future__ import annotations
import json,math
from .engine import SETTINGS_FILE

FILE=SETTINGS_FILE.with_name('turntable_defaults.json')

def load_speed():
    try:
        value=float(json.loads(FILE.read_text(encoding='utf-8')).get('zero_speed_dps',2.0))
        if math.isfinite(value) and .2<=value<=5.0:return value
    except (OSError,ValueError,TypeError,KeyError):pass
    return 2.0

def save_speed(speed):
    speed=float(speed)
    if not math.isfinite(speed) or not .2<=speed<=5.0:raise ValueError('回零速度必须为0.2–5°/s')
    FILE.parent.mkdir(parents=True,exist_ok=True)
    tmp=FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps({'zero_speed_dps':speed},indent=2),encoding='utf-8')
    tmp.replace(FILE)
