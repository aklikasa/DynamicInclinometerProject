"""Non-certifying fault isolation: amplitude, phase, gyro drift and holdout time shift.

Uses only observed DLL encoder readings and IMU outputs. Never feeds fitted
shifts, gains or zero offsets into real-time filters / hardware motion.
A fixed, conservative time-domain exclusion mask prevents interpolation or
training-data cherry-picking around missing reference samples.
"""
from __future__ import annotations
import math
import numpy as np
from .angles import unwrap_encoder_deg


def _harmonic(y,t,frequency):
    w=2.*math.pi*frequency
    X=np.column_stack((np.sin(w*t),np.cos(w*t),np.ones(len(t))))
    coefficients=np.linalg.lstsq(X,y,rcond=None)[0]
    return float(np.hypot(coefficients[0],coefficients[1])),float(math.atan2(coefficients[1],coefficients[0])),float(coefficients[2])


def diagnostic_reference_mask(ts,t,limit_shift=.25,max_interval=.4):
    """Return identical eligible timestamps for *all* tested shifts.

    Exclude the expanded neighbourhood of every reference gap, not just the
    samples that would otherwise be invalid at a particular trial shift.
    """
    ts=np.asarray(ts,dtype=float);t=np.asarray(t,dtype=float)
    if len(ts)<2 or np.any(np.diff(ts)<=0):return np.zeros(len(t),dtype=bool)
    valid=(t>=ts[0]+limit_shift)&(t<=ts[-1]-limit_shift)
    for i in np.flatnonzero(np.diff(ts)>max_interval):
        valid &= ((t<ts[i]-limit_shift)|(t>ts[i+1]+limit_shift))
    return valid


def diagnose_dynamic_components(table_rows,imu_rows,analysis,axis,output,sign,amp,freq,motion_start_ns,motion_end_ns):
    result={'available':False,'hardware_synchronized':False,'certified_accuracy':False,
            'method':'encoder actual angle + fixed-gap-exclusion + fit 60% / holdout 40%',
            'note':('相位/时间补偿只做离线归因。拟合可能吸收传感器滤波相位；幅值缩放是事后诊断，'
                    '不得作为实时算法或±0.1°验收结果。')}
    if not analysis.get('valid') or len(table_rows)<25 or len(imu_rows)<400:
        result['reason']='有效数据不足，或原始参考质量检查失败';return result
    try:
        from .dynamic_experiment import recover_imu_timebase
        ts=np.asarray([float(r['pc_mid_ns'])/1e9 for r in table_rows]);pos=unwrap_encoder_deg([float(r[f'axis_{axis}_pos']) for r in table_rows]);
        times,_=recover_imu_timebase(imu_rows,int(ts[0]*1e9),int(ts[-1]*1e9))
        if np.any(np.diff(times)<=0) or np.any(np.diff(ts)<=0):
            result['reason']='时间戳没有严格递增，拒绝做偏移拟合';return result
        start=motion_start_ns/1e9;end=motion_end_ns/1e9
        pre=(times>=max(ts[0],start-2.5))&(times<start-.1)
        table_pre=(ts>=max(ts[0],start-2.5))&(ts<start-.1)
        stable=(times>=start+1./freq)&(times<=end-.3)
        eligible=stable&diagnostic_reference_mask(ts,times)
        if np.count_nonzero(pre)<30 or np.count_nonzero(table_pre)<2 or np.count_nonzero(eligible)<450:
            result['reason']='有效基线或避开参考缺口后的稳定段不足';return result
        reference_zero=float(np.mean(pos[table_pre]));t=times[eligible]
        # Equivalent data for every candidate. No cross-gap interpolation.
        ref=sign*(np.interp(t,ts,pos)-reference_zero)
        result['available']=True
        result['eligible_imu_samples']=len(t)
        result['reference_gaps_excluded']=int(np.count_nonzero(np.diff(ts)>.4))
        result['reference_amplitude_sine_deg']=round(_harmonic(ref,t-start,freq)[0],6)
        result['components']=[]
        for alg in ('gyro','accel','adaptive','adaptive_lever','motion_guard','gyro_anchor','gyro_anchor3d'):
            col=f'cal_{alg}_{output}'
            if col not in imu_rows[0]:continue
            arr=np.asarray([float(r.get(col)) if r.get(col) not in ('',None) else np.nan for r in imu_rows],dtype=float)
            if np.count_nonzero(np.isfinite(arr[pre]))<30:continue
            y_all=arr-float(np.nanmean(arr[pre]));y=y_all[eligible]
            good=np.isfinite(y)
            if np.count_nonzero(good)<400:continue
            # Crop this channel to a single monotonic train/test partition.
            tt=t[good]; yy=y[good];rr=ref[good]
            cut=int(.6*len(tt));train=np.arange(0,cut,max(1,cut//1300));test=np.arange(cut,len(tt),max(1,(len(tt)-cut)//1000))
            if len(train)<100 or len(test)<100:continue
            ra,rf,_=_harmonic(rr,tt-start,freq);ya,yf,_=_harmonic(yy,tt-start,freq)
            phase=(rf-yf+math.pi)%(2*math.pi)-math.pi
            # Fit one lag on *training* data. Do not also fit gain/offset for
            # this comparison; that would conflate algorithm defects.
            candidates=np.arange(-.250,.250001,.002)
            losses=[]
            for shift in candidates:
                target=sign*(np.interp(tt[train]+shift,ts,pos)-reference_zero)
                losses.append(float(np.mean((yy[train]-target)**2)))
            best_index=int(np.argmin(losses));shift=float(candidates[best_index])
            r_before=rr[test]
            r_after=sign*(np.interp(tt[test]+shift,ts,pos)-reference_zero)
            rmse_before=float(np.sqrt(np.mean((yy[test]-r_before)**2)))
            rmse_after=float(np.sqrt(np.mean((yy[test]-r_after)**2)))
            # Diagnostics only: separate amplitude and DC mismatch after lag.
            XX=np.column_stack((r_after,np.ones(len(r_after))))
            gain,intercept=np.linalg.lstsq(XX,yy[test],rcond=None)[0]
            # Drift is estimated against the *time-shifted reference*, not a
            # truth claim about electronics; it also includes other effects.
            residual=yy[test]-r_after
            slope=float(np.polyfit(tt[test]-tt[test][0],residual,1)[0])
            result['components'].append({'algorithm':alg,
                'reference_sine_amplitude_deg':round(ra,6),
                'imu_sine_amplitude_deg':round(ya,6),
                'amplitude_ratio':round(ya/max(1e-9,ra),6),
                'amplitude_excess_deg':round(ya-ra,6),
                'apparent_phase_lag_ms':round(phase/(2*math.pi*freq)*1000,3),
                'holdout_optimal_reference_shift_ms':round(shift*1000,3),
                'holdout_rmse_original_deg':round(rmse_before,6),
                'holdout_rmse_shift_only_deg':round(rmse_after,6),
                'holdout_residual_trend_deg_per_s':round(slope,6),
                'holdout_apparent_gain_after_shift':round(float(gain),6),
                'holdout_apparent_offset_after_shift_deg':round(float(intercept),6),
                'shift_at_search_boundary':abs(shift)>.245,
                'holdout_samples':len(test),
                'amplitude_or_gain_applied_to_imu':False,
                'time_shift_applied_to_imu':False})
        if not result['components']:
            result.update(available=False,reason='校正后角度通道不存在或无有效数据')
    except (ValueError,KeyError,TypeError,IndexError,OverflowError) as exc:
        result.update(available=False,reason='诊断计算未能完成：'+str(exc))
    return result
