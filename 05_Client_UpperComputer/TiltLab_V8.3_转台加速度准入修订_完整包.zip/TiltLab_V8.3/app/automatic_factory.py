"""Exclusive R10 ambient calibration orchestration. Never substitute fitted angle offsets."""
import json, os, subprocess, sys, threading, time, zipfile
from pathlib import Path
from .factory_recovery import prepare,import_pair,write_json
from .factory_table_bridge import FactoryBridge
from .table_diagnostics import DIAG

class AutomaticFactory:
    def __init__(self,engine,table,lifecycle,auto,root):
        self.engine=engine;self.table=table;self.lifecycle=lifecycle;self.auto=auto;self.root=Path(root)
        self.lock=threading.RLock();self.state={'state':'idle'};self.active=False;self.last_heartbeat=0;self.cancel=threading.Event();self.job=None;self.safety_latched=False
    def status(self):
        with self.lock:
            s=dict(self.state)
            if self.job:
                try:
                    with (self.job/'worker_progress.jsonl').open('rb') as f:
                        f.seek(0,2);size=f.tell();f.seek(max(0,size-16384));tail=f.read()
                    # Ignore an incomplete line written concurrently.
                    for line in reversed(tail.splitlines() if tail.endswith(b'\n') else tail.splitlines()[:-1]):
                        try:s['worker']=json.loads(line);break
                        except (ValueError,UnicodeError):continue
                except OSError:pass
            return {**s,'running':self.active,'safety_latched':self.safety_latched}
    def readiness(self):
        """Read-only preliminary checks; never authorizes motion or opens a port.

        The start() motion admission remains authoritative and unchanged.
        """
        import importlib.util
        issues=[]
        e=self.engine
        if os.name!='nt':issues.append('R10自动标定只支持Windows实机环境')
        for module,label in (('PySide6','PySide6界面'),('openpyxl','Excel校准'),
                             ('xlsxwriter','Excel报告')):
            if importlib.util.find_spec(module) is None:
                issues.append(f'缺少{label}依赖 {module}；运行 安装依赖.bat（一次安装PCB及R10依赖）')
        if self.active:issues.append('已有自动标定正在执行')
        if self.safety_latched:issues.append('上次停车未确认：保持锁定，必须现场排查')
        if not self.table.connected:issues.append('转台未连接；请先现场确认连接、双轴使能和机械零点')
        if not e.running or not e.connected or not getattr(e,'serial_connection',None):
            issues.append('PCB未处于正常实时串口采集状态')
        if getattr(e,'_pipeline_error',''):
            issues.append('PCB采集故障：'+str(e._pipeline_error))
        if not e.cal or e.cal_status!='matched':
            issues.append('没有匹配的有效常温ACC/GYRO厂标定文件；原R10交接要求先核对旧文件UID和重力符号')
        else:
            try:
                old_docs=[json.loads(Path(e.cal[k].path).read_text(encoding='utf-8-sig')) for k in ('acc','gyro')]
                signs=[d.get('gravity_sign') for d in old_docs]
                if signs[0] not in (-1,1) or signs[1]!=signs[0] or any(d.get('axis_model')!='outer_x_inner_z' for d in old_docs):
                    issues.append('原标定文件的重力方向或轴系不一致；按R10原安全门禁禁止运动')
            except (KeyError,ValueError,TypeError,OSError) as exc:
                issues.append('无法读取原标定文件：'+str(exc))
        if e.record_fp or (e.stability and e.stability.state=='running'):
            issues.append('请先结束录制或稳定性实验')
        return {'ready_for_preflight':not issues, 'blockers':issues,
                'note':'V8.1：常温R10只需要主程序及R10依赖，不需要温箱PLC的snap7。此处是静态只读检查；不能验证硬件安全。启动时仍执行原R10依赖自检、双轴停车确认与现场授权。'}

    def _set(self,**values):
        with self.lock:self.state.update(values)
    def heartbeat(self):
        with self.lock:self.last_heartbeat=time.monotonic()
        return {'ok':True}
    def abort(self):
        self.cancel.set()
        if getattr(self.auto,'running',False):self.auto.abort()
        if self.job:(self.job/'abort').touch()
        return {'requested':True,'note':'已请求R10停车；须等待实际停车确认，实体急停仍可用'}
    def start(self,confirmed,load_secured,manual=False):
        if confirmed is not True or load_secured is not True:raise ValueError('必须确认双轴全周运动、线缆、负载独立支撑和现场急停')
        if os.name!='nt':raise ValueError('R10实机自动标定仅支持Windows')
        with self.lock:
            if self.active:raise ValueError('自动标定正在执行')
            if self.safety_latched:raise ValueError('上次停车未验证，禁止新运动；须现场排查并重新确认机械安全')
            run=self.auto.status();e=self.engine
            if not self.table.connected:raise ValueError('请先连接转台并按设备规程确认双轴使能、机械零点和安全状态')
            if run.get('running'):raise ValueError('已有实验运行')
            if not e.running or not e.cal or not getattr(e,'serial_connection',None):raise ValueError('IMU连接参数未记录，请先重新连接IMU')
            if e.record_fp or (e.stability and e.stability.state=='running'):raise ValueError('请先结束录制或稳定性实验')
            # Preserve the old reference sign; never guess it from a static error.
            old_docs=[json.loads(Path(e.cal[k].path).read_text(encoding='utf-8-sig')) for k in ('acc','gyro')]
            signs=[d.get('gravity_sign') for d in old_docs]
            if signs[0] not in (-1,1) or signs[1]!=signs[0] or any(d.get('axis_model')!='outer_x_inner_z' for d in old_docs):
                raise ValueError('原标定轴系/重力符号不明确或不一致，禁止自动运动')
            self.cancel.clear();self.active=True;self.state={'state':'preparing','detail':'检查R10依赖与标定文件'};self.job=None
            try:
                worker=self.root/'r10_ambient'/'tiltlab_ambient_worker.py'
                # Check dependencies before disconnecting or moving anything.
                # Use the SAME interpreter as the workstation and force UTF-8 for readable errors.
                check_env={**os.environ,'PYTHONIOENCODING':'utf-8'}
                check=subprocess.run([sys.executable,str(worker),'--check'],cwd=str(worker.parent),
                                     capture_output=True,timeout=30,env=check_env)
                if check.returncode:
                    detail=(check.stderr or check.stdout).decode('utf-8',errors='replace')
                    if "No module named 'PySide6'" in detail:
                        raise ValueError('R10缺少PySide6：请在当前软件目录运行 安装依赖.bat（主程序+R10一键安装），不要在其他版本目录安装。')
                    raise ValueError('R10工作进程导入检查失败：'+detail[-900:]+
                                     '；请查看 install_logs\\r10_worker_check.txt，勿启动标定运动。')
                if self.cancel.is_set():raise RuntimeError('操作员已取消')
                with e.lock:handoff=prepare(e,run,self.root/'data'/'factory_recovery',manual=manual)
                self.job=Path(handoff['job']);self.state={**handoff,'state':'preparing','note':'自动执行原R10工艺；保留原始数据和备份','run_manifest_file':run.get('run_manifest_file')}
                port,baud,address=e.serial_connection
                cfg={'uid':handoff['uid'],'uid_hex':handoff['uid_hex'],'imu_port':port,'imu_baud':baud,'imu_address':address,'table_port':self.table.port,'gravity_sign':signs[0],'stage_folder':handoff['stage_folder'],'confirmed_full_motion':True}
                if self.cancel.is_set():raise RuntimeError('操作员已取消')
                self.last_heartbeat=time.monotonic();self.active=True
                threading.Thread(target=self._run,args=(handoff,cfg,None if manual else run['plan'],worker),daemon=True,name='R10-ambient-supervisor').start()
                return self.status()
            except Exception as exc:
                self.active=False;self.state={'state':'failed','detail':str(exc)};raise
    def _alive(self):return not self.cancel.is_set() and time.monotonic()-self.last_heartbeat<=6
    def _restart_imu(self,cfg):
        # No competing research filters on the restored live acquisition.
        self.engine.set_pipeline_mode('realtime')
        self.engine.start('serial',cfg['imu_port'],cfg['imu_baud'],cfg['imu_address'])
        self._set(reconnect_pipeline=self.engine.pipeline_status())
    def _require_live_pipeline(self):
        if not self.engine.running or not self.engine.connected or self.engine._pipeline_error:
            raise RuntimeError('IMU实时采集恢复失败：'+(self.engine._pipeline_error or self.engine.error or '采集未运行'))
    def _wait_live(self,*,bias_ready=False,timeout=30):
        deadline=time.monotonic()+timeout
        while True:
            if not self._alive():raise RuntimeError('操作员取消或浏览器授权超时')
            self._require_live_pipeline()
            latest=self.engine.latest or {}
            observed=latest.get('pc_observed_ns')
            if observed and 0 <= time.monotonic_ns()-observed <= 500_000_000 and (not bias_ready or latest.get('cal',{}).get('stationary_bias_ready') is True):return
            if time.monotonic()>deadline:raise RuntimeError('实时IMU数据或零偏未就绪；禁止继续运动')
            time.sleep(.1)
    def _hold_stop(self):
        self.table.stop()
        if self.table.stopped_verified(timeout=20) is not True:
            raise RuntimeError('双轴物理停车未确认；禁止继续，现场按设备应急规程处理')
        st=self.table.read_status()['axes']
        if not all(st[str(a)]['enabled'] and st[str(a)]['zeroed'] and st[str(a)]['healthy'] and not any(st[str(a)][k] for k in ('driver_fault','upper_limit','lower_limit','over_speed')) for a in (0,2)):
            raise RuntimeError('双轴保持使能、机械零点或健康状态未确认；禁止继续')
        DIAG.record('factory_hold_verified','R10交接保持双轴使能，COM连接未关闭')
    def _run(self,handoff,cfg,plan,worker):
        bridge=None;proc=None;imu_released=False;stop_ok=False
        try:
            self._set(state='transferring',detail='确认停车并保持双轴使能；仅交接IMU串口')
            if not self._alive():raise RuntimeError('启动授权失效')
            self._hold_stop()
            profile=json.loads((worker.parent/'production_quality_profile.json').read_text(encoding='utf-8'))
            rates=profile['rates']['fit_dps']+profile['rates']['verify_dps']
            bridge=FactoryBridge(self.table,self._alive,rates)
            bridge.verify_holding()
            if not self._alive():raise RuntimeError('启动授权失效')
            self.engine.stop();imu_released=True
            if not self._alive():raise RuntimeError('操作员取消或心跳超时，未启动标定')
            # The capability token is local to this run and excluded from diagnostic ZIPs.
            write_json(self.job/'worker_request.json',{**cfg,'bridge':bridge.endpoint})
            with (self.job/'worker.log').open('wb') as log:
                proc=subprocess.Popen([sys.executable,str(worker),str(self.job)],cwd=str(worker.parent),stdout=log,stderr=subprocess.STDOUT)
                self._set(state='calibrating',detail='R10常温标定执行中；转台连接与使能保持')
                failure=None;abort_since=None
                while proc.poll() is None:
                    if failure is None:
                        try:
                            if not self._alive():raise RuntimeError('操作员取消或浏览器心跳超时')
                            with self.table.lock:bridge.verify_holding()
                        except Exception as exc:
                            failure=str(exc);bridge.revoke();(self.job/'abort').touch();abort_since=time.monotonic()
                            self._set(state='stopping',detail=failure+'；已撤销运动授权，正在停车')
                            self._hold_stop();stop_ok=True
                    elif time.monotonic()-abort_since>30:
                        # Child owns only the IMU, no turntable handle. Terminate
                        # only after parent has independently verified physical stop.
                        if not stop_ok:raise RuntimeError('停车未验证，不允许自动终止工作进程')
                        proc.terminate();proc.wait(timeout=10);break
                    time.sleep(.15)
                if failure:raise RuntimeError(failure)
            bridge.revoke();self._hold_stop();stop_ok=True
            result=json.loads((self.job/'worker_result.json').read_text(encoding='utf-8'))
            if result.get('imu_released') is not True:raise RuntimeError('R10未确认释放IMU；禁止自动重连')
            if proc.returncode or result.get('success') is not True:raise RuntimeError(result.get('message','R10标定失败'))
            if not self._alive():raise RuntimeError('标定完成但授权已取消；新文件留在暂存目录，未覆盖旧文件')
            self._set(state='loading',detail='重新连接同一IMU并事务式加载新标定')
            self._restart_imu(cfg);imu_released=False
            self._wait_live(timeout=15)
            if not self._alive():raise RuntimeError('授权已取消，未覆盖旧文件')
            loaded=import_pair(self.engine,handoff)
            loaded['note']='原R10质量门禁已通过；未追加六轴验证，保留动态前静态预检；双轴保持使能'
            self._set(**loaded,detail='新ACC/GYRO已加载，等待无杆臂实时数据收敛')
            self._wait_live(bias_ready=True)
            if not self._alive():raise RuntimeError('新标定已加载，操作员取消后续实验')
            self._hold_stop()
            self._wait_live(bias_ready=True,timeout=3)
            if plan is None:
                self._set(state='completed',detail='常温标定完成，新ACC/GYRO已生效；双轴保持使能，未启动动态实验')
            else:
                if not self._alive():raise RuntimeError('后续实验授权失效')
                self.auto.start(plan['axis'],plan['output'],plan['requested_roll_sign'],plan['amplitude_deg'],plan['frequency_hz'],plan['cycles'],plan['zero_speed_dps'],True,plan['mounting_mode'],plan['fixture_confirmed'],plan['requested_pitch_sign'],True,plan['static_limit_deg'],True,False,plan['pre_sway_axis_check'])
                self._set(state='resumed',detail='最新标定已加载，已从原静态预检重新开始实验')
        except Exception as exc:
            if bridge:bridge.revoke()
            if self.job:(self.job/'abort').touch()
            # Never disable either servo or close the table port on error.
            try:
                if not self.table.connected:raise RuntimeError('转台连接丢失，停车无法确认')
                self._hold_stop();stop_ok=True
            except Exception as stop_exc:
                stop_ok=False;self.safety_latched=True;exc=RuntimeError(str(exc)+'；停车未确认：'+str(stop_exc))
            if proc is not None and proc.poll() is None:
                try:proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    if stop_ok:
                        proc.terminate()
                        try:proc.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            self.safety_latched=True
                            self._set(state='unsafe_stop',detail='工作进程未释放IMU，禁止新任务')
                            while proc.poll() is None:time.sleep(.5)
                    else:
                        self._set(state='unsafe_stop',detail=str(exc)+'；子进程未退出，禁止新任务。请现场按设备应急规程处置')
                        while proc.poll() is None:time.sleep(.5)
            if imu_released and stop_ok and (proc is None or proc.poll() is not None):
                try:
                    if proc is not None:
                        release=json.loads((self.job/'worker_result.json').read_text(encoding='utf-8'))
                        if release.get('imu_released') is not True:raise RuntimeError('工作进程未确认释放IMU；不自动重连')
                    self._restart_imu(cfg)
                except Exception as imu_exc:exc=RuntimeError(str(exc)+'；IMU恢复失败：'+str(imu_exc))
            self._set(state='unsafe_stop' if self.safety_latched else 'failed',detail=str(exc),note='未自动继续实验；双轴不主动断使能。请现场核查实际停车、负载支撑及故障状态。旧文件备份及暂存文件保留。')
        finally:
            if bridge:
                try:bridge.close()
                except Exception as bridge_exc:
                    self.safety_latched=True;self._set(state='unsafe_stop',detail='控制桥关闭异常：'+str(bridge_exc))
            try:
                self._set(diagnostic_zip=str(self.job/'compact_diagnostics.zip'))
                self._set(final_pipeline=self.engine.pipeline_status())
                write_json(self.job/'supervisor_status.json',{**self.status(),'running':False})
                with zipfile.ZipFile(self.job/'compact_diagnostics.zip','w',zipfile.ZIP_DEFLATED) as z:
                    for name in ('supervisor_status.json','handoff.json','worker_progress.jsonl','worker_result.json','worker.log'):
                        p=self.job/name
                        if p.is_file():z.writestr(name,p.read_bytes()[-256000:])
                    for p in (self.job/'r10_raw').glob('*/manifest.json'):
                        if p.stat().st_size<=256000:z.write(p,str(p.relative_to(self.job)))
                    for p in (self.job/'new_calibration').glob('*.json'):
                        if p.stat().st_size<=256000:z.write(p,str(p.relative_to(self.job)))
            except Exception:pass
            with self.lock:self.active=False
