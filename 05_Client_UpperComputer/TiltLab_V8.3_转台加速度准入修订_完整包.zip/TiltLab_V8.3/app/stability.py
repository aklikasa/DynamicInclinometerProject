"""Measured-device stationary repeatability experiment.

Uses only actual real-device samples; no reference angle means NO absolute accuracy.
No hardware motion or write commands. Records independent filter branches at full rate.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
import json, math, pathlib


class RunningStats:
    def __init__(self):
        self.n=0; self.mean=0.; self.m2=0.; self.min=float('inf'); self.max=float('-inf')
        self.st=0.; self.stt=0.; self.sx=0.; self.stx=0.; self.first=None; self.last=None
    def add(self, t, x):
        if not isinstance(x,(int,float)) or not math.isfinite(x): return
        self.n+=1
        dx=x-self.mean; self.mean+=dx/self.n; self.m2+=dx*(x-self.mean)
        self.min=min(self.min,x); self.max=max(self.max,x)
        self.st+=t;self.stt+=t*t;self.sx+=x;self.stx+=t*x
        if self.first is None:self.first=x
        self.last=x
    def result(self, unit='deg'):
        if not self.n:return None
        variance=self.m2/(self.n-1) if self.n>1 else 0.
        denom=self.n*self.stt-self.st*self.st
        slope=(self.n*self.stx-self.st*self.sx)/denom if self.n>1 and abs(denom)>1e-9 else 0.
        return dict(n=self.n,mean=self.mean,std=math.sqrt(max(0.,variance)),peak_to_peak=self.max-self.min,
                    drift_deg_per_min=slope*60.,net_change=self.last-self.first,unit=unit)


class StationaryEvaluation:
    def __init__(self,duration_s,device_uid,cal_mode,params):
        # 0 means indefinite recording until the operator presses Stop.
        # A finite duration can be freely chosen up to 7 days; statistics use
        # constant memory regardless of the number of incoming samples.
        duration_s=float(duration_s)
        if not math.isfinite(duration_s) or duration_s<0 or (0<duration_s<1) or duration_s>604800:
            raise ValueError('测试时长应为1–604800秒；填写0表示不限时并手动结束')
        self.duration=duration_s; self.uid=device_uid;self.cal_mode=cal_mode
        self.params=dict(params);self.started_at=datetime.now().isoformat(timespec='seconds')
        self.state='running';self.t0=None;self.elapsed=0.;self.samples=0;self.gaps=0
        self.channels={};self.inputs={key:RunningStats() for key in
                      ('gyro_raw_x','gyro_raw_y','gyro_raw_z','gyro_cal_x','gyro_cal_y','gyro_cal_z',
                       'acc_norm_g','gyro_norm_dps')}
        self.report_path=None
    def add(self, record):
        if self.state!='running':return False
        t=record['t']
        if self.t0 is None:self.t0=t
        self.elapsed=max(0.,t-self.t0)
        if self.duration>0 and self.elapsed>self.duration:
            self.state='completed';return True
        self.samples+=1
        for group in ('raw','cal'):
            for key,v in record['outputs'].items():
                pose=v.get(group)
                if pose is None:continue
                for axis in ('roll','pitch','yaw'):
                    stat=self.channels.setdefault((group,key,axis),RunningStats())
                    stat.add(self.elapsed,pose[axis])
        for i,axis in enumerate('xyz'):
            self.inputs['gyro_raw_'+axis].add(self.elapsed,record['gyro'][i])
            if record['gyro_cal'] is not None:self.inputs['gyro_cal_'+axis].add(self.elapsed,record['gyro_cal'][i])
        self.inputs['acc_norm_g'].add(self.elapsed,math.sqrt(sum(v*v for v in record['acc'])))
        self.inputs['gyro_norm_dps'].add(self.elapsed,math.sqrt(sum(v*v for v in record['gyro'])))
        return False
    def summary(self,include_metrics=True):
        out=dict(state=self.state,uid=self.uid,cal_mode=self.cal_mode,started_at=self.started_at,
                 duration_s=self.duration,elapsed_s=round(self.elapsed,3),samples=self.samples,
                 report_file=self.report_path,frame_gaps=self.gaps)
        if not include_metrics:return out
        metrics={}
        for (group,algo,axis),stat in self.channels.items():
            metrics.setdefault(group,{}).setdefault(algo,{})[axis]=stat.result()
        inputs={key:stat.result('g' if key=='acc_norm_g' else 'deg/s') for key,stat in self.inputs.items()}
        # Conservative gross motion warnings. Extremely slow motion remains unobservable.
        gr=inputs['gyro_norm_dps'];ac=inputs['acc_norm_g']
        warn=[]
        if gr and gr['peak_to_peak']>1.5:warn.append('测试中角速度变化较大，可能发生运动')
        if ac and ac['peak_to_peak']>.09:warn.append('加速度模长变化明显，可能存在振动或位移')
        if self.samples<20:warn.append('有效样本过少')
        if self.elapsed<10:warn.append('记录不足10秒，漂移趋势估计不稳定')
        if self.gaps:warn.append(f'采集时出现{self.gaps}次超过500ms的数据间隔，期间滤波状态可能被重置')
        if not warn:warn.append('未检出明显运动；无法排除极慢匀速旋转，请确认设备实际静止')
        # There is deliberately no single "winner" and no fabricated RMSE/reference.
        results=[]
        for group,algos in metrics.items():
            for name,axes in algos.items():
                r,p=axes.get('roll'),axes.get('pitch')
                if r and p:
                    results.append(dict(channel=group,algorithm=name,
                           roll_std=r['std'],pitch_std=p['std'],
                           roll_pp=r['peak_to_peak'],pitch_pp=p['peak_to_peak'],
                           roll_drift_dpm=r['drift_deg_per_min'],pitch_drift_dpm=p['drift_deg_per_min'],
                           yaw_drift_dpm=axes.get('yaw',{}).get('drift_deg_per_min',0.),samples=min(r['n'],p['n'])))
        results.sort(key=lambda r:(r['channel'], math.hypot(r['roll_std'],r['pitch_std'])))
        out.update(metrics=metrics,inputs=inputs,comparison=results,warnings=warn,reference_available=False,
                   note='仅评价静止离散程度与漂移；没有可信角度基准，不能计算绝对精度或证明动态跟踪性能。')
        return out
    def save(self,folder):
        pathlib.Path(folder).mkdir(parents=True,exist_ok=True)
        name=f"stationary_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{self.uid or 'UNKNOWN'}.json"
        self.report_path=name
        path=pathlib.Path(folder)/name
        path.write_text(json.dumps({**self.summary(),'algorithm_parameters':self.params},ensure_ascii=False,indent=2),encoding='utf-8')
        return name
