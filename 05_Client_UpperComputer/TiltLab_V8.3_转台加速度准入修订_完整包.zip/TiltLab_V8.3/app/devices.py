"""Real ASM330/R10 Modbus RTU adapter, based on user's R10 register layout.
One serial owner: never poll UID concurrently with FIFO. Windows pyserial required.
"""
import hashlib,struct,time
from .calibration import uid_to_serial

ACC_SCALE={2:.061,4:.122,8:.244,16:.488}
GYR_SCALE={125:4.37,250:8.75,500:17.5,1000:35.,2000:70.,4000:140.}

class DeviceError(RuntimeError):pass

def crc16(data:bytes)->int:
    value=0xffff
    for x in data:
        value^=x
        for _ in range(8):value=(value>>1)^(0xA001 if value&1 else 0)
    return value

def list_ports():
    try:
        import serial.tools.list_ports
        return [{'device':p.device,'label':p.description} for p in serial.tools.list_ports.comports()]
    except ImportError:return []

class R10Device:
    def __init__(self,port,baudrate=1500000,address=1,timeout=1.0):
        self.port=port;self.baudrate=int(baudrate);self.address=int(address)
        if not 1<=self.address<=247:raise DeviceError('Modbus从站地址无效')
        self.timeout=timeout;self.serial=None;self.uid=None;self.serial_no=None
        self.last_tick=None;self.epoch=0;self.last_odr=None;self.dropped_batches=0
        self.uid_warning=None;self._pending_registers=None
        self.last_tx_hex="";self.last_rx_hex="";self.last_rx_length=0;self.last_rx_ms=0.0
    def open(self):
        """Open and verify the IMU endpoint without requiring UID support.

        R10 reference uses address 1 by default (even when its comment mentions
        RS485=2). Do not silently change slave addresses on a production bus.
        """
        try:
            import serial
            self.serial=serial.Serial(self.port,self.baudrate,timeout=self.timeout,
                                      bytesize=8,parity='N',stopbits=1)
        except ImportError:
            raise DeviceError('尚未安装pyserial，请先运行安装依赖.bat')
        except Exception as e:
            raise DeviceError(f'串口打开失败: {e}')
        try:
            # Validate 1000 first, which works on older firmwares without UID.
            self._pending_registers=self.read(1000,104)
        except Exception as e:
            detail=str(e)
            self.close()
            raise DeviceError(f'串口已打开，IMU 1000读取失败（从站{self.address}，{self.baudrate}bps）：{detail}。'
                              'R10源码默认地址1；请运行RS485只读诊断工具核对地址1/2及实际收发帧。')
        try:
            uid=self.read(3000,6)
            raw=struct.pack('>' + 'H'*6,*uid)
            self.serial_no=uid_to_serial(raw);self.uid=raw.hex().upper()
        except (DeviceError,ValueError) as e:
            self.serial_no=None;self.uid=None
            self.uid_warning='IMU已连通，但UID不可读：'+str(e)+'。仅允许未标定数据采集。'
    def close(self):
        if self.serial:
            try:self.serial.close()
            finally:self.serial=None
    def read(self,addr,count):
        """Read holding registers following R10 fixed-length receive convention.

        Expose TX/RX and lengths for field diagnostics. Never write to registers.
        """
        if self.serial is None:raise DeviceError('设备未连接')
        if not 1 <= count <= 126:raise DeviceError('寄存器数量须为1~126')
        req=struct.pack('>BBHH',self.address,3,addr,count)
        req+=struct.pack('<H',crc16(req))
        self.last_tx_hex=req.hex(' ').upper()
        self.last_rx_hex='';self.last_rx_length=0;self.last_rx_ms=0
        target_len=5+count*2
        began=time.perf_counter()
        try:
            self.serial.reset_input_buffer()
            self.serial.write(req)
            # R10 reads the exact total byte count in one call; pySerial
            # accumulates until count is met or the configured timeout expires.
            response=self.serial.read(target_len)
        except Exception as exc:
            raise DeviceError(f'串口读写异常：{type(exc).__name__}: {exc}; TX={self.last_tx_hex}') from exc
        finally:
            self.last_rx_ms=round((time.perf_counter()-began)*1000,1)
        self.last_rx_hex=response.hex(' ').upper()
        self.last_rx_length=len(response)
        diagnostic=(f'TX={self.last_tx_hex} / RX({len(response)}/{target_len})='
                    f'{self.last_rx_hex or "<空>"} / {self.last_rx_ms:.0f}ms')
        if len(response)==5 and response[0]==self.address and response[1]==0x83:
            if crc16(response[:-2])==int.from_bytes(response[-2:],'little'):
                raise DeviceError(f'Modbus异常码 {response[2]}; {diagnostic}')
        if len(response)!=target_len:
            raise DeviceError(f'Modbus响应超时或不完整; {diagnostic}')
        if response[0]!=self.address:
            raise DeviceError(f'应答从站地址不一致; {diagnostic}')
        if response[1]!=3 or response[2]!=(count*2):
            raise DeviceError(f'应答功能码/字节数不一致; {diagnostic}')
        if crc16(response[:-2])!=int.from_bytes(response[-2:],'little'):
            raise DeviceError(f'Modbus CRC校验失败; {diagnostic}')
        return list(struct.unpack('>'+str(count)+'H',response[3:-2]))
    @staticmethod
    def signed(u):return u-65536 if u>=32768 else u
    def next_batch(self):
        r=self._pending_registers if self._pending_registers is not None else self.read(1000,104)
        self._pending_registers=None
        unread=r[0]
        if unread==0:return []
        tick=(r[99]<<16)|r[98]
        if self.last_tick is not None:
            if tick==self.last_tick:return []
            if tick<self.last_tick and self.last_tick-tick>2**31:self.epoch+=2**32
            elif tick<self.last_tick:raise DeviceError('MCU时间戳回退，请重新连接')
        self.last_tick=tick
        afs=r[100] if r[100] in ACC_SCALE else 2
        gfs=r[101] if r[101] in GYR_SCALE else 250
        odr=r[102] if 10<=r[102]<=10000 else (self.last_odr or 833)
        self.last_odr=odr
        if unread>1:self.dropped_batches+=unread-1
        if r[103]&0x20:self.dropped_batches+=1
        self.frame_status=r[103]
        # R10 contains 16 samples, end tick only; approximate intra-batch time by 1/ODR.
        samples=[];end=(self.epoch+tick)/1000
        temp=(self.signed(r[97])/256.)+25. # ASM330 die temperature formula; verify with firmware model
        for i in range(16):
            acc=[self.signed(r[off+i])*ACC_SCALE[afs]/1000 for off in (1,17,33)]
            gyro=[self.signed(r[off+i])*GYR_SCALE[gfs]/1000 for off in (49,65,81)]
            samples.append(dict(t=end-(15-i)/odr,acc=acc,gyro=gyro,temp=temp,ref=None,source='hardware',
                                timestamp_quality='frame_end_tick+ODR_interpolation',fifo_state=r[103],odr=odr,reported_odr=r[102]))
        return samples
