"""Operator-positioned, read-only three-point static cross-axis diagnostic.

IMPORTANT: contains no calls to move/sway/stop/enable on the table.
Uses actual angle readback; nonzero DLL speed is flagged, not treated as
proof of safety. The operator is solely responsible for safe positioning.
"""
from __future__ import annotations
import datetime as dt
import json
import threading
import time
from pathlib import Path
import numpy as np
from .angles import angle_delta_deg
from .fusion import FILTERS

class StaticThreePoint:
    def __init__(self,table,engine,folder):
        self.table=table;self.engine=engine;self.dir=Path(folder);self.lock=threading.RLock()
        self.direction='roll';self.points={};self.report_file=None
    def reset(self,direction):
        if direction not in ('roll','pitch'):raise ValueError('方向必须是Roll或Pitch')
        with self.lock:self.direction=direction;self.points={};self.report_file=None
        return self.status()
    def status(self):
        with self.lock:
            res={'direction':self.direction,'points':{str(x):self.points[x] for x in sorted(self.points)},
                 'report_file':self.report_file,'read_only':True,'analysis':self._analysis()}
        return res
    def _analysis(self):
        if not all(x in self.points for x in (-3,0,3)):
            return {'ready':False,'reason':'请人工定位并依次采集外轴-3°、0°、+3°'}
        left,right=self.points[-3],self.points[3]
        dx=right['outer_actual_deg']-left['outer_actual_deg']
        if not 4.5<=dx<=7.5:return {'ready':False,'reason':'三点外轴实际反馈角度不匹配'}
        target=self.direction;other='pitch' if target=='roll' else 'roll'
        stats={}
        for ch in ('cal','raw'):
            for algo in FILTERS:
                try:
                    a=left['poses'][ch][algo];b=right['poses'][ch][algo]
                    kt=(b[target]-a[target])/dx;ko=(b[other]-a[other])/dx
                except (KeyError,TypeError):continue
                stats[ch+'_'+algo]={'target_gain':round(kt,6), 'cross_axis_gain':round(ko,6),
                    'apparent_2d_cross_axis_deg':round(float(np.degrees(np.arctan2(abs(ko),abs(kt)))),5)}
        return {'ready':bool(stats),'measured_outer_span_deg':dx,'algorithms':stats,
                'interpretation':'二维静态串扰，不等同三维机械安装角；不能单凭它验证动态精度。'}
    def capture(self,point,confirmed=False):
        if not confirmed:raise ValueError('操作员须先确认转台已实际停稳，本功能仅采样')
        if type(point) is not int or point not in (-3,0,3):raise ValueError('仅支持-3°、0°、+3°')
        e=self.engine
        if not(self.table.connected and e.running and e.connected and e.source=='serial'):
            raise ValueError('请先连接真实转台与RS485倾角仪')
        if not(e.cal_status=='matched' and e.latest and e.latest.get('cal')):
            raise ValueError('UID标定数据未加载')
        inner=0 if self.direction=='roll' else 90
        started=time.monotonic_ns();positions=[];reports=[]
        for n in range(8):
            st=self.table.read_status();axes=st['axes']
            x,y=axes['0'],axes['2']
            if not x['healthy'] or not y['healthy'] or any(z[k] for z in (x,y) for k in ('driver_fault','upper_limit','lower_limit','over_speed')):
                raise ValueError('轴状态故障或限位，禁止采集')
            if abs(angle_delta_deg(x['position_deg'],inner))>.35 or abs(angle_delta_deg(y['position_deg'],point))>.35:
                raise ValueError(f'当前位置不符合：内轴{inner}°、外轴{point}°（±0.35°）')
            positions.append((float(x['position_deg']),float(y['position_deg'])))
            reports.append((float(x['speed_dps']),float(y['speed_dps'])))
            if n<7:time.sleep(.28)
        stopped=time.monotonic_ns();spread=np.ptp(np.asarray(positions),axis=0)
        if max(spread)>.025:raise ValueError('约2秒内角度变化超过0.025°，未满足静态采样条件')
        with e.lock:
            rows=[x for x in e.recent if started<=x.get('pc_observed_ns',0)<=stopped and x.get('uid')==e.uid]
        if len(rows)<80:raise ValueError('静态窗口内IMU样本不足80条')
        poses={'raw':{},'cal':{}}
        for ch in ('raw','cal'):
            for algo in FILTERS:
                values=[r.get('outputs',{}).get(algo,{}).get(ch) for r in rows]
                values=[v for v in values if v and 'roll' in v and 'pitch' in v]
                if values:
                    poses[ch][algo]={k:float(np.mean([float(v[k]) for v in values])) for k in ('roll','pitch')}
        record={'outer_command_target_deg':point,'outer_actual_deg':round(float(np.mean(np.asarray(positions)[:,1])),5),
                'inner_actual_deg':round(float(np.mean(np.asarray(positions)[:,0])),5),
                'position_drift_deg':{'inner':round(float(spread[0]),5),'outer':round(float(spread[1]),5)},
                'reported_speed_max_abs_dps':round(max(abs(v) for xy in reports for v in xy),5),
                'reported_speed_not_zero':any(abs(v)>.06 for xy in reports for v in xy),
                'samples':len(rows),'uid':e.uid,'poses':poses}
        with self.lock:
            if self.points and any(x['uid']!=e.uid for x in self.points.values()):
                raise ValueError('UID变化，必须新建检查')
            self.points[point]=record
            data=self.status()
            self.dir.mkdir(parents=True,exist_ok=True)
            name=dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+f'_{e.uid}_{self.direction.upper()}_STATIC_AXIS.json'
            (self.dir/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
            self.report_file=name
        return self.status()
