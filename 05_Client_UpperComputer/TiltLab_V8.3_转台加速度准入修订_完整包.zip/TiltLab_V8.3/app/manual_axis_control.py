"""Guarded vendor-DLL dual-axis positioning for TiltLab's integrated console.

Never runs on import. Real motion requires a live browser, a fresh snapshot,
operator path approval, healthy homed servos, and periodic heartbeat. Each
axis uses the existing R10 DLL, limit/feedback checks, dual-axis STOP and
stopped_verified. This is NOT safety-rated and cannot substitute an E-stop.
"""
from __future__ import annotations

import math
import secrets
import threading
import time

from .angles import angle_delta_deg
from .table_diagnostics import DIAG


class GuardedManualAxis:
    def __init__(self, table, occupied):
        self.table = table
        self.occupied = occupied
        self.lock = threading.RLock()
        self.cancel = threading.Event()
        self.running = False
        self.state = 'idle'
        self.error = ''
        self.target = None
        self.speed = None
        self.position_mode = 'absolute'
        self.observed_relative_travel_deg = 0.0
        self.relative_travel_quality = 'not_applicable'
        self.axis = None
        self.token = None
        self.valid_until = 0
        self.snapshot = None
        self.heartbeat_ns = 0
        self.stopped_verified = None
        self.safety_latched = False
        self.last_feedback = None
        self.thread = None

    def status(self):
        with self.lock:
            return {'running': self.running, 'state': self.state, 'error': self.error,
                    'axis': self.axis, 'target_deg': self.target, 'speed_dps': self.speed,
                    'position_mode': self.position_mode,
                    'observed_relative_travel_deg': self.observed_relative_travel_deg,
                    'relative_travel_quality': self.relative_travel_quality,
                    'stopped_verified': self.stopped_verified, 'safety_latched': self.safety_latched,
                    'last_feedback': self.last_feedback,
                    'note': '手动绝对/相对位置；运动前检查健康、静止和限位；位置参数原样发送厂家DLL'}

    def _exclusive(self):
        if not self.table.connected:
            raise RuntimeError('转台尚未连接')
        if self.occupied():
            raise RuntimeError('有自动实验、准备、监测、使能或关闭转台任务，禁止手动定位')
        if self.running:
            raise RuntimeError('上一项定位尚未结束')
        if self.safety_latched:
            raise RuntimeError('上次定位安全故障未确认处理；本进程不允许再次运动，请现场排障')

    def _check_feedback(self, st, *, must_be_stationary=False, target_speed=None):
        axes = (st or {}).get('axes') or {}
        for axis in (0, 2):
            x = axes.get(str(axis))
            if not x:
                raise RuntimeError(f'轴{axis}反馈不存在')
            if any(not x.get(k) for k in ('enabled', 'zeroed', 'healthy')):
                raise RuntimeError(f'轴{axis}未同时确认使能、机械找零及健康状态')
            if any(x.get(k) for k in ('driver_fault', 'upper_limit', 'lower_limit', 'over_speed')):
                raise RuntimeError(f'轴{axis}检测到驱动故障、限位或超速')
            if not all(isinstance(x.get(k), (int, float)) and math.isfinite(x[k]) for k in ('position_deg', 'speed_dps')):
                raise RuntimeError(f'轴{axis}位置/速度反馈无效')
            if must_be_stationary and (abs(x['speed_dps']) >= .06 or x.get('mode') not in (0, 2, 20)):
                raise RuntimeError(f'轴{axis}没有处于确认静止状态')
            if target_speed is not None and abs(x['speed_dps']) > max(1.0, target_speed + .9):
                raise RuntimeError(f'轴{axis}实测速率异常，触发软件停车')
        return axes

    @staticmethod
    def _validate_target(axis, target, speed, position_mode="absolute"):
        if axis not in (0, 2):
            raise ValueError('仅允许内轴0、外轴2')
        if not math.isfinite(target) or not math.isfinite(speed):
            raise ValueError('角度和速度必须是有限数值')
        if speed <= 0:
            raise ValueError('手动定位速度必须大于0（厂家额定值须由设备控制器保证）')
        if position_mode not in ('absolute', 'relative'):
            raise ValueError('请选择绝对位置或相对位移')
        if position_mode == 'relative' and target == 0:
            raise ValueError('相对位移不能为0')

    def preflight(self, axis, target, speed, position_mode='absolute'):
        axis, target, speed = int(axis), float(target), float(speed)
        self._validate_target(axis, target, speed, position_mode)
        with self.lock:
            self._exclusive()
            st = self.table.read_status()
            axes = self._check_feedback(st, must_be_stationary=True)
            self.snapshot = {a: axes[str(a)]['position_deg'] for a in (0, 2)}
            self.token = secrets.token_urlsafe(22)
            self.valid_until = time.monotonic() + 30
            self.axis, self.target, self.speed = axis, target, speed
            self.position_mode = position_mode
            self.observed_relative_travel_deg = 0.0
            self.relative_travel_quality = 'pending' if position_mode == 'relative' else 'not_applicable'
            self.state, self.error, self.stopped_verified = 'preflight_ok', '', None
            DIAG.snapshot('manual_position_preflight', st, '手动定位仅预检查（无运动指令）')
            return {'token': self.token, 'expires_in_s': 30, 'axis': axis,
                    'target_deg': target, 'speed_dps': speed, 'position_mode': position_mode,
                    'from_deg': axes[str(axis)]['position_deg'],
                    'other_axis_deg': axes[str(2 if axis == 0 else 0)]['position_deg'],
                    'note': '请现场核对从当前位置到目标位置的整条路径、线缆、装夹、负载及实体急停。预检查本身不发送运动指令。'}

    def start(self, token, confirmed):
        with self.lock:
            if confirmed is not True:
                raise ValueError('必须由现场人员再次确认路径与急停')
            self._exclusive()
            if not token or token != self.token or time.monotonic() >= self.valid_until:
                raise RuntimeError('预检查凭证已过期，请重新检查')
            axes = self._check_feedback(self.table.read_status(), must_be_stationary=True)
            if any(abs(angle_delta_deg(axes[str(a)]['position_deg'], self.snapshot[a])) > .1 for a in (0, 2)):
                raise RuntimeError('预检后轴位置发生改变，必须重新检查')
            self.token = None
            self.cancel.clear()
            self.running = True
            self.state, self.error, self.stopped_verified = 'running', '', None
            self.heartbeat_ns = time.monotonic_ns()
            self.thread = threading.Thread(target=self._run, daemon=True, name='2TD600-guarded-manual-position')
            self.thread.start()
            DIAG.record('manual_position_start', '人工确认后开始手动定位', axis=self.axis, target=self.target, speed=self.speed)
            return self.status()

    def heartbeat(self):
        with self.lock:
            if not self.running:
                raise ValueError('当前没有手动定位任务')
            self.heartbeat_ns = time.monotonic_ns()
            return {'ok': True}

    def abort(self):
        self.cancel.set()
        if self.table.connected:
            self.table.stop()
        return self.status()

    def _run(self):
        try:
            axis, target, speed = self.axis, self.target, self.speed
            mode = self.position_mode
            start_position = self.snapshot[axis]
            if hasattr(self.table, 'manual_position'):
                self.table.manual_position(axis, target, speed, mode)
            elif mode == 'absolute':
                # Old test doubles may not provide the new operator-only API.
                if axis == 0:
                    self.table.move_inner_manual(target, speed)
                else:
                    self.table.move(axis, target, speed)
            else:
                raise RuntimeError('当前转台驱动缺少相对位移 SetAxisOpposition 封装')
            DIAG.record('manual_position_command', '已向厂家DLL发送手动位置命令',
                        axis=axis, target=target, speed=speed, position_mode=mode)
            # Relative travel is a signed displacement. Never substitute a
            # shortest 360-degree angular difference for the requested travel.
            travel_budget = abs(target) if mode=='relative' else abs(target-start_position)
            deadline = time.monotonic() + min(3600, max(20, travel_budget / speed * 3 + 20))
            stable = 0
            idle_stable = 0
            previous_motor_position = start_position
            last_position = start_position
            last_obs_ns = time.monotonic_ns()
            accumulated = 0.0
            observable = True
            started_at = time.monotonic()
            while time.monotonic() < deadline:
                if self.cancel.is_set():
                    raise RuntimeError('操作员请求中止')
                if time.monotonic_ns() - self.heartbeat_ns > 6_000_000_000:
                    raise RuntimeError('浏览器心跳超过6秒未到，执行停车')
                if not self.table.connected:
                    raise RuntimeError('转台连接丢失')
                st = self.table.read_status()
                axes = self._check_feedback(st, target_speed=speed)
                here = axes[str(axis)]
                now_ns = time.monotonic_ns()
                diff = angle_delta_deg(here['position_deg'], last_position)
                # A wrapped encoder cannot distinguish rotations of >180 degrees
                # between reads. Mark, do not invent, a reliable turn count.
                elapsed = (now_ns-last_obs_ns)/1e9
                if (abs(diff) >= 145.0 or elapsed > .5 or
                        max(abs(here['speed_dps']), speed) * elapsed > 145.0 or
                        abs(diff) > max(4.0, speed*elapsed*2.0+3.0)):
                    observable = False
                accumulated += diff
                last_position = here['position_deg']
                last_obs_ns = now_ns
                with self.lock:
                    self.last_feedback = {'time_monotonic_ns': st.get('time_monotonic_ns'),
                                          'axis': axis, 'position_deg': here['position_deg'],
                                          'speed_dps': here['speed_dps']}
                    if mode == 'relative':
                        self.observed_relative_travel_deg = accumulated
                        self.relative_travel_quality = 'observed_unwrapped' if observable else 'uncertain_360_wrap'
                stationary_encoder = abs(angle_delta_deg(here['position_deg'], previous_motor_position)) < .015
                idle_stable = idle_stable+1 if stationary_encoder else 0
                previous_motor_position = here['position_deg']
                motor_idle = (idle_stable >= 3 and here.get('in_place')
                              and here.get('mode') in (0, 2, 20)
                              and abs(here['speed_dps']) < .06)
                if mode == 'relative':
                    reached = observable and abs(accumulated-target) <= max(.2, abs(target)*.002)
                else:
                    # Absolute 0 and 360 are the same orientation; this does NOT
                    # prove a full turn physically occurred.
                    reached = abs(angle_delta_deg(here['position_deg'], target)) <= .12
                if motor_idle and reached and time.monotonic()-started_at >= .45:
                    stable += 1
                    if stable >= 3:
                        self.state = 'at_target' if mode=='absolute' else 'relative_observed_complete'
                        break
                else:
                    stable = 0
                # When the controller is idle but wrapped multi-turn tracking
                # cannot prove the requested travel, do not claim completion.
                if mode=='relative' and motor_idle and time.monotonic()-started_at > 1.3:
                    if not observable or abs(accumulated-target)>max(.2, abs(target)*.002):
                        raise RuntimeError('控制器已静止，但多圈累计转角未被独立证实；不宣称完成')
                if self.cancel.wait(.14):
                    raise RuntimeError('操作员请求中止')
            else:
                raise TimeoutError('手动定位超时，执行停车')
        except Exception as exc:
            with self.lock:
                self.error = f'{type(exc).__name__}: {exc}'
                self.state = 'failed'
            DIAG.record('manual_position_failed', '手动定位失败，尝试双轴STOP', error=str(exc))
        finally:
            try:
                self.table.stop()
                confirmed = self.table.stopped_verified(timeout=20)
                with self.lock:
                    self.stopped_verified = confirmed
                    if not confirmed:
                        self.safety_latched = True
                        self.state = 'failed'
                        self.error += '；停车反馈未确认，请使用实体急停，禁止再运动'
            except Exception as stop_exc:
                with self.lock:
                    self.stopped_verified = False
                    self.safety_latched = True
                    self.state = 'failed'
                    self.error += '；STOP故障，请使用实体急停：' + str(stop_exc)
            finally:
                DIAG.record('manual_position_finished', '手动定位任务结束', state=self.state,
                            stopped_verified=self.stopped_verified, error=self.error)
                with self.lock:
                    self.running = False
