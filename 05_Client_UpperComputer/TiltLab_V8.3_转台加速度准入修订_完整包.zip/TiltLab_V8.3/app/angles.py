"""Circular encoder-angle handling for 2TD-600.

Raw encoder feedback is retained for forensic logs. Zero and position equality
are checked modulo 360 degrees; relative motion is unwrapped for analysis.
"""
import math


def angle_delta_deg(value, reference=0.0):
    """Signed shortest delta, in [-180, 180), from reference to value."""
    value = float(value)
    reference = float(reference)
    if not math.isfinite(value) or not math.isfinite(reference):
        raise ValueError("位置角度必须为有限数值")
    return (value - reference + 180.0) % 360.0 - 180.0


def zero_distance_deg(value):
    return abs(angle_delta_deg(value))


def unwrap_encoder_deg(values):
    """Unwrap degree-series across 359.9/0.1 seam without smoothing samples."""
    import numpy as np
    arr = np.asarray(values, dtype=float)
    if np.any(~np.isfinite(arr)):
        raise ValueError("角度序列存在无效值")
    return np.rad2deg(np.unwrap(np.deg2rad(arr)))
