"""Experimental motion-aware IMU attitude filter (no encoder or future samples).

This is a diagnostic branch alongside the original production/research filters.
Stationary bias is identified only after sustained low-motion evidence; during
rotation, roll/pitch gravity correction is suppressed, rather than assuming
acceleration magnitude close to 1 g proves the direction is uncontaminated.
No calibration matrix is overwritten and no motion control is performed.
"""
from __future__ import annotations
import math
from .fusion import R, D, norm, cross, gravity_body, q_to_euler, initial_q, integrate, clamp, emit


class MotionGuard:
    """Causal Mahony-type observer with deliberately low motion ACC confidence.

    - Gyro bias is estimated from a sustained *start-of-run stationary* period.
    - Motion holdoff spans sinusoidal rate zero crossings; these are not static.
    - Gravity correction remains strong at rest and attenuates while moving.
    - Encoder/time shift never feeds back into the filter.

    Parameters are intentionally internal to this *experimental* algorithm.
    Never interpret the resulting error as a certified dynamic accuracy.
    """
    def __init__(self, p):
        self.p=p
        self.q=None
        self.bias=[0.,0.,0.]
        self._initial_bias_samples=[]
        self._initial_bias_frozen=False
        self._last_g=None
        self._gyro_lp=None
        self._last_a=None
        self._holdoff_s=0.
        self._moving=False
        self._static_duration=0.
        self._trust=0.
        self._evidence_residual=0.

    def update(self, a, g, dt):
        if self.q is None:
            self.q=initial_q(a)
        if dt<=0 or not all(math.isfinite(float(v)) for v in (*a,*g,dt)):
            return self._out()
        if dt>.25:
            # A long interval must never result in a huge gyro integration.
            self._holdoff_s=.8
            self._last_a=list(a);self._last_g=list(g)
            return self._out()
        rate=norm(g)
        da=norm([a[i]-self._last_a[i] for i in range(3)])/dt if self._last_a is not None else 0.
        # Low-pass the gyro *before* differentiating, otherwise measurement
        # noise at 350-833 Hz looks like enormous angular acceleration and
        # prevents the true stationary baseline from ever being recognized.
        previous_lp=self._gyro_lp if self._gyro_lp is not None else list(g)
        beta=1.-math.exp(-dt/.12)
        self._gyro_lp=[previous_lp[i]+beta*(g[i]-previous_lp[i]) for i in range(3)]
        dg=norm([self._gyro_lp[i]-previous_lp[i] for i in range(3)])/dt
        self._last_a=list(a);self._last_g=list(g)
        # Use both observed rate and rate derivative. At turning points of a
        # sinusoid the rate is zero but the acceleration is at its maximum.
        detected_moving=rate>0.8 or dg>0.9
        self._holdoff_s=.8 if detected_moving else max(0.,self._holdoff_s-dt)
        self._moving=self._holdoff_s>0
        stationary=(not self._moving and rate<.5 and da<8.0 and abs(norm(a)-1.)<.04)
        self._static_duration=self._static_duration+dt if stationary else 0.
        if not self._initial_bias_frozen and stationary:
            # Collect after 0.4 s of stable observations; avoid transition data.
            if self._static_duration>=.4:
                self._initial_bias_samples.append(list(g))
            if self._static_duration>=1.2 and len(self._initial_bias_samples)>=50:
                # Mean of stationary observations; bounded to reject a gross
                # nonstationary / broken-unit input instead of removing motion.
                self.bias=[clamp(sum(v[i] for v in self._initial_bias_samples)/len(self._initial_bias_samples),-.5,.5)
                           for i in range(3)]
                self._initial_bias_frozen=True
                self._initial_bias_samples=[]
        # No adaptation during motion, no learning a sinusoidal turning point.
        corrected=[g[i]-self.bias[i] for i in range(3)]
        predicted=integrate(self.q,corrected,dt)
        expected=gravity_body(predicted)
        n=norm(a)
        trust=0.
        if n>.2:
            unit=[v/n for v in a]
            error=cross(unit,expected)
            self._evidence_residual=norm(error)
            magnitude=math.exp(-((n-1.)/self.p.acc_threshold)**2)
            # Directional innovation by itself cannot separate a true static
            # tilt from a rotation-induced acceleration. Suppress updates when
            # the gyroscope demonstrates actual motion.
            motion_weight=.025 if self._moving else 1.
            direction_weight=math.exp(-(self._evidence_residual/.25)**2)
            trust=clamp(magnitude*direction_weight*motion_weight,0.,1.)
            # Correction is fed to the gyro-rate integration without modifying
            # the manufacturer's calibrated gyro samples or calibration files.
            corrected=[corrected[i]+self.p.kp*trust*error[i]*D for i in range(3)]
        self._trust=trust
        self.q=integrate(self.q,corrected,dt)
        return self._out()

    def _out(self):
        return {**emit(self.q,self._trust),
                'gyro_bias_dps':[round(v,6) for v in self.bias],
                'stationary_bias_ready':self._initial_bias_frozen,
                'motion_detected':self._moving,
                'accel_direction_residual':round(self._evidence_residual,6)}
