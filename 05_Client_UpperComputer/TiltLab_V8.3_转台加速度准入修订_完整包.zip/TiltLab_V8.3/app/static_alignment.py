"""Session-only, fixture-referenced static Roll/Pitch angle alignment.

Small-angle (±5 deg) empirical output-frame affine correction, NOT a 3-D
installation rotation, not an accelerometer/gyro factory calibration, and not
valid by default outside the measured fixture, temperature or angle domain.

Fit ONLY outbound calibration-ACC points, validate on reversed points and on
an independently computed fusion output. Refuse to apply unobservable or
unphysical fits. Preserve pre-alignment readings in every hardware capture.
"""
from __future__ import annotations
import math
import numpy as np
from .fusion import euler_to_q


def _sample_vector(st,algorithm):
    pose=(st.get('angles') or {}).get('cal',{}).get(algorithm)
    if pose is None:return None
    try:
        r,p=float(pose['roll']),float(pose['pitch'])
    except (ValueError,TypeError,KeyError):return None
    return [r,p] if math.isfinite(r) and math.isfinite(p) else None


def _points(reports,algorithm):
    result=[]
    for report in reports:
        direction=report['output'];sign=int(report['analysis']['reference_sign'])
        for step in report['items']:
            values=_sample_vector(step,algorithm)
            if values is None:raise ValueError(f'{direction}静态点缺少cal_{algorithm}数据')
            true_angle=sign*float(step['actual_outer_deg'])
            if not math.isfinite(true_angle):raise ValueError('转台静态参考角不是有限数值')
            ref=[true_angle,0.] if direction=='roll' else [0.,true_angle]
            result.append({'ref':ref,'measured':values,'travel':step.get('travel',''),
                           'direction':direction,'target':float(step['target_deg'])})
    return result


def _metrics(points,bias,matrix):
    if not points:return {'samples':0,'max_abs_deg':None,'rmse_deg':None,'p95_abs_deg':None}
    y=np.asarray([p['measured'] for p in points],dtype=float)
    r=np.asarray([p['ref'] for p in points],dtype=float)
    estimate=np.linalg.solve(matrix,(y-np.asarray(bias)).T).T
    # Evaluate the commanded Roll/Pitch component AND crosstalk on the other.
    err=estimate-r
    abs_err=np.abs(err).ravel()
    return {'samples':len(points),'max_abs_deg':round(float(abs_err.max()),6),
            'rmse_deg':round(float(np.sqrt(np.mean(err**2))),6),
            'p95_abs_deg':round(float(np.percentile(abs_err,95)),6),
            'roll_max_abs_deg':round(float(np.abs(err[:,0]).max()),6),
            'pitch_max_abs_deg':round(float(np.abs(err[:,1]).max()),6)}


def _raw_metrics(points):return _metrics(points,[0.,0.],np.eye(2))


def fit_static_alignment(reports,uid,calibration_mode,active_algorithm,threshold_deg=.1):
    """Return an auditable two-axis candidate, never auto-apply on failure.

    Train on outbound points; validate reverse traversal. Excludes zero-angle
    repeats from over-weighting the fit. Independent calibration-ACC is used for
    the physical gravity reference and ACTIVE fused-angle validation is also
    checked. Results are session-scoped and keyed to UID/mode.
    """
    answer={'valid':False,'applied':False,'uid':uid,'calibration_mode':calibration_mode,
            'fit_algorithm':'accel','active_algorithm':active_algorithm,
            'threshold_deg':float(threshold_deg),'kind':'SMALL_ANGLE_FIXTURE_AFFINE',
            'note':'静态小角度经验对齐；不可解释为精确3D安装角，不能取代工厂标定。输出保留原厂标定角；反向行程独立验收。'}
    if not uid or calibration_mode not in ('ambient','thermal'):
        answer['reason']='缺少真实UID或有效标定模式';return answer
    if len(reports)!=2 or {r['output'] for r in reports}!={'roll','pitch'}:
        answer['reason']='完整的双轴安装对齐要求Roll与Pitch两套静态检查';return answer
    if len({r.get('uid') for r in reports})!=1 or reports[0].get('uid')!=uid:
        answer['reason']='静态数据UID与当前设备不一致';return answer
    if any(r.get('calibration_mode')!=calibration_mode for r in reports):
        answer['reason']='静态数据标定模式与当前设备不一致';return answer
    try:
        source=_points(reports,'accel')
        active=_points(reports,active_algorithm)
        train=[p for p in source if p['travel']=='out']
        holdout=[p for p in source if p['travel']=='back']
        active_holdout=[p for p in active if p['travel']=='back']
        if len(train)<12 or len(holdout)<10 or len(active_holdout)<10:
            raise ValueError('正向拟合或反向验证静态点不足')
        X=np.asarray([[*p['ref'],1.] for p in train],dtype=float)
        Y=np.asarray([p['measured'] for p in train],dtype=float)
        if np.linalg.matrix_rank(X)<3 or np.linalg.cond(X)>20:
            raise ValueError('静态点阵列退化，无法区分X/Y误差')
        coefficients=np.linalg.lstsq(X,Y,rcond=None)[0]
        # measured = A @ true + b
        matrix=coefficients[:2,:].T
        bias=coefficients[2,:]
        determinant=float(np.linalg.det(matrix))
        if not np.all(np.isfinite(matrix)) or not np.all(np.isfinite(bias)):
            raise ValueError('静态拟合存在非有限参数')
        if not (.7<matrix[0,0]<1.3 and .7<matrix[1,1]<1.3 and
                max(abs(matrix[0,1]),abs(matrix[1,0]))<.3 and
                min(abs(bias))<10 and max(abs(bias))<10 and determinant>.55):
            raise ValueError('偏差过大或方向/量程异常，拒绝自动用拟合掩盖安装或标定故障')
        ref_val=_metrics(holdout,bias,matrix)
        active_val=_metrics(active_holdout,bias,matrix)
        before_source=_raw_metrics(holdout)
        before_active=_raw_metrics(active_holdout)
        answer.update(matrix=[[round(float(v),9) for v in row] for row in matrix],
                      bias_deg=[round(float(v),9) for v in bias],
                      determinant=round(determinant,7),
                      train_points=len(train),validation_points=len(holdout),
                      validation_accel_before=before_source,
                      validation_accel_after=ref_val,
                      validation_active_before=before_active,
                      validation_active_after=active_val,
                      effective_roll_zero_offset_deg=round(float(bias[0]),6),
                      effective_pitch_zero_offset_deg=round(float(bias[1]),6),
                      active_statically_pass=active_val['max_abs_deg']<=threshold_deg,
                      gravity_statically_pass=ref_val['max_abs_deg']<=threshold_deg)
        # A trained correction may not be enabled if it has made either
        # independent validation channel worse by more than the noise margin.
        if ref_val['rmse_deg']>before_source['rmse_deg']+.01 or active_val['rmse_deg']>before_active['rmse_deg']+.01:
            answer['reason']='独立反向点验证未改善，加计或当前融合输出恶化；不应用补偿';return answer
        answer.update(valid=True,reason=('拟合与留出验证完成，静态满足门槛' if answer['active_statically_pass']
                                         else '拟合与留出验证完成，但静态留出误差仍超过门槛'))
    except (ValueError,KeyError,TypeError,np.linalg.LinAlgError) as exc:
        answer['reason']=str(exc)
    return answer


def align_pose(pose,alignment):
    if pose is None:return None
    y=np.array([float(pose['roll']),float(pose['pitch'])],dtype=float)
    a=np.array(alignment['matrix'],dtype=float)
    b=np.array(alignment['bias_deg'],dtype=float)
    z=np.linalg.solve(a,y-b)
    result=dict(pose)
    result.update(roll=float(z[0]),pitch=float(z[1]),
                  q=euler_to_q(float(z[0]),float(z[1]),float(pose.get('yaw',0))))
    return result
