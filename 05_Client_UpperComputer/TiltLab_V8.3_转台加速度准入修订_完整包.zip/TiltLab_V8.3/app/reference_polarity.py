"""Conservative stationary, fixture-specific encoder-to-output reference polarity inference.

Never commands hardware; never reverses motors or changes factory calibration.
Both independent gravity and selected fusion angles must agree, including reverse
traversal. Incorrect or uncertain polarity is a BLOCK, not an automatic pass.
"""
from __future__ import annotations
import math
import numpy as np


def infer_static_polarity(report, requested_sign, active_algorithm):
    output=report.get('output')
    result={'valid':False,'output':output,'requested_sign':int(requested_sign),
            'selected_sign':None,'changed':False,'channels':{},
            'note':'只修正转台编码器→IMU输出的比较符号，不发送反向运动，不改IMU标定。'}
    if output not in ('roll','pitch') or requested_sign not in (-1,1):
        result['reason']='方向或手动符号输入不合法';return result
    steps=report.get('items') or []
    if len(steps)<12 or sum(st.get('travel')=='out' for st in steps)<6 or sum(st.get('travel')=='back' for st in steps)<5:
        result['reason']='没有充分的正向及反向静态验证点';return result
    algos=['accel',active_algorithm]
    if active_algorithm=='accel':
        algos=['accel','madgwick']
    if len(set(algos))<2:
        result['reason']='无法获取两个独立静态角度通道';return result
    sign_votes=[]
    for algo in algos:
        try:
            x=np.array([float(st['actual_outer_deg']) for st in steps])
            y=np.array([float(st['angles']['cal'][algo][output]) for st in steps])
            travel=np.array([st.get('travel')=='out' for st in steps])
            if not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):
                raise ValueError('检测到非有限的实际角度')
            if np.ptp(x)<2. or np.ptp(x[travel])<2. or np.ptp(x[~travel])<2.:
                raise ValueError('静态扫描跨度不足±1°，无法识别方向')
            gain,bias=np.polyfit(x[travel],y[travel],1)
            reverse_residual=y[~travel]-(gain*x[~travel]+bias)
            reverse_rmse=float(np.sqrt(np.mean(reverse_residual**2)))
            corr=float(np.corrcoef(x,y)[0,1])
            vote=1 if gain>0 else -1
            result['channels'][algo]={'slope_deg_per_deg':round(float(gain),6),
                'bias_deg':round(float(bias),6),'reverse_rmse_deg':round(reverse_rmse,6),
                'correlation':round(corr,6),'sign':vote}
            # Reject other axes, incoherent trend, poor reversal repeatability or implausible gain.
            if not .70<=abs(gain)<=1.30 or abs(corr)<.975 or reverse_rmse>.22 or abs(bias)>9:
                raise ValueError(f'{algo}变化幅度/一致性异常，不能安全判断方向')
            sign_votes.append(vote)
        except (TypeError,ValueError,KeyError,IndexError,np.linalg.LinAlgError) as exc:
            result['reason']=f'{output}静态参考极性不确定：{exc}';return result
    if sign_votes[0]!=sign_votes[1]:
        result['reason']=f'{output}加速度与融合角度的极性相互矛盾，禁止继续';return result
    selected=sign_votes[0]
    result.update(valid=True,selected_sign=selected,changed=selected!=requested_sign,
                  reason=('自动发现'+output.upper()+'比较方向应为反向（−），已基于正反向静态点核对' if selected==-1
                          else '自动确认'+output.upper()+'比较方向为同向（+）'))
    return result


def update_static_polarity(report, original_sign, selected_sign, active_algorithm):
    """Change only reference comparison, and preserve original raw and incorrect-sign stats."""
    from .static_accuracy import summarize_static
    if selected_sign not in (-1,1):raise ValueError('无效方向')
    if original_sign!=selected_sign:
        report['analysis_with_original_reference_sign']=report['analysis']
    report['analysis']=summarize_static(report['items'],report['output'],selected_sign,
                                       report.get('threshold_deg',report['analysis'].get('threshold_deg',.1)),active_algorithm)
    for step in report['items']:
        pose=step['angles']['cal'][active_algorithm]
        step['current_signed_error_deg']=float(pose[report['output']])-selected_sign*float(step['actual_outer_deg'])
    return report
