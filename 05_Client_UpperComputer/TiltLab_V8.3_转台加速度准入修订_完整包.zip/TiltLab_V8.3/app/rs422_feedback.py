"""2TD-600 Appendix-A high-rate *read-only* status receiver.

Only parses 55-byte 0xA0 periodic status frames. It NEVER sends serial
commands. The channel MUST be a separate physical serial port from the
vendor DLL motion-control connection, and must be validated in situ before
using readings as metrological references. Endianness can be configured;
protocol description provides typed fields but not a wire-endian example.
"""
from __future__ import annotations
import csv
import datetime as dt
import math
import struct
import threading
import time
from collections import deque
from pathlib import Path

BAUDS=(115200,921600)
FRAMESIZE=55
COLUMNS=['pc_monotonic_ns','pc_utc','counter','device_datetime','device_milliseconds',
         'inner_status_raw','inner_position_deg','inner_speed_dps',
         'middle_status_raw','middle_position_deg','middle_speed_dps',
         'outer_status_raw','outer_position_deg','outer_speed_dps',
         'status_header_bytes','byte_order','checksum_valid']


def parse_status_frame(frame:bytes,byte_order='little'):
    if not isinstance(frame,(bytes,bytearray)) or len(frame)!=FRAMESIZE:
        raise ValueError('status frame must contain 55 bytes')
    if frame[:2] not in (b'\xAA\x55',b'\x55\xAA') or frame[2]!=55 or frame[3]!=1 or frame[4]!=0xA0 or frame[-1]!=0xFE:
        raise ValueError('invalid 2TD-600 A.0 status header or trailer')
    if sum(frame[2:53])&255 != frame[53]:
        raise ValueError('2TD-600 A.0 status checksum mismatch')
    endian={'little':'<','big':'>'}.get(byte_order)
    if endian is None:raise ValueError('byte order must be little or big')
    u16=lambda n:struct.unpack_from(endian+'H',frame,n)[0]
    i16=lambda n:struct.unpack_from(endian+'h',frame,n)[0]
    u32=lambda n:struct.unpack_from(endian+'I',frame,n)[0]
    f32=lambda n:float(struct.unpack_from(endian+'f',frame,n)[0])
    # 1-based specification: inner at 24..33, middle 34..43, outer 44..53.
    pairs=[('inner',23),('middle',33),('outer',43)]
    result={'counter':u32(5),'device_milliseconds':u16(21),'status_header_bytes':frame[:2].hex(),
            'byte_order':byte_order,'checksum_valid':True}
    for name,start in pairs:
        raw=u16(start);position=f32(start+2);speed=f32(start+6)
        if not math.isfinite(position) or not math.isfinite(speed) or abs(position)>100000 or abs(speed)>100000:
            raise ValueError('invalid physical float values; check byte order')
        result.update({name+'_status_raw':raw,name+'_position_deg':position,name+'_speed_dps':speed})
    t=[i16(x) for x in (9,11,13,15,17,19,21)]
    try:
        val=dt.datetime(*t[:6],microsecond=t[6]*1000)
        result['device_datetime']=val.isoformat(timespec='milliseconds')
    except (ValueError,OverflowError):
        result['device_datetime']=''  # vendor clock may be unconfigured
    return result


class FrameStreamParser:
    def __init__(self,byte_order='little'):
        self.byte_order=byte_order;self.buffer=bytearray();self.bad_frames=0
    def feed(self,chunk):
        self.buffer.extend(chunk)
        if len(self.buffer)>100000:self.buffer=self.buffer[-100000:]
        frames=[]
        while len(self.buffer)>=FRAMESIZE:
            starts=[self.buffer.find(x) for x in (b'\xAA\x55',b'\x55\xAA')]
            starts=[x for x in starts if x>=0]
            if not starts:
                self.buffer=self.buffer[-1:];break
            start=min(starts)
            if start:del self.buffer[:start]
            if len(self.buffer)<FRAMESIZE:break
            candidate=bytes(self.buffer[:FRAMESIZE])
            try:
                parsed=parse_status_frame(candidate,self.byte_order)
            except ValueError:
                self.bad_frames+=1;del self.buffer[0];continue
            frames.append(parsed);del self.buffer[:FRAMESIZE]
        return frames


class ReadOnlyFeedback422:
    def __init__(self,root:Path,table):
        self.dir=Path(root);self.table=table;self.lock=threading.RLock();self.thread=None
        self.stop_event=threading.Event();self.running=False;self.port='';self.baudrate=921600
        self.byte_order='little';self.error='';self.count=0;self.dropped=0;self.bad=0;self.last_counter=None
        self.latest=None;self.path=None;self.frame_history=deque(maxlen=2500);self.started_ns=None
    def status(self):
        with self.lock:
            age=(time.monotonic_ns()-self.latest['pc_monotonic_ns'])/1e6 if self.latest else None
            elapsed=(time.monotonic_ns()-self.started_ns)/1e9 if self.started_ns else 0
            rate=round(self.count/elapsed,2) if elapsed>0 else 0
            return {'running':self.running,'measured_rate_hz':rate,'port':self.port,'baudrate':self.baudrate,'byte_order':self.byte_order,
                    'samples':self.count,'estimated_missing_counter_values':self.dropped,
                    'rejected_frames':self.bad,'latest':self.latest,'latest_age_ms':round(age,1) if age is not None else None,
                    'file':self.path.name if self.path else None,'error':self.error,
                    'note':'专用第二串口，协议状态帧只读；未与IMU实现硬件同步，严禁作为自动使能或安全停车证明'}
    def start(self,port,baudrate=921600,byte_order='little'):
        port=str(port).strip()
        if not port:raise ValueError('请先选择独立RS422/RS232状态串口')
        if int(baudrate) not in BAUDS:raise ValueError('波特率只允许115200或921600')
        if byte_order not in ('little','big'):raise ValueError('数据字节序选择无效')
        if self.table.connected and self.table.port is not None:
            try:
                if port.upper().startswith('COM') and port[3:].isdigit() and int(port[3:])==int(self.table.port):
                    raise ValueError('独立状态串口不能与DLL控制端口相同，避免两进程抢占与数据丢失')
            except (TypeError,AttributeError):pass
        with self.lock:
            if self.running:raise ValueError('独立状态采集已经运行')
            # Validate the port before changing running state.
            try:import serial
            except ImportError as exc:raise RuntimeError('请先运行安装依赖.bat安装pyserial') from exc
            link=serial.Serial(port=port,baudrate=baudrate,timeout=.05)
            self.dir.mkdir(parents=True,exist_ok=True)
            name=dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_2TD600_NATIVE_STATUS_READONLY.csv'
            self.path=self.dir/name
            self.port=port;self.baudrate=int(baudrate);self.byte_order=byte_order
            self.count=self.dropped=self.bad=0;self.last_counter=None;self.latest=None;self.error=''
            self.frame_history.clear();self.stop_event.clear();self.running=True;self.started_ns=time.monotonic_ns()
            self.thread=threading.Thread(target=self._run,args=(link,),daemon=True,name='2TD600-native-feedback')
            self.thread.start()
            return self.status()
    def stop(self):
        self.stop_event.set()
        thread=self.thread
        if thread and thread is not threading.current_thread():thread.join(timeout=3)
        return self.status()
    def _run(self,link):
        parser=FrameStreamParser(self.byte_order)
        try:
            with self.path.open('w',encoding='utf-8-sig',newline='') as f:
                w=csv.DictWriter(f,fieldnames=COLUMNS);w.writeheader()
                while not self.stop_event.is_set():
                    data=link.read(max(55,link.in_waiting or 55))
                    now_ns=time.monotonic_ns()
                    for result in parser.feed(data):
                        result['pc_monotonic_ns']=now_ns
                        result['pc_utc']=dt.datetime.now().astimezone().isoformat(timespec='milliseconds')
                        c=result['counter']
                        with self.lock:
                            if self.last_counter is not None:
                                jump=(c-self.last_counter)&0xffffffff
                                if 1<jump<100000:self.dropped+=jump-1
                            self.last_counter=c;self.latest=result
                            self.frame_history.append(result);self.count+=1
                        w.writerow(result)
                    with self.lock:self.bad=parser.bad_frames
                    if self.stop_event.is_set():break
                f.flush()
        except Exception as exc:
            with self.lock:self.error=f'{type(exc).__name__}: {exc}'
        finally:
            try:link.close()
            except Exception:pass
            with self.lock:self.bad=parser.bad_frames;self.running=False

