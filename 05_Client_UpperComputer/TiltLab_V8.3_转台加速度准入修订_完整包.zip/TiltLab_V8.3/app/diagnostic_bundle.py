"""Single-run diagnostic export. Read only; never operates hardware."""
from pathlib import Path
import csv,io,json,zipfile,datetime


def make_bundle(report_dir,record_dir,name):
    report_dir,record_dir=Path(report_dir),Path(record_dir)
    if Path(name).name!=name or not name.endswith('_DYNAMIC.json'):raise ValueError('请选择单轴动态JSON报告')
    report=report_dir/name
    r=json.loads(report.read_text(encoding='utf-8'))
    if r.get('kind')!='REAL_2TD600_SINE_DIAGNOSTIC':raise ValueError('不是单轴动态报告')
    buf=io.BytesIO();notes=[];members=set()
    def safe(root,n):
        if not n or Path(n).name!=n:return None
        p=root/n
        if p.is_file() and p.resolve().parent==root.resolve():return p
        return None
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        def add(root,n):
            p=safe(root,n)
            if p and p.name not in members:z.write(p,p.name);members.add(p.name)
            elif n:notes.append('未找到：'+str(n))
        add(report_dir,name)
        for n in (r.get('raw_file_imu'),r.get('raw_file_table'),(r.get('offline_replay') or {}).get('file'),r.get('html_report_file')):add(report_dir,n)
        snap=safe(report_dir,r.get('calibration_snapshot_file'))
        if snap:
            with zipfile.ZipFile(snap) as src:
                for i in src.infolist():
                    if Path(i.filename).name==i.filename and i.filename.endswith('.json') and i.file_size<=4_000_000 and i.filename not in members:
                        z.writestr(i.filename,src.read(i));members.add(i.filename)
        else:notes.append('未保存本次标定原文件快照；不事后猜测或复制其他标定文件')
        begin=r.get('pipeline_start') or {};end=r.get('pipeline_end') or {}
        lo=begin.get('poll_count');hi=end.get('poll_count')
        if isinstance(lo,int) and isinstance(hi,int) and 0<=lo<=hi:
            for typ,n in [('poll',end.get('poll_file')),('raw',end.get('raw_file'))]:
                src=safe(record_dir,n)
                if not src:notes.append('缺少独立'+typ+'记录');continue
                # Export only this experiment (+one preceding request), not the
                # full connection session. A partially flushed tail is flagged.
                count=0;min_id=None;max_id=None
                with src.open(encoding='utf-8-sig',newline='') as f:
                    reader=csv.DictReader(f)
                    if not reader.fieldnames or 'poll_id' not in reader.fieldnames:
                        notes.append('独立'+typ+'记录无poll_id，无法截取');continue
                    out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=reader.fieldnames);w.writeheader()
                    for row in reader:
                        try:i=int(row.get('poll_id') or '')
                        except ValueError:continue
                        if i<max(1,lo-1):continue
                        if i>hi:break
                        if None in row or any(v is None for v in row.values()):continue
                        w.writerow(row);count+=1;min_id=i if min_id is None else min_id;max_id=i
                z.writestr(report.stem+'_'+typ+'_link_excerpt.csv',out.getvalue().encode('utf-8-sig'))
                notes.append(f'{typ}：{count}行，实际poll_id {min_id}..{max_id}；目标范围 {max(1,lo-1)}..{hi}')
                if typ=='poll' and (max_id!=hi or min_id!=max(1,lo-1)):notes.append('轮询日志范围不全（可能尚未写入）；请在实验结束后再次导出。')
        else:notes.append('旧报告无逐轮询区间；仅导出实验CSV。')
        # Include only selected link/report events near this run; no unrelated session logs.
        try:
            finish=datetime.datetime.fromisoformat(r['finished_at']);low=finish-datetime.timedelta(seconds=float(r['plan']['duration_s'])+60)
            high=finish+datetime.timedelta(seconds=120)
            events=[]
            for log in sorted((report_dir.parent/'logs').glob('2TD600_*.jsonl')):
                for line in log.open(encoding='utf-8'):
                    try:
                        event=json.loads(line);when=datetime.datetime.fromisoformat(event['time'])
                        if low<=when<=high and event.get('stage') in ('imu_watchdog_failure','dynamic_report_worker_complete','auto_failed','auto_stage_complete'):
                            events.append(event)
                    except (ValueError,KeyError,TypeError):continue
            if events:z.writestr(report.stem+'_link_watchdog_events.json',json.dumps(events,ensure_ascii=False,indent=2))
        except (OSError,ValueError,KeyError,TypeError):notes.append('本次链接看门狗事件不可用')
        z.writestr('诊断包说明.txt',('独立原始链路截取范围以实验起止快照为准；所有时间均未硬件同步。\n'+'\n'.join(notes)).encode('utf-8-sig'))
    return buf.getvalue()


def make_light_bundle(report_dir,name):
    """Compact research bundle: preserve full measured IMU/table rows and calibration snapshots;
    omit duplicate replay, HTML, and raw-link polls. Not a link fault diagnostic.
    """
    root=Path(report_dir).resolve()
    if Path(name).name!=name or not name.endswith('_DYNAMIC.json'):raise ValueError('请选择单轴动态JSON报告')
    r=json.loads((root/name).read_text(encoding='utf-8'))
    if r.get('kind')!='REAL_2TD600_SINE_DIAGNOSTIC':raise ValueError('不是单轴动态报告')
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        # Small metadata summary deliberately omits chart arrays and repeated offline series.
        keys=('kind','uid','plan','state','error','finished_at','calibration_mode','calibration_files','fusion_parameters_used','imu_algorithm_at_start','imu_samples','table_samples','pipeline_start','pipeline_end','temperature_diagnostics','stopped_verified','motion_start_pc_monotonic_ns','motion_end_pc_monotonic_ns','raw_file_imu','raw_file_table','reference_provenance','quality','certified_dynamic_accuracy','static_alignment','offline_replay')
        compact={k:r[k] for k in keys if k in r}
        a=r.get('analysis') or {};compact['analysis']={k:a[k] for k in ('valid','reason','comparison','absolute_accuracy','reference_quality','reference_steady_state','imu_sampling_diagnostics','feedback_rate_hz','max_feedback_gap_ms') if k in a}
        z.writestr(name,json.dumps(compact,ensure_ascii=False,indent=2))
        for k in ('raw_file_imu','raw_file_table','calibration_snapshot_file'):
            n=r.get(k)
            if not n or Path(n).name!=n or not (root/n).is_file() or (root/n).resolve().parent!=root:raise ValueError('缺少原始数据或标定快照：'+k+'，请使用完整诊断包')
            z.write(root/n,n)
        z.writestr('轻量包说明.txt','保留本次原始IMU与转台CSV及原标定快照；JSON只保留主要指标和元数据。省略离线回放CSV、HTML及独立链路轮询日志。链路问题需完整包。未硬件同步，不代表计量验收。')
    return buf.getvalue()
