"""Bounded offline causal candidate comparison, after verified STOP only.
The filter receives six-axis samples and dt; reference enters evaluate() only.
No settings writes, no external hardware, no auto application or re-run.
"""
from __future__ import annotations
import csv,html,json,math,zipfile
from pathlib import Path
import numpy as np
from .fusion import qmul,qnorm,integrate,initial_q,q_to_euler,cross
from .research_diagnostic import readcols,vec,clock
from .auto_research_report import write_json,local_file

CONFIGS=[("cascade",o,t,0.) for o,t in [(2,1.2),(2,2.0),(2,3.0),(3,1.0),(3,1.2),(3,1.5),(4,1.0)]]+[("butterworth",3,fc,d) for fc,d in [(.085,0.),(.105,0.),(.105,.5),(.13,0.)]]

def rotate(q,v):
    u=q[1:];z=cross(u,v);h=cross(u,[z[k]+q[0]*v[k] for k in range(3)])
    return [v[k]+2*h[k] for k in range(3)]

def norm(v):return math.sqrt(sum(x*x for x in v))

def tilt(v):
    n=norm(v);a,b,c=(x/n for x in v)
    if 1+c<1e-10:return initial_q(v)
    return qnorm([1+c,b,-a,0.])

def replay(a,g,delta,order,tau,family="cascade",derivative_gain=0.,seed=None):
    """Streaming bias is initialized once, only after sustained quiet IMU samples.
    No externally marked motion times, orientation, or reference passed in.
    """
    q=tilt(a[0]);last=list(g[0]);lp=last[:];bias=[0.]*3;hold=quiet=0.;sums=[0.]*3;count=0;ready=False
    if seed is not None:
        q=tilt(seed["acc_mean_g"]);bias=list(seed["gyro_bias_dps"]);ready=True
    init_acc=seed["acc_mean_g"] if seed is not None else a[0]
    world=rotate(q,[v/norm(init_acc) for v in init_acc]);states=[world[:] for _ in range(order)];out=[];z=[0.]*3;last_filtered=world[:];corrected_world=world[:]
    for av,gv,h in zip(a,g,delta):
        na=norm(av);ng=norm(gv)
        if 0<h<=.4:
            k=1-math.exp(-h/.07);lp=[lp[j]+k*(gv[j]-lp[j]) for j in range(3)]
            if norm(lp)>.65 or ng>1.05 or abs(na-1)>.075 or h>.010:hold=.8
            else:hold=max(0.,hold-h)
            rest=hold==0 and norm(lp)<.35 and ng<.8 and .94<na<1.06
            if rest and not ready:
                quiet+=h;count+=1;sums=[sums[j]+gv[j] for j in range(3)]
                if quiet>=1.5 and count>=100:bias=[v/count for v in sums];ready=True
            elif not rest:quiet=0.;count=0;sums=[0.]*3
            q=integrate(q,[(gv[j]+last[j])*.5-bias[j] for j in range(3)],h)
            if h<=.010 and .94<na<1.06:
                w=rotate(q,[v/na for v in av])
                if family=='cascade':
                    k=1-math.exp(-h/(.18 if rest else tau))
                    for j in range(order):w=states[j]=[states[j][i]+k*(w[i]-states[j][i]) for i in range(3)]
                    corrected_world=states[-1][:]
                else:
                    # Analog 3rd-order Butterworth: first-order section and
                    # Q=1 second-order section; causal trapezoidal state update.
                    omega=2*math.pi*(.88 if rest else tau);k=1-math.exp(-h*omega);r=omega*h*.5
                    states[0]=[states[0][i]+k*(w[i]-states[0][i]) for i in range(3)]
                    y=states[-1];r1=[y[i]+r*z[i] for i in range(3)];r2=[z[i]+r*(2*states[0][i]-y[i]-z[i]) for i in range(3)];den=1+r+r*r
                    yn=[((1+r)*r1[i]+r*r2[i])/den for i in range(3)];z=[(r2[i]-r*r1[i])/den for i in range(3)];states[-1]=yn
                    corrected_world=[yn[i]+(0. if rest else derivative_gain)*(yn[i]-last_filtered[i])/h for i in range(3)];last_filtered=yn[:]
        elif h>.4:hold=.8;quiet=0.;count=0;sums=[0.]*3
        pose=q_to_euler(qnorm(qmul(tilt(corrected_world),q)));out.append((pose['roll'],pose['pitch']));last=gv
    return np.asarray(out),ready


def verified_seed(folder,r,first_ns,first_seq):
    """Recompute from a preceding, passed stationary CSV. No reference data.
    Missing/invalid seed is explicitly disclosed; never use a failed window.
    """
    from .pre_research import assess
    meta=r.get('pre_research')
    if not meta:return None,'无长静止记录；使用因果短窗初始化'
    try:
        if meta.get('state')!='passed' or meta.get('seed_applied') is not True or meta.get('output')!=r['plan']['output']:raise ValueError('静止记录未通过/方向不一致')
        p=local_file(folder,meta['raw_csv']);jp=local_file(folder,meta['json_file']);j=json.loads(jp.read_text(encoding='utf-8-sig'))
        if j.get('state')!='passed' or j.get('seed_applied') is not True or j.get('raw_csv')!=p.name or j.get('output')!=meta['output'] or j.get('requested_s')!=meta['requested_s']:raise ValueError('静止JSON关联不一致')
        if not p.name.startswith(jp.stem) or f"_{r['uid']}_{meta['output'].upper()}_PRE_RESEARCH" not in p.stem:raise ValueError('设备或方向不匹配')
        rows=[]
        with p.open(encoding='utf-8-sig',newline='') as f:
            for row in csv.DictReader(f):
                rows.append(dict(sequence=int(row['sequence']),host_est_ns=int(row['host_est_ns']),batch_id=int(row['batch_id']),batch_index=int(row['batch_index']),acc_cal=[float(row[f'cal_acc_{k}_g']) for k in 'xyz'],gyro_cal=[float(row[f'cal_gyro_{k}_dps']) for k in 'xyz']))
        if len(rows)!=j.get('samples_captured') or len(rows)!=meta.get('samples'):raise ValueError('静止CSV样本数不匹配')
        seconds=int(meta['requested_s'])
        if seconds not in (30,60,120,600):raise ValueError('静止时间不合法')
        gap=(first_ns-rows[-1]['host_est_ns'])/1e9
        if not 0<=gap<=2. or not 0<first_seq-rows[-1]['sequence']<=2000:raise ValueError('静止窗口与本次动态文件时序不匹配')
        v=assess(rows,seconds)
        for key in ('acc_mean_g','gyro_bias_dps'):
            if not np.allclose(v[key],j[key],rtol=0,atol=1e-9) or not np.allclose(v[key],meta[key],rtol=0,atol=1e-9):raise ValueError('静止均值核对失败')
        return {**{k:v[k] for k in ('acc_mean_g','gyro_bias_dps','duration_s','samples')},'source':p.name,'unobserved_interval_s':gap},'合格长静止CSV重算；未观测间隔不积分'
    except Exception as exc:return None,'长静止初始化不可用：'+str(exc)+'；使用因果短窗'


def time_variants(d,delta):
    """Diagnostics only: same evaluation timestamps, vary integration dt.
    MCU batch interval distributed across current batch; no reference fitting.
    """
    out={}
    odr=d.get('imu_nominal_odr_hz',d.get('reported_odr'))
    if odr is not None and np.isfinite(odr).all() and np.all(odr>0):
        h=1/odr;h[0]=0.;out['nominal_odr']=h.tolist()
    if all(k in d for k in ('device_t_s','batch_id','batch_index')):
        dev,bid,bi=(d[k] for k in ('device_t_s','batch_id','batch_index'))
        ends=np.flatnonzero(bi==15);h=np.array(delta,copy=True);eligible=0
        for prev,end in zip(ends[:-1],ends[1:]):
            span=dev[end]-dev[prev]
            if end-prev==16 and bid[end]==bid[prev]+1 and 0<span<=.05 and np.array_equal(bi[prev+1:end+1],np.arange(16)):
                h[prev+1:end+1]=span/16;eligible+=1
        if eligible:out['mcu_batch_uniform']=h.tolist()
    return out


def load(folder,r):
    if r.get('static_alignment') or r.get('state')!='completed' or not r.get('stopped_verified'):
        raise ValueError('仅使用已停车、已完成且无现场经验对齐的实验')
    plan=r['plan'];axis=plan['output'];j=('roll','pitch').index(axis)
    if plan.get('sign') not in (-1,1):raise ValueError('参考方向无效')
    cols=['host_est_ns','imu_dt_s','alignment_active','seq','device_t_s','batch_id','batch_index','imu_nominal_odr_hz','reported_odr',*[f'cal_acc_{k}_g' for k in 'xyz'],*[f'cal_gyro_{k}_dps' for k in 'xyz'],f'cal_gyro_anchor_{axis}']
    d=readcols(local_file(folder,r['raw_file_imu']),cols)
    a=vec(d,[f'cal_acc_{k}_g' for k in 'xyz']);g=vec(d,[f'cal_gyro_{k}_dps' for k in 'xyz']);x,_=clock(d);delta=d['imu_dt_s'].copy();delta[0]=0
    if not np.isfinite(delta).all() or np.any(delta[1:]<=0) or np.any(np.linalg.norm(a,axis=1)<.1) or ('alignment_active' not in d or np.any(d['alignment_active']!=0)):raise ValueError('六轴数据/时间或对齐状态无效')
    t=readcols(local_file(folder,r['raw_file_table']),['pc_mid_ns',f'axis_{plan["axis"]}_pos']);tx,_=clock(t,'pc_mid_ns')
    ref=np.rad2deg(np.unwrap(np.deg2rad(t[f'axis_{plan["axis"]}_pos'])));ref=(ref-360*round(ref[0]/360))*plan['sign']
    full=(x>=r['motion_start_pc_monotonic_ns']/1e9)&(x<=r['motion_end_pc_monotonic_ns']/1e9);idx=np.clip(np.searchsorted(tx,x),1,len(tx)-1)
    m=full&(x>=tx[0])&(x<=tx[-1])&((tx[idx]-tx[idx-1])<=.4)
    if not np.any(m) or not np.isfinite(ref).all():raise ValueError('无有效参考覆盖')
    seq=d.get('seq');gap=float(np.max(delta[1:]));continuous=gap<=.010 and seq is not None and bool(np.all(np.diff(seq)==1))
    seed,seed_status=verified_seed(folder,r,int(d['host_est_ns'][0]),int(seq[0])) if seq is not None else (None,'无序号；不能核对长静止初始化')
    return dict(seed=seed,seed_status=seed_status,time_variants=time_variants(d,delta),axis=axis,j=j,a=a.tolist(),g=g.tolist(),dt=delta.tolist(),x=x,m=m,ref=np.interp(x,tx,ref),full=int(full.sum()),gap_ms=gap*1000,continuous=continuous,filename=r['raw_file_imu'],plan=plan,baseline=d.get(f'cal_gyro_anchor_{axis}'))

def evaluate(ds,pred):
    m=ds['m'];p=np.asarray(pred)
    if not np.isfinite(p[m]).all():raise ValueError('候选输出无效')
    e=(p[m]-ds['ref'][m]+180)%360-180;bad=abs(e)>.05
    return {'axis':ds['axis'],'file':ds['filename'],'max_abs_deg':float(np.max(abs(e))),'rmse_deg':float(np.sqrt(np.mean(e*e))),'over_0p05_pct':float(bad.mean()*100),'evaluated':int(m.sum()),'full_motion_samples':ds['full'],'excluded':ds['full']-int(m.sum()),'max_imu_gap_ms':ds['gap_ms'],'continuity_qualified':ds['continuous'],'measured_subset_below_target':bool(np.max(abs(e))<=.05),'certified':False}


def history(folder,reports):
    """Fixed selection by recency, never by error; max two per axis.
    UID/calibration path match is not proof of identical calibration bytes.
    """
    known={r['raw_file_imu'] for r in reports};uid=reports[0].get('uid');mode=reports[0].get('calibration_mode');files=reports[0].get('calibration_files');counts={'roll':0,'pitch':0};out=[];rejected=[]
    for p in sorted(folder.glob('*_DYNAMIC.json'),key=lambda p:p.name,reverse=True):
        if len(out)>=4:break
        try:
            r=json.loads(p.read_text(encoding='utf-8-sig'));name=r.get('raw_file_imu');axis=r.get('plan',{}).get('output')
            if name in known or r.get('uid')!=uid or not uid or r.get('calibration_mode')!=mode or r.get('calibration_files')!=files or axis not in counts or counts[axis]>=2:continue
            ds=load(folder,r);known.add(name);counts[axis]+=1;out.append(ds)
        except Exception as exc:rejected.append({'file':p.name,'error':str(exc)})
    return out,rejected


def optimize(folder,reports,stem):
    folder=Path(folder);current=[load(folder,r) for r in reports];candidates=[]
    baseline=[evaluate(d,d['baseline']) for d in current if d['baseline'] is not None and np.isfinite(d['baseline'][d['m']]).all()]
    for family,order,tau,dgain in CONFIGS:
        metrics=[]
        for ds in current:
            v,ready=replay(ds['a'],ds['g'],ds['dt'],order,tau,family,dgain,seed=ds['seed']);m=evaluate(ds,v[:,ds['j']]);m['bias_ready']=ready;m['seed_status']=ds['seed_status'];metrics.append(m)
        candidates.append({'family':family,'order':order,'tau_s':tau if family=='cascade' else None,'cutoff_hz':tau if family=='butterworth' else None,'derivative_gain_s':dgain,'current':metrics,'worst_max_abs_deg':max(m['max_abs_deg'] for m in metrics)})
    candidates.sort(key=lambda c:c['worst_max_abs_deg']);best=candidates[0]
    hist,rejected=history(folder,reports);checks=[]
    for ds in hist:
        v,ready=replay(ds['a'],ds['g'],ds['dt'],best['order'],best['tau_s'] if best['family']=='cascade' else best['cutoff_hz'],best['family'],best['derivative_gain_s'],seed=ds['seed']);m=evaluate(ds,v[:,ds['j']]);m['bias_ready']=ready;m['seed_status']=ds['seed_status'];checks.append(m)
    sensitivity=[]
    for ds in current:
        config=(best['order'],best['tau_s'] if best['family']=='cascade' else best['cutoff_hz'],best['family'],best['derivative_gain_s'])
        for name,delta in [('pc_estimated',ds['dt']),*ds['time_variants'].items()]:
            v,ready=replay(ds['a'],ds['g'],delta,*config,seed=ds['seed']);m=evaluate(ds,v[:,ds['j']]);m.update(time_model=name,bias_ready=ready);sensitivity.append(m)
        if ds['seed'] is not None:
            v,ready=replay(ds['a'],ds['g'],ds['dt'],*config);m=evaluate(ds,v[:,ds['j']]);m.update(time_model='pc_estimated_short_seed_control',bias_ready=ready);sensitivity.append(m)
    # Selection and holdout remain separate: no retuning on history, no deployment.
    out={'state':'completed','version':'7.23','target_deg':.05,'execution_mode':'offline_causal_research_only','auto_applied':False,'certified':False,'baseline_realtime':baseline,'candidates':candidates,'selected_current_candidate':{k:best[k] for k in ('family','order','tau_s','cutoff_hz','derivative_gain_s','worst_max_abs_deg')},'initialization':[{'axis':d['axis'],'status':d['seed_status'],'seed':d['seed']} for d in current],'time_sensitivity':sensitivity,'time_sensitivity_note':'积分dt敏感性而非时间同步校准；保持原参考比较时刻，MCU按完整批次均分，不恢复真实采样、不改变在线算法。','historical_check':checks,'history_rejected':rejected,'history_status':'available_research_only' if checks else 'no_eligible_history','note':'本次数据用于筛选，历史按UID/标定路径/模式及时间选取，可能已参与以往研发，非独立验收；标定路径相同不保证内容相同。未硬件同步，不扣零位、不平移时间、不补造样本。缺口或覆盖不足不得宣称全段达标。候选不自动应用，不自动复测。'}
    jp=folder/(stem+'.json');hp=folder/(stem+'.html');zp=folder/(stem+'.zip');write_json(jp,out)
    esc=lambda x:html.escape(str(x));axes=[d['axis'].upper() for d in current]
    rows=''.join('<tr><td>'+esc(f"{c['order']}级 / {c['tau_s']}秒" if c['family']=='cascade' else f"三阶Butterworth / {c['cutoff_hz']}Hz / D={c['derivative_gain_s']}s")+'</td>'+''.join(f"<td>{m['max_abs_deg']:.6f}° / {m['over_0p05_pct']:.2f}%</td>" for m in c['current'])+f"<td>{c['worst_max_abs_deg']:.6f}°</td></tr>" for c in candidates)
    historyrows=''.join(f"<tr><td>{esc(m['file'])}</td><td>{m['max_abs_deg']:.6f}°</td><td>{m['over_0p05_pct']:.2f}%</td><td>{m['continuity_qualified']}</td><td>{m['excluded']}</td></tr>" for m in checks)
    timingrows=''.join(f"<tr><td>{esc(m['axis'])}</td><td>{esc(m['time_model'])}</td><td>{m['max_abs_deg']:.6f}°</td><td>{m['rmse_deg']:.6f}°</td></tr>" for m in sensitivity)
    initrows=''.join(f"<p>{esc(d['axis'])}：{esc(d['seed_status'])}</p>" for d in current)
    hp.write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>TiltLab V7.23 离线寻优</title><style>body{font:15px/1.6 sans-serif;max-width:1100px;margin:30px auto;padding:20px;background:#f4f7f7;color:#173c40}section{background:white;padding:20px;margin:16px 0;border-radius:12px}table{border-collapse:collapse;width:100%}td,th{padding:8px;border-bottom:1px solid #ccdcdc;text-align:left}pre{white-space:pre-wrap;overflow-wrap:anywhere}</style><h1>V7.23 · 因果融合离线寻优</h1><p>'+esc(out['note'])+'</p><section><h2>本次候选排序（最大误差 / 超差比例）</h2><table><tr><th>候选</th>'+''.join('<th>'+esc(a)+'</th>' for a in axes)+'<th>最坏最大误差</th></tr>'+rows+'</table></section><section><h2>固定候选历史检查（不参与本次排序）</h2><p>'+esc(out['history_status'])+'</p><table><tr><th>文件</th><th>最大误差</th><th>超差率</th><th>连续性</th><th>参考未覆盖点</th></tr>'+historyrows+'</table></section><section><h2>初始化与积分时间敏感性</h2>'+initrows+'<p>'+esc(out['time_sensitivity_note'])+'</p><table><tr><th>轴</th><th>时间模型</th><th>最大误差</th><th>RMSE</th></tr>'+timingrows+'</table></section><details><summary>完整结果（含原实时基线、覆盖与质量）</summary><pre>'+esc(json.dumps(out,ensure_ascii=False,indent=2))+'</pre></details></html>',encoding='utf-8')
    with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
        for p in (jp,hp):z.write(p,p.name)
    return {'state':'completed','json_file':jp.name,'html_file':hp.name,'zip_file':zp.name,'selected':out['selected_current_candidate'],'historical_count':len(checks),'auto_applied':False}
