"""Spawned, read-only IMU transport. The child exclusively owns the serial port.
All request/receipt timestamps are taken in the child on the system monotonic
clock (Windows Python >=3.10). No fusion, DLL, disk, or web work in this process.
A bounded IPC queue fails loudly on overflow. No silent dropping or auto fallback.
"""
import multiprocessing as mp
import queue
import time
from .acquisition_v712 import windows_timer_resolution


def _owner(factory, args, messages, control, stop, begin, last_sample_ns):
    dev=None
    try:
        dev=factory(*args);dev.open()
        control.send(('ready',dev.serial_no,dev.uid))
        while not begin.wait(.05):
            if stop.is_set():return
        dev._pending_registers=None
        previous_end=None;poll_id=0
        with windows_timer_resolution():
            while not stop.is_set():
                requested=time.monotonic_ns();batch=dev.next_batch();observed=time.monotonic_ns()
                if batch:last_sample_ns.value=observed
                poll_id+=1
                poll={'poll_id':poll_id,'request_pc_ns':requested,'received_pc_ns':observed,
                      'serial_read_ms':(observed-requested)/1e6,
                      'previous_idle_ms':(requested-previous_end)/1e6 if previous_end is not None else 0.,
                      'accepted_samples':len(batch),'device_tick_ms':getattr(dev,'last_tick',None),
                      'fifo_state':getattr(dev,'frame_status',None),'reported_dropped_batches':getattr(dev,'dropped_batches',None)}
                previous_end=observed
                try:messages.put_nowait((batch,poll))
                except queue.Full:raise RuntimeError('采集进程IPC队列已满；停止，不静默丢点')
                # Keep the proven V7.13 cadence until physical testing supports a change.
                time.sleep(.003)
    except Exception as exc:
        try:control.send(('error',f'{type(exc).__name__}: {exc}'))
        except (OSError,EOFError):pass
    finally:
        if dev is not None:
            try:dev.close()
            except Exception:pass
        try:control.send(('done',))
        except (OSError,EOFError):pass
        control.close()


class ProcessTransport:
    def __init__(self,factory,port,baudrate,address):
        self.ctx=mp.get_context('spawn');self.messages=self.ctx.Queue(maxsize=128)
        self.control,child=self.ctx.Pipe(duplex=False)
        self.stop_event=self.ctx.Event();self.begin=self.ctx.Event();self.last_sample_ns=self.ctx.Value('q',0)
        self.proc=self.ctx.Process(target=_owner,args=(factory,(port,baudrate,address),self.messages,child,self.stop_event,self.begin,self.last_sample_ns),daemon=True,name='TiltLab-IMU-serial')
        self.closed=False;self.serial_no=None;self.uid=None;self.failure=None;self.done=False;self.peak=0;self.dropped_batches=None
        try:self.proc.start()
        finally:child.close()
    def open(self):
        try:
            if not self.control.poll(8):raise RuntimeError('IMU采集进程启动超时')
            msg=self.control.recv()
            if msg[0]!='ready':raise RuntimeError(msg[1] if len(msg)>1 else 'IMU采集进程未就绪')
            self.serial_no,self.uid=msg[1:]
        except BaseException:self.close();raise
    def _control(self):
        try:
            while self.control.poll():
                m=self.control.recv()
                if m[0]=='error':self.failure=m[1]
                if m[0]=='done':self.done=True
        except (EOFError,OSError):pass
    def next_poll(self):
        # Queue feeder can deliver the final items after the control pipe's done
        # message. Only declare EOF once the process has exited AND queue drained.
        self._control()
        try:self.peak=max(self.peak,self.messages.qsize())
        except (NotImplementedError,OSError):pass
        try:
            batch,poll=self.messages.get(timeout=.05)
            self.dropped_batches=poll.get('reported_dropped_batches')
            return batch,poll
        except queue.Empty:
            self._control()
            if not self.proc.is_alive():
                if self.failure:raise RuntimeError(self.failure)
                if not self.stop_event.is_set():raise RuntimeError('IMU采集进程意外退出')
                return None
            if self.failure:raise RuntimeError(self.failure)
            return ()
    def request_stop(self):self.stop_event.set();self.begin.set()
    def close(self):
        if self.closed:return
        self.request_stop()
        # Discard any unconsumed IPC only during failed startup or explicit abort;
        # normal shutdown drains via next_poll before close.
        deadline=time.monotonic()+1.5
        while self.proc.is_alive() and time.monotonic()<deadline:
            try:self.messages.get(timeout=.03)
            except queue.Empty:pass
            self.proc.join(.01)
        if self.proc.is_alive():self.proc.terminate();self.proc.join(1.)
        self.control.close();self.messages.close();self.messages.join_thread();self.closed=True
