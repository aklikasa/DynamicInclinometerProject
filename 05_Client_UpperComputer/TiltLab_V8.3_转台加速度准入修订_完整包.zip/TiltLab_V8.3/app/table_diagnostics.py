"""Read-only persistent hardware diagnostics for local field commissioning.

Never sends movement commands. Stores actual DLL request/response observations and
workflow milestones. A DLL state read is NOT proof of fresh servo-controller frames.
"""
from __future__ import annotations
import datetime, json, threading, time
from collections import deque
from pathlib import Path

class TableDiagnostics:
    def __init__(self, root=None):
        self.root=Path(root) if root else Path(__file__).resolve().parent.parent/'data'/'logs'
        self.lock=threading.RLock()
        self.buffer=deque(maxlen=400)
        self.seq=0
        self.last_file=None
    def record(self, stage, message, **details):
        entry={'seq':0,'time':datetime.datetime.now().astimezone().isoformat(timespec='milliseconds'),
               'stage':str(stage),'message':str(message),'details':details}
        with self.lock:
            self.seq+=1;entry['seq']=self.seq;self.buffer.append(entry)
            try:
                self.root.mkdir(parents=True,exist_ok=True)
                file=self.root/('2TD600_'+datetime.date.today().strftime('%Y%m%d')+'.jsonl')
                with file.open('a',encoding='utf-8') as f:
                    f.write(json.dumps(entry,ensure_ascii=False,default=str)+'\n')
                self.last_file=file
            except OSError:
                # Lack of write permission must not stop hardware safety monitoring.
                pass
        return entry
    def snapshot(self, stage, st, message='两轴反馈快照'):
        axes={}
        for a,x in (st.get('axes') or {}).items():
            axes[str(a)]={k:x.get(k) for k in ('position_deg','speed_dps','mode','enabled','zeroed','healthy','driver_fault','upper_limit','lower_limit','over_speed','in_place','raw_flags')}
        return self.record(stage,message,connected=st.get('connected'),axes=axes,host_time_ns=st.get('time_monotonic_ns'),note='为PC读取时刻，非厂家设备内部反馈时间戳')
    def recent(self,limit=80):
        with self.lock:
            return {'events':list(self.buffer)[-max(1,min(400,int(limit))):],
                    'log_file':self.last_file.name if self.last_file else None,
                    'note':'此日志记录DLL反馈和命令调用；不能单独证明设备时钟同步或伺服实际运动'}
    def file(self):
        with self.lock:return self.last_file

DIAG=TableDiagnostics()
