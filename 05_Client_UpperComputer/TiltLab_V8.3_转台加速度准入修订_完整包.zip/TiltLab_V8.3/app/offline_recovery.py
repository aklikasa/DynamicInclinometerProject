"""Read-only recovery of existing completed-motion dynamic CSVs.

Never communicates with devices, writes control commands, or replaces the
source report. Valid analysis is not proof of safe stop or certified accuracy.
"""
from __future__ import annotations
import csv, datetime as dt, html, json, math
from pathlib import Path
from .dynamic_experiment import analyze_tracking


def _csv_rows(path):
    with path.open('r',encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))


def recover_report(report_path:Path, output_dir:Path|None=None):
    report_path=Path(report_path).resolve()
    if not report_path.is_file() or report_path.suffix.lower()!='.json':
        raise ValueError('请选择存在的动态实验JSON报告')
    original=json.loads(report_path.read_text(encoding='utf-8-sig'))
    if original.get('kind')!='REAL_2TD600_SINE_DIAGNOSTIC':
        raise ValueError('文件不是2TD600动态实验原始报告')
    plan=original.get('plan') or {}
    a=original.get('motion_start_pc_monotonic_ns')
    b=original.get('motion_end_pc_monotonic_ns')
    if not isinstance(a,int) or not isinstance(b,int) or b<=a:
        raise ValueError('原始JSON没有完整的运动起止时间戳；不能推算运动区间')
    expected=float(plan['cycles'])/float(plan['frequency_hz'])
    if not (.9*expected <= (b-a)/1e9 <= 1.1*expected):
        raise ValueError('原始运动区间未覆盖预定周期；不能当作完整测试')
    folder=report_path.parent
    csvnames=[original.get('raw_file_table'),original.get('raw_file_imu')]
    if any(not isinstance(x,str) or not x or Path(x).name != x for x in csvnames):
        raise ValueError('JSON中的CSV文件名无效')
    table_path,imu_path=(folder/x for x in csvnames)
    for x in (table_path,imu_path):
        if not x.is_file():raise FileNotFoundError(f'缺少原始文件：{x.name}；请放在同一目录')
    table=_csv_rows(table_path);imu=_csv_rows(imu_path)
    analysis=analyze_tracking(table,imu,int(plan['axis']),str(plan['output']),int(plan['sign']),
                              float(plan['amplitude_deg']),float(plan['frequency_hz']),a,b)
    stop_ok=original.get('stopped_verified') is True
    state=('analysis_available_stop_verified' if stop_ok else 'analysis_available_stop_unverified') if analysis.get('valid') else ('partial_research_only' if analysis.get('partial_research_only') else 'analysis_invalid')
    output={
        'kind':'2TD600_READ_ONLY_OFFLINE_RECOVERY', 'state':state,
        'source_report':report_path.name,'source_report_state':original.get('state'),
        'uid':original.get('uid'), 'plan':plan, 'table_samples_actual':len(table),
        'imu_samples_actual':len(imu),'reanalysis_time':dt.datetime.now().astimezone().isoformat(),
        'original_stop_confirmed':stop_ok,'motion_period_captured':True,
        'analysis':analysis,'quality':'RESEARCH_ONLY_UNSYNCHRONIZED',
        'certified_dynamic_accuracy':False,
        'warning':('仅恢复采集数据分析。原测试停车未获DLL确认；现场需独立核查设备，'
                   '这份报告不代表运动安全闭环完成，也不能自动继续下一轴。' if not stop_ok else
                   ('整段稳态参考缺口超限，仅计算未跨缺口的长连续片段；禁止将局部RMSE视为完整精度验收。' if analysis.get('partial_research_only') else '仅作研究级相对动态跟踪分析，非精度验收。'))}
    output_dir=Path(output_dir or folder)
    output_dir.mkdir(parents=True,exist_ok=True)
    outfile=output_dir/(report_path.stem+'_OFFLINE_ANALYSIS.json')
    outfile.write_text(json.dumps(output,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    htmlfile=output_dir/(report_path.stem+'_OFFLINE_ANALYSIS.html')
    htmlfile.write_text(make_html(output),encoding='utf-8')
    return outfile,htmlfile,output


def make_html(info):
    """Single offline HTML page, with real reference vs algorithm & error plots."""
    data=json.dumps(info,ensure_ascii=False,allow_nan=False).replace('</','<\\/')
    # No external dependencies. Never use data content as unescaped HTML.
    page=r'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>2TD600 · 动态采集数据恢复分析</title>
<style>
:root{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;color:#24332e;background:#f6f8f7}*{box-sizing:border-box}body{margin:0}main{max-width:1260px;margin:auto;padding:48px 24px 80px}
header{display:flex;justify-content:space-between;align-items:flex-start;gap:18px}h1{font-size:32px;letter-spacing:-.8px;margin:10px 0 6px}p{line-height:1.65;color:#617169}.chip{border:1px solid #cdd7d2;padding:8px 12px;border-radius:30px;background:#fff;font-size:12px}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.card{background:#fff;border:1px solid #e3eae6;border-radius:20px;padding:20px;box-shadow:0 12px 28px #18241b08;margin:12px 0}.card b{font-size:24px;font-variant-numeric:tabular-nums}.card small{display:block;color:#76857b;margin-bottom:12px}.warning{padding:14px 18px;background:#fdf5ed;border:1px solid #e9d5bd;color:#7b5b35;border-radius:14px;margin-top:18px}.toolbar{display:flex;gap:12px;flex-wrap:wrap;align-items:center}.toolbar label{display:inline-flex;align-items:center;gap:5px;font-size:13px;color:#44544b}.toolbar select{padding:8px;border-radius:9px;border:1px solid #d1ddd6;background:white}canvas{display:block;width:100%;height:290px;cursor:crosshair}.plots{display:grid;grid-template-columns:1fr;gap:8px}.plotTitle{font-size:16px;margin:0 0 12px}table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:right;border-bottom:1px solid #edf1ee;padding:10px 8px}th:first-child,td:first-child{text-align:left}tr:hover{background:#f8faf8}.small{font-size:12px}.legend{display:flex;flex-wrap:wrap;gap:18px;font-size:12px;margin:6px 0 14px;color:#587066}#hover{font-variant-numeric:tabular-nums;min-height:22px}@media(max-width:800px){.grid{grid-template-columns:repeat(2,1fr)}main{padding:20px 14px}}
</style></head><body><main><header><div><div class="small">TILT LAB / READ-ONLY RECOVERY</div><h1>动态跟踪 · 离线数据恢复分析</h1><p id="subtitle"></p></div><div class="chip" id="tag">研究级诊断</div></header>
<div class="warning" id="warning"></div><section class="grid" id="stats"></section>
<section class="card"><h3 class="plotTitle">实际角度跟踪曲线</h3><div class="toolbar"><span>算法选择</span><div id="choices"></div><label>通道 <select id="channel"><option value="cal">常温补偿</option><option value="raw">原始数据</option></select></label></div><div class="legend"><span>● 黑色：转台真实反馈</span><span>彩色：IMU算法输出（相对运动）</span></div><canvas id="angles"></canvas><div class="small" id="hover"></div></section>
<section class="card"><h3 class="plotTitle">独立误差曲线 · 算法输出 − 转台反馈</h3><canvas id="errors"></canvas><p class="small">误差曲线基于PC时间轴和静止基线计算，未进行硬件级时间同步。浅色参考线为±0.1°研发观察线，不表示产品验收合格。</p></section>
<section class="card"><h3 class="plotTitle">算法比较 · 缺口超限时仅为局部片段研究数值（非验收）</h3><div style="overflow:auto"><table id="comparison"></table></div></section>
<p class="small" id="footer"></p></main><script id="data" type="application/json">__DATA__</script>
<script>
const d=JSON.parse(document.getElementById('data').textContent),a=d.analysis||{},chart=a.chart||[];
const $=id=>document.getElementById(id),safe=(v)=>String(v??'—').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const algorithms=['lever3d','vqf6d','vqf_lever','gyro_anchor','gyro','accel','adaptive','motion_guard','adaptive_lever','leverarm','complementary','kalman','mahony','madgwick'];
const names={vqf6d:'VQF-6D（论文对照）',vqf_lever:'VQF杆臂补偿实验',gyro_anchor:'陀螺主导·动态重力约束（V7.8）',motion_guard:'运动干扰抑制实验',adaptive_lever:'自适应旋转补偿融合',complementary:'互补滤波',kalman:'Kalman',mahony:'Mahony',adaptive:'自适应Mahony',madgwick:'Madgwick',lever3d:'三维杆臂补偿融合',leverarm:'旋转附加加速度补偿（试验）',accel:'加速度直算',gyro:'陀螺积分'};
const colors={vqf6d:'#694bd1',vqf_lever:'#ca3077',gyro_anchor:'#0e91a8',motion_guard:'#d78935',adaptive_lever:'#28518a',complementary:'#C08055',kalman:'#365C6F',mahony:'#559273',adaptive:'#9BB48D',madgwick:'#B78BA4',lever3d:'#c45c19',leverarm:'#569B81',accel:'#8A8984',gyro:'#B4B9BC'};
$('warning').textContent=d.warning+(a.reference_gaps_masked?'；已剔除反馈缺口内的数据，稳定段覆盖率 '+a.reference_quality?.stable_coverage_pct+'%，有效RMSE仅用于研究对照。':'');$('subtitle').textContent=`设备 ${d.uid||'未知'} · ${d.plan?.output==='pitch'?'Pitch / 内轴90°':'Roll / 内轴0°'} · 幅度 ±${d.plan?.amplitude_deg}° · ${d.plan?.frequency_hz} Hz · ${d.plan?.cycles} 周期`;
$('tag').textContent=a.valid?'研究性分析可用 · 停车另核验':a.partial_research_only?'局部片段可分析 · 整段精度无效':'数据分析未通过';
const best=(a.comparison||[]).filter(x=>x.channel==='cal').slice().sort((x,y)=>x.relative_tracking_rmse_deg-y.relative_tracking_rmse_deg)[0];
const stats=[['转台反馈',d.table_samples_actual],['IMU采样',d.imu_samples_actual],['有效运动幅值',a.reference_amplitude_est_deg!=null?a.reference_amplitude_est_deg+'°':'未算出'],[a.partial_research_only?'局部研究最小RMSE（非验收）':'补偿后最小RMSE',best?best.relative_tracking_rmse_deg+'°':'未算出']];
$('stats').innerHTML=stats.map(([t,v])=>`<div class="card"><small>${safe(t)}</small><b>${safe(v)}</b></div>`).join('');
const selected=new Set(['gyro','accel','adaptive','gyro_anchor']);
$('choices').innerHTML=algorithms.map(k=>`<label style="margin:0 8px 0 0;display:inline-flex;gap:5px;color:${colors[k]}"><input type="checkbox" value="${k}" ${selected.has(k)?'checked':''}>${names[k]}</label>`).join('');
$('choices').onchange=e=>{if(e.target.type==='checkbox'){if(e.target.checked)selected.add(e.target.value);else selected.delete(e.target.value);draw()}};
$('channel').onchange=()=>{draw();table()};
function table(){const ch=$('channel').value;const rr=(a.comparison||[]).filter(x=>x.channel===ch).slice().sort((x,y)=>x.relative_tracking_rmse_deg-y.relative_tracking_rmse_deg);
$('comparison').innerHTML='<thead><tr><th>算法</th><th>相对RMSE</th><th>最大绝对误差</th><th>P95绝对误差</th><th>幅值比</th><th>表观延迟</th></tr></thead><tbody>'+rr.map(x=>`<tr><td>${safe(names[x.algorithm]||x.algorithm)}</td><td>${safe(x.relative_tracking_rmse_deg)}°</td><td>${safe(x.relative_max_error_deg)}°</td><td>${safe(x.relative_p95_error_deg)}°</td><td>${safe(x.amplitude_ratio)}</td><td>${safe(x.apparent_phase_lag_ms)}ms</td></tr>`).join('')+'</tbody>'}
function drawCanvas(id,type){const cv=$(id),ctx=cv.getContext('2d'),w=cv.clientWidth,h=cv.clientHeight;const r=window.devicePixelRatio||1;cv.width=Math.round(w*r);cv.height=Math.round(h*r);ctx.setTransform(r,0,0,r,0,0);ctx.clearRect(0,0,w,h);
const pad={l:57,r:20,t:16,b:36},x0=pad.l,x1=w-pad.r,y0=pad.t,y1=h-pad.b;if(!chart.length)return;
const xx=chart.map(x=>x.t_s);const mi=Math.min(...xx),ma=Math.max(...xx);let curves=[];
if(type==='angles')curves.push({key:'reference',color:'#152620',values:chart.map(p=>p.reference_deg)});
for(const k of selected){const key=$('channel').value+'_'+k;curves.push({key,color:colors[k],values:chart.map(p=>p[type]?.[key]??null)})}
let vals=curves.flatMap(c=>c.values).filter(Number.isFinite);if(!vals.length)return;let lo=Math.min(...vals),hi=Math.max(...vals);if(type==='errors'){lo=Math.min(lo,-.1);hi=Math.max(hi,.1)}let marg=Math.max(.01,(hi-lo)*.13);lo-=marg;hi+=marg;
const x=t=>x0+(t-mi)/(ma-mi||1)*(x1-x0),y=v=>y1-(v-lo)/(hi-lo||1)*(y1-y0);
ctx.strokeStyle='#E8EFEA';ctx.fillStyle='#8A9990';ctx.lineWidth=1;ctx.font='11px system-ui';for(let n=0;n<=4;n++){let v=lo+(hi-lo)*n/4;let yy=y(v);ctx.beginPath();ctx.moveTo(x0,yy);ctx.lineTo(x1,yy);ctx.stroke();ctx.fillText(v.toFixed(3)+'°',5,yy+3)}
for(let n=0;n<=5;n++){let v=mi+(ma-mi)*n/5;ctx.fillText(v.toFixed(1)+'s',x(v)-8,y1+18)}
if(type==='errors'){for(const v of [-.1,0,.1]){ctx.strokeStyle=v===0?'#647F75':'#DED3C1';ctx.setLineDash(v===0?[]:[4,5]);ctx.beginPath();ctx.moveTo(x0,y(v));ctx.lineTo(x1,y(v));ctx.stroke()}ctx.setLineDash([])}
for(const c of curves){ctx.strokeStyle=c.color;ctx.lineWidth=c.key==='reference'?2.7:1.6;ctx.beginPath();let active=false;for(let i=0;i<c.values.length;i++){let v=c.values[i];if(!Number.isFinite(v)){active=false;continue}if(!active){ctx.moveTo(x(xx[i]),y(v));active=true}else ctx.lineTo(x(xx[i]),y(v))}ctx.stroke()}
cv.onmousemove=e=>{const t=mi+(Math.max(0,Math.min(w-x0,e.offsetX-x0))/(x1-x0))*(ma-mi);let best=chart.reduce((p,c)=>Math.abs(c.t_s-t)<Math.abs(p.t_s-t)?c:p,chart[0]);$('hover').textContent='t='+best.t_s+'s · 转台='+best.reference_deg+'° · '+[...selected].map(k=>names[k]+': '+(best.angles?.[$('channel').value+'_'+k]??'—')+'°').join(' | ')};}
function draw(){drawCanvas('angles','angles');drawCanvas('errors','errors')}
window.addEventListener('resize',draw);$('footer').textContent='数据来源：'+d.source_report+'；时间基准：'+(a.timing_method||'未建立')+'。本离线文件不连接转台、不发送控制指令、不构成安全停止确认或正式动态精度验收。';table();draw();
</script></body></html>'''
    return page.replace('__DATA__',data)
