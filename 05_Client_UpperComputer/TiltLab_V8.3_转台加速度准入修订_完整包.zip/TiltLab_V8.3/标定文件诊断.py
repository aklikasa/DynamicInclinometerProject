# -*- coding: utf-8 -*-
"""Read-only, local calibration pairing diagnostic. Does not touch the PCB."""
import sys, json
from pathlib import Path
from app.calibration import scan

def main():
    print('='*65)
    print('常温 / 全温 标定文件诊断 V4.5（只读）')
    print('='*65)
    folder=input('输入标定文件夹完整路径: ').strip().strip('"')
    serial=input('输入设备编号 (例 DTS872028): ').strip().upper()
    mode=input('常温 ambient / 全温 thermal [ambient]: ').strip().lower() or 'ambient'
    if mode not in ('ambient','thermal'):
        print('模式无效');return 2
    try:
        result=scan(folder,serial=serial,mode=mode)
    except Exception as e:
        print('目录诊断失败:',e);return 1
    print('\n状态:',result['status'])
    print('说明:',result.get('detail',''))
    print('扫描JSON数:',result['files_scanned'])
    print('有效ACC/GYRO匹配:')
    for f in result.get('matched_files',[]):
        print('  ',f)
    print('逐文件矩阵诊断:')
    for f in result.get('matrix_diagnostics',[]):
        print('  ', f)
    print('校验异常:')
    for e in result.get('issues',[]):
        print('  ',e)
    print('注意：本工具不对标定文件写入，也不会将可疑矩阵用于补偿。')
    return 0 if result['status']=='matched' else 1

if __name__=='__main__':
    try:sys.exit(main())
    finally: input('\n按回车关闭窗口...')
