"""Read-only retrospective fusion evaluation from a real 2TD-600 capture.

Usage:
    python 离线算法对照_只读.py "D:/.../YOUR_DYNAMIC.json"

For selected radius, output the 8-algorithm comparison in a self-contained HTML.
The radius search uses a chronological training split; holdout is still from
THE SAME TEST, not independent validation. The original data is never edited.
This utility never loads a turntable DLL, opens a COM port or issues movement.
"""
from pathlib import Path
import csv, json, math, sys
import numpy as np
from app.fusion import Params, create_filter
from app.dynamic_experiment import analyze_tracking, recover_imu_timebase
from app.angles import unwrap_encoder_deg
from app.html_report import write_interactive_report

CANDIDATES_CM=[0,5,10,15,20,22,25,30,35,40]


def _load_csv(path):
    with Path(path).open('r',encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))


def replay_candidate(rows,radius_cm,beta=.075,tau=.09):
    """Causal replay, calibrated P-axis only; original row values unchanged."""
    params=Params(beta=beta,lever_z_cm=radius_cm,lever_tau_s=tau).validate()
    engine=create_filter('leverarm',params,calibrated=True)
    yroll=np.full(len(rows),np.nan,dtype=float)
    ypitch=np.full(len(rows),np.nan,dtype=float)
    last_t=None
    for i,row in enumerate(rows):
        t=float(row['device_t_s']);dt=0.0 if last_t is None else t-last_t
        if last_t is not None and dt<=0:raise ValueError(f'设备时间戳不单调，样本{i}')
        if dt>.5:engine=create_filter('leverarm',params,calibrated=True);dt=0.
        last_t=t
        a=[float(row[f'cal_acc_{ax}_g']) for ax in 'xyz']
        g=[float(row[f'cal_gyro_{ax}_dps']) for ax in 'xyz']
        if not all(math.isfinite(v) for v in a+g):continue
        pose=engine.update(a,g,dt)
        yroll[i]=pose['roll'];ypitch[i]=pose['pitch']
    return yroll,ypitch


def evaluation_windows(report,table,imu):
    plan=report['plan'];start=report['motion_start_pc_monotonic_ns']/1e9
    end=report['motion_end_pc_monotonic_ns']/1e9
    ts=np.array([float(r['pc_mid_ns'])/1e9 for r in table])
    pos=unwrap_encoder_deg([float(r[f"axis_{plan['axis']}_pos"]) for r in table])
    ix,_=recover_imu_timebase(imu,int(ts[0]*1e9),int(ts[-1]*1e9))
    pre=(ix>=max(ts[0],start-2.5))&(ix<start-.1)
    table_pre=(ts>=max(ts[0],start-2.5))&(ts<start-.1)
    mask=(ix>=start+1/float(plan['frequency_hz']))&(ix<=end-.3)&(ix>=ts[0])&(ix<=ts[-1])
    if np.count_nonzero(pre)<20 or np.count_nonzero(table_pre)<2 or np.count_nonzero(mask)<100:
        raise ValueError('真实数据运动/静止基线不足，不允许评估')
    if not np.all(np.diff(ts)>0) or not np.all(np.diff(ix)>0):
        raise ValueError('时间戳非严格递增；需要先修复时间轴')
    ref=float(plan['sign'])*(np.interp(ix[mask],ts,pos)-np.mean(pos[table_pre]))
    split=int(.6*len(ref))
    if split<100 or len(ref)-split<100:raise ValueError('训练或独立留出段样本不足')
    return pre,mask,ref,split,ix


def metrics(y,pre,mask,ref,split):
    base=y[pre]
    out=y[mask]-float(np.nanmean(base))
    if not np.all(np.isfinite(out)):raise ValueError('补偿结果存在无效角度')
    e=out-ref
    def rms(a):return round(float(np.sqrt(np.mean(a*a))),6)
    return {'rmse_train_deg':rms(e[:split]),'rmse_holdout_deg':rms(e[split:]),
            'rmse_entire_deg':rms(e),'max_error_deg':round(float(np.max(np.abs(e))),6),
            'p95_abs_deg':round(float(np.percentile(np.abs(e),95)),6),
            'samples_train':split,'samples_holdout':len(e)-split}


def evaluate_existing_experiment(source_path, output_dir=None, extra_radius=None):
    source_path=Path(source_path).absolute()
    r=json.loads(source_path.read_text(encoding='utf-8-sig'))
    if r.get('kind')!='REAL_2TD600_SINE_DIAGNOSTIC':raise ValueError('仅支持单轴动态实验原始JSON')
    if r.get('plan',{}).get('output') not in ('roll','pitch'):raise ValueError('报告缺少Roll/Pitch方向')
    required=('raw_file_table','raw_file_imu')
    for key in required:
        val=r.get(key)
        if not val or Path(val).name!=val:raise ValueError(f'报告文件名{key}无效')
    table=_load_csv(source_path.parent/r['raw_file_table'])
    imu=_load_csv(source_path.parent/r['raw_file_imu'])
    pre,mask,ref,split,clock=evaluation_windows(r,table,imu)
    roll=r['plan']['output']=='roll';field='roll' if roll else 'pitch'
    old=np.array([float(row[f'cal_madgwick_{field}']) for row in imu])
    original=metrics(old,pre,mask,ref,split)
    candidates=CANDIDATES_CM+([float(extra_radius)] if extra_radius is not None else [])
    candidates=sorted(set(candidates))
    measurements=[];cached={}
    print(f'原始标定后Madgwick全段RMSE {original["rmse_entire_deg"]:.5f}°；原始文件只读。',flush=True)
    for cm in candidates:
        yr,yp=replay_candidate(imu,cm)
        arr=yr if roll else yp
        performance=metrics(arr,pre,mask,ref,split)
        measurements.append({'equivalent_lever_z_cm':cm,**performance})
        cached[cm]=(yr,yp)
        print(f'{cm:5g}cm  训练 {performance["rmse_train_deg"]:.5f}°  留出 {performance["rmse_holdout_deg"]:.5f}°',flush=True)
    # Radius is chosen using TRAINING ONLY, not holdout RMSE.
    best=min(measurements,key=lambda x:x['rmse_train_deg'])
    chosen=best['equivalent_lever_z_cm']
    yr,yp=cached[chosen]
    for i,row in enumerate(imu):
        # In the raw sensor frame the physical lever arm coordinates are unknown.
        # Leave the raw branch as the ORIGINAL uncorrected Madgwick comparison.
        row['raw_leverarm_roll']=row.get('raw_madgwick_roll','')
        row['raw_leverarm_pitch']=row.get('raw_madgwick_pitch','')
        row['cal_leverarm_roll']=float(yr[i]) if math.isfinite(float(yr[i])) else ''
        row['cal_leverarm_pitch']=float(yp[i]) if math.isfinite(float(yp[i])) else ''
    plan=r['plan'];analysis=analyze_tracking(table,imu,int(plan['axis']),field,int(plan['sign']),
        float(plan['amplitude_deg']),float(plan['frequency_hz']),r['motion_start_pc_monotonic_ns'],r['motion_end_pc_monotonic_ns'])
    if not analysis.get('valid'):raise ValueError('增强对照失败：'+str(analysis.get('reason')))
    out=Path(output_dir or source_path.parent/'V68_离线回放')
    out.mkdir(parents=True,exist_ok=True)
    name=source_path.stem+'_ROTATION_REPLAY'
    diagnostic={'kind':'2TD600_OFFLINE_ROTATION_COMP_REPLAY','state':'analysis_only',
        'source_report':source_path.name,'uid':r.get('uid'),'stop_feedback_confirmed':r.get('stopped_verified'),
        'motion_commands_sent_during_replay':False,
        'target_axis':field,'plan':plan,'original_madgwick':original,
        'train_fraction':.6,'model':'rigid-body alpha×r + omega×(omega×r), r=(0,0,r_z), calibrated product P coordinates only',
        'candidate_grid':measurements,'selected_by_training_only_cm':chosen,
        'selected_train_and_holdout':best,
        'possible_overfit':'同一次实验的顺序分割不是其他日期/频率/方向的独立验证，等效距离不是测量的真实工装尺寸。',
        'default_in_live_app_cm':0,
        'notes':'原始RMSE不平移时间轴；并未将拟合参数用于转台控制；不构成动态±0.1°产品验收。',
        'calibration_mode':r.get('calibration_mode'),
        'replay_uses_legacy_beta_default':.075,
        'analysis':analysis}
    outfile=out/(name+'.json');outfile.write_text(json.dumps(diagnostic,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    # HTML is stand-alone with the real table reference and all 8 methods.
    # HTML renderer expects the normal experiment format. This overlay is
    # explicitly marked as retrospective analysis and never a fresh hardware run.
    wrapper={**diagnostic,'kind':'REAL_2TD600_SINE_DIAGNOSTIC','state':'invalid',
        'stopped_verified':r.get('stopped_verified'),'analysis':analysis,
        'raw_file_imu':r['raw_file_imu'],'raw_file_table':r['raw_file_table'],
        'finished_at':r.get('finished_at'),
        'replay_not_live':True}
    report_for_html=out/(name+'_INTERACTIVE.json')
    report_for_html.write_text(json.dumps(wrapper,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    html=write_interactive_report(report_for_html)
    # Original numeric comparison and parameter sweep remain in the JSON.
    return outfile,html,diagnostic


def main():
    if len(sys.argv)<2:
        print('使用：python 离线算法对照_只读.py "原始动态实验.json" [等效Z偏心厘米（可选）]')
        return 2
    try:
        radius=float(sys.argv[2]) if len(sys.argv)>=3 else None
        a,b,d=evaluate_existing_experiment(sys.argv[1],extra_radius=radius)
        print('\n已输出真实数据离线回放：',a,'\n交互HTML：',b)
        print('训练段选择的等效半径',d['selected_by_training_only_cm'],'cm')
        print('旧版全段RMSE',d['original_madgwick']['rmse_entire_deg'],'°')
        print('新方案全段RMSE',d['selected_train_and_holdout']['rmse_entire_deg'],'°')
        print('仅为本次工况研究对照；现场尺寸未知、停止未确认、时间未硬件同步。')
    except Exception as e:
        print('离线回放失败：',type(e).__name__,str(e));return 1
    return 0

if __name__=='__main__':raise SystemExit(main())
