@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title TiltLab V7.24.1 - Auto Timing Diagnostic
if exist ".venv\Scripts\python.exe" (
  set "PYEXE=%CD%\.venv\Scripts\python.exe"
) else (
  set "PYEXE=python"
)
"%PYEXE%" --version >nul 2>&1
if errorlevel 1 (
 echo [ERROR] Python not installed or missing. Please run INSTALL_DEPENDENCIES.bat.
 pause
 exit /b 1
)
echo Connect hardware only through the original V7.24.1 server.
echo Start START_TILT_LAB.bat FIRST, then use this console.
"%PYEXE%" "tools\auto_timebase\control_client.py"
if errorlevel 1 echo The diagnostic stopped unexpectedly. If moving, use hardware E-STOP.
pause
