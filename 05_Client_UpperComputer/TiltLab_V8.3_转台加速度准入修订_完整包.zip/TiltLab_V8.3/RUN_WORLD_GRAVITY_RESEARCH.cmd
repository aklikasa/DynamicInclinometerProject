@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set "PY=python"
if exist ".venv\Scripts\python.exe" set "PY=.venv\Scripts\python.exe"
echo OFFLINE RESEARCH ONLY - No device connection. Close live application safely first.
set /p "IMU=Drag IMU CSV here and press Enter: "
set /p "TABLE=Drag table CSV here and press Enter: "
set /p "REPORT=Drag matching dynamic HTML or JSON here and press Enter: "
"%PY%" tools\world_gravity_research.py "%IMU:"=%" "%TABLE:"=%" "%REPORT:"=%" --output "%CD%\V720_world_gravity_result.json"
pause
