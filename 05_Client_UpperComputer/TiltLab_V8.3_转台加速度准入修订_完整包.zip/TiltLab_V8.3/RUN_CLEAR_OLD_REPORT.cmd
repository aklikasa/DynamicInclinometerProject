@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 将旧TiltLab动态HTML文件拖到本窗口，或粘贴完整路径（无需转台或IMU连接）
set /p "SOURCE=HTML路径: "
set "SOURCE=%SOURCE:"=%"
if exist .venv\Scripts\python.exe (
 .venv\Scripts\python.exe tools\label_old_dynamic_html.py "%SOURCE%"
) else (
 python tools\label_old_dynamic_html.py "%SOURCE%"
)
pause
