@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title TiltLab V7.8 - IMU CSV Replay (No Table Control)
set "PYTHON=python"
if exist ".venv\Scripts\python.exe" set "PYTHON=.venv\Scripts\python.exe"
echo This only replays existing IMU CSV data. No turntable connection or motion commands.
echo Drag and drop a *_DYNAMIC_imu.csv into this window, or paste its full path below.
set /p CSVFILE=IMU CSV path: 
if "%CSVFILE%"=="" goto END
"%PYTHON%" tools\replay_v78.py "%CSVFILE%" --frequency .3 --from-s 14
:END
pause
endlocal
