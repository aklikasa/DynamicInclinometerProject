"""Read only: summarize an existing TiltLab embedded-JSON HTML report.

Does not contain IMU raw sample arrays. It cannot replay the new filter, prove
physical lever-arm size, or make time synchronization/certification claims.
Usage: python 旧动态报告_快速归因_只读.py path_to_DYNAMIC.html
"""
import json, sys
from pathlib import Path


def summarize(path):
    source=Path(path).read_text(encoding='utf-8-sig')
    tag='const DATA='
    if tag not in source:raise ValueError('不是包含内嵌DATA对象的TiltLab HTML报告')
    obj,_=json.JSONDecoder().raw_decode(source.split(tag,1)[1])
    reports=[]
    if obj.get('stages'):
        reports=[x.get('report') or {} for x in obj['stages']]
    else:reports=[obj.get('report') or {}]
    lines=['TiltLab 历史动态报告只读归因摘要','='*55,
        '注意：原始HTML只有报告指标/降采样曲线，不能重放原始六轴或新运动干扰抑制算法。']
    for report in reports:
        analysis=report.get('analysis') or {}
        plan=report.get('plan') or {}
        lines += ['',f"测试方向：{plan.get('output','未知')}，指令 ±{plan.get('amplitude_deg','?')}°、{plan.get('frequency_hz','?')}Hz",
                  f"反馈参考：约 ±{analysis.get('reference_amplitude_est_deg','未知')}°；反馈率 {analysis.get('feedback_rate_hz','未知')}Hz",
                  f"最大反馈采样缺口：{analysis.get('max_feedback_gap_ms','未知')}ms",
                  f"硬件时间同步：{bool(report.get('certified_dynamic_accuracy',False))}（不能以本字段证明已同步）",
                  '算法         幅值比    表观滞后ms    原时间轴RMSE°']
        by_alg={x.get('algorithm'):x for x in analysis.get('comparison',[]) if x.get('channel')=='cal'}
        for alg in ('gyro','accel','adaptive','adaptive_lever','motion_guard'):
            x=by_alg.get(alg)
            if x:lines.append(f"{alg:<14s} {x.get('amplitude_ratio','?'):>7} {x.get('apparent_phase_lag_ms','?'):>12} {x.get('relative_tracking_rmse_deg','?'):>14}")
        g=by_alg.get('gyro',{}).get('amplitude_ratio',None)
        acc=by_alg.get('accel',{}).get('amplitude_ratio',None)
        if isinstance(g,(int,float)) and isinstance(acc,(int,float)) and abs(g-1)<.025 and acc>1.04:
            lines+=['诊断线索：GYRO基波幅值接近真实参考、ACC幅值偏大。优先检查动态线加速度/补偿几何/融合可信度。']
        lines+=['报告中的相位只是波形拟合的等效滞后，不能视为已测得的通信固定时延。',
                '需要同一次测试的原始 *_DYNAMIC_imu.csv 与 *_DYNAMIC_table.csv，才能复算新的实验算法。']
    return '\n'.join(lines)+'\n'


if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('用法：python 旧动态报告_快速归因_只读.py 文件_DYNAMIC.html')
    print(summarize(sys.argv[1]))
