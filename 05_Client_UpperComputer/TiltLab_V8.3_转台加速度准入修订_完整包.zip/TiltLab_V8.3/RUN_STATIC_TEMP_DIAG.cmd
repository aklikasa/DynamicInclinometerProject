@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if not exist "app\devices.py" (
 echo Copy both files into the extracted TiltLab V7.16 folder, beside run.py.
 goto END
)
if exist ".venv\Scripts\python.exe" (
 ".venv\Scripts\python.exe" -u STATIC_TEMP_DIAG.py %*
 goto END
)
where py >nul 2>&1
if not errorlevel 1 (
 py -3 -u STATIC_TEMP_DIAG.py %*
 goto END
)
python -u STATIC_TEMP_DIAG.py %*
:END
pause
endlocal
