@echo off
cd /d "%~dp0"
echo Installing R10 optional calibration GUI/PLC dependencies. No hardware control.
call "INSTALL_DEPENDENCIES_DEBUG.cmd" --mode r10
