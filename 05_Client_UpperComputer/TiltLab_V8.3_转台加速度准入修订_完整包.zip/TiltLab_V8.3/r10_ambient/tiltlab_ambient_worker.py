"""Run the original R10 C-model ambient task in an exclusive hardware process.
No thermal/chamber UI or extra six-axis alignment is instantiated.
"""
import os, sys, time, json, math, threading, traceback
from pathlib import Path
from types import SimpleNamespace
import platform
if hasattr(platform,"_wmi_query"):
    def _wmi_disabled(*args,**kwargs):raise OSError("not supported")
    platform._wmi_query=_wmi_disabled
ROOT=Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0,str(ROOT.parent))
for sub in ('form','tilt_sensor','turntable','debug','tilt_sensor_calibration','ellipsoid','lm','acc_tdc'):
    sys.path.insert(0,str(ROOT/sub))
from PySide6.QtWidgets import QApplication,QTabWidget,QPushButton,QMessageBox
os.environ["TILTLAB_FACTORY_BRIDGE"]="1"
from app.factory_table_bridge import FactoryDLLProxy, FactoryAuthorization
import form_imu_calibration as r10
import turntable_2TD600_comm as vendor
from turntable_data_get import turntableComm,turntableData,turntableState,thread_of_turntable_data_get_create_and_start
from tilt_sensor_asm330_data_get import (tiltSensorComm,tiltSensorRawData,tilt_sensor_comm_open,tilt_sensor_comm_close,
    thread_of_tilt_sensor_data_get_create_and_start,thread_of_tilt_sensor_data_get_terminate,tilt_sensor_user_habits_get)

def atomic_json(path,data):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,path)

def run(job):
    cfg=json.loads((job/'worker_request.json').read_text(encoding='utf-8'))
    raw=job/'r10_raw';raw.mkdir(exist_ok=False)
    app=QApplication([]);tabs=QTabWidget();app.setQuitOnLastWindowClosed(False)
    dll_proxy=None
    # The parent retains the only vendor DLL/COM handle.
    turntableComm.thread_lock=threading.RLock()
    proxy=SimpleNamespace(button_TurntableCommPortOpen=QPushButton('打开转台'),turntable_2TD600_comm_port=f"COM{cfg['table_port']}",_speed_limit_tripped=False)
    notes=[];form=None;result=None;imu_started=False;table_started=False
    authorization=FactoryAuthorization(cfg['bridge'])
    def progress(state,**extra):
        record={'state':state,'updated_at':time.time(),**extra}
        with (job/'worker_progress.jsonl').open('a',encoding='utf-8') as f:
            f.write(json.dumps(record,ensure_ascii=False)+'\n')
    def cancelled():
        return (job/'abort').exists() or authorization.cancelled()
    def uid_ok():
        return tiltSensorComm.device_sn==cfg['uid'] and tiltSensorComm.device_uid_raw.upper()==cfg['uid_hex'].upper()
    # Only the original per-task confirmation is delegated to the explicit
    # full-range operator approval in TiltLab. All other questions deny.
    class Dialogs:
        Yes=QMessageBox.Yes;No=QMessageBox.No
        @staticmethod
        def question(parent,title,message,*args):
            if title=='确认开始自动标定' and cfg.get('confirmed_full_motion') is True and not cancelled() and uid_ok():
                return Dialogs.Yes
            notes.append(f'{title}: {message}');return Dialogs.No
        @staticmethod
        def warning(parent,title,message,*args):notes.append(f'{title}: {message}')
        critical=warning;information=warning
    r10.QMessageBox=Dialogs
    class OwnedForm(r10.FormImuCalibration):
        def _task_both_axes_safe(self):
            if cancelled():return False,'操作员取消或浏览器心跳丢失'
            if not uid_ok():return False,'IMU UID发生变化或不可读'
            if not (turntableState.is_inner_axis_find_zero and turntableState.is_outer_axis_find_zero):return False,'机械零点状态丢失，禁止自动找零'
            if any(not math.isfinite(float(v)) or abs(float(v))>10 for v in (turntableData.inner_axis_speed,turntableData.outer_axis_speed)):
                return False,'R10反馈软件限速±10°/s触发'
            return super()._task_both_axes_safe()
        def _finalize_auto_task(self,success,reason,show_dialog=False):
            self.finished=(bool(success),str(reason))
            super()._finalize_auto_task(success,reason,show_dialog=False)
    def wait_for(predicate,timeout,description):
        deadline=time.monotonic()+timeout
        while not predicate():
            if cancelled():raise RuntimeError('操作员取消或心跳丢失')
            if time.monotonic()>deadline:raise RuntimeError(description)
            app.processEvents();time.sleep(.025)
    try:
        if cancelled():raise RuntimeError('启动授权失效')
        progress('connecting_imu',detail='正在连接IMU并核对完整UID及有效数据')
        tilt_sensor_user_habits_get('config.xml')
        tiltSensorComm.comm_port=cfg['imu_port'];tiltSensorComm.baudrate=cfg['imu_baud'];tiltSensorComm.comm_addr=cfg['imu_address']
        if not tilt_sensor_comm_open():raise RuntimeError('R10 IMU串口打开失败')
        thread_of_tilt_sensor_data_get_create_and_start();imu_started=True
        wait_for(lambda:uid_ok() and tiltSensorComm.is_data_available and tiltSensorRawData.data_update_count>0,15,'R10未读取同一IMU的完整UID/有效数据')
        progress('imu_verified',detail='同一IMU UID及有效数据已确认')
        # Check configuration before enabling the table.
        from production_calibration import load_profile,verify_sensor_config
        profile=load_profile(str(ROOT));verify_sensor_config(profile,OwnedForm._sensor_reading_snapshot())
        if cancelled():raise RuntimeError('启动授权失效')
        dll_proxy=FactoryDLLProxy(cfg['bridge']);vendor.turntableDll=dll_proxy
        if not all(dll_proxy.GetAxisFindZero(a)==1 and dll_proxy.GetAxisEnable(a)==1 for a in (0,2)):raise RuntimeError('转台机械零点或使能未确认，禁止自动标定')
        turntableComm.turntable_model='2TD600';thread_of_turntable_data_get_create_and_start('2TD600');table_started=True
        proxy.button_TurntableCommPortOpen.setText('关闭转台')
        form=OwnedForm(SimpleNamespace(tabWidget_CalMain=tabs),proxy)
        form.line_device_sn.setText(cfg['uid']);form.line_output_root.setText(str(raw));form.check_safety.setChecked(True)
        form.combo_gravity_sign.setCurrentIndex(form.combo_gravity_sign.findData(cfg['gravity_sign']))
        form.combo_calibration_model.setCurrentIndex(form.combo_calibration_model.findData('C'))
        wait_for(lambda:turntableData.is_turntable_data_available and turntableState.is_inner_axis_find_zero and turntableState.is_outer_axis_find_zero,10,'R10转台反馈未就绪')
        for kind,start,filename in [('ACC',form._start_accel_auto,'accel_calibration.json'),('GYRO',form._start_gyro_auto,'gyro_calibration.json')]:
            if cancelled():raise RuntimeError('标定已取消')
            form.finished=None;start()
            if form._auto_task is None:raise RuntimeError('R10拒绝启动 '+kind+'：'+'；'.join(notes[-3:]))
            last=0
            while form._auto_task is not None:
                if cancelled():form._request_auto_abort('操作员取消或浏览器心跳丢失')
                app.processEvents();time.sleep(.01)
                if time.monotonic()-last>=.5:
                    last=time.monotonic();progress('calibrating',sensor=kind,detail=form.label_auto_task.text(),percent=form.progress_auto_task.value())
            if not form.finished or not form.finished[0]:raise RuntimeError(kind+'未通过：'+str(form.finished))
            doc=json.loads((raw/filename).read_text(encoding='utf-8'))
            if doc.get('quality_gate',{}).get('metric_pass') is not True or doc.get('device_serial')!=cfg['uid'] or not uid_ok():raise RuntimeError(kind+'质量门禁或UID不通过')
            # Add observed full UID, without altering R10 fitted parameters.
            doc['uid_hex']=cfg['uid_hex'];atomic_json(Path(cfg['stage_folder'])/filename,doc)
        result={'success':True,'message':'原R10 ACC/GYRO C方案均通过原质量门禁'}
    except Exception as exc:
        result={'success':False,'message':str(exc),'traceback':traceback.format_exc()}
    finally:
        # Parent independently revokes motion and verifies STOP. Child never
        # disables, opens or closes the table DLL/COM connection.
        if form is not None:form.shutdown()
        if dll_proxy is not None:
            for axis in (0,2):
                try:dll_proxy.SetAxisStop(axis)
                except Exception as exc:progress('stop_request_failed',detail=str(exc));result['success']=False
        if table_started:
            turntableComm.terminate_thread_requst=True
            deadline=time.monotonic()+10
            while turntableComm.thread_instance is not None and time.monotonic()<deadline:time.sleep(.02)
            if turntableComm.thread_instance is not None:result['success']=False;result['message']='R10反馈线程未退出'
        try:
            if imu_started:thread_of_tilt_sensor_data_get_terminate()
            tilt_sensor_comm_close()
            result['imu_released']=not tiltSensorComm.is_serial_opened
        except Exception as exc:
            result['success']=False;result['imu_released']=False;result['message']=str(exc)
        atomic_json(job/'worker_result.json',result)
    return 0 if result['success'] else 1

if __name__=='__main__':
    if len(sys.argv)==2 and sys.argv[1]=='--check':sys.exit(0)
    sys.exit(run(Path(sys.argv[1]).resolve()))
