@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONPATH=%CD%;%CD%\form;%CD%\tilt_sensor;%CD%\turntable;%CD%\temperature_chamber;%CD%\debug
python tools\test_fixed_gyro_operator_flow.py
if errorlevel 1 goto fail
python tools\test_flexible_full_scale.py
if errorlevel 1 goto fail
echo.
echo [PASS] Fixed hardware conversion and UI checks passed.
pause
exit /b 0
:fail
echo.
echo [FAIL] See the error messages above.
pause
exit /b 1
