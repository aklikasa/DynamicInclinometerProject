@echo off
cd /d "%~dp0"
call "INSTALL_DEPENDENCIES_DEBUG.cmd" --mode r10
exit /b %errorlevel%
