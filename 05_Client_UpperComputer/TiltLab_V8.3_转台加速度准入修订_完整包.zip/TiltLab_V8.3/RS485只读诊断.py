"""Field diagnostics for R10/ASM330: no register writes, no turntable motion."""
import time
from pathlib import Path
from app.devices import R10Device, DeviceError, list_ports


def check_port(port, baud, addr):
    dev=R10Device(port,baud,addr,timeout=1.0)
    try:
        # Do not use open() here: 3000 UID may be unsupported on older fw.
        import serial
        dev.serial=serial.Serial(port, baud, timeout=1.0, bytesize=8, parity='N', stopbits=1)
        time.sleep(.08)
        regs=dev.read(1000,104)
        print(f'  地址 {addr}：IMU 1000读取成功，收到104个寄存器')
        print(f'  TX: {dev.last_tx_hex}')
        print(f'  RX: {dev.last_rx_length}字节 / {dev.last_rx_ms:.1f}ms')
        print(f'  未读批次={regs[0]}，量程 ACC={regs[100]}g GYRO={regs[101]}dps，ODR={regs[102]}Hz，状态=0x{regs[103]:04X}')
        try:
            uid=dev.read(3000,6)
            import struct
            from app.calibration import uid_to_serial
            raw=struct.pack('>6H',*uid)
            print('  UID:',raw.hex().upper(),'编号:',uid_to_serial(raw))
        except Exception as exc:
            print('  UID 3000未读到（不影响IMU通信）:',str(exc)[:320])
        return True
    except Exception as exc:
        print(f'  地址 {addr}：失败：{str(exc)[:700]}')
        return False
    finally:
        dev.close()


def main():
    print('===== R10 / ASM330 RS485 只读诊断 =====')
    print('不会写入寄存器，不启动转台；与标定上位机不要同时占用同一COM口。')
    print('R10实际源码默认从站地址是1；注释有RS485为2的描述，因此在此测试1和2。')
    available=list_ports()
    print('发现串口：',', '.join(p['device']+'('+p['label']+')' for p in available) if available else '未检测到')
    port=input('实际USB-RS485串口（例如 COM5）：').strip().upper()
    if not port:
        print('未输入串口');return
    baud=int(input('波特率 [1500000]：').strip() or '1500000')
    try:
        for addr in (1,2):
            print(f'\n--- 检查地址 {addr} ---')
            check_port(port,baud,addr)
        print('\n请把以上两组诊断结果发给我；无需猜测地址。')
    except Exception as exc:
        print('诊断工具遇到错误：',repr(exc))

if __name__=='__main__':main()
