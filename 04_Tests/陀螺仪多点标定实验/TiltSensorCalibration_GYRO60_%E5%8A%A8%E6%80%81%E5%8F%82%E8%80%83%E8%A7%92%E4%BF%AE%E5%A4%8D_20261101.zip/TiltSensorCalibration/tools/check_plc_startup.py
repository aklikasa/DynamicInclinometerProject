# -*- coding: utf-8 -*-
"""只读检查源码目录及 python-snap7 导入。不会连接 PLC。"""
from pathlib import Path
import sys
import importlib
ROOT = Path(__file__).resolve().parents[1]
TC = ROOT / "temperature_chamber"
assert (TC / "plc_comm.py").is_file(), "缺少 temperature_chamber/plc_comm.py；请完整解压 ZIP，勿把文件重命名为 plc_comm_兼容修复.py"
sys.path.insert(0, str(TC))
sys.path.insert(0, str(ROOT / "debug"))
try:
    import snap7
except ImportError as exc:
    raise SystemExit(f"FAIL: 当前解释器未安装 python-snap7：{exc}")
try:
    importlib.import_module('plc_comm')
except Exception as exc:
    raise SystemExit(f"FAIL: plc_comm 导入失败：{type(exc).__name__}: {exc}")
print('PASS: plc_comm.py 路径、命名及 snap7 导入正常（未访问实际PLC）')
