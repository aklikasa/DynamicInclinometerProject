# -*- coding: utf-8 -*-
"""离线多速率扩展专项测试：限速、工况展开、冻结配置、拟合与独立验证。"""
import ast
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import production_calibration as pc

orig = pc.load_profile(str(ROOT))
fit = pc.parse_gyro_rate_text('1, 2, 3, 5, 7.5, 10')
val = pc.parse_gyro_rate_text('1.5，3.5; 4.5 6 9')
assert fit == list(pc.GYRO_EXTENDED_FIT_DPS)
assert val == list(pc.GYRO_EXTENDED_VERIFY_DPS)
expanded = pc.profile_with_gyro_rates(orig, fit, val)
steps_fit = pc.gyro_fit_steps(expanded)
steps_val = pc.gyro_verify_steps(expanded)
assert len(steps_fit) == 37 and len(steps_val) == 31, (len(steps_fit),len(steps_val))
assert len(steps_fit) + len(steps_val) == 68
assert orig['rates']['fit_dps'] == [1.0, 2.0, 5.0]
assert orig['rates']['verify_dps'] == [1.5, 3.5]
assert all(abs(s['target_rate_dps']) <= 10 for s in steps_fit+steps_val if s['mode']=='rate')
assert len({s['step_id'] for s in steps_fit+steps_val}) == 68
for steps, rates in ((steps_fit, fit), (steps_val, val)):
    speed_steps = [s for s in steps if s['mode']=='rate']
    for axis in ('X','Y','Z'):
        axis_steps = [s for s in speed_steps if '_'+axis+'_' in s['step_id']]
        assert {s['target_rate_dps'] for s in axis_steps} == {sign * v for sign in (-1, 1) for v in rates}
for invalid_fit, invalid_val in (("1, 2, 2", "3"),("1, 1.5", "1.5"),("1, 15", "3"),
                                 ("nan", "3"),("inf", "3"),("-1", "3"),("", "3")):
    try:
        pc.profile_with_gyro_rates(orig, pc.parse_gyro_rate_text(invalid_fit), pc.parse_gyro_rate_text(invalid_val))
    except ValueError:
        pass
    else:
        raise AssertionError('无效速率未拦截: '+invalid_fit+' / '+invalid_val)

# 从真实页面提取数学建模方法，验证增加速率点后能拟合3×3参数，且验证数据不参与拟合。
source = ROOT/'form'/'form_imu_calibration.py'
tree = ast.parse(source.read_text(encoding='utf-8'))
funcs = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in
         ('_rotation_x','_rotation_y','_rotation_z','_platform_rotation','_platform_angular_rate','_fit_affine_reference')]
namespace={'np':np}
exec(compile(ast.fix_missing_locations(ast.Module(body=funcs,type_ignores=[])),str(source),'exec'),namespace)
def rate_vec(s):
    if s['mode']=='static':
        return np.zeros(3)
    return namespace['_platform_angular_rate'](s['inner_deg'],s['outer_deg'],
        s['target_rate_dps'] if s['rotation_axis']=='inner' else 0.,
        s['target_rate_dps'] if s['rotation_axis']=='outer' else 0.,'outer_x_inner_z')
refs=np.asarray([rate_vec(s) for s in steps_fit])
val_refs=np.asarray([rate_vec(s) for s in steps_val])
assert np.linalg.matrix_rank(np.column_stack((refs,np.ones(len(refs))))) == 4
matrix=np.array([[.93,-.03,.02],[.02,1.05,.01],[-.012,.018,1.02]])
bias=np.array([.06,-.05,.1]); rng=np.random.default_rng(20261101)
raw=refs@matrix.T+bias+rng.normal(0,.003,refs.shape)
result=namespace['_fit_affine_reference'](refs,raw,'deg/s','deg/s')
assert np.max(np.abs(result['forward_matrix']-matrix)) < .01
metrics=pc.residual_statistics(val_refs,val_refs@matrix.T+bias,
                               result['bias'],result['correction_matrix'],'gyro')
assert metrics['rmse_vector'] < .04

# 静态连线：三个入口都使用用户冻结 profile，运行时参数与显示参数一致。
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='FormImuCalibration')
methods={n.name: ast.get_source_segment(source.read_text(encoding='utf-8'),n) for n in cls.body if isinstance(n,ast.FunctionDef)}
for method in ('_start_gyro_compare','_start_alignment_auto','_generate_gyro_plan'):
    assert 'self._load_ui_gyro_profile()' in methods[method], method
# GYRO主任务新增独立研发质控开关，其他入口仍使用原严格质控。
assert 'self._load_ui_gyro_profile(allow_std_warning=True)' in methods['_start_gyro_auto']
for method in ('_start_gyro_auto','_start_gyro_compare','_start_alignment_auto'):
    assert 'profile_override=profile' in methods[method], method
assert 'copy.deepcopy(profile_override)' in methods['_start_auto_task']
assert 'expected_steps' in methods['_start_auto_task']
assert 'PROTOTYPE_MAX_ABS_SPEED_DPS' in methods['_check_gyro_profile_rate_safety']
assert 'self.edit_gyro_fit_rates.setEnabled(False)' in methods['_start_auto_task']
assert 'self.edit_gyro_fit_rates.setEnabled(True)' in methods['_finalize_auto_task']
print('PASS: GUI速率计划/68工况/原工艺隔离/量程安全/拟合测试/界面-任务参数一致')

# 用真实页面的标定求参函数对“扩展工况”完成整段合成数据回归。
methods_ast = [node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == '_fit_gyroscope_result']
fit_cls = ast.ClassDef(name='FitPageStub', bases=[], keywords=[], decorator_list=[], body=methods_ast)
ns = {'np':np,'residual_statistics':pc.residual_statistics,
      'evaluate':pc.evaluate,'sensor_axis_invariants':pc.sensor_axis_invariants,
      '_fit_affine_reference':namespace['_fit_affine_reference'],
      '_now_iso':lambda:'2026-11-01T00:00:00+08:00'}
exec(compile(ast.fix_missing_locations(ast.Module(body=[fit_cls],type_ignores=[])),str(source),'exec'),ns)
obj=ns['FitPageStub']()
obj.run_id='SYNTHETIC_EXTENDED_RATE'
def row(s):
    r=rate_vec(s)
    return {**s,'reference':r.tolist(), 'measured':(matrix@r+bias).tolist(),
            'temperature_mean_c':25.0}
task={'gyro_fit_samples':[row(s) for s in steps_fit],
      'gyro_validation_samples':[row(s) for s in steps_val],
      'quality_profile':expanded,'device_serial':'SYNTHETIC-01',
      'axis_model':'outer_x_inner_z','gravity_sign':1}
result=obj._fit_gyroscope_result(task)
assert result['quality_gate']['metric_pass'],result['quality_gate']
assert len(result['fit_measurements'])==37 and len(result['validation_measurements'])==31
assert len(result['tested_rate_points_dps'])==11
print('PASS: 扩展速率37+31工况完整拟合/验证/结果文件字段（合成数据）')
