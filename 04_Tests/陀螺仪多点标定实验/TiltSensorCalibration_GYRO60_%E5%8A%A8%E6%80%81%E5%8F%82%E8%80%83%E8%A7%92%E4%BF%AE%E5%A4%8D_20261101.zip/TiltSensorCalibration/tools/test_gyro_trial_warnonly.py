# -*- coding: utf-8 -*-
"""试验模式仅抖动报警变为警告，不改变安全相关/其他数据完整性限制。"""
import sys
import numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import production_calibration as pc
p=pc.load_profile(str(ROOT))
p=pc.profile_with_gyro_rates(p,pc.GYRO_FULL60_FIT_DPS,pc.GYRO_FULL60_VERIFY_DPS,
                             high_speed_acknowledged=True,acceleration_dps2=10.)
rng=np.random.default_rng(5)
frames=[]
for i in range(220):
    frames.append(dict(acc=[.03,0.,1.],
      gyro=[4+rng.normal(0,.4),-6+rng.normal(0,.4),116+rng.normal(0,.76)],
      inner_rate_dps=15.+rng.normal(0,.001),outer_rate_dps=0.,
      inner_deg=200+i*.1,outer_deg=0., temp_c=27.0,
      gyro_raw_samples=16,gyro_accepted_samples=16,acc_raw_samples=16,acc_accepted_samples=16))
try:pc.robust_segment(frames,'rate',p,target_rate=15,axis='inner')
except ValueError as e:assert '动态GYRO抖动' in str(e)
else:raise AssertionError('默认严格抖动阈值应拒绝这组数据')
p['quality']['rate_gyro_std_policy']='warn_only'
pc.validate_profile(p)
s=pc.robust_segment(frames,'rate',p,target_rate=15,axis='inner')
assert s['accepted_frames']>=200
assert len(s['quality_warnings'])==1
assert s['gyro_std_dps'][2]>0.55
frames2=[dict(f,inner_rate_dps=10.) for f in frames]
try: pc.robust_segment(frames2,'rate',p,target_rate=15,axis='inner')
except ValueError as e:assert '转台稳定段实际平均转速偏离目标' in str(e)
else:raise AssertionError('研发采集不能跳过参考速度误差')
frames3=[dict(f,temp_c=60.) for f in frames]
try:pc.robust_segment(frames3,'rate',p,target_rate=15,axis='inner')
except ValueError as e:assert '温度' in str(e)
else:raise AssertionError('研发采集不能跳过温度限制')
p['approved_for_production']=True
try: pc.validate_profile(p)
except ValueError:pass
else:raise AssertionError('警告模式必须禁止生产放行')
print('PASS: 试验模式只对动态GYRO波动降级为警告，其它质量门槛保留')
