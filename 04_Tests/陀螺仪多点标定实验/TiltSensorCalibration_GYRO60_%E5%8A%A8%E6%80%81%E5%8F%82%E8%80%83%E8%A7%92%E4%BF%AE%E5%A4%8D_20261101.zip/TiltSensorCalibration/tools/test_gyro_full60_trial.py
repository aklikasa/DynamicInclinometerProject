# -*- coding: utf-8 -*-
"""60°/s 陀螺仪自动标定全范围离线专项检查。只用合成数据，不发转台指令。"""
import ast
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import production_calibration as pc

profile_disk = pc.load_profile(str(ROOT))
assert profile_disk['rates']['maximum_command_rate_dps'] == 10.0
assert profile_disk['rates']['fit_dps'] == [1.0, 2.0, 5.0]
fit = list(pc.GYRO_FULL60_FIT_DPS)
val = list(pc.GYRO_FULL60_VERIFY_DPS)
assert max(fit) == 60 and 60 not in val
assert not set(fit) & set(val)

def must_fail(f, v, **opts):
    try:
        pc.profile_with_gyro_rates(profile_disk, f, v, **opts)
    except ValueError:
        return
    raise AssertionError(f'拒绝规则未生效: {f}, {v}, {opts}')

must_fail(fit, val)  # 未明确授权不能解锁
must_fail(fit+[65], val, high_speed_acknowledged=True, acceleration_dps2=10)
must_fail(fit, val+[60], high_speed_acknowledged=True, acceleration_dps2=10)
must_fail(fit, val, high_speed_acknowledged=True, acceleration_dps2=0.5)
must_fail(fit, val, high_speed_acknowledged=True, acceleration_dps2=35)
p = pc.profile_with_gyro_rates(profile_disk, fit, val,
                               high_speed_acknowledged=True, acceleration_dps2=10.0)
assert p['rates']['maximum_command_rate_dps'] == 60.0
assert p['rates']['velocity_accel_dps2'] == 10.0
assert p['rates']['high_speed_trial_acknowledged'] is True
assert p['approved_for_production'] is False
assert profile_disk['rates']['maximum_command_rate_dps'] == 10.0
assert p['quality'] == profile_disk['quality']
steps_f, steps_v = pc.gyro_fit_steps(p), pc.gyro_verify_steps(p)
assert (len(steps_f), len(steps_v)) == (55, 43)
assert len({s['step_id'] for s in steps_f + steps_v}) == 98
for steps, expected in ((steps_f,fit),(steps_v,val)):
    for axis in ('X','Y','Z'):
        batch=[s['target_rate_dps'] for s in steps if s['mode']=='rate' and f'_{axis}_' in s['step_id']]
        assert set(batch) == {sign*m for m in expected for sign in (-1, 1)}

source = ROOT/'form'/'form_imu_calibration.py'
tree = ast.parse(source.read_text('utf-8'))
math_methods=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in
    ('_rotation_x','_rotation_y','_rotation_z','_platform_rotation','_platform_angular_rate','_fit_affine_reference')]
ns={'np':np}
exec(compile(ast.fix_missing_locations(ast.Module(body=math_methods,type_ignores=[])),str(source),'exec'),ns)
def vector(step):
    if step['mode']=='static': return np.zeros(3)
    return ns['_platform_angular_rate'](
        step['inner_deg'], step['outer_deg'],
        step['target_rate_dps'] if step['rotation_axis']=='inner' else 0.0,
        step['target_rate_dps'] if step['rotation_axis']=='outer' else 0.0,
        'outer_x_inner_z')
ref=np.asarray([vector(x) for x in steps_f])
assert np.linalg.matrix_rank(np.column_stack([ref, np.ones(len(ref))])) == 4
matrix=np.array([[.94,.015,-.01],[-.02,1.035,.008],[.012,-.018,.975]])
bias=np.array([.12,-.15,.08])
raw=ref @ matrix.T + bias
fitted=ns['_fit_affine_reference'](ref,raw,'°/s','°/s')
assert np.max(np.abs(fitted['forward_matrix']-matrix)) < 1e-10
assert np.max(np.abs(fitted['bias']-bias)) < 1e-10
cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='FormImuCalibration')
methods={x.name:ast.get_source_segment(source.read_text('utf-8'),x) for x in cls.body if isinstance(x,ast.FunctionDef)}
assert 'high_speed_trial_acknowledged' in methods['_check_gyro_profile_rate_safety']
assert 'self.check_gyro_high_speed.isChecked()' in methods['_load_ui_gyro_profile']
assert "get('velocity_accel_dps2', 1.0)" in methods['_send_axis_velocity']
assert 'abs(target) / accel + 12.0' in methods['_auto_task_tick']
assert 'abs(target) * 0.005' in methods['_auto_task_tick']
assert 'stop_timeout' in methods['_auto_task_tick']
assert 'self.check_gyro_high_speed.setChecked(False)' in methods['_finalize_auto_task']
assert 'PROTOTYPE_MAX_ABS_SPEED_DPS' in methods['_start_single_velocity'] if '_start_single_velocity' in methods else \
    'PROTOTYPE_MAX_ABS_SPEED_DPS' in source.read_text('utf-8')
# 复用真实求参方法完成完整拟合/验证集的结果结构检查。
func=[x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='_fit_gyroscope_result']
cls_math=ast.ClassDef(name='PageSynthetic', bases=[], keywords=[], decorator_list=[],body=func)
ns.update({'residual_statistics':pc.residual_statistics, 'evaluate':pc.evaluate,
           'sensor_axis_invariants':pc.sensor_axis_invariants,
           '_now_iso':lambda:'2026-11-01T00:00:00+08:00'})
exec(compile(ast.fix_missing_locations(ast.Module(body=[cls_math],type_ignores=[])),str(source),'exec'),ns)
obj=ns['PageSynthetic'](); obj.run_id='SYNTHETIC_GYRO_FULL60'
def row(step):
    v=vector(step)
    return {**step,'reference':v.tolist(),'measured':(matrix@v+bias).tolist(),
            'temperature_mean_c':25.0}
result=obj._fit_gyroscope_result({
    'gyro_fit_samples':[row(s) for s in steps_f],
    'gyro_validation_samples':[row(s) for s in steps_v],
    'quality_profile':p,'device_serial':'SYNTHETIC-FULL60',
    'axis_model':'outer_x_inner_z','gravity_sign':1})
assert result['quality_gate']['metric_pass'], result['quality_gate']
assert len(result['fit_measurements'])==55
assert len(result['validation_measurements'])==43
assert set(result['tested_rate_points_dps']) == set(fit + val)
assert result['quality_profile_snapshot']['rates']['velocity_accel_dps2'] == 10.0
print('PASS: 60°/s速率许可、98工况/覆盖3轴正反转、非法输入拦截、真实线性求参、结果快照（纯离线）')
