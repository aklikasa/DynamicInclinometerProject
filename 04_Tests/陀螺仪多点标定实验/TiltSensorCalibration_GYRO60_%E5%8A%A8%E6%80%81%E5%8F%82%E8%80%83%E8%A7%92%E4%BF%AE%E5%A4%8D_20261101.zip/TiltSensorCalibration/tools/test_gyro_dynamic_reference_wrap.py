# -*- coding: utf-8 -*-
"""回归测试：动态采样静止轴跨360°时，参考方向不得旋转180°。
纯离线；不加载DLL或控制实际转台。
"""
from pathlib import Path
import sys, math
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import production_calibration as pc

root=Path(__file__).resolve().parents[1]
profile=pc.load_profile(str(root))
profile['quality']['rate_gyro_std_policy']='warn_only'  # 与研发采集模式一致，测试中不触发抖动门槛

def fake_frames(inner_angles, outer_angles, axis, rate):
    return [dict(acc=[0,0,1],gyro=[4.,-7., 8*rate-3.5],
            inner_rate_dps=rate if axis=='inner' else 0.,
            outer_rate_dps=rate if axis=='outer' else 0.,
            inner_deg=float(ai),outer_deg=float(ao),temp_c=25.0)
            for ai,ao in zip(inner_angles, outer_angles)]

n=225
wrapped = np.array([359.9, 0.1]*((n+1)//2))[:n]
# X：固定内轴≈0°跨周期边界，外轴旋转；必须接近 +X 而非 -X。
s=pc.robust_segment(fake_frames(wrapped,np.full(n,180.),'outer',15.),'rate',profile,target_rate=15.,axis='outer')
angle=s['inner_actual_mean_deg']
assert min(abs(angle), abs(angle-360.)) < .2, angle
assert abs(s['inner_rate_mean_dps'])<.001
# Y：内轴固定270°，不能改变原来 Y 轴的姿态与运动向量。
s=pc.robust_segment(fake_frames(np.full(n,270.),np.full(n,180.),'outer',15.),'rate',profile,target_rate=15.,axis='outer')
assert abs(s['inner_actual_mean_deg']-270.)<.001
# Z：外轴固定零位附近、内轴旋转，转台位置仍应按周期等效0°处理。
s=pc.robust_segment(fake_frames(np.linspace(0,600,n),wrapped,'inner',15.),'rate',profile,target_rate=15.,axis='inner')
assert min(abs(s['outer_actual_mean_deg']),abs(s['outer_actual_mean_deg']-360.)) < .2
# 动态采样的真实运动轴仍可报告原始算术均值（不做虚假的周期姿态估计）。
assert abs(s['inner_actual_mean_deg']-300.)<1e-6
print('PASS: X/Y/Z参考角零位跨周处理及运动轴原有统计保持不变')
