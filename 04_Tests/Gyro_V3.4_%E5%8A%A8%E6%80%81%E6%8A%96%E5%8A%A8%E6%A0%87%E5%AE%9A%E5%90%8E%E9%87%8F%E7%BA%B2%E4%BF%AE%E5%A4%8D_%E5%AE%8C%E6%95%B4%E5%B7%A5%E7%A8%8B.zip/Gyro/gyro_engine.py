# -*- coding: utf-8 -*-
"""Gyro 恒速独立验证，与 ACC Experiment 共用串口/使能/回零/自动暂存。

核心区分：转台运动期间采样；参考角速度使用实际双轴速率反馈，
并在厂商原上位机的帧内MAD、跨帧MAD及质量门槛上计算。
"""
from __future__ import annotations
import csv
import sys
import math
import time
import threading
from datetime import datetime
from pathlib import Path
import numpy as np
from engine import save_json_atomic,Cancelled
from core import circular_distance
from vendor.production_calibration import robust_segment, frame_average_sanitized
from devices import HardwareError,HARDWARE_MOTION_LOCKED
from stop_evidence import StopEvidence


def build_gyro_cases(speeds=(3.5,7.5,15.,30.,45.),repeats=3):
    """轴/方向映射基于 outer_x_inner_z; 所有速度仅为候选，需要实机核验。"""
    cases=[]
    for direction,axis,beta,alpha in [('X','outer',0.,180.),('Y','outer',270.,180.),('Z','inner',180.,0.)]:
        for speed in speeds:
            for rep in range(1,int(repeats)+1):
                for sign in (1,-1):
                    cases.append({'id':len(cases)+1,'direction':direction,'axis':axis,
                                  'inner_setup_deg':beta,'outer_setup_deg':alpha,
                                  'target_rate_dps':round(float(speed)*sign,5),'repeat':rep})
    return cases


def gyro_ref(inner_deg,outer_speed,inner_speed):
    beta=math.radians(float(inner_deg))
    return np.array([outer_speed*math.cos(beta), -outer_speed*math.sin(beta),inner_speed],float)


def summarize_rate(frames,cal,profile,case):
    """真实与模拟采样帧进入相同的 Gyro 稳态筛选程序。"""
    filtered=[]
    for f in frames:
        gyro,total,accepted=frame_average_sanitized(f['gyr_dps_arr'],
            profile['quality'].get('gyro_mad_sigma',6),True)
        if gyro is None:continue
        # ACC 不参与动态质量判定；但仍提供源算法必需的三维输入。
        accel,atot,aacc=frame_average_sanitized(f['acc_g_arr'],
            profile['quality']['mad_sigma'],True)
        if accel is None:accel=np.zeros(3)
        filtered.append({'acc':np.asarray(accel).tolist(),'gyro':np.asarray(gyro).tolist(),
            'acc_raw_samples':atot,'acc_accepted_samples':aacc,
            'gyro_raw_samples':total,'gyro_accepted_samples':accepted,
            'inner_deg':f['inner_deg'],'outer_deg':f['outer_deg'],
            'inner_rate_dps':f['inner_rate_dps'],'outer_rate_dps':f['outer_rate_dps'],
            'temp_c':f['temp_c'],'time':f.get('elapsed_s',None)})
    if len(frames)<profile['quality']['minimum_frames']:
        raise ValueError(f'速度稳定段帧数不足：{len(frames)}')
    # 按原标定规则完成相同MAD筛选；仅动态噪声QC使用校正后的P系标准差。
    # 原生产标定、静态复核的判据不变。
    stat=robust_segment(filtered,'rate',profile,
        target_rate=case['target_rate_dps'],axis=case['axis'],
        gyro_qc_matrix=cal.gyro_matrix)
    total_reject=1-stat['accepted_frames']/max(1,len(frames))
    if total_reject>profile['quality']['max_rejection_fraction']:
        raise ValueError(f'总帧剔除率{total_reject:.1%}超过门槛（含帧内无效）')
    raw=np.asarray(stat['gyro_raw_mean_dps'],float)
    corrected=cal.gyro_matrix@(raw-cal.gyro_bias)
    # Match the per-frame CSV: project each accepted feedback frame, then average.
    # Never project a linear mean of angles spanning 0/360 degrees.
    ref=np.asarray(stat['rate_reference_xyz_dps'],float)
    if ref.shape != (3,) or not np.all(np.isfinite(ref)):
        raise ValueError('转台参考角速度向量缺失或无效')
    err=corrected-ref
    axis_idx={'X':0,'Y':1,'Z':2}[case['direction']]
    cross=math.sqrt(float(sum(err[i]**2 for i in range(3) if i!=axis_idx)))
    out={**case,'status':'PASS','reference_xyz_dps':ref.tolist(),
         'raw_xyz_dps':raw.tolist(),'cal_xyz_dps':corrected.tolist(),
         'error_xyz_dps':err.tolist(),'main_axis_error_dps':float(err[axis_idx]),
         'main_axis_absolute_error_dps':float(abs(err[axis_idx])),
         'relative_error_pct':float(100*abs(err[axis_idx])/abs(ref[axis_idx])) if abs(ref[axis_idx])>.01 else None,
         'cross_axis_norm_dps':cross,'vector_error_dps':float(np.linalg.norm(err)),
         'actual_inner_rate_dps':stat['inner_rate_mean_dps'],
         'actual_outer_rate_dps':stat['outer_rate_mean_dps'],
         'accepted_frames':stat['accepted_frames'],'received_frames':len(frames),
         'reject_fraction':total_reject,'gyro_std_dps':stat['gyro_std_dps'],
         'gyro_calibrated_std_dps':stat['gyro_calibrated_std_dps'],
          'gyro_qc_domain':'calibrated_platform_P',
          'gyro_qc_std_limit_dps':float(profile['quality']['rate_gyro_std_max_dps']),
          'temperature_c':stat['temperature_mean_c'],'temperature_span_c':stat['temperature_span_c'],
         'filter_method':'frame_mad_then_cross_frame_mad',
         'frame_mad_sigma':float(profile['quality'].get('gyro_mad_sigma',6)),
         'segment_mad_sigma':float(profile['quality']['mad_sigma'])}
    # 原始XYZ未统一坐标/存在约8倍数值比例，不计算原始相对于平台参考的“误差”。
    return out


class GyroExperiment:
    output_mode='gyro'
    def __init__(self,tt,imu,calibration,profile,cases,settle_seconds,sample_seconds,
                 root,movement_speed,events,stop_event=None,demo=False,accel_dps2=1.,
                 high_speed_approved=False,max_travel_deg=360.,zero_seconds=20.,home_before_run=True):
        self.tt,self.imu,self.cal,self.profile=tt,imu,calibration,profile
        self.cases=list(cases);self.settle=float(settle_seconds);self.sample=float(sample_seconds)
        self.position_speed=float(movement_speed);self.acceleration=float(accel_dps2)
        self.high_speed_approved=bool(high_speed_approved)
        self.max_travel=float(max_travel_deg);self.zero_seconds=float(zero_seconds);self.zero_result=None
        self.home_before_run=bool(home_before_run)
        self.events,self.stop_event,self.demo=events,stop_event or threading.Event(),demo
        self.stop_confirmed=False
        self.folder=Path(root)/('GYRO_动态验证_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
        self.folder.mkdir(parents=True,exist_ok=False)
        self.rows=[];self.failed=[];self.completed=False;self.state='准备';self.log_lines=[]
        self.config={'validation_type':'GYRO_DYNAMIC','mode':'演示/模拟数据' if demo else '实际硬件',
            'device_serial':calibration.device_serial,'calibration_file':calibration.source,
            'axis_model':calibration.axis_model,'cases':self.cases,'case_count':len(self.cases),
            'sample_seconds':self.sample,'settle_seconds':self.settle,'zero_seconds':self.zero_seconds,
            'rate_acceleration_dps2':self.acceleration,'normal_stop':'active_axis_only',
            'emergency_stop':'both_axes_request_not_equivalent_to_hardware_estop',
            'baseline':'production gyro_rate_steps and production active-axis STOP',
            'test_motion_budget_deg':self.max_travel,
            'high_speed_approved_by_operator':self.high_speed_approved,
            'controller_feedback_timestamp_available':False,
            'stop_confirmation_limit':'主机多次读取速度与模式；无法证明DLL控制器底层帧新鲜度',
            'quality_profile_id':profile.get('profile_id'),
            'validation_gyro_noise_qc_domain':'calibrated_platform_P',
             'validation_gyro_noise_qc_limit_dps':float(profile['quality']['rate_gyro_std_max_dps']),
            'started_at':datetime.now().isoformat(timespec='seconds'),
            'warning':'动态试运行，转台手册未给角速率计量精度；Gyro原始量纲存在约8倍换算疑点；不签发正式PASS'}
        save_json_atomic(self.folder/'任务配置.json',self.config);self._checkpoint()

    def emit(self,msg,level='INFO'):
        ln=f'[{datetime.now().strftime("%H:%M:%S")}] [{level}] {msg}'
        self.log_lines.append(ln)
        with (self.folder/'运行日志.txt').open('a',encoding='utf-8') as f:f.write(ln+'\n')
        self.events('log',ln)

    def _checkpoint(self):
        save_json_atomic(self.folder/'自动暂存_逐工况.json',{
            'config':self.config,'rows':self.rows,'failed':self.failed,
            'completed':self.completed,'state':self.state,'zero_result':self.zero_result,
            'stop_confirmed':self.stop_confirmed,
            'safety_fault_latched':self.tt.safety_fault_latched,
            'safety_fault_reason':self.tt.safety_fault_reason,
            'last_stop_diagnostics':self.tt.last_stop_diagnostics,
            'updated_at':datetime.now().isoformat(timespec='seconds')})

    def _sleep(self,d):
        end=time.monotonic()+d
        while time.monotonic()<end:
            if self.stop_event.is_set():raise Cancelled('用户停止')
            time.sleep(min(.08,max(0,end-time.monotonic())))

    def _await_home(self):
        deadline=time.monotonic()+(5 if self.demo else 180)
        while time.monotonic()<deadline:
            if self.stop_event.is_set():raise Cancelled()
            s=self.tt.read();self.tt.validate_state(s)
            if self.tt.check_home(s):return
            time.sleep(.13)
        raise HardwareError('Gyro运行前双轴找零超时')

    def _await_position(self,outer,inner):
        deadline=time.monotonic()+(5 if self.demo else 120)
        previous=None;last_motion=time.monotonic()
        while time.monotonic()<deadline:
            if self.stop_event.is_set():raise Cancelled()
            s=self.tt.read();self.tt.validate_state(s)
            if self.tt.check_position(s,outer,inner):return s
            if previous is None or abs(circular_distance(s['outer'],previous['outer']))>.025 or abs(circular_distance(s['inner'],previous['inner']))>.025:
                last_motion=time.monotonic()
            previous=s
            if not self.demo and time.monotonic()-last_motion>12:
                raise HardwareError('预置姿态时转台12秒未运动；请检查控制状态')
            time.sleep(.13)
        raise HardwareError('预置姿态位置运动超时')

    def _position_for_case(self,case):
        # 严格先使外轴归0，再在外轴0°时改变内轴朝向，防止违反双轴负载姿态要求。
        s=self.tt.read();self.tt.validate_state(s)
        if abs(s['inner_speed'])>.05 or abs(s['outer_speed'])>.05:
            raise HardwareError('工况切换前转台尚未停车')
        if abs(circular_distance(s['outer'],0.))>.2:
            self.emit('预置：先将外轴返回0°，保持内轴当前位置')
            self.tt.position_commands(0.,s['inner'],self.position_speed)
            self._await_position(0.,s['inner'])
        s=self.tt.read()
        inner=case['inner_setup_deg']
        if abs(circular_distance(s['inner'],inner))>.2:
            self.emit(f'预置：外轴0°下将内轴调到{inner:g}°')
            self.tt.position_commands(0.,inner,self.position_speed)
            self._await_position(0.,inner)
        # Production gyro_rate_steps: X=(inner0,outer180), Y=(270,180), Z=(180,0).
        # Inner is repositioned ONLY with outer=0; the outer axis is moved last.
        outer=case['outer_setup_deg']
        s=self.tt.read()
        if abs(circular_distance(s['outer'],outer))>.2:
            self.emit(f'预置：保持内轴{inner:g}°，最后将外轴调整到{outer:g}°')
            self.tt.position_commands(outer,inner,self.position_speed)
            self._await_position(outer,inner)
        self._sleep(.01 if self.demo else self.settle)

    def _wait_stop(self,timeout=20,active_axis=None,commanded_rate=None,evidence=None):
        # 诊断增强：保留原来每轴<0.05°/s且连续0.5s的停车标准，不以位置到位标志替代速率反馈。
        t_stop=time.monotonic()
        end=t_stop+timeout;since=None
        last_report=0.0;last_state=None
        valid_stop_reads=0
        previous_valid_poll_seq=None
        last_feedback_position=None
        travel_after_stop={'inner':0.0,'outer':0.0}
        contradictory_reads=0
        # Modes from the supplied turntable manual; a rate-mode response is
        # not accepted as a confirmed STOP even if the speed temporarily reads 0.
        safe_modes={'空闲','静止','停止'}
        base_speed=abs(float(commanded_rate)) if commanded_rate is not None else None
        # 并不替代硬件保护；只用于尽早发现控制器持续维持原速。
        if active_axis not in ('inner','outer'): active_axis=None
        while time.monotonic()<end:
            s=self.tt.read();last_state=s
            if evidence is not None:
                evidence.snapshot(s)
            self.tt.validate_state(s,need_enabled=False)
            now=time.monotonic()
            # A newly completed DLL call is not proof that the controller sent
            # a new frame. Bound the host round-trip and inspect BOTH modes.
            # STOP 指令之后必须有后台线程产生的新轮询快照；旧缓存不作为停车成功证据。
            poll_seq=s.get('host_query_seq')
            stop_seq=getattr(self.tt,'last_stop_feedback_sequence',None)
            if not self.demo and stop_seq is not None and poll_seq is not None and int(poll_seq)<=int(stop_seq):
                time.sleep(.03)
                continue
            poll_age=float(s.get('host_poll_age_ms',0.))
            if not self.demo and (not math.isfinite(poll_age) or poll_age>750.):
                raise HardwareError(f'生产后台转台反馈已过期：{poll_age:.1f}ms')
            duration=float(s.get('read_duration_ms',0.0))
            if not math.isfinite(duration) or duration>750.0:
                raise HardwareError(f'转台反馈读取耗时异常：{duration!r}ms；'
                    '不能用此反馈确认停车，须核查机械状态')
            if not all(math.isfinite(float(s[k])) for k in ('inner','outer','inner_speed','outer_speed')):
                raise HardwareError('转台位置/速率反馈含非有限值，禁止停车确认')
            # Changes in host-observed positions are diagnostic evidence only.
            # An unchanged cache can NEVER establish standstill/freshness.
            if last_feedback_position is not None:
                delta_inner=abs(circular_distance(s['inner'],last_feedback_position[0]))
                delta_outer=abs(circular_distance(s['outer'],last_feedback_position[1]))
                travel_after_stop['inner']+=delta_inner
                travel_after_stop['outer']+=delta_outer
            last_feedback_position=(s['inner'],s['outer'])
            if active_axis is not None and base_speed is not None and base_speed >= 1.0 and not self.demo:
                # 理想1deg/s²减速2.5s会降低约2.5deg/s；给出宽裕门槛。
                # 若2.5秒后反馈仍至少为目标的90%，视为 STOP 未执行。
                # 避免再次无意义等待到20秒；提示立即使用独立硬件急停。
                if now-t_stop >= 2.5 and abs(s[active_axis+'_speed']) >= base_speed*.90:
                    raise HardwareError('STOP后2.5秒运动轴仍维持原速附近：'
                        f'{active_axis}反馈={s[active_axis+"_speed"]:+.4f}°/s、'
                        f'停前目标={commanded_rate:+.4f}°/s；可能未减速！'
                        '立即按现场规程使用硬件急停，禁止再发运动命令')
            both_slow=(abs(s['inner_speed'])<.05 and abs(s['outer_speed'])<.05)
            modes_stopped=(s.get('inner_mode') in safe_modes and s.get('outer_mode') in safe_modes)
            if both_slow and not modes_stopped:
                contradictory_reads+=1
                if contradictory_reads>=3 and not self.demo:
                    raise HardwareError('停车反馈矛盾：两轴速率接近0，但至少一个轴仍显示运动模式；'
                        '不可仅凭低速读数确认停车')
            else:
                contradictory_reads=0
            if both_slow and modes_stopped:
                # 同一后台数据快照重复 read 不能算多次独立反馈。
                if self.demo or poll_seq is None or poll_seq!=previous_valid_poll_seq:
                    valid_stop_reads+=1
                    previous_valid_poll_seq=poll_seq
                if since is None:since=now
                if self.demo or (now-since>=.5 and valid_stop_reads>=3):
                    self.emit('停车反馈确认：内轴={:+.4f}°/s〔{}〕，外轴={:+.4f}°/s〔{}〕；'
                              '连续读数{}次，主机确认窗口≥0.5秒。'
                              '注意：DLL未提供控制器帧计数，无法单凭软件证明反馈帧新鲜度。'.format(
                        s['inner_speed'],s.get('inner_mode'),s['outer_speed'],s.get('outer_mode'),valid_stop_reads))
                    return
            else:
                since=None;valid_stop_reads=0;previous_valid_poll_seq=None
            if now-last_report>=.5:
                last_report=now
                self.emit('停车反馈：内轴={:+.4f}°/s〔模式={}，位置={:.3f}°〕；外轴={:+.4f}°/s〔模式={}，位置={:.3f}°〕；'
                          'STOP后累计位置变化(内/外)={:.3f}/{:.3f}°，主机DLL读取耗时={:.1f}ms，'
                          '查询序号={}（非控制器帧号）'.format(
                    s['inner_speed'],s.get('inner_mode'),s['inner'],
                    s['outer_speed'],s.get('outer_mode'),s['outer'],
                    travel_after_stop['inner'],travel_after_stop['outer'],
                    duration,s.get('host_query_seq','未知')))
            time.sleep(.08)
        if last_state:
            s=last_state
            raise HardwareError(
                '速率停车后未确认双轴静止（内轴={:+.4f}°/s，外轴={:+.4f}°/s，'
                '内轴模式={}，外轴模式={}，内轴位置={:.3f}°，外轴位置={:.3f}°）；禁止下一工况'.format(
                    s['inner_speed'],s['outer_speed'],s.get('inner_mode'),
                    s.get('outer_mode'),s['inner'],s['outer']))
        raise HardwareError('速率停车后未取得有效双轴反馈，禁止下一工况')

    def _demo_frames(self,case):
        seed=2026+case['id']*7
        rng=np.random.default_rng(seed)
        o=case['target_rate_dps'] if case['axis']=='outer' else 0.
        i=case['target_rate_dps'] if case['axis']=='inner' else 0.
        reference=gyro_ref(case['inner_setup_deg'],o,i)
        raw=np.linalg.solve(self.cal.gyro_matrix,reference)+self.cal.gyro_bias
        frames=[]
        for ix in range(90):
            gs=raw+rng.normal(0,.045,(16,3))
            ac=rng.normal(0,.003,(16,3))+np.array([0,0,1])
            frames.append({'gyr_dps_arr':gs.tolist(),'acc_g_arr':ac.tolist(),
                'inner_deg':case['inner_setup_deg'],'outer_deg':0.,
                'inner_rate_dps':i,'outer_rate_dps':o,
                'temp_c':24.+rng.normal(0,.015),'elapsed_s':ix*.04})
        return frames

    def _capture_speed(self,case):
        if self.demo:
            self.tt.velocity_command(case['axis'],case['target_rate_dps'],self.acceleration)
            self.emit('演示：模拟速率命令及稳定匀速数据（不控制真实转台）')
            frames=self._demo_frames(case)
            self.tt.stop_axis(case['axis'], observer=lambda text:self.emit(text,'STOP'))
            self._wait_stop()
            self.stop_confirmed=True
            return frames
        self.stop_confirmed=False
        axis=case['axis'];target=case['target_rate_dps']
        accel=float(case.get('accel_dps2',self.acceleration))
        sample=float(case.get('sample_seconds',self.sample))
        if not (.05<=accel<=20. and 1.<=sample<=30.):
            raise HardwareError('当前工况采样时间或加速度超出配置允许范围')
        self.emit(f'当前工况控制参数：加速度={accel:g}°/s²；匀速有效采样={sample:g}s（计划参数，非设备能力保证）')
        other='inner' if axis=='outer' else 'outer'
        speed_tolerance=min(.3,max(.08,abs(target)*.04))
        frame_list=[];sensor_cfg=None
        evidence=StopEvidence(self.folder,case)
        self.imu.begin()
        start=time.monotonic();steady=None;travel=0.;last_ts=start
        # 运动开始后数据队列一直读取；只有反馈满足稳定门槛才记录用于指标的帧。
        try:
            self.tt.velocity_command(axis,target,accel)
            evidence.write('velocity_command',axis=axis,target_rate_dps=target,acceleration_dps2=accel,
                           note='DLL速率命令返回成功，不代表电机已达到设定速度')
            self.emit(f'速率指令已发送：{axis}={target:+g}°/s，等待稳定反馈')
            deadline=start+20+sample+8
            while time.monotonic()<deadline:
                if self.stop_event.is_set():raise Cancelled('操作员停止 Gyro 验证')
                s=self.tt.read();self.tt.validate_state(s)
                now=time.monotonic();dt=max(0,min(.5,now-last_ts));last_ts=now
                travel+=abs(s[axis+'_speed'])*dt
                if travel+abs(s[axis+'_speed'])**2/(2*accel)+10.>self.max_travel:
                    raise HardwareError('预计含减速的累计转角将超过单工况运动预算，提前停止；请缩短采样时间或调整工况')
                measured=s[axis+'_speed']
                good=(abs(measured-target)<=speed_tolerance and abs(s[other+'_speed'])<.08)
                if good:
                    if steady is None:steady=now
                else:
                    if steady is not None and frame_list:
                        raise HardwareError('采样期间转台匀速条件丢失')
                    steady=None
                stable=steady is not None and now-steady>=.5
                f=self.imu.get_frame()
                if f is not None and stable:
                    ts=float(f['monotonic_time_ns'])/1e9
                    if now-ts>min(.25,self.profile['quality']['feedback_age_max_ms']/1000):
                        raise HardwareError('IMU帧与转台反馈时间不一致/队列延迟超限')
                    if f.get('fifo_state',0)&0x0060:raise HardwareError('IMU FIFO溢出')
                    cfg=(int(f['acc_fs']),int(f['gyro_fs']),int(f.get('data_odr',0)))
                    if min(cfg[0],cfg[1])<=0:raise HardwareError('IMU量程字段无效')
                    if sensor_cfg is None:sensor_cfg=cfg
                    elif cfg!=sensor_cfg:raise HardwareError('采样期间量程/ODR发生变化')
                    frame_list.append({**f,'inner_deg':s['inner'],'outer_deg':s['outer'],
                        'inner_rate_dps':s['inner_speed'],'outer_rate_dps':s['outer_speed'],
                        'elapsed_s':now-steady})
                if stable and now-steady >=.5+sample:
                    break
                if steady is None and now-start>20:
                    raise HardwareError('20秒内未进入稳定匀速段；请检查速率反馈和控制模式')
                time.sleep(.004)
            else:
                raise HardwareError('等待稳定匀速采集超时')
            if self.imu.get_drop_count()>0:raise HardwareError('IMU专用队列丢帧，拒绝当前工况')
            return frame_list
        finally:
            # 别让停车确认异常覆盖前面更早发生的稳定段超时、丢帧等原始异常。
            original_error=sys.exc_info()[1]
            stop_error=None
            try:
                # Capture is diagnostic only: reading cannot be allowed to prevent STOP.
                try:
                    evidence.snapshot(self.tt.read(),event='before_stop',unique_poll=False)
                except Exception as read_exc:
                    evidence.write('before_stop_read_failed',reason=repr(read_exc))
                self.emit(f'采样段结束：仅对正在运动的{axis}轴下发STOP（原生产标定方式）')
                def stop_observer(text):
                    evidence.write('stop_dll_reply',message=text)
                    self.emit(text,'STOP')
                self.tt.stop_axis(axis,observer=stop_observer)
                evidence.write('stop_dispatch_complete',native_result=self.tt.last_stop_diagnostics[-1]
                               if self.tt.last_stop_diagnostics else None)
            except Exception as exc:
                stop_error=exc
                evidence.write('stop_dispatch_failed',reason=repr(exc),
                               native_result=self.tt.last_stop_diagnostics[-1]
                               if self.tt.last_stop_diagnostics else None)
                self.emit('停车指令下发异常：{}：{}'.format(type(exc).__name__,exc),'ERROR')
            try:
                self.imu.end()
            except Exception as exc:
                self.emit('关闭正式采样队列异常：{}：{}'.format(type(exc).__name__,exc),'ERROR')
                if stop_error is None:stop_error=exc
            try:
                self._wait_stop(active_axis=axis,commanded_rate=target,evidence=evidence)
                evidence.write('stop_feedback_confirmed',note='仅经主机后台轮询确认，未证明控制器底层帧新鲜度')
            except Exception as exc:
                evidence.write('stop_feedback_failed',reason=repr(exc))
                self.emit('停车确认异常：{}：{}'.format(type(exc).__name__,exc),'ERROR')
                if stop_error is None:stop_error=exc
            if stop_error is not None:
                self.stop_confirmed=False
                self.tt.latch_fault('工况停车未确认：'+str(stop_error))
                self.emit('严重安全警告：停车指令或停车确认失败；真实转台可能仍在旋转！'
                          '现场按设备规程执行硬件急停；软件禁止下一工况。','CRITICAL')
            else:
                self.stop_confirmed=True
            if evidence.error:
                self.emit('停车证据文件写入失败：'+evidence.error,'ERROR')
            evidence.write('final',stop_confirmed=self.stop_confirmed,
                           primary_error=repr(original_error) if original_error is not None else None,
                           stop_error=repr(stop_error) if stop_error is not None else None,
                           safety_fault_latched=self.tt.safety_fault_latched)
            if original_error is not None:
                self.emit('停车前已经发生的原始异常：{}：{}'.format(type(original_error).__name__, original_error),'ERROR')
            elif stop_error is not None:
                raise stop_error

    def _capture_zero(self):
        """在双轴零位且静止时复核 Gyro 校正零偏，使用原上位机 MAD 规则。"""
        self.emit(f'静态零偏复核：预计采集{self.zero_seconds:g}秒')
        if self.demo:
            rng=np.random.default_rng(20261026)
            zero=[]
            for j in range(100):
                raw=np.asarray(self.cal.gyro_bias)+rng.normal(0,.04,(16,3))
                zero.append({'gyr_dps_arr':raw.tolist(),'acc_g_arr':np.tile([0.,0.,1.],(16,1)).tolist(),
                    'inner_deg':0.,'outer_deg':0.,'inner_rate_dps':0.,'outer_rate_dps':0.,'temp_c':24.})
        else:
            self.imu.begin();zero=[];started=time.monotonic()
            try:
                while time.monotonic()-started<self.zero_seconds:
                    if self.stop_event.is_set():raise Cancelled('零偏验证被停止')
                    f=self.imu.get_frame()
                    if f is None:time.sleep(.008);continue
                    ts=float(f['monotonic_time_ns'])/1e9
                    if ts<started:continue
                    s=self.tt.read();self.tt.validate_state(s)
                    if not self.tt.check_position(s,0.,0.):raise HardwareError('零偏采样时两轴未稳定在零位')
                    if int(f.get('gyro_fs',0))<=0:raise HardwareError('Gyro量程标识无效')
                    zero.append({**f,'inner_deg':s['inner'],'outer_deg':s['outer'],
                        'inner_rate_dps':s['inner_speed'],'outer_rate_dps':s['outer_speed']})
                if self.imu.get_drop_count()>0:raise HardwareError('零偏采集期间IMU数据队列溢出')
            finally:self.imu.end()
        usable=[]
        for f in zero:
            raw,n,k=frame_average_sanitized(f['gyr_dps_arr'],self.profile['quality'].get('gyro_mad_sigma',6.),True)
            if raw is None:continue
            usable.append({'acc':[0.,0.,1.],'gyro':np.asarray(raw).tolist(),
                'acc_raw_samples':0,'acc_accepted_samples':0,'gyro_raw_samples':n,
                'gyro_accepted_samples':k,'inner_deg':f['inner_deg'],'outer_deg':f['outer_deg'],
                'inner_rate_dps':f['inner_rate_dps'],'outer_rate_dps':f['outer_rate_dps'],
                'temp_c':f['temp_c'],
                'sample_time_s':float(f['monotonic_time_ns'])/1e9 if 'monotonic_time_ns' in f else float(len(usable))*.04})
        # Always save the static observations before QC: rejected tests must be diagnosable.
        static_path=self.folder/'GYRO静态零偏逐帧诊断.csv'
        with static_path.open('w',newline='',encoding='utf-8-sig') as fp:
            writer=csv.writer(fp)
            writer.writerow(['单调时间s','原始GyroX°/s','原始GyroY°/s','原始GyroZ°/s',
                             '校正GyroX°/s','校正GyroY°/s','校正GyroZ°/s',
                             '内轴角度°','外轴角度°','内轴速度°/s','外轴速度°/s','温度°C'])
            for sample in usable:
                raw0=np.asarray(sample['gyro'],float)
                cal0=self.cal.gyro_matrix@(raw0-self.cal.gyro_bias)
                writer.writerow([sample['sample_time_s'],*raw0,*cal0,sample['inner_deg'],
                    sample['outer_deg'],sample['inner_rate_dps'],sample['outer_rate_dps'],sample['temp_c']])
        self.emit(f'GYRO静态逐帧诊断已保存：{static_path}；即使质控失败也保留')
        try:
            stat=robust_segment(usable,'static',self.profile,static_sensor='gyro',
                                expected_seconds=self.zero_seconds if not self.demo else None)
        except Exception as exc:
            self.emit('静态零偏质控未通过：{}；完整已处理逐帧数据保留在{}'.format(exc,static_path),'ERROR')
            raise
        raw=np.asarray(stat['gyro_raw_mean_dps'],float)
        corrected=self.cal.gyro_matrix@(raw-self.cal.gyro_bias)
        result={'raw_zero_xyz_dps':raw.tolist(),'cal_zero_xyz_dps':corrected.tolist(),
                'cal_zero_norm_dps':float(np.linalg.norm(corrected)),
                'accepted_frames':stat['accepted_frames'],'received_frames':len(zero),
                'temperature_c':stat['temperature_mean_c'],'gyro_std_dps':stat['gyro_std_dps'],
                'gyro_zero_quality':stat.get('gyro_zero_quality')}
        self.zero_result=result;self._checkpoint()
        qc=stat.get('gyro_zero_quality') or {}
        if qc.get('noise_warning'):
            self.emit('静态GYRO噪声超过试运行预警线，但通过了原标定硬上限、时间窗均值漂移和不确定度检查；仅做噪声预警，不代表出厂合格', 'WARN')
        self.emit('零偏复核完成：校正后零速模长 {:.5f}°/s，有效帧{}'.format(
            result['cal_zero_norm_dps'],result['accepted_frames']))

    def _save_case_frames(self,case,frames):
        folder=self.folder/'动态采样记录';folder.mkdir(exist_ok=True)
        p=folder/f"工况_{case['id']:03d}_{case['direction']}_{case['target_rate_dps']:+g}.csv"
        with p.open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f)
            w.writerow(['时间s','转台参考X°/s','参考Y°/s','参考Z°/s',
                        '原始GyroX°/s','原始GyroY°/s','原始GyroZ°/s',
                        '校正GyroX°/s','校正GyroY°/s','校正GyroZ°/s','温度°C'])
            for x in frames:
                raw,_,_=frame_average_sanitized(x['gyr_dps_arr'],
                    self.profile['quality'].get('gyro_mad_sigma',6),True)
                if raw is None:continue
                cal=self.cal.gyro_matrix@(np.asarray(raw)-self.cal.gyro_bias)
                ref=gyro_ref(x['inner_deg'],x['outer_rate_dps'],x['inner_rate_dps'])
                w.writerow([x.get('elapsed_s'),*ref,*raw,*cal,x['temp_c']])
        return p

    def run(self):
        try:
            self.tt.require_motion_authorized()
            if not(self.tt.connected and self.tt.enabled and self.imu.connected):
                raise HardwareError('Gyro验证开始前需要连接转台/IMU并使能双轴')
            limit=float(self.profile.get('rates',{}).get('maximum_command_rate_dps',10.))
            max_rate=max(abs(c['target_rate_dps']) for c in self.cases)
            if not self.demo and max_rate>60.:
                raise HardwareError('速率超出2TD-600手册60°/s上限')
            if not self.demo and max_rate>limit and not self.high_speed_approved:
                raise HardwareError(f'工程原限速为{limit:g}°/s；高速工况需要操作者明确确认')
            if max_rate>limit:
                self.emit('高于既有工艺10°/s：现场确认仅是操作授权，不构成STOP可靠性或转台速率计量精度证明','WARN')
            self.emit(f'开始Gyro动态独立验证：{len(self.cases)}组，最大速率{max_rate:g}°/s')
            self.state='回零确认';self.events('status',self.state)
            if self.home_before_run:
                self.tt.home_commands(self.stop_event);self._await_home()
            else:
                s=self.tt.read();self.tt.validate_state(s)
                if not self.tt.check_home(s):
                    raise HardwareError('实验启动前未确认双轴零位，不能跳过手动找零')
                self.emit('复用当前转台会话：已确认双轴手动找零并处于0°；不重复找零')
            self._capture_zero()
            for case in self.cases:
                self.stop_confirmed=False
                if self.stop_event.is_set():raise Cancelled('用户停止')
                idx=case['id'];self.events('pose',(idx,case));self.state=f'工况{idx}/{len(self.cases)}'
                self.events('status',self.state)
                self.emit(f'工况{idx}/{len(self.cases)}：{case["direction"]}轴 {case["target_rate_dps"]:+g}°/s，第{case["repeat"]}次')
                self._position_for_case(case)
                frames=self._capture_speed(case)
                # Save the acquired steady-state frames before calculating metrics.
                # Reporting errors must never silently discard a finished capture.
                saved_path=self._save_case_frames(case,frames)
                self.emit(f'工况{idx}稳定段采样已先行保存：{saved_path}')
                summary=summarize_rate(frames,self.cal,self.profile,case)
                summary['sample_csv']=str(saved_path)
                self.rows.append(summary);self._checkpoint()
                self.emit(f'完成工况{idx}：实测速率={summary["actual_"+case["axis"]+"_rate_dps"]:.3f}°/s，'
                    f'主轴绝对误差={summary["main_axis_absolute_error_dps"]:.4f}°/s；'
                    f'有效帧数={summary["accepted_frames"]}；'
                    f'动态STD原始/校正后最大={max(summary["gyro_std_dps"]):.4f}/'
                    f'{max(summary["gyro_calibrated_std_dps"]):.4f}°/s')
                self.events('progress',(idx,len(self.cases)))
            self.completed=True;self.state='完成'
            self.emit('Gyro动态验证全部完成，可保存Excel与曲线')
        except Cancelled as exc:
            self.state='人工停止';self.emit(f'{exc}','WARN')
        except Exception as exc:
            self.state='失败';self.failed.append({'case':len(self.rows)+1,'reason':str(exc)})
            self.emit(f'Gyro工况失败，停止后续运动：{type(exc).__name__}：{exc}','ERROR')
        finally:
            if not self.demo and HARDWARE_MOTION_LOCKED:
                # Important: zero motion was allowed. Never touch the DLL when
                # run() is accidentally invoked with this diagnostic build.
                self.emit('诊断版硬件运动锁定：没有执行真实运动或停车指令。','WARN')
            elif self.tt.safety_fault_latched:
                # Previous stop has already failed. Never hide the fault by
                # claiming 'done'; don't spend another 15s silently retrying.
                self.completed=False
                self.state='安全锁定：停车未确认'
                self.emit('严重安全警告：上一次停车未确认，禁止发送后续运动！'
                          '软件状态不是机械静止证明，须按现场规程检查硬件急停。','CRITICAL')
            elif not self.stop_confirmed:
                try:
                    self.emit('结束前停车检查：发送双轴停车指令并核实反馈')
                    self.tt.stop(observer=lambda text:self.emit(text,'STOP'))
                    self._wait_stop()
                    self.stop_confirmed=True
                except Exception as exc:
                    self.tt.latch_fault('任务结束停车未确认：'+str(exc))
                    self.completed=False
                    self.state='安全锁定：停车未确认'
                    self.emit('严重安全警告：停车失败；设备可能仍在运动！'
                              '请依现场规程使用硬件急停。'+str(exc),'CRITICAL')
            self._checkpoint()
            self.events('done',(self.completed,self.state,str(self.folder)))
