# -*- coding: utf-8 -*-
"""Offline reference projection regression; NEVER touches the real turntable."""
import numpy as np
from vendor.production_calibration import robust_segment, load_profile
from pathlib import Path

profile=load_profile(Path(__file__).parent/'vendor')
def generate_case(degs, speed, axis='outer'):
    frames=[]
    for i,deg in enumerate(degs):
        frames.append({'acc':[0,0,1], 'gyro':[0,0,0],
            'inner_deg':float(deg), 'outer_deg':180.,
            'inner_rate_dps':float(speed) if axis=='inner' else 0.,
            'outer_rate_dps':float(speed) if axis=='outer' else 0.,
            'temp_c':25., 'sample_time_s':i*.02})
    return robust_segment(frames,'rate',profile,axis=axis,target_rate=speed)

for speed,deg,expected in [(10.,np.array([360.]*154+[0.]*96),[10.,0.,0.]),
                           (-10.,np.array([360.]*91+[0.]*160),[-10.,0.,0.]),
                           (10.,np.full(250,270.),[0.,10.,0.])]:
    result=generate_case(deg,speed)
    got=np.asarray(result['rate_reference_xyz_dps'])
    assert np.allclose(got,expected,atol=1e-7),(got,expected)
    assert abs(((result['inner_actual_mean_deg']-deg[0]+180)%360)-180)<1e-7
print('PASS: 0/360 wrap and Y-axis projection')
