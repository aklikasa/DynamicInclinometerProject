# -*- coding: utf-8 -*-
"""独立硬件适配：只复用厂商已有接口，不会悄悄打开串口/使能/运动。"""
import os
import sys
import time
import threading
import math
import queue
from pathlib import Path
from core import circular_distance
from safety_gate import LIVE_AUTHORIZED, AUTH_MESSAGE, LIVE_PERMIT, persist_stop_fault

VENDOR = Path(__file__).resolve().parent / 'vendor'
for sub in ('debug','tilt_sensor','turntable'):
    sys.path.insert(0, str(VENDOR/sub))

class HardwareError(RuntimeError): pass

# 现场许可与故障锁由 safety_gate.py 判定；不能将其视为硬件急停。
HARDWARE_MOTION_LOCKED = not LIVE_AUTHORIZED

class Turntable:
    def __init__(self, demo=False):
        self.demo=demo; self.connected=False; self.enabled=False
        self.lock=threading.RLock(); self._pos=[0.,0.]
        self._homed=False; self._t0=time.monotonic()
        self.m=None;self._demo_rate=None
        self.production_feedback=None;self._last_production_record=None
        self._last_poll_seq=0;self.last_stop_feedback_sequence=None
        self.safety_fault_latched=False
        self.safety_fault_reason=''
        self.last_stop_diagnostics=[]
        self._feedback_query_sequence=0  # host-side query counter only; NOT controller frame counter
        self._live_authorized=(not demo and LIVE_AUTHORIZED)
        self.initial_feedback_ready=False

    def latch_fault(self, reason):
        self.safety_fault_latched=True
        self.safety_fault_reason=str(reason)
        if self._live_authorized:
            try: persist_stop_fault(reason)
            except Exception as exc:
                self.safety_fault_reason += '; 故障锁写入失败：'+str(exc)

    def require_motion_authorized(self):
        if self.safety_fault_latched:
            raise HardwareError('安全锁定：'+self.safety_fault_reason+'；禁止进一步运动')
        if not self.demo and HARDWARE_MOTION_LOCKED:
            raise HardwareError('真实运动未授权：'+AUTH_MESSAGE+'。请保持停机，勿直接修改代码绕过门控。')

    def open(self, port, original_calibration_startup=False):
        import re
        m=re.fullmatch(r'COM(\d+)',port.upper().strip())
        if not m:raise HardwareError('无效转台串口')
        if self.demo:self.connected=True;self.initial_feedback_ready=True;return
        self.initial_feedback_ready=False
        self._last_production_record=None
        self._last_poll_seq=0
        if os.name!='nt':raise HardwareError('2TD600.dll 仅支持 Windows x64')
        if self.connected:raise HardwareError('请先关闭当前转台串口')
        # DLL 按路径定位，不依赖 cwd；原V1.1接口和OpenPort参数完全不变。
        try:
            import turntable_2TD600_comm as mcomm
        except (ImportError, OSError) as exc:
            raise HardwareError('加载2TD600.dll或通信模块失败：{}；请检查DLL是否存在、Python是否64位和依赖DLL'.format(exc)) from exc
        with self.lock:
            try:
                accepted=mcomm.twoTD600_openPort(int(m.group(1)),115200)
            except Exception as exc:
                raise HardwareError('2TD600 OpenPort({},115200)调用异常：{}。检查DLL、端口、驱动和其他程序占用。'.format(port,exc)) from exc
            if not accepted:
                raise HardwareError('2TD600 OpenPort({},115200)返回0（连接失败）。常见原因：端口被旧版软件/原装软件占用、所选COM号不正确、驱动或线缆异常；需要根据连接诊断和Windows设备管理器继续排查。'.format(port))
            self.m=mcomm; self.connected=True
        # 真实运动时：严格复用原上位机的启动顺序：OpenPort -> 内轴使能 -> 等待100ms -> 外轴使能 -> 等待500ms -> 启动轮询。
        # 这个顺序不同于先轮询/状态检查、再调用 enable() 的前几版独立验证程序。
        # 只读预检 original_calibration_startup=False 时绝不发送使能命令。
        if original_calibration_startup:
            self.require_motion_authorized()
            try:
                with self.lock:
                    if not self.m.twoTD600_SetAxisEnable(0):
                        raise HardwareError('原标定使能顺序：内轴 SetAxisEnable(0) 返回失败')
                    time.sleep(0.1)
                    if not self.m.twoTD600_SetAxisEnable(2):
                        raise HardwareError('原标定使能顺序：外轴 SetAxisEnable(2) 返回失败')
                time.sleep(0.5)
                self.enabled=True
            except BaseException:
                # 可能发生部分使能，不得假设两轴均失能或已停止。
                self.latch_fault('按原标定连接后使能遇到异常，驱动状态可能不一致，需现场核查')
                raise
        # 原生产标定工程的转台后台轮询 + 同一 DLL 通信锁；不改变标定矩阵/算法。
        try:
            import production_2td600_feedback as fb
            if fb.turntableComm.thread_instance is not None:
                raise HardwareError('生产反馈轮询线程已存在，拒绝重复打开')
            fb.turntableComm.terminate_thread_requst=False
            fb.turntableData.is_turntable_data_available=False
            fb.turntableData.last_update_monotonic_ns=0
            fb.turntable_feedback_queue_set(True,clear=True)
            self.production_feedback=fb
            self.lock=fb.turntableComm.thread_lock
            fb.thread_of_turntable_data_get_create_and_start('2TD600')
            initial=time.monotonic()+3.0
            while time.monotonic()<initial:
                try:
                    self.read()
                    break
                except HardwareError:
                    time.sleep(.04)
            else:
                raise HardwareError('生产后台反馈3秒内未获得有效完整轮询，禁止使能或运动')
        except Exception:
            if self.production_feedback is not None:
                self.production_feedback.turntableComm.terminate_thread_requst=True
            # 当前程序不能假设 DLL 调用已经结束；失败时优先留在安全锁定状态。
            self.latch_fault('生产后台反馈初始化失败，需现场确认通信状态')
            raise

    def close(self):
        """Close only after independently checking both disable flags and stop state.

        Never send more motion/disable commands during disconnect. Retain connection
        bookkeeping on failed ClosePort, rather than claiming a successful release.
        """
        if not self.connected:return
        if self.enabled:raise HardwareError('请先确认两轴停车并解除使能')
        if not self.demo:
            s=self.read()
            if s['inner_enabled'] or s['outer_enabled']:
                raise HardwareError('真实反馈仍显示至少一轴使能，禁止关闭转台连接')
            if any(abs(s[a+'_speed']) >= .05 or s[a+'_mode'] not in ('静止','停止','空闲')
                   for a in ('inner','outer')):
                raise HardwareError('存在运动反馈，不允许关闭转台；请先完成独立停车确认')
            fb=self.production_feedback
            if fb is not None:
                fb.turntable_feedback_queue_set(False,clear=True)
                fb.turntableComm.terminate_thread_requst=True
                thread=fb.turntableComm.thread_instance
                if thread is not None and thread.is_alive():
                    thread.join(timeout=3.0)
                    if thread.is_alive():
                        self.latch_fault('DLL后台轮询未退出，不允许关闭仍被使用的DLL串口句柄')
                        raise HardwareError('转台后台采集没有退出，保留COM连接；禁止强制关闭DLL句柄')
            # The original working calibration stopped polling before ClosePort;
            # don't falsely report disconnected if the DLL call throws.
            time.sleep(.1)
            try:
                with self.lock:
                    self.m.twoTD600_closePort()
            except Exception as exc:
                raise HardwareError('调用ClosePort发生异常，真实COM连接状态未知；'
                                    '未标记断开，请现场核查，不要反复点击：'+str(exc)) from exc
            self.production_feedback=None
        self.connected=False;self.enabled=False;self._homed=False
        self.initial_feedback_ready=False
        self._last_production_record=None
        self._last_poll_seq=0

    def read(self):
        if not self.connected:raise HardwareError('转台串口未打开')
        if self.demo:
            ds=self._demo_rate
            inner_rate=ds[1] if ds and ds[0]=='inner' else 0.
            outer_rate=ds[1] if ds and ds[0]=='outer' else 0.
            return {'inner':self._pos[1],'outer':self._pos[0], 'inner_speed':inner_rate, 'outer_speed':outer_rate,
                    'inner_enabled':self.enabled,'outer_enabled':self.enabled,
                    'inner_homed':self._homed,'outer_homed':self._homed,
                    'inner_in_place':True,'outer_in_place':True,'inner_normal':True,'outer_normal':True,
                    'inner_up_limit':False,'inner_down_limit':False,'outer_up_limit':False,'outer_down_limit':False,
                    'inner_over_speed':False,'outer_over_speed':False,'inner_over_diff':False,'outer_over_diff':False,
                    'inner_driver_fault':False,'outer_driver_fault':False,
                    'inner_over_voltage':False,'outer_over_voltage':False,
                    'inner_mode':'静止','outer_mode':'静止','inner_locked':False,'outer_locked':False,
                    'time':time.monotonic(), 'read_duration_ms':0.0,
                    'host_query_seq':self._feedback_query_sequence,
                    'controller_frame_freshness_verified':False}
        # 使用原生产程序后台轮询产生的完整快照，而非本线程直接调用几十个DLL getter。
        fb=self.production_feedback
        if fb is None or fb.turntableComm.thread_instance is None or not fb.turntableComm.thread_instance.is_alive():
            raise HardwareError('生产转台后台反馈线程未运行；禁止继续运动')
        started=time.monotonic()
        latest=None
        while True:
            try:latest=fb.turntable_feedback_get_nowait()
            except queue.Empty:break
        if latest is not None:self._last_production_record=latest
        rec=self._last_production_record
        if rec is None:raise HardwareError('尚无有效的生产后台反馈，禁止判断转台状态')
        monotonic_ns=int(rec.get('monotonic_time_ns',0))
        age=(time.perf_counter_ns()-monotonic_ns)/1e9 if monotonic_ns else float('inf')
        if age<0 or age>0.75:
            raise HardwareError(f'生产转台反馈超过0.75秒未更新：{age:.3f}s；禁止运动或停车确认')
        flags=('enabled','homed','in_place','normal','up_limit','down_limit',
               'over_speed','over_diff','driver_fault','over_voltage','locked')
        state={'inner':float(rec['inner_position_deg']), 'outer':float(rec['outer_position_deg']),
               'inner_speed':float(rec['inner_speed_dps']), 'outer_speed':float(rec['outer_speed_dps']),
               'inner_mode':rec['inner_run_mode'], 'outer_mode':rec['outer_run_mode']}
        for axis in ('inner','outer'):
            for flag in flags:
                source={'enabled':'enable','homed':'find_zero'}.get(flag,flag)
                state[f'{axis}_{flag}']=bool(rec.get(f'{axis}_{source}',False))
        # 这里是生产轮询的主机时间/更新计数，不是控制器内部帧计数。
        self._last_poll_seq=int(rec['update_count'])
        state.update(time=time.monotonic(),read_duration_ms=(time.monotonic()-started)*1000.,
            host_query_seq=self._last_poll_seq,host_poll_age_ms=age*1000,
            controller_frame_freshness_verified=False,
            feedback_queue_dropped=fb.turntable_feedback_queue_drop_count_get())
        if state['feedback_queue_dropped']:
            raise HardwareError('生产反馈队列发生丢包，拒绝继续自动验证')
        for key in ('inner','outer','inner_speed','outer_speed'):
            if not math.isfinite(state[key]):
                raise HardwareError(f'生产转台反馈非有限值：{key}={state[key]}')
        return state

    def wait_initial_state_ready(self, timeout=4.0, good_polls=3, min_span_s=0.20,
                                 require_stationary=True, observer=None):
        """连接后启动状态确认：先等不同主机轮询中的有效状态，再执行后续操作。

        仅校验主机轮询计数（不是控制器帧号），不能替代原厂动态STOP验收。
        不要求轴使能或本次回零；这两项和正常标志在协议中是不同状态位。
        持续正常标志为False时不放行；出现明确报警/运动立即拒绝。
        """
        if not self.connected:
            raise HardwareError('转台串口尚未连接，无法检查初始反馈')
        if self.demo:
            self.initial_feedback_ready=True
            return self.read()
        safe_modes={'空闲','静止','停止'}
        alarm_keys=('up_limit','down_limit','over_speed','over_diff','driver_fault','over_voltage')
        deadline=time.monotonic()+float(timeout)
        good=0;since=None;last_seq=None;last_seen='尚无反馈'
        self.initial_feedback_ready=False
        while time.monotonic()<deadline:
            try:
                s=self.read()
            except HardwareError as exc:
                # 初始化阶段仅允许等待“尚无有效快照”；反馈超时、线程退出、数据非法均直接拒绝。
                if '尚无有效的生产后台反馈' not in str(exc):
                    raise
                last_seen=str(exc)
                time.sleep(.04)
                continue
            seq=s.get('host_query_seq')
            if not isinstance(seq,int) or seq<=0:
                raise HardwareError('启动轮询序号无效，禁止信任状态')
            if last_seq is not None:
                if seq<last_seq:
                    raise HardwareError('启动主机轮询序号倒退，拒绝后续操作')
                if seq==last_seq:
                    time.sleep(.04)
                    continue
            last_seq=seq
            if s.get('feedback_queue_dropped',0):
                raise HardwareError('启动轮询队列发生丢包，拒绝后续操作')
            for axis in ('inner','outer'):
                for alarm in alarm_keys:
                    if s.get(f'{axis}_{alarm}'):
                        raise HardwareError(f'初始化时{axis}轴真实报警：{alarm}，禁止操作')
            if require_stationary:
                for axis in ('inner','outer'):
                    if abs(float(s[f'{axis}_speed']))>=.05 or s[f'{axis}_mode'] not in safe_modes:
                        raise HardwareError(f'初始化时{axis}轴不是静止状态：'
                            f'速度={s[f"{axis}_speed"]:+.4f}°/s，模式={s[f"{axis}_mode"]}；拒绝操作')
            if not (s.get('inner_normal') and s.get('outer_normal')):
                last_seen=(f'轮询={seq}，内轴正常={s.get("inner_normal")}，'
                           f'外轴正常={s.get("outer_normal")}；可能初始反馈未就绪')
                good=0;since=None
            else:
                if since is None:since=time.monotonic()
                good+=1
                if good>=int(good_polls) and time.monotonic()-since>=float(min_span_s):
                    self.initial_feedback_ready=True
                    if observer:
                        observer(f'初始化状态通过：{good}次不同主机轮询、持续'
                            f'{time.monotonic()-since:.2f}s，当前序号={seq}；'
                            '未证明控制器帧计数更新，且没有执行使能/找零/运动')
                    return s
                last_seen=f'有效状态累计{good}次，主机序号={seq}，等待稳定观察窗口'
            time.sleep(.04)
        raise HardwareError('转台初始反馈未完成可靠确认：'+last_seen+
            '；拒绝STOP/使能/运动诊断。可通过只读状态工具检查控制器报警')

    @staticmethod
    def validate_state(s, need_enabled=True):
        for axis in ('inner','outer'):
            if need_enabled and not s[f'{axis}_enabled']:
                raise HardwareError(f'{axis} 未使能')
            if not s[f'{axis}_normal']:
                raise HardwareError(f'{axis} 驱动状态异常')
            for f in ('up_limit','down_limit','over_speed','over_diff','driver_fault','over_voltage'):
                if s[f'{axis}_{f}']:raise HardwareError(f'{axis} 报警：{f}')

    def _pause_feedback_for_original_calibration_command(self):
        """Quiesce DLL polling while keeping the existing COM port open.

        Original calibration issued enable/disable commands without a competing
        reader.  Manual GUI connect is read-only, so we reproduce that command
        phase by pausing polling, not by opening the COM port for a second time.
        """
        if self.demo:
            return
        fb=self.production_feedback
        if fb is None:
            raise HardwareError('没有已初始化的转台反馈服务')
        thread=fb.turntableComm.thread_instance
        if thread is None or not thread.is_alive():
            self.latch_fault('无法正常暂停转台轮询；连接状态待现场核查')
            raise HardwareError('轮询线程不在运行，不能安全执行使能/解除使能')
        fb.turntable_feedback_queue_set(False,clear=True)
        fb.turntableComm.terminate_thread_requst=True
        thread.join(timeout=3.0)
        if thread.is_alive():
            self.latch_fault('转台轮询不能停止，禁止与DLL并发发送控制指令')
            raise HardwareError('转台后台查询无法退出；没有发送使能或解除使能命令')
        self._last_production_record=None
        self.initial_feedback_ready=False

    def _restart_feedback_after_original_calibration_command(self):
        if self.demo:
            return
        fb=self.production_feedback
        if fb is None:
            raise HardwareError('转台反馈模块已丢失，禁止操作')
        if fb.turntableComm.thread_instance is not None:
            raise HardwareError('旧的轮询线程尚未释放，不能重复创建')
        fb.turntableComm.terminate_thread_requst=False
        fb.turntableData.is_turntable_data_available=False
        fb.turntableData.last_update_monotonic_ns=0
        fb.turntable_feedback_queue_set(True,clear=True)
        self._last_production_record=None
        fb.thread_of_turntable_data_get_create_and_start('2TD600')
        self.wait_initial_state_ready(timeout=5.,require_stationary=True)

    def _wait_enabled_flags(self, expected, timeout=5.):
        """Only fresh, distinct host polls count; host polls are not controller sequence IDs."""
        deadline=time.monotonic()+timeout
        last_seq=None; count=0; latest=None
        while time.monotonic()<deadline:
            latest=self.read()
            seq=latest.get('host_query_seq')
            if seq==last_seq:
                time.sleep(.06)
                continue
            last_seq=seq
            matches=all(bool(latest[a+'_enabled'])==bool(expected) for a in ('inner','outer'))
            if matches:
                count+=1
                if count>=3:
                    return latest
            else:
                count=0
            time.sleep(.06)
        summary=('无反馈' if latest is None else
            f'内轴使能={latest["inner_enabled"]}，外轴使能={latest["outer_enabled"]}')
        raise HardwareError(f'转台使能反馈未达到预期({expected})：{summary}；不能据DLL命令返回推断驱动器状态')

    def enable(self):
        """Preserve manual button while mirroring the original calibration command order.

        No automatic enable on connect.  Once the operator presses enable, stop
        the reader, issue axis 0 -> wait .1 s -> axis 2 -> wait .5 s, resume
        reading and confirm each axis on fresh host polls.
        """
        self.require_motion_authorized()
        if not self.connected:
            raise HardwareError('转台未连接')
        if self.demo:
            self.enabled=True
            return
        state=self.wait_initial_state_ready(require_stationary=True)
        self.validate_state(state,need_enabled=False)
        if state['inner_enabled'] and state['outer_enabled']:
            self.enabled=True
            return
        self._pause_feedback_for_original_calibration_command()
        command_error=None
        try:
            with self.lock:
                for id_,name in ((0,'inner'),(2,'outer')):
                    # Prevent a repeat enable command on a partially enabled axis.
                    if not state[name+'_enabled']:
                        if not self.m.twoTD600_SetAxisEnable(id_):
                            raise HardwareError(f'{name} SetAxisEnable({id_}) 返回失败')
                    if id_==0:
                        time.sleep(.1)
            time.sleep(.5)
        except Exception as exc:
            command_error=exc
        try:
            self._restart_feedback_after_original_calibration_command()
            s=self.read()
            self.enabled=bool(s['inner_enabled'] or s['outer_enabled'])
            if command_error is None:
                self._wait_enabled_flags(True)
                self.enabled=True
        except Exception as exc:
            self.latch_fault('使能后未能重新建立可靠反馈：'+str(exc))
            raise
        if command_error is not None:
            raise HardwareError('使能指令有异常，已恢复状态轮询但可能部分使能：'+str(command_error))

    def disable(self):
        """Original calibration axis order and 0.1-s spacing; confirm feedback before updating flags."""
        if not self.connected:
            return
        state=self.wait_initial_state_ready(require_stationary=True)
        self.validate_state(state,need_enabled=False)
        if any(abs(state[a+'_speed'])>.05 for a in ('inner','outer')):
            raise HardwareError('两轴未静止，禁止解除使能')
        if self.demo:
            self.enabled=False
            return
        if not (state['inner_enabled'] or state['outer_enabled']):
            self.enabled=False
            return
        self._pause_feedback_for_original_calibration_command()
        command_errors=[]
        try:
            with self.lock:
                for id_,name in ((0,'inner'),(2,'outer')):
                    if state[name+'_enabled']:
                        try:
                            if not self.m.twoTD600_SetAxisDisable(id_):
                                command_errors.append(f'{name} SetAxisDisable 返回失败')
                        except Exception as exc:
                            command_errors.append(f'{name} SetAxisDisable 异常：{exc}')
                    if id_==0:
                        time.sleep(.1)
        finally:
            # Even if a command fails, restore feedback; never claim disabled by assumption.
            try:
                self._restart_feedback_after_original_calibration_command()
            except Exception as exc:
                self.enabled=True
                self.latch_fault('解除使能后反馈无法恢复：'+str(exc))
                raise
        latest=self.read()
        self.enabled=bool(latest['inner_enabled'] or latest['outer_enabled'])
        if command_errors:
            raise HardwareError('解除使能指令存在异常：'+'；'.join(command_errors)+
                                f'；当前内轴={latest["inner_enabled"]}外轴={latest["outer_enabled"]}')
        # Do not update self.enabled=False until actual fresh status says both disabled.
        try:
            self._wait_enabled_flags(False)
            self.enabled=False
        except HardwareError:
            latest=self.read()
            self.enabled=bool(latest['inner_enabled'] or latest['outer_enabled'])
            raise

    def stop_axis(self, axis, observer=None):
        """Normal production-calibration stopping: only the moving axis.

        DLL success is *not* a physical stop confirmation. This API records
        a command result only; feedback must be checked by the caller.
        This method does NOT override the hardware motion lock.
        """
        names = {'inner': (0, 'inner'), 'outer': (2, 'outer'),
                 0: (0, 'inner'), 2: (2, 'outer')}
        if axis not in names:
            raise HardwareError('停车轴必须是 inner/outer 或 0/2')
        axis_id, name = names[axis]
        if not self.connected:
            raise HardwareError('转台未连接，无法通过软件请求停车；需要现场核查物理状态')
        if self.demo:
            if self._demo_rate and self._demo_rate[0] == name:
                self._demo_rate = None
            if observer:
                observer(f'模拟单轴停车：axis={axis_id}({name})，未调用任何DLL')
            return True
        if self.m is None:
            raise HardwareError('转台DLL句柄无效，无法发送停车命令')
        self.last_stop_feedback_sequence=self._last_poll_seq if not self.demo else None
        started = time.monotonic()
        timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
        try:
            with self.lock:
                # 已知厂家包装将原生 c_int 返回值转换为 bool。
                # 优先调用独立包装新增的 Raw 接口，使日志保留真正的返回码。
                native = getattr(self.m, 'twoTD600_SetAxisStopRaw', None)
                if native is not None:
                    raw = native(axis_id)
                    origin='原生DLL返回码'
                    ok = (raw == 1)
                else:
                    raw = self.m.twoTD600_SetAxisStop(axis_id)
                    origin='Python包装返回值(测试替身)'
                    ok = (raw is True or raw == 1)
            msg = (f'STOP指令 {timestamp} axis={axis_id}({name}), {origin}={raw!r}, '
                   f'调用耗时={(time.monotonic()-started)*1000:.1f}ms；仅代表接口返回，不代表机械已停止')
        except Exception as exc:
            raw = None
            ok = False
            msg = (f'STOP调用异常 {timestamp} axis={axis_id}({name}), '
                   f'{type(exc).__name__}: {exc}, 耗时={(time.monotonic()-started)*1000:.1f}ms')
        self.last_stop_diagnostics.append({'axis':axis_id,'name':name,'raw':repr(raw),'origin':locals().get('origin','exception'),
                                           'ok':ok,'timestamp':timestamp,'message':msg})
        if observer:
            try: observer(msg)
            except Exception: pass
        if not ok:
            self.latch_fault(f'轴{name}的STOP接口返回失败或抛出异常')
            raise HardwareError(f'轴{name}的STOP接口失败：{msg}；不可认为转台已静止')
        return True

    def stop(self, observer=None):
        """Fault/abort path: attempt both axes, even if the first fails.

        This is NOT the normal completion path. With real hardware the DLL may
        block and this is not a hardware E-stop; the operator must retain an
        independent physical emergency-stop path.
        """
        if not self.connected:
            raise HardwareError('转台未连接，软件不能发送停车命令；检查物理安全状态')
        if self.demo:
            self._demo_rate = None
            if observer: observer('模拟双轴停车：未调用真实DLL')
            return {'inner':True,'outer':True}
        if self.m is None:
            raise HardwareError('转台DLL句柄无效，无法发送停车命令')
        self.last_stop_diagnostics=[]
        results={}
        for idx,name in enumerate(('inner','outer')):
            if idx: time.sleep(.1)  # DIAGNOSTIC variant; not established as root cause
            try:
                results[name] = bool(self.stop_axis(name, observer=observer))
            except Exception:
                results[name] = False
        if not all(results.values()):
            reason=f'停车接口至少一个轴失败，原始结果={results!r}'
            self.latch_fault(reason)
            raise HardwareError(reason+'；检查物理安全状态，禁止后续运动')
        return results

    def home_commands(self, stop_event=None):
        """原标定：逐轴找零、确认静止后再对零位；避免同时找零。"""
        self.require_motion_authorized()
        state=self.read();self.validate_state(state)
        if self.demo:
            self._pos=[0.,0.];self._homed=True
            return
        if max(abs(state['inner_speed']),abs(state['outer_speed']))>.05:
            raise HardwareError('逐轴回零开始前两轴必须先静止')
        safe_modes={'空闲','静止','停止'}
        for axis_id,axis in ((0,'inner'),(2,'outer')):
            state=self.read()
            if not state[f'{axis}_homed']:
                with self.lock:
                    ok=self.m.twoTD600_SetAxisFindZero(axis_id,2,2)
                if not ok:
                    raise HardwareError(f'{axis}找零指令返回失败')
            start=time.monotonic();since=None
            while time.monotonic()-start<180.:
                if stop_event is not None and stop_event.is_set():
                    raise HardwareError(f'{axis}找零过程中收到停止请求，退出并请求停车')
                state=self.read();self.validate_state(state)
                stopped=(abs(state['inner_speed'])<.05 and abs(state['outer_speed'])<.05
                         and state['inner_mode'] in safe_modes and state['outer_mode'] in safe_modes)
                if state[f'{axis}_homed'] and stopped:
                    if since is None:since=time.monotonic()
                    if time.monotonic()-since>=.5:break
                else:since=None
                time.sleep(.08)
            else:
                raise HardwareError(f'{axis}找零180秒未获确认；禁止继续下一轴运动')
        state=self.read()
        if not self.check_home(state):
            # 原标定在找零完毕后将两轴回到0°，等待由调用者 _await_home 完成。
            self.position_commands(0.,0.,5.)

    def position_commands(self,outer,inner,speed):
        self.require_motion_authorized()
        s=self.read();self.validate_state(s)
        if not (s['inner_homed'] and s['outer_homed']):raise HardwareError('两轴未回零')
        if self.demo:self._pos=[outer,inner];return
        with self.lock:
            # 与原上位机 form_imu_calibration._send_position_pair 对齐：两轴指令相隔30 ms。
            # 只表示 DLL 已接收，不意味着转台确实运动；必须以后续反馈为准。
            if not self.m.twoTD600_SetAxisPosition(0,float(inner),float(speed)):
                raise HardwareError('内轴位置指令失败（DLL 返回0）')
            time.sleep(0.03)
            if not self.m.twoTD600_SetAxisPosition(2,float(outer),float(speed)):
                raise HardwareError('外轴位置指令失败（DLL 返回0）；后续将请求停车')
        return {'inner_sent':True,'outer_sent':True,'speed':float(speed)}

    def velocity_command(self,axis,rate_dps,accel_dps2=10.):
        """与旧生产标定共用厂商 DLL SetAxisVelocity；未在 Windows 实机验证。"""
        self.require_motion_authorized()
        s=self.read();self.validate_state(s)
        if not (s['inner_homed'] and s['outer_homed']):raise HardwareError('两轴未回零，禁止速率指令')
        if axis not in ('inner','outer'):raise HardwareError('旋转轴必须 inner / outer')
        if s.get(f'{axis}_locked'):raise HardwareError(f'{axis} 轴处于锁紧状态')
        rate=float(rate_dps);accel=float(accel_dps2)
        if not (0.01<=abs(rate)<=60 and 0<accel<=120):
            raise HardwareError('速率必须在0.01～60°/s内，加速度必须在0～120°/s²内')
        other='outer' if axis=='inner' else 'inner'
        if abs(s[f'{other}_speed'])>.05:raise HardwareError('另一轴未静止，禁止发速率指令')
        if self.demo:
            self._demo_rate=(axis,rate)
            return True
        with self.lock:
            result=self.m.twoTD600_SetAxisVelocity(0 if axis=='inner' else 2,rate,accel)
        if not result:raise HardwareError(f'{axis} 轴速率指令返回0；控制器未接收')
        return True

    def check_home(self,s,tol=.20):
        return bool(s['inner_homed'] and s['outer_homed'] and s['inner_in_place'] and s['outer_in_place']
                 and abs(circular_distance(s['inner'],0))<=tol
                 and abs(circular_distance(s['outer'],0))<=tol
                 and abs(s['inner_speed'])<.05 and abs(s['outer_speed'])<.05)

    def check_position(self,s,outer,inner,tol=.20):
        return bool(s['inner_in_place'] and s['outer_in_place']
            and abs(circular_distance(s['inner'],inner))<=tol
            and abs(circular_distance(s['outer'],outer))<=tol
            and abs(s['inner_speed'])<.05 and abs(s['outer_speed'])<.05)

class IMU:
    def __init__(self,demo=False):
        self.demo=demo; self.connected=False
        self.data=None;self.t0=time.monotonic();self._counter=0

    def open(self,port):
        if self.demo:self.connected=True;return
        import tilt_sensor_asm330_data_get as d
        if d.tiltSensorComm.thread_instance is not None:
            raise HardwareError('IMU 已有采集线程，禁止重复打开')
        d.tiltSensorComm.comm_port=port
        if not d.tilt_sensor_comm_open():raise HardwareError('IMU 串口打开失败，请核对波特率和地址')
        d.thread_of_tilt_sensor_data_get_create_and_start()
        self.data=d;self.connected=True

    def close(self):
        if not self.connected:return
        if not self.demo:
            self.data.tilt_sensor_calibration_queue_set(False,clear=True)
            self.data.thread_of_tilt_sensor_data_get_terminate()
            self.data.tilt_sensor_comm_close()
        self.connected=False

    def preview(self):
        if not self.connected:return None
        if self.demo:
            return {'acc':[.005,-.009,1.002],'gyro':[.01,-.02,.005],
                    'rate':50.,'frames':int((time.monotonic()-self.t0)*50),
                    'age':0.,'valid':True,'temp':24.0}
        d=self.data
        if not d.tiltSensorComm.is_serial_opened:return {'valid':False,'error':'串口已断开'}
        with d.tiltSensorRawData.data_lock:
            age=time.time()-d.tiltSensorComm.last_success_time_sec if d.tiltSensorComm.last_success_time_sec else float('inf')
            acc=[float(sum(x[j] for x in d.tiltSensorRawData.acc_g_arr)/len(d.tiltSensorRawData.acc_g_arr)) for j in range(3)]
            gyr=[float(sum(x[j] for x in d.tiltSensorRawData.gyr_dps_arr)/len(d.tiltSensorRawData.gyr_dps_arr)) for j in range(3)]
            return {'acc':acc,'gyro':gyr,'temp':float(d.tiltSensorRawData.temp_c),
                    'rate':d.tiltSensorComm.comm_rate,'frames':d.tiltSensorComm.comm_success_count,
                    'age':age,'valid':bool(d.tiltSensorComm.is_data_available and age<2 and not d.tiltSensorComm.is_data_no_update)}

    def begin(self):
        if not self.connected:raise HardwareError('IMU 串口未连接')
        if self.demo:return
        self.data.tilt_sensor_calibration_queue_set(True, clear=True)

    def end(self):
        if not self.demo:self.data.tilt_sensor_calibration_queue_set(False)

    def get_frame(self):
        if self.demo:return None
        import queue
        try:return self.data.tilt_sensor_calibration_frame_get_nowait()
        except queue.Empty:return None

    def get_drop_count(self):
        return 0 if self.demo else self.data.tilt_sensor_calibration_queue_drop_count_get()
