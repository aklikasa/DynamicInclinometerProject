# -*- coding: utf-8 -*-
"""100位置实验状态机：单后台线程，严格按到位→静置→采样→QC→保存执行。"""
from __future__ import annotations
import json
import math
import os
import time
import threading
from datetime import datetime
from pathlib import Path
import numpy as np
from core import process_frames,make_result,metrics,gravity_ref
from devices import HardwareError

class Cancelled(Exception): pass

def save_json_atomic(path, data):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp')
    with tmp.open('w',encoding='utf-8') as f:
        json.dump(data,f,ensure_ascii=False,indent=2,allow_nan=False)
        f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)

class Experiment:
    def __init__(self,tt,imu,calibration,profile,poses,settle_seconds,sample_seconds,
                 root,movement_speed,events,stop_event=None,demo=False):
        self.tt=tt; self.imu=imu;self.cal=calibration;self.profile=profile
        self.poses=poses;self.settle=settle_seconds;self.sample=sample_seconds
        self.speed=movement_speed;self.events=events
        self.stop_event=stop_event or threading.Event();self.demo=demo
        self.folder=Path(root)/('多姿态验证_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
        self.folder.mkdir(parents=True,exist_ok=False)
        self.rows=[];self.failed=[];self.completed=False;self.state='准备'
        self.log_lines=[]
        self.config={'mode':'演示/模拟数据' if demo else '实际硬件',
            'device_serial':calibration.device_serial,'calibration_file':calibration.source,
            'axis_model':calibration.axis_model,'gravity_sign':calibration.gravity_sign,
            'sample_seconds':self.sample,'settle_seconds':self.settle,'movement_speed_dps':self.speed,
            'pose_count':len(self.poses),'poses':self.poses,
            'quality_profile_id':profile.get('profile_id'),
            'started_at':datetime.now().isoformat(timespec='seconds'),
            'warning':'外X内Z模型下，内轴旋转可改变倾斜姿态的重力参考；但外轴0°和180°等位置可能出现方向重复，100位置不一定有100个独立重力方向',
            'release_warning':'试运行测量数据，不等于正式产品出厂放行'}
        save_json_atomic(self.folder/'任务配置.json',self.config)
        self._checkpoint()

    def emit(self,text,level='INFO'):
        message=f'[{datetime.now().strftime("%H:%M:%S")}] [{level}] {text}'
        self.log_lines.append(message)
        with (self.folder/'运行日志.txt').open('a',encoding='utf-8') as f:f.write(message+'\n')
        self.events('log',message)

    def _checkpoint(self):
        save_json_atomic(self.folder/'自动暂存_逐姿态.json',{
            'config':self.config,'rows':self.rows,'failed':self.failed,
            'completed':self.completed,'state':self.state,
            'updated_at':datetime.now().isoformat(timespec='seconds')})

    def _wait(self,duration):
        deadline=time.monotonic()+duration
        while time.monotonic()<deadline:
            if self.stop_event.is_set():raise Cancelled('用户请求停止')
            time.sleep(min(.08,max(0,deadline-time.monotonic())))

    @staticmethod
    def _motion_summary(s, outer, inner):
        def flag(k): return int(bool(s.get(k, False)))
        return (f"反馈外轴={s['outer']:.3f}°/目标{outer:.3f}°，"
                f"内轴={s['inner']:.3f}°/目标{inner:.3f}°；"
                f"速率 外={s['outer_speed']:.3f}、内={s['inner_speed']:.3f}°/s；"
                f"到位 外={flag('outer_in_place')}、内={flag('inner_in_place')}；"
                f"运动模式 外={s.get('outer_mode','未知')}、内={s.get('inner_mode','未知')}；"
                f"锁紧 外={flag('outer_locked')}、内={flag('inner_locked')}")

    def _await_position(self,outer=None,inner=None,homing=False,timeout=240,no_motion_timeout=12):
        started=time.monotonic(); steady_start=None
        last_log=started-3.0
        baseline=None; movement_seen=False
        while time.monotonic()-started<timeout:
            if self.stop_event.is_set():raise Cancelled('用户请求停止')
            s=self.tt.read();self.tt.validate_state(s)
            ok=self.tt.check_home(s) if homing else self.tt.check_position(s,outer,inner)
            now=time.monotonic()
            if not homing:
                if baseline is None:
                    baseline=(s['outer'],s['inner'])
                # 检测位置反馈变化或真实速度，不能单凭 DLL 返回1判断执行成功。
                if (abs(s['outer']-baseline[0])>.05 or abs(s['inner']-baseline[1])>.05
                    or abs(s['outer_speed'])>.03 or abs(s['inner_speed'])>.03):
                    movement_seen=True
                if now-last_log>=3.0:
                    self.emit(f'转台等待到位({now-started:.1f}s)：'+self._motion_summary(s,outer,inner))
                    last_log=now
                if not ok and not self.demo and not movement_seen and now-started>no_motion_timeout:
                    raise HardwareError(
                        '运动指令已发送但连续12秒未检测到位置/速度变化。'
                        '已经停止后续姿态，请检查控制器运动模式、轴锁紧、使能及位置命令。'
                        + self._motion_summary(s,outer,inner))
            if ok:
                if steady_start is None:steady_start=now
                if now-steady_start >= (0 if self.demo else .4):return s
            else:steady_start=None
            time.sleep(.15)
        label='回零' if homing else '位置运动'
        raise HardwareError(f'转台{label}等待超时（{timeout}秒），已停止后续动作；'
                            +(self._motion_summary(s,outer or 0,inner or 0) if not homing else '请检查两轴回零状态'))

    def _capture(self,position,target,index,retry):
        if self.demo:
            # 演示数据与真实硬件结果隔离；生成足够的 16 样本帧供 QC 流程测试。
            rng=np.random.default_rng(2026+index*10+retry)
            n=60  # 模拟演示固定60帧；真实硬件严格按用户设置的采集时间运行
            frames=[]
            ref=gravity_ref(target[1],target[0],self.cal.axis_model,self.cal.gravity_sign)
            raw=np.linalg.solve(self.cal.matrix,ref)+self.cal.bias
            for j in range(n):
                acc=(raw+rng.normal(0,.001,(16,3))).tolist()
                gyro=rng.normal(0,.008,(16,3)).tolist()
                frames.append({'acc_g_arr':acc,'gyr_dps_arr':gyro,
                    'temp_c':24.+rng.normal(0,.008),'inner_deg':position['inner'],
                    'outer_deg':position['outer'],'inner_rate_dps':0.,'outer_rate_dps':0.})
            return frames
        self.imu.begin(); frames=[];start=time.monotonic();deadline=start+self.sample
        sensor_cfg=None
        try:
            while time.monotonic()<deadline:
                if self.stop_event.is_set():raise Cancelled('用户请求停止')
                f=self.imu.get_frame()
                if f is None:
                    time.sleep(.01);continue
                # 按队列时间戳保障仅计正式采样窗口；拒绝旧缓存与时间戳逆序帧
                ts=f['monotonic_time_ns']/1e9
                if ts<start or ts>=deadline:continue
                s=self.tt.read()
                self.tt.validate_state(s)
                if not self.tt.check_position(s,target[0],target[1]):
                    raise HardwareError('采集期间转台位置/速度异常')
                if abs(s['time']-ts) > self.profile['quality']['feedback_age_max_ms']/1000:
                    raise HardwareError('转台反馈时间戳过期')
                if f.get('fifo_state',0)&0x0060:
                    raise HardwareError('IMU FIFO 溢出/满标志，拒绝本次采样')
                if int(f['acc_fs'])<=0 or int(f['gyro_fs'])<=0:
                    raise HardwareError('IMU 量程字段无效')
                cfg=(int(f['acc_fs']),int(f['gyro_fs']),int(f.get('data_odr',0)))
                if sensor_cfg is None:sensor_cfg=cfg
                elif sensor_cfg!=cfg:raise HardwareError('采集期间IMU量程或ODR变化，拒绝本次采样')
                frames.append({**f,'inner_deg':s['inner'],'outer_deg':s['outer'],
                    'inner_rate_dps':s['inner_speed'],'outer_rate_dps':s['outer_speed']})
            if self.imu.get_drop_count()>0:raise HardwareError('IMU 标定专用队列溢出，拒绝本次采样')
            return frames
        finally:self.imu.end()

    def run(self):
        try:
            if not self.tt.connected or not self.tt.enabled or not self.imu.connected:
                raise HardwareError('设备未就绪：串口连接、转台使能和IMU通信是前置条件')
            self.emit('开始验证；先执行双轴机械回零')
            self.state='回零';self.events('status',self.state)
            self.tt.home_commands()
            self._await_position(homing=True,timeout=180 if not self.demo else 5)
            self.emit('内外轴回零成功，位置与状态已确认')
            for idx,target in enumerate(self.poses,1):
                if self.stop_event.is_set():raise Cancelled('用户请求停止')
                self.state=f'运动 第{idx}/100';self.events('status',self.state)
                self.events('pose',(idx,target))
                self.emit(f'[{idx}/100] 目标外轴{target[0]:g}° / 内轴{target[1]:g}°')
                self.emit(f'即将下发位置指令：内轴={target[1]:g}°、外轴={target[0]:g}°，目标速度={self.speed:g}°/s')
                sent=self.tt.position_commands(target[0],target[1],self.speed)
                self.emit(f'位置指令返回：{sent!r}；注意：DLL返回成功不代表机械轴已运动')
                s=self._await_position(target[0],target[1],timeout=240 if not self.demo else 5)
                self.emit('目标位置已由控制器反馈确认：'+self._motion_summary(s,target[0],target[1]))
                self.state=f'静置 第{idx}/100';self.events('status',self.state)
                self._wait(.03 if self.demo else self.settle)
                limit=int(self.profile['quality'].get('static_sample_max_retries',5))
                success=False
                for retry in range(limit+1):
                    if retry:self.emit(f'第{idx}姿态第{retry}次重采样', 'WARN')
                    self.state=f'采集 第{idx}/100';self.events('status',self.state)
                    try:
                        frames=self._capture(s,target,idx,retry)
                        stat=process_frames(frames,self.profile)
                        row=make_result(idx,target,stat,self.cal)
                        row['retries']=retry
                        row['status']='PASS'
                        self.rows.append(row)
                        self.state=f'已完成 {idx}/100';self._checkpoint()
                        self.emit(f'姿态{idx}完成：有效帧{stat["accepted_frames"]}，前/后模长误差 {row["raw_norm_error_mg"]:.3f}/{row["cal_norm_error_mg"]:.3f} mg')
                        self.events('progress',(idx,len(self.poses)))
                        success=True;break
                    except (ValueError,HardwareError) as e:
                        self.emit(f'姿态{idx}采样质量失败：{e}', 'WARN')
                        if retry<limit:
                            self._wait(.03 if self.demo else self.settle)
                if not success:
                    self.failed.append({'pose':idx,'target':target,'reason':'质量重试耗尽'})
                    raise HardwareError(f'姿态{idx}质量重试耗尽，已停止整轮验证')
            self.completed=True;self.state='完成'
            self.emit('100姿态全部完成；可保存输出结果')
        except Cancelled as e:
            self.state='人工停止';self.emit(str(e),'WARN')
        except Exception as e:
            self.state='失败';self.emit(f'验证异常中止：{type(e).__name__}: {e}','ERROR')
        finally:
            # Stop 只是软件受控停车，非硬件急停；不在工作线程自动断使能
            try:
                self.tt.stop()
                self.emit('已发送双轴停车指令，仍请观察控制器实际停止状态')
            except Exception as e:self.emit(f'停车命令失败，需要人工硬件安全处理：{e}','ERROR')
            self._checkpoint()
            self.events('done',(self.completed,self.state,str(self.folder)))
