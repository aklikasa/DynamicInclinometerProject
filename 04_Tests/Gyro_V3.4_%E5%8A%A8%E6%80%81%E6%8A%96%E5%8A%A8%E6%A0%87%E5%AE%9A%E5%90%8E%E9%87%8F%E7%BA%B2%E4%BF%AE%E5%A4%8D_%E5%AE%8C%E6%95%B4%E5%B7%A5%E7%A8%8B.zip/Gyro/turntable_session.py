# -*- coding: utf-8 -*-
"""Single-owner live turntable session for the Gyro GUI.

One process owns the 2TD600 DLL handle from connect through Gyro test completion.
Standard input is newline-delimited JSON commands; stdout emits tagged JSON events.
No movement is sent on process startup or on connect.
"""
from __future__ import annotations
import json
import math
import queue
import re
import sys
import threading
import time
import traceback
from pathlib import Path
from datetime import datetime

from devices import Turntable, IMU, HardwareError
from core import circular_distance
from engine import Cancelled
from safety_gate import FAULT_PATH, LIVE_AUTHORIZED, AUTH_MESSAGE

TAG='@@TT@@'
SAFE_MODES={'空闲','静止','停止'}
STDOUT_LOCK=threading.Lock()

def send(kind, **fields):
    message={'kind':kind,**fields}
    with STDOUT_LOCK:
        print(TAG+json.dumps(message,ensure_ascii=False,default=str),flush=True)

def log(msg):send('log',message=str(msg))

class Session:
    def __init__(self):
        self.tt=Turntable(demo=False)
        self.imu=None
        self.stop_event=threading.Event()
        self.busy=False
        self.test_running=False
        self.shutdown=False
        self.connected_port=None
        self.queue=queue.Queue()
        self.last_state=None
        self.guard=threading.RLock()

    def status(self):
        if not self.tt.connected:
            send('state',connected=False,enabled=False,homed=False,busy=self.busy,testing=self.test_running)
            return None
        s=self.tt.read()
        send('state',connected=True,enabled=bool(s['inner_enabled'] and s['outer_enabled']),
             homed=bool(self.tt.check_home(s)),busy=self.busy,testing=self.test_running,
             inner={k:s['inner_'+k] for k in ('enabled','homed','in_place','normal','mode','speed','locked')},
             outer={k:s['outer_'+k] for k in ('enabled','homed','in_place','normal','mode','speed','locked')},
             inner_deg=round(s['inner'],4),outer_deg=round(s['outer'],4),
             host_poll_age_ms=round(s.get('host_poll_age_ms',0),1))
        return s

    def ensure_safe_stationary(self):
        s=self.tt.wait_initial_state_ready(require_stationary=True)
        self.tt.validate_state(s,need_enabled=False)
        if any(s[a+'_locked'] for a in ('inner','outer')):
            raise HardwareError('转台存在机械锁定标志，禁止使能/找零')
        return s

    def confirm_stopped(self,timeout=20.):
        deadline=time.monotonic()+timeout
        since=None;last_seq=None;count=0
        while time.monotonic()<deadline:
            s=self.tt.read()
            self.tt.validate_state(s,need_enabled=False)
            good=all(abs(s[a+'_speed'])<.05 and s[a+'_mode'] in SAFE_MODES for a in ('inner','outer'))
            seq=s.get('host_query_seq')
            if good:
                if seq!=last_seq:count+=1;last_seq=seq
                if since is None:since=time.monotonic()
                if count>=3 and time.monotonic()-since>=.5:return s
            else:count=0;since=None;last_seq=None
            time.sleep(.08)
        raise HardwareError('两轴 STOP 停稳确认超时；软件 STOP 不等于机械停车，请现场使用硬件急停')

    def abort_check(self):
        if self.stop_event.is_set():raise Cancelled('操作员请求停止')

    def wait_axis_home(self,axis,need_zero=True,timeout=180.):
        end=time.monotonic()+timeout;since=None
        while time.monotonic()<end:
            self.abort_check()
            s=self.tt.read();self.tt.validate_state(s)
            stable=(all(abs(s[a+'_speed'])<.05 and s[a+'_mode'] in SAFE_MODES for a in ('inner','outer'))
                and bool(s[axis+'_homed']) and (not need_zero or (abs(circular_distance(s[axis],0.))<=.20 and s[axis+'_in_place'])))
            if stable:
                if since is None:since=time.monotonic()
                if time.monotonic()-since>=.5:return s
            else:since=None
            time.sleep(.08)
        raise HardwareError(axis+'找零/返回0°超时，拒绝后续运动')

    def _home_one(self,axis):
        self.tt.require_motion_authorized()
        axis_id={'inner':0,'outer':2}[axis]
        s=self.ensure_safe_stationary()
        self.tt.validate_state(s,need_enabled=True)
        if not s[axis+'_homed']:
            log(f'{axis}发送原标定找零命令 SetAxisFindZero({axis_id},2,2)')
            with self.tt.lock:
                ok=self.tt.m.twoTD600_SetAxisFindZero(axis_id,2,2)
            if not ok:raise HardwareError(axis+' SetAxisFindZero 返回失败')
            self.wait_axis_home(axis,need_zero=False)
        self.abort_check()
        s=self.tt.read()
        if abs(circular_distance(s[axis],0.))>.20 or not s[axis+'_in_place']:
            log(f'{axis}找零标志有效，单独返回0°（原厂 SetAxisPosition；不移动另一轴）')
            with self.tt.lock:
                ok=self.tt.m.twoTD600_SetAxisPosition(axis_id,0.,5.)
            if not ok:raise HardwareError(axis+' SetAxisPosition(0°)返回失败')
        self.wait_axis_home(axis,need_zero=True)
        log(f'{axis} 找零且位置0°确认通过；另一轴未发送位置运动命令')

    def _safe_abort(self,reason):
        if not self.tt.connected:return
        log(f'操作异常/取消，尝试双轴软件 STOP：{reason}；现场必须核查机械状态。')
        try:
            self.tt.stop(observer=log)
            self.confirm_stopped()
            log('双轴 STOP 后静止反馈已达到主机轮询判定条件（不等于硬件急停验收）')
        except BaseException as exc:
            self.tt.latch_fault('停止失败或未确认：'+str(exc))
            send('fatal',message='软件停车未确认：'+str(exc)+'；请使用独立硬件急停并排查！')

    def handle(self,command):
        name=command['cmd']
        if name=='connect':
            if self.tt.connected:raise RuntimeError('转台已连接；请先断开再更改端口')
            port=str(command['port']).strip().upper()
            if not re.fullmatch(r'COM[1-9][0-9]*',port):raise ValueError('转台串口格式必须如 COM1')
            self.tt.open(port,original_calibration_startup=False)
            self.tt.wait_initial_state_ready(require_stationary=True,observer=log)
            self.connected_port=port
            log(f'转台 {port} 已连接（仅只读；未发送使能/找零指令）')
        elif name=='enable':
            if not self.tt.connected:raise RuntimeError('请先连接转台')
            if FAULT_PATH.exists():raise HardwareError('发现历史 STOP 故障锁，禁止使能')
            self.ensure_safe_stationary()
            # 与10月22日成功标定流程对齐：暂退后台轮询、0轴使能、间隔100ms、2轴使能、延迟500ms、恢复轮询并确认。
            self.tt.enable()
            s=self.tt.read()
            if not (s['inner_enabled'] and s['outer_enabled']):raise HardwareError('DLL使能指令已返回，但双轴状态未确认')
            log('内轴0 / 外轴2 已使能，且从转台反馈确认双轴使能位')
        elif name in ('home_inner','home_outer','home_both'):
            if not self.tt.connected:raise RuntimeError('请先连接转台')
            self.ensure_safe_stationary()
            s=self.tt.read()
            self.tt.validate_state(s,need_enabled=True)
            if name=='home_both':
                self._home_one('inner')
                self._home_one('outer')
            else:self._home_one('inner' if name=='home_inner' else 'outer')
            s=self.tt.read()
            log('当前位置反馈：内轴{:.3f}°；外轴{:.3f}°。'.format(s['inner'],s['outer']))
        elif name=='disable':
            if not self.tt.connected:raise RuntimeError('转台未连接')
            self.confirm_stopped()
            self.tt.disable()
            # Turntable.disable() itself pauses polling, applies original axis spacing,
            # resumes polling and checks three fresh feedback updates.
            log('双轴解除使能已通过分轴原标定序列与恢复轮询后的反馈确认')
        elif name=='disconnect':
            if not self.tt.connected:
                log('转台已经断开');return
            self.confirm_stopped()
            s=self.tt.read()
            if s['inner_enabled'] or s['outer_enabled']:
                raise HardwareError('双轴仍处于使能状态。请先点击“解除使能”，然后断开。')
            self.tt.close();self.connected_port=None
            log('后台轮询已停止，原厂 ClosePort 已调用且未抛出异常；主机已释放转台会话')
        elif name=='run':
            self.run_test(command['config'])
        elif name=='status':
            pass
        elif name=='exit':
            if self.tt.connected:raise HardwareError('请先解除使能并断开转台，才可退出控制会话')
            self.shutdown=True
        else:raise ValueError('未知会话操作 '+name)

    def run_test(self,cfg):
        from vendor.production_calibration import load_profile
        from core import load_gyro_calibration
        from gyro_engine import GyroExperiment
        from gyro_reports import export_gyro
        from Gyro多速率_原标定调用_实机测试 import axes_parse,speeds_parse,cases_build
        from ui_validators import validate_entries
        if FAULT_PATH.exists():raise HardwareError('存在STOP故障锁，禁止运动测试')
        cfg=validate_entries(cfg)
        if not self.tt.connected or not self.tt.enabled:raise HardwareError('请先连接并完成双轴使能')
        s=self.ensure_safe_stationary();self.tt.validate_state(s,need_enabled=True)
        if not self.tt.check_home(s):raise HardwareError('请先手动完成双轴找零且返回0°，再开始多速率测试')
        imu_port=cfg['imu_port'].strip().upper()
        if imu_port==self.connected_port:raise ValueError('IMU 串口不能与转台相同')
        cal=load_gyro_calibration(cfg['json_path'])
        profile=load_profile(str(Path(__file__).resolve().parent/'vendor'))
        rates=speeds_parse(cfg['rates'])
        limit=float(profile['rates']['maximum_command_rate_dps'])
        if max(rates)>60.:raise ValueError('速率超过2TD-600手册60°/s范围，禁止运行')
        if max(rates)>limit and not cfg.get('high_speed_approved',False):
            raise ValueError(f'大于原工艺{limit:g}°/s的实验需本次现场独立安全放行')
        accel=float(cfg['accel']);sample=float(cfg['sample']);settle=float(cfg['settle']);zero=float(cfg['zero'])
        budget=float(cfg['travel_budget']);speed=float(cfg['position_speed'])
        from rate_protocol import resolve_rate_params,estimated_turn_deg,add_rate_params
        use_rate_profiles=bool(cfg.get('use_rate_profiles',False))
        for rate in rates:
            a,t=resolve_rate_params(rate,use_rate_profiles,accel,sample)
            needed=estimated_turn_deg(rate,a,t)
            if needed>budget:raise ValueError(f'{rate:g}°/s预算需要{needed:.1f}°，超过当前{budget:.1f}°')
        cases=cases_build(list(cfg['axes']),rates,cfg['direction'],int(cfg['repeats']))
        add_rate_params(cases,use_rate_profiles,accel,sample)
        if not cases:raise ValueError('没有工况')
        output=Path(cfg['output_dir']).expanduser().resolve()
        output.mkdir(parents=True,exist_ok=True)
        self.imu=IMU(demo=False)
        exp=None
        try:
            self.imu.open(imu_port)
            deadline=time.monotonic()+8
            while time.monotonic()<deadline:
                self.abort_check()
                p=self.imu.preview()
                if p and p.get('valid') and float(p.get('rate',0))>=20:break
                time.sleep(.18)
            else:raise HardwareError('IMU没有达到20fps有效接收帧率，不执行运动')
            status=self.imu.preview() or {}
            fps=float(status.get('rate',0))
            send('imu_state',phase='acquiring',port=imu_port,fps=fps)
            log('IMU 实验串口 {} 已重新打开且收到有效数据（{:.1f} 帧/秒）；'
                '随后持续接收 Gyro XYZ 帧，并记录有效匀速段数据；关闭的仅是预览采集。'.format(imu_port,fps))
            def events(event,value):
                if event=='log':log(value)
                elif event=='status':send('progress_text',message=str(value))
                elif event=='progress':
                    n,total=value
                    send('progress',current=n,total=total)
                elif event=='done':send('result',completed=value[0],state=value[1],folder=value[2])
            exp=GyroExperiment(self.tt,self.imu,cal,profile,cases,settle,sample,str(output),speed,
                               events,self.stop_event,demo=False,accel_dps2=accel,max_travel_deg=budget,
                               zero_seconds=zero,high_speed_approved=bool(cfg.get('high_speed_approved',False)),
                               home_before_run=False)
            exp.run()
            if exp.completed and exp.stop_confirmed and not self.tt.safety_fault_latched and len(exp.rows)==len(cases):
                result=export_gyro(exp)
                log('✅ 全部实际工况完成，报告：'+str(result))
                send('finished',success=True,folder=str(exp.folder))
            else:
                log('实验未全部完成；停止后续操作，检查停车反馈、数据和设备状态')
                send('finished',success=False,folder=str(exp.folder))
        finally:
            if self.imu is not None:
                try:self.imu.close()
                except Exception as exc:log('IMU 关闭失败：'+str(exc))
                self.imu=None
                send('imu_state',phase='closed',port=imu_port)
            if self.tt.connected and self.tt.safety_fault_latched:
                send('fatal',message='转台进入故障锁状态，可能仍在运动，禁止继续控制！')

    def work(self):
        while not self.shutdown:
            try:cmd=self.queue.get(timeout=.2)
            except queue.Empty:continue
            name=cmd.get('cmd')
            with self.guard:self.busy=True;self.test_running=(name=='run')
            self.stop_event.clear()
            send('busy',busy=True,testing=self.test_running,action=name)
            try:
                self.handle(cmd)
                send('done',action=name,success=True)
            except BaseException as exc:
                send('error',action=name,message=f'{type(exc).__name__}: {exc}')
                log('操作失败：'+traceback.format_exc(limit=3))
                if name in ('home_inner','home_outer','home_both'):
                    self._safe_abort(str(exc))
                elif name=='enable' and self.tt.connected:
                    try:
                        s=self.tt.read()
                        if s['inner_enabled'] or s['outer_enabled']:
                            log('使能过程存在部分成功风险；禁止启动运动，请确认停稳后解除使能')
                    except Exception:log('使能异常后状态不可读：必须现场核查两轴是否已使能')
                elif name=='run' and self.tt.connected and self.tt.safety_fault_latched:
                    send('fatal',message='多速率实验存在停车故障锁定，必须按现场规程处理机械急停')
            finally:
                with self.guard:self.busy=False;self.test_running=False
                send('busy',busy=False,testing=False,action=name)
                try:self.status()
                except Exception as exc:log('状态读取异常：'+str(exc))

    def monitor(self):
        while not self.shutdown:
            time.sleep(1.0)
            if self.tt.connected and not self.busy:
                try:self.status()
                except Exception as exc:
                    send('status_error',message=str(exc))


def main():
    if '--live' not in sys.argv or not LIVE_AUTHORIZED:
        print('需要通过 GUI 明确开启实机控制会话：'+AUTH_MESSAGE,flush=True)
        return 2
    session=Session()
    threading.Thread(target=session.work,daemon=True,name='tt-single-owner').start()
    threading.Thread(target=session.monitor,daemon=True,name='tt-feedback-monitor').start()
    send('ready',message='转台会话已启动，但未打开串口或发送任何使能/运动命令')
    for line in sys.stdin:
        try:
            cmd=json.loads(line)
            if not isinstance(cmd,dict) or not isinstance(cmd.get('cmd'),str):
                raise ValueError('无效命令结构')
            name=cmd['cmd']
            if name=='stop':
                session.stop_event.set()
                log('收到操作员停止请求；自动实验/找零即将请求 STOP。此消息不保证机械停止！')
                continue
            with session.guard:
                if session.busy or not session.queue.empty():
                    send('error',action=name,message='控制器正在执行操作，拒绝重复操作')
                    continue
                session.queue.put(cmd)
            if name=='exit':
                # worker validates no open handle; return after successful exit or keep stdin loop
                pass
        except Exception as exc:send('error',action='parse',message=str(exc))
        if session.shutdown:break
    if session.tt.connected:
        log('GUI 通信管道关闭，但转台端口仍持有：不能证明电机静止。请现场核查硬件急停！')
        return 5
    return 0

if __name__=='__main__':
    sys.exit(main())
