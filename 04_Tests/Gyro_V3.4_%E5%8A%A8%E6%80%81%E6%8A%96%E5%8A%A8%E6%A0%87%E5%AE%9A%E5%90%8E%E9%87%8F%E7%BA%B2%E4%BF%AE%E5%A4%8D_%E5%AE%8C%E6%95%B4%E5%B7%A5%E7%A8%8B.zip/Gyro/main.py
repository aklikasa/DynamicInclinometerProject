# -*- coding: utf-8 -*-
"""PyCharm 直接右键运行 main.py 即可打开 Gyro 多速率验证界面。"""
from app import main
if __name__ == '__main__':
    main()
