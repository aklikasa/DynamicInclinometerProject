# -*- coding: utf-8 -*-
"""Gyro 实测结果：按工况保存独立验证报表/图表，绝不重拟合标定矩阵。"""
from collections import defaultdict
from pathlib import Path
import math
import numpy as np
from vendor.original_excel_report import _write_xlsx


def _rms(items):
    return float(math.sqrt(sum(x*x for x in items)/len(items))) if items else None


def _stats(rows):
    vals=[float(r['vector_error_dps']) for r in rows]
    main=[float(r['main_axis_error_dps']) for r in rows]
    return {'count':len(rows),'vector_rmse':_rms(vals),
        'main_rmse':_rms(main),'vector_max':max(vals) if vals else None,
        'cross_mean':float(np.mean([r['cross_axis_norm_dps'] for r in rows])) if rows else None}


def export_gyro(experiment):
    rows=experiment.rows
    stat=_stats(rows)
    subtitle=(f'PCB {experiment.cal.device_serial} | Gyro动态独立验证 | '
              f'{len(rows)}/{len(experiment.cases)}组 | {experiment.state} | '
              f'{experiment.config["mode"]}')
    overview=[['指标','结果','单位','说明'],
        ['已完成',len(rows),'组','仅 QC 合格且具有有效匀速采集的工况'],
        ['计划总工况',len(experiment.cases),'组','三方向 × 正反转 × 速率 × 重复'],
        ['静态零速校正后模长',experiment.zero_result.get('cal_zero_norm_dps') if experiment.zero_result else None,'°/s','静态零偏检验，独立于动态速率工况'],
        ['主轴误差RMSE',stat['main_rmse'],'°/s','相对于平台 P 参考角速度'],
        ['三轴向量RMSE',stat['vector_rmse'],'°/s','每组先求向量残差，再对工况等权RMSE'],
        ['最大向量误差',stat['vector_max'],'°/s','已完成工况的最大值'],
        ['平均交叉轴残差',stat['cross_mean'],'°/s','非主轴方向两分量范数的均值'],
        ['实验完成标志','完成' if experiment.completed else '未完成','','未完成不得当作全套验证'],
        ['质量结论','研发试运行，未正式批准','','无转台速率精度保证及Gyro底层8倍比例核验'],
        ['矩阵使用方式','固定JSON参数，无重新拟合','','原始Gyro数值不作未对齐的误差改善宣称']]
    headers=['工况号','状态','主轴','驱动轴','目标角速度°/s','重复号',
        '计划加速度°/s²','稳态采样目标s','速率参数来源',
        '参考X°/s','参考Y°/s','参考Z°/s',
        '原始X°/s','原始Y°/s','原始Z°/s',
        '校正X°/s','校正Y°/s','校正Z°/s',
        '误差X°/s','误差Y°/s','误差Z°/s',
        '主轴带符号误差°/s','主轴绝对误差°/s','主轴相对误差%',
        '交叉轴残差°/s','三轴向量误差°/s',
        '外轴平均速率°/s','内轴平均速率°/s','有效帧','采集帧','剔除比例','温度°C']
    data=[]
    for r in rows:
        data.append([r['id'],r['status'],r['direction'],r['axis'],r['target_rate_dps'],r['repeat'],
            r.get('accel_dps2'),r.get('sample_seconds'),r.get('rate_profile'),
            *r['reference_xyz_dps'],*r['raw_xyz_dps'],*r['cal_xyz_dps'],*r['error_xyz_dps'],
            r['main_axis_error_dps'],r['main_axis_absolute_error_dps'],r['relative_error_pct'],
            r['cross_axis_norm_dps'],r['vector_error_dps'],
            r['actual_outer_rate_dps'],r['actual_inner_rate_dps'],
            r['accepted_frames'],r['received_frames'],r['reject_fraction'],r['temperature_c']])
    quality=[['工况号','主轴','目标°/s','计划稳态采样s','有效帧','总帧','剔除率',
              '校正前STD-X°/s','校正前STD-Y°/s','校正前STD-Z°/s',
              '校正后STD-X°/s','校正后STD-Y°/s','校正后STD-Z°/s',
              '温度°C','温差°C','状态']]
    for r in rows:
        quality.append([r['id'],r['direction'],r['target_rate_dps'],r.get('sample_seconds'),r['accepted_frames'],
            r['received_frames'],r['reject_fraction'],*r['gyro_std_dps'],
            *r['gyro_calibrated_std_dps'],r['temperature_c'],r['temperature_span_c'],r['status']])
    for f in experiment.failed:
        quality.append([f['case']]+[None]*14+['FAIL: '+f['reason']])
    notes=[['指标','解释'],
        ['参考角速度','outer_x_inner_z: [外轴速率*cos(内轴角), -外轴速率*sin(内轴角), 内轴速率]'],
        ['标定后','gyro_P=K_g@(gyro_raw-b_g)，直接使用导入的gyro JSON，不重新拟合。'],
        ['原始值限制','原始Gyro位于芯片轴S系，且旧数据有约8倍比例疑点；原始XYZ仅供诊断，不直接对参考逐轴算RMSE。'],
        ['稳态门槛','控制器实际速率反馈稳定后才收取数据；加减速阶段不纳入稳态误差指标。'],
        ['MAD异常筛选','沿用现有上位机：子采样内6×1.4826×MAD，再跨帧稳健剔除。'],
        ['工程质量门槛','保留原MAD、最少帧数、温漂、转台反馈等硬门槛；独立验证的动态Gyro标准差按冻结矩阵投影到平台P系后再比对0.55°/s，原始标准差仅诊断；原生产标定不受影响。'],
        ['速率上限','标定工程当前最大命令速度10°/s，超过此值需现场确认后显式允许。'],
        ['转台计量边界','手册标称可达60°/s，但未保证速率精度；本验证为研发试运行。'],
        ['同步边界','按采集队列时间戳和当次DLL反馈判断，未进行独立高精度时钟同步。'],
        ['完整性','每组稳态CSV先保存，统计QC失败仍保留CSV；QC失败中止后续，报告区分完成状态。'],
        ['数据时序','每组动态采集记录在 动态采样记录/ 下，仅输出稳定匀速段。'],
        ['逐速率控制参数','加速度与采样时间随速率分档，实际每组参数记录于任务配置.json、汇总表；仍需现场确认加减速能力和运动行程。']]
    def form(name, content):
        return (name,(name+' — IMU Gyro动态验证',subtitle,content[0],content[1:],{}))
    sheets=[form('结果概览',overview),form('Gyro逐工况',[headers]+data),
            form('数据质量',quality),form('指标解释',notes)]
    path=experiment.folder/'Gyro动态验证结果.xlsx'
    _write_xlsx(str(path),sheets)
    count=plot_gyro(experiment)
    return str(path),count,'原工程XLSX写入器'


def plot_gyro(exp):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    for p in font_manager.findSystemFonts():
        if 'notosanscjk' in Path(p).name.lower():
            try:font_manager.fontManager.addfont(p)
            except Exception:pass
    names={f.name for f in font_manager.fontManager.ttflist}
    for n in ['Microsoft YaHei','SimHei','Noto Sans CJK SC','Noto Sans CJK JP','DejaVu Sans']:
        if n in names:plt.rcParams['font.sans-serif']=[n,'DejaVu Sans'];break
    plt.rcParams['axes.unicode_minus']=False
    folder=exp.folder/'对比图';folder.mkdir(exist_ok=True)
    rows=exp.rows
    if not rows:return 0
    def save(fig,name):
        fig.savefig(folder/name,dpi=170,facecolor='white',bbox_inches='tight')
        plt.close(fig)
    count=0
    # 方向 × 速度 统计
    by=defaultdict(list)
    for r in rows:by[(r['direction'],abs(r['target_rate_dps']))].append(r)
    speeds=sorted({x[1] for x in by})
    fig,ax=plt.subplots(figsize=(10,4.5))
    for direction in 'XYZ':
        values=[_rms([rr['main_axis_error_dps'] for rr in by[(direction,s)]]) for s in speeds]
        ax.plot(speeds,values,marker='o',label=direction+'主轴')
    ax.set(xlabel='目标角速度绝对值 (°/s)',ylabel='主轴误差RMSE (°/s)',title='Gyro 不同速率下的主轴误差')
    ax.grid(alpha=.25);ax.legend();save(fig,'01_不同速度主轴RMSE.png');count+=1
    fig,ax=plt.subplots(figsize=(10,4.5))
    for direction in 'XYZ':
        values=[_rms([rr['vector_error_dps'] for rr in by[(direction,s)]]) for s in speeds]
        ax.plot(speeds,values,marker='o',label=direction+'旋转')
    ax.set(xlabel='目标角速度绝对值 (°/s)',ylabel='三轴向量RMSE (°/s)',title='Gyro 不同速度的三轴综合误差')
    ax.grid(alpha=.25);ax.legend();save(fig,'02_不同速度向量RMSE.png');count+=1
    fig,ax=plt.subplots(figsize=(10,4.5))
    for direction in 'XYZ':
        vals=[float(np.mean([rr['cross_axis_norm_dps'] for rr in by[(direction,s)]])) if by[(direction,s)] else float('nan') for s in speeds]
        ax.plot(speeds,vals,marker='o',label=direction+'旋转')
    ax.set(xlabel='目标角速度绝对值 (°/s)',ylabel='交叉轴残差 (°/s)',title='Gyro 轴间耦合残差')
    ax.grid(alpha=.25);ax.legend();save(fig,'03_轴间耦合与速度.png');count+=1
    fig,ax=plt.subplots(figsize=(10,4.5))
    for direction in 'XYZ':
        pp=[r for r in rows if r['direction']==direction and r['target_rate_dps']>0]
        nn=[r for r in rows if r['direction']==direction and r['target_rate_dps']<0]
        if pp:ax.scatter([r['target_rate_dps'] for r in pp],[r['main_axis_error_dps'] for r in pp],label=direction+'正转',marker='o')
        if nn:ax.scatter([abs(r['target_rate_dps']) for r in nn],[r['main_axis_error_dps'] for r in nn],label=direction+'反转',marker='x')
    ax.set(xlabel='目标角速度绝对值 (°/s)',ylabel='主轴带符号误差 (°/s)',title='Gyro 正反转误差分布')
    ax.axhline(0,color='gray',lw=.9);ax.grid(alpha=.25);ax.legend(ncol=3);save(fig,'04_正反转主轴误差.png');count+=1
    # 在各轴中选一个已完成工况展示随时间的参考和校正后的速度对比；原始输出在单独子图。
    for direction in 'XYZ':
        r=next((item for item in rows if item['direction']==direction and item['target_rate_dps']>0),None)
        if r is None:continue
        p=exp.folder/'动态采样记录'/f"工况_{r['id']:03d}_{direction}_{r['target_rate_dps']:+g}.csv"
        if not p.exists():continue
        import csv
        with p.open('r',encoding='utf-8-sig',newline='') as f:
            data=list(csv.DictReader(f))
        if not data:continue
        t=np.asarray([float(d['时间s']) for d in data])
        k={'X':0,'Y':1,'Z':2}[direction]
        ref=np.asarray([float(d[['转台参考X°/s','参考Y°/s','参考Z°/s'][k]]) for d in data])
        raw=np.asarray([float(d[['原始GyroX°/s','原始GyroY°/s','原始GyroZ°/s'][k]]) for d in data])
        cal=np.asarray([float(d[['校正GyroX°/s','校正GyroY°/s','校正GyroZ°/s'][k]]) for d in data])
        fig,(a,b)=plt.subplots(2,1,figsize=(10,6),sharex=True)
        a.plot(t,ref,'--',lw=2,label='参考'+direction)
        a.plot(t,cal,lw=1.4,label='校正后'+direction)
        a.set(ylabel='平台角速度 °/s',title=direction+'轴：稳定匀速段参考与校正后比较')
        a.legend();a.grid(alpha=.25)
        b.plot(t,raw,lw=1.2,label='原始'+direction+'（S系，仅供诊断）')
        b.set(xlabel='稳定段时间 (s)',ylabel='原始读数 °/s（待核对比例）')
        b.legend();b.grid(alpha=.25)
        fig.tight_layout();save(fig,f'{count+1:02d}_{direction}轴角速度曲线.png');count+=1
    return count
