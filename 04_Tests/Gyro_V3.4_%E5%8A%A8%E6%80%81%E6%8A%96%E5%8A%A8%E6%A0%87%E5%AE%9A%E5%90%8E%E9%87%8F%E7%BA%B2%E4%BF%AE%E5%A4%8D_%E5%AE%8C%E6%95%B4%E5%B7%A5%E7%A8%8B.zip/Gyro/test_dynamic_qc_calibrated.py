# -*- coding: utf-8 -*-
"""V3.4 离线回归：仅检查严格QC在原始/校正后量纲中的区别，不碰硬件。"""
from pathlib import Path
import numpy as np
from vendor.production_calibration import load_profile, robust_segment
from gyro_engine import summarize_rate

profile=load_profile(Path(__file__).parent/'vendor')
assert profile['quality']['rate_gyro_std_max_dps']==0.55
rng=np.random.default_rng(20261029)
M=np.eye(3)/8.
frames=[]
for t in range(200):
    raw = np.array([0.,0.,15*8.])+rng.normal(0.,0.85,3)
    frames.append(dict(acc=[0.,0.,1.],gyro=raw.tolist(),
        inner_rate_dps=15.,outer_rate_dps=0.,inner_deg=180.,outer_deg=0.,temp_c=25.,
        sample_time_s=t*.025))
try:
    robust_segment(frames,'rate',profile,target_rate=15.,axis='inner')
except ValueError as exc:
    assert '动态GYRO抖动' in str(exc),repr(exc)
else:
    raise AssertionError('原生产标定不应忽略未补偿的0.85°/s原始STD')
stat=robust_segment(frames,'rate',profile,target_rate=15.,axis='inner',gyro_qc_matrix=M)
assert max(stat['gyro_std_dps'])>0.55,stat['gyro_std_dps']
assert max(stat['gyro_calibrated_std_dps'])<0.55,stat['gyro_calibrated_std_dps']
assert np.allclose(stat['gyro_calibrated_std_dps'],np.asarray(stat['gyro_std_dps'])/8,atol=1e-9)
# 对具有耦合的任意矩阵，比较逐帧变换的样本STD，而不是std/8捷径。
R=np.array([[.08,-.09,0],[.09,.08,0],[0,0,.125]])
stat2=robust_segment(frames,'rate',profile,target_rate=15.,axis='inner',gyro_qc_matrix=R)
assert len(stat2['gyro_calibrated_std_dps'])==3
# 校正后噪声真正过大仍然应当拒绝工况。
frames_noisy=[]
for t in range(200):
    raw=np.array([0,0,120.])+rng.normal(0,7,3)
    frames_noisy.append(dict(acc=[0,0,1],gyro=raw.tolist(),inner_rate_dps=15.,outer_rate_dps=0.,inner_deg=180.,outer_deg=0.,temp_c=25.))
try:
    robust_segment(frames_noisy,'rate',profile,target_rate=15.,axis='inner',gyro_qc_matrix=M)
except ValueError as exc:
    assert '校正后抖动' in str(exc),str(exc)
else:
    raise AssertionError('校正后抖动超过0.55不应放行')
print('PASS: 旧门槛仍有效；独立验证使用校正后STD；高噪声仍拒绝；跨轴矩阵可用')
