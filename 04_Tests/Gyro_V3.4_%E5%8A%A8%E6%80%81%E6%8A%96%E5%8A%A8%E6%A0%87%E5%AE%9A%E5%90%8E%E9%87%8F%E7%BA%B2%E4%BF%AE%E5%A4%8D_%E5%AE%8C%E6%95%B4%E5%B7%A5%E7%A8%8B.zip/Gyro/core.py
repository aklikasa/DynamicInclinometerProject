# -*- coding: utf-8 -*-
"""独立多姿态验证的标定参数、参考模型、QC 与统计。

原始计算直接复用 vendor.production_calibration 对应算法；不假定
标定前的传感器 XYZ 与转台平台坐标系 P 同轴。
"""
from __future__ import annotations
import json
import math
from pathlib import Path
from dataclasses import dataclass
import numpy as np
from vendor.production_calibration import robust_segment, frame_average_sanitized

@dataclass
class Calibration:
    source: str
    device_serial: str
    axis_model: str
    gravity_sign: int
    bias: np.ndarray
    matrix: np.ndarray
    gyro_bias: np.ndarray | None = None
    gyro_matrix: np.ndarray | None = None
    status: str = ''
    approved: bool = False


def load_calibration(path: str) -> Calibration:
    payload = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    if not isinstance(payload, dict):
        raise ValueError('JSON 根节点必须是对象')
    combined = payload.get('combined_calibration')
    if isinstance(combined, dict):
        # alignment.json 中包含当前候选 combined_calibration
        raw = combined
        meta = payload
    else:
        raw = payload
        meta = payload
    if 'accelerometer' in raw:
        acc = raw['accelerometer']
        b = acc['raw_bias_g']; k = acc['raw_to_platform_matrix']
        gyro = raw.get('gyroscope')
        gb = gyro.get('raw_bias_dps') if isinstance(gyro, dict) else None
        gk = gyro.get('raw_to_platform_matrix') if isinstance(gyro, dict) else None
    elif 'raw_accel_bias_g' in raw:
        b = raw['raw_accel_bias_g']; k = raw['raw_to_platform_matrix']
        gb = gk = None
    else:
        raise ValueError('JSON 不含可识别 ACC 校正参数；请选择 accel_calibration.json 或六轴 combined JSON')
    def vector(vals):
        a = np.asarray(vals, dtype=float)
        if a.shape != (3,) or not np.all(np.isfinite(a)):
            raise ValueError('标定零偏必须是3维有限数值')
        return a
    def matrix(vals):
        a = np.asarray(vals, dtype=float)
        if a.shape != (3,3) or not np.all(np.isfinite(a)) or abs(np.linalg.det(a)) < 1e-10:
            raise ValueError('标定矩阵必须是非奇异 3×3 有限矩阵')
        return a
    model = str(meta.get('axis_model') or raw.get('axis_model') or '').strip()
    if model not in ('outer_x_inner_z', 'outer_x_inner_y', 'outer_y_inner_x'):
        raise ValueError('缺失或不支持的 axis_model，不能可靠计算转台重力参考')
    gravity = meta.get('gravity_sign', raw.get('gravity_sign'))
    if gravity not in (-1,1):
        # 一体化候选JSON不一定携带 gravity_sign，尝试读取同目录同PCB的ACC原结果。
        sibling = Path(path).parent / 'accel_calibration.json'
        if sibling.exists():
            acc_meta = json.loads(sibling.read_text(encoding='utf-8-sig'))
            if (str(acc_meta.get('device_serial')) == str(meta.get('device_serial') or raw.get('device_serial'))
                and acc_meta.get('axis_model') == model):
                gravity = acc_meta.get('gravity_sign')
    if gravity not in (-1, 1):
        raise ValueError('缺少 gravity_sign (+1/-1)。候选六轴文件需使用带 gravity_sign 的 alignment.json 或对应 ACC JSON')
    status = str(meta.get('status') or raw.get('release_verdict') or meta.get('quality_gate', {}).get('verdict') or '')
    approved = bool(meta.get('quality_gate', {}).get('approved_for_production', False))
    return Calibration(path, str(meta.get('device_serial') or raw.get('device_serial') or '未填写'),
                       model, int(gravity), vector(b), matrix(k),
                       vector(gb) if gb is not None else None,
                       matrix(gk) if gk is not None else None, status, approved)


def rotation_x(angle):
    a = np.deg2rad(angle); c,s = np.cos(a),np.sin(a)
    return np.array([[1,0,0],[0,c,-s],[0,s,c]])
def rotation_y(angle):
    a = np.deg2rad(angle); c,s = np.cos(a),np.sin(a)
    return np.array([[c,0,s],[0,1,0],[-s,0,c]])
def rotation_z(angle):
    a = np.deg2rad(angle); c,s = np.cos(a),np.sin(a)
    return np.array([[c,-s,0],[s,c,0],[0,0,1]])


def gravity_ref(inner, outer, model, sign):
    if model == 'outer_x_inner_z': r = rotation_x(outer) @ rotation_z(inner)
    elif model == 'outer_x_inner_y': r = rotation_x(outer) @ rotation_y(inner)
    elif model == 'outer_y_inner_x': r = rotation_y(outer) @ rotation_x(inner)
    else: raise ValueError('轴系未确认')
    return r.T @ np.array([0., 0., float(sign)])


def circular_distance(actual, target):
    return (float(actual)-float(target)+180) % 360-180


def build_poses(outer_values, inner_values):
    """生成10×10姿态序列；不执行独立软件角度限位检查。

    设备运动许可仍由控制器自身的限位/报警状态决定；程序必须检查回零、
    状态反馈和到位/超时。这里只进行数据有效性检查，防止NaN/Inf与重复点。
    """
    outer_values=list(outer_values);inner_values=list(inner_values)
    poses=[(float(o),float(i)) for o in outer_values for i in inner_values]
    if len(outer_values)!=10 or len(inner_values)!=10 or len(poses)!=100 or len(set(poses))!=100:
        raise ValueError('要求外轴和内轴各10个不同角度，共100个不同目标组合')
    if not all(math.isfinite(o) and math.isfinite(i) for o,i in poses):
        raise ValueError('姿态角度不得包含NaN或无穷大')
    return poses


def process_frames(frames, profile):
    """frames 来自驱动层在正式采样窗内的帧。源文件同款 MAD 两级过滤。"""
    filtered = []
    for f in frames:
        av, atotal, avalid = frame_average_sanitized(
            f['acc_g_arr'], profile['quality']['mad_sigma'], return_stats=True)
        gv, gtotal, gvalid = frame_average_sanitized(
            f['gyr_dps_arr'], profile['quality'].get('gyro_mad_sigma',6.0), return_stats=True)
        if av is None: continue
        filtered.append(dict(acc=np.asarray(av).tolist(),gyro=np.asarray(gv).tolist() if gv is not None else [None,None,None],
            acc_raw_samples=atotal,acc_accepted_samples=avalid,
            gyro_raw_samples=gtotal,gyro_accepted_samples=gvalid,
            inner_deg=float(f['inner_deg']),outer_deg=float(f['outer_deg']),
            inner_rate_dps=float(f['inner_rate_dps']),outer_rate_dps=float(f['outer_rate_dps']),
            temp_c=float(f['temp_c'])))
    if len(filtered) < int(profile['quality']['minimum_frames']):
        raise ValueError(f'有效数据帧不足：帧内筛选后 {len(filtered)} / {profile["quality"]["minimum_frames"]}')
    stats = robust_segment(filtered, 'static', profile, static_sensor='acc')
    stats['received_frames'] = len(frames)
    stats['frame_internal_rejected'] = len(frames) - len(filtered)
    # 不能将缺失/无效帧从分母抹掉
    total_rej = 1. - float(stats['accepted_frames']) / len(frames)
    if total_rej > float(profile['quality']['max_rejection_fraction']):
        raise ValueError(f'总帧剔除比例 {total_rej:.1%} 超限（含帧内无效帧）')
    stats['total_reject_fraction'] = total_rej
    return stats


def make_result(index, target, stats, calibration):
    raw = np.asarray(stats['acc_raw_mean_g'], float)
    corrected = calibration.matrix @ (raw - calibration.bias)
    ref = gravity_ref(stats['inner_actual_mean_deg'],stats['outer_actual_mean_deg'],
                      calibration.axis_model,calibration.gravity_sign)
    raw_err = (np.linalg.norm(raw) - np.linalg.norm(ref)) * 1000
    cal_err = (np.linalg.norm(corrected) - np.linalg.norm(ref)) * 1000
    v_err = np.linalg.norm(corrected - ref)*1000
    cosine = float(np.dot(corrected,ref)/(np.linalg.norm(corrected)*np.linalg.norm(ref)))
    direction = float(np.degrees(np.arccos(np.clip(cosine,-1,1))))
    gyro_available = stats.get('gyro_raw_mean_dps') is not None
    gyro_mean = np.asarray(stats['gyro_raw_mean_dps'],float) if gyro_available else None
    if calibration.gyro_matrix is not None and gyro_available:
        gyro_cal = calibration.gyro_matrix @ (gyro_mean - calibration.gyro_bias)
    else: gyro_cal = np.array([float('nan')]*3)
    return dict(index=index, outer_target_deg=float(target[0]), inner_target_deg=float(target[1]),
        outer_actual_deg=float(stats['outer_actual_mean_deg']),
        inner_actual_deg=float(stats['inner_actual_mean_deg']),
        reference_xyz_g=ref.tolist(), raw_xyz_g=raw.tolist(), cal_xyz_g=corrected.tolist(),
        raw_norm_g=float(np.linalg.norm(raw)), cal_norm_g=float(np.linalg.norm(corrected)),
        raw_norm_error_mg=float(raw_err),cal_norm_error_mg=float(cal_err),
        vector_error_mg=float(v_err),direction_error_deg=direction,
        gyro_raw_dps=(gyro_mean.tolist() if gyro_available else [None,None,None]),
        gyro_cal_dps=(gyro_cal.tolist() if calibration.gyro_matrix is not None and gyro_available else [None,None,None]),
        gyro_raw_zero_norm_dps=(float(np.linalg.norm(gyro_mean)) if gyro_available else None),
        gyro_cal_zero_norm_dps=(float(np.linalg.norm(gyro_cal)) if calibration.gyro_matrix is not None and gyro_available else None),
        **stats)


def unique_reference_directions(rows,precision=7):
    return len({tuple(round(float(v),precision) for v in x['reference_xyz_g']) for x in rows})

def metrics(rows):
    def get(k):return np.asarray([x[k] for x in rows],float)
    if not rows:return {}
    return {'poses':len(rows),'unique_gravity_directions':unique_reference_directions(rows),'pre_norm_rmse_mg':float(np.sqrt(np.mean(get('raw_norm_error_mg')**2))),
        'post_norm_rmse_mg':float(np.sqrt(np.mean(get('cal_norm_error_mg')**2))),
        'pre_norm_mae_mg':float(np.mean(np.abs(get('raw_norm_error_mg')))),
        'post_norm_mae_mg':float(np.mean(np.abs(get('cal_norm_error_mg')))),
        'pre_norm_max_abs_mg':float(np.max(np.abs(get('raw_norm_error_mg')))),
        'post_norm_max_abs_mg':float(np.max(np.abs(get('cal_norm_error_mg')))),
        'post_vector_rmse_mg':float(np.sqrt(np.mean(get('vector_error_mg')**2))),
        'post_vector_max_mg':float(np.max(get('vector_error_mg'))),
        'post_direction_max_deg':float(np.max(get('direction_error_deg'))),
        'post_direction_mean_deg':float(np.mean(get('direction_error_deg')))}


@dataclass
class GyroCalibration:
    """Gyro 独立验证只需要 gyro JSON，不强制同时提供 ACC。"""
    source: str
    device_serial: str
    axis_model: str
    gyro_bias: np.ndarray
    gyro_matrix: np.ndarray
    status: str = ''


def load_gyro_calibration(path: str) -> GyroCalibration:
    payload = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    if not isinstance(payload,dict):raise ValueError('Gyro JSON 必须为对象')
    raw=payload.get('combined_calibration') or payload
    if isinstance(raw.get('gyroscope'),dict):
        gyr=raw['gyroscope']
        bias=gyr.get('raw_bias_dps')
        mat=gyr.get('raw_to_platform_matrix')
    else:
        bias=raw.get('raw_gyro_bias_dps')
        mat=raw.get('raw_to_platform_matrix') if 'gyroscope' in str(raw.get('calibration_type','')).lower() else None
    if bias is None or mat is None:
        raise ValueError('文件缺少 Gyro 零偏或 3×3 校正矩阵，请选择 gyro_calibration.json 或六轴合并文件')
    b=np.asarray(bias,float);K=np.asarray(mat,float)
    if b.shape!=(3,) or not np.isfinite(b).all():raise ValueError('Gyro 零偏必须为3个有限数值')
    if K.shape!=(3,3) or not np.isfinite(K).all() or abs(np.linalg.det(K))<1e-10:
        raise ValueError('Gyro 校正矩阵必须为非奇异3×3矩阵')
    model=str(payload.get('axis_model') or raw.get('axis_model') or '').strip()
    if model!='outer_x_inner_z':
        raise ValueError('当前 Gyro 自动验证仅支持已验证的 outer_x_inner_z 轴系模型')
    serial=str(payload.get('device_serial') or raw.get('device_serial') or '未填写')
    status=str(payload.get('release_verdict') or payload.get('status') or '')
    return GyroCalibration(str(Path(path).resolve()),serial,model,b,K,status)
