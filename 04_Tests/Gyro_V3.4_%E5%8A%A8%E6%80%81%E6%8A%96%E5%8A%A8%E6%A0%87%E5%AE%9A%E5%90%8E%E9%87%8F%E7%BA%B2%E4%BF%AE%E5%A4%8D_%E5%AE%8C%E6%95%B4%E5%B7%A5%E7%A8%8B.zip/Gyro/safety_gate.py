# -*- coding: utf-8 -*-
"""实验操作员放行：保留事故故障锁，不再依赖 V1.7.0 的外部 JSON 放行文件。

实机使能须由主程序在端口打开之前要求操作员现场确认。
本模块只负责检查 --live 和上次停止失败故障锁；不是硬件安全保护。
"""
import json
import sys
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parent
FAULT_PATH = ROOT / 'STOP故障锁定_勿删除.json'

def authorization_status(argv=None):
    argv=sys.argv if argv is None else argv
    if '--live' not in argv:
        return False, '需要明确申请 --live 实机运动', None
    if FAULT_PATH.exists():
        return False, f'检测到历史 STOP 故障锁：{FAULT_PATH}；先完成现场维修/验收，不得在本软件中绕过', None
    return True, '已收到 --live 请求；现场 STOP 和急停有效性仍须由操作员独立确认', {'approved_max_speed_dps':60.0}

LIVE_AUTHORIZED, AUTH_MESSAGE, LIVE_PERMIT = authorization_status()

def persist_stop_fault(reason):
    data={'time':datetime.now().isoformat(timespec='seconds'), 'reason':str(reason),
          'action':'停止后续运动；确认机械停稳、排查 STOP 控制故障并由设备负责人验收后方可重新启机。不得仅凭关闭本程序或删除该文件再次运行。'}
    tmp=FAULT_PATH.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(FAULT_PATH)
