# -*- coding: utf-8 -*-
"""2TD-600 + ASM330LHHX：Gyro 多速率实机测试（原标定调用链）。

真实接口依次来自 devices.Turntable（原生产标定 DLL 与后台轮询）
以及 GyroExperiment（原生产流程的逐轴回零、位置预置、速率、STOP）。
不修改标定 JSON，不重新辨识补偿矩阵，不包含模拟模式。
"""
import argparse
import json
import math
import signal
import sys
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def say(s):
    print(f'[{datetime.now():%H:%M:%S}] {s}',flush=True)


def ask(text, default=None):
    label=f'{text}'+(f' [默认 {default}]' if default is not None else '')+'：'
    try: s=input(label).strip()
    except EOFError: raise RuntimeError('输入终止：不运行设备')
    if s: return s
    if default is not None:return str(default)
    raise ValueError(f'{text}必须输入')


def axes_parse(s):
    # XYZ、X,Y,Z 和单个轴都支持。
    v=s.upper().replace(',','').replace(' ','').replace('，','')
    if not v or len(set(v))!=len(v) or any(x not in 'XYZ' for x in v):
        raise ValueError('待测轴只能使用 X/Y/Z，不可重复，例如 XYZ / Z / XZ')
    return list(v)


def speeds_parse(s):
    items=[x.strip() for x in s.replace('，',',').split(',')]
    if not items or any(x=='' for x in items): raise ValueError('输入至少一个速率，例如 1,3.5,7.5')
    values=[]
    for x in items:
        rate=float(x)
        if not math.isfinite(rate) or rate<=0:
            raise ValueError('速率只能输入非零的正数幅值；方向另行选择')
        if rate in values: raise ValueError('速率幅值不得重复')
        values.append(rate)
    return values


def cases_build(axes,rates,directions,repeats):
    from gyro_engine import build_gyro_cases
    # 使用已经与原标定对应的姿态：X=外轴+内轴180°，Y=外轴+内轴270°，Z=内轴。
    generated=build_gyro_cases(tuple(rates),repeats)
    allowed={'双向':(1,-1),'正向':(1,),'反向':(-1,)}[directions]
    cases=[c for a in axes for c in generated if c['direction']==a and
          (1 if c['target_rate_dps']>0 else -1) in allowed]
    for i,c in enumerate(cases,1):c['id']=i
    return cases


def cli(argv=None):
    p=argparse.ArgumentParser(description='原 Gyro 标定驱动调用，多速率真实设备验证（无模拟）')
    p.add_argument('--live',action='store_true',help='实际使能/找零/启动电机；仍需现场确认')
    p.add_argument('--precheck',action='store_true',help='只读连接检查，不使能/运动/STOP')
    p.add_argument('--tt-port',default='',help='转台通信端口；留空在运行时输入')
    p.add_argument('--imu-port',default='',help='IMU/PCB端口；留空在运行时输入')
    p.add_argument('--json',dest='calibration',default='',help='以前已标定好的 gyro_calibration.json')
    p.add_argument('--axes',default='',help='XYZ 或 XZ 或 Z；留空交互输入')
    p.add_argument('--rates',default='',help='多个速率幅值如 1,3.5,7.5；留空交互输入')
    p.add_argument('--directions',default='',choices=['','双向','正向','反向'])
    p.add_argument('--repeats',type=int,default=None)
    p.add_argument('--accel',type=float,default=None,help='速率指令加速度°/s²，默认原标定1')
    p.add_argument('--sample',type=float,default=None,help='匀速采样秒数')
    p.add_argument('--settle',type=float,default=None,help='每次预置位静置秒数')
    p.add_argument('--zero',type=float,default=None,help='归零后零偏复核秒数')
    p.add_argument('--position-speed',type=float,default=None)
    p.add_argument('--travel-budget',type=float,default=None,help='运动预算°（软件估算，不是硬件限位）')
    p.add_argument('--stop-file',default='',help='GUI 软件停止请求文件；由实验运行线程监视')
    p.add_argument('--out',default=str(ROOT/'实测结果'))
    return p.parse_args(argv)


def collect(p,profile):
    if not p.calibration: p.calibration=ask('请输入已有 gyro_calibration.json 路径')
    p.calibration=p.calibration.strip('"').strip("'")
    if not Path(p.calibration).is_file(): raise FileNotFoundError('找不到真实标定文件：'+p.calibration)
    if Path(p.calibration).name.lower().startswith('demo'):raise ValueError('不能使用演示标定文件')
    p.axes=axes_parse(p.axes or ask('测试哪些轴（如 XYZ 或 Z）','XYZ'))
    p.rates=speeds_parse(p.rates or ask('输入多个目标速度幅值，逗号分隔（°/s），不需要写±号'))
    p.directions=p.directions or ask('正反转测试（双向/正向/反向）','双向')
    if p.directions not in ('双向','正向','反向'):raise ValueError('方向不合法')
    p.repeats=p.repeats if p.repeats is not None else int(ask('每个方向每档重复次数',1))
    p.accel=p.accel if p.accel is not None else float(ask('速率运动加速度 °/s²（原标定为1）',1))
    p.sample=p.sample if p.sample is not None else float(ask('每组稳定匀速采样时长（秒）',5))
    p.settle=p.settle if p.settle is not None else float(ask('预置姿态静置（秒）',3))
    p.zero=p.zero if p.zero is not None else float(ask('零位 Gyro 零偏复核时长（秒）',20))
    p.position_speed=p.position_speed if p.position_speed is not None else float(ask('回到测试姿态的定位速度（°/s）',5))
    p.travel_budget=p.travel_budget if p.travel_budget is not None else float(ask('单组最大软件运动角度预算（°，不是机械限位）',120))
    limit=float(profile['rates']['maximum_command_rate_dps'])
    if min(p.rates)<0.01:
        raise ValueError('速率设置错误')
    if max(p.rates)>limit:
        raise ValueError(f'当前原生产标定工艺文件限定 ≤{limit:g}°/s；该范围以外不可直接声称复用已验证工艺')
    if not (1<=p.repeats<=20):raise ValueError('重复次数应为1-20')
    if any(not math.isfinite(v) for v in (p.accel,p.sample,p.settle,p.zero,p.position_speed,p.travel_budget)):
        raise ValueError('参数包含非法数值')
    if not (0.05<=p.accel<=20 and 1<=p.sample<=30 and 1<=p.settle<=30 and 10<=p.zero<=120
            and .1<=p.position_speed<=5 and 20<=p.travel_budget<=360):
        raise ValueError('加速度、采样时间、回零时间或角位移预算不在当前实验程序的操作范围内')
    for rate in p.rates:
        # 加速+匀速+减速预算来自原验证脚本；预算只是保险用的主机估算。
        travel=rate*rate/p.accel+rate*p.sample+10
        if travel>p.travel_budget:
            raise ValueError(f'速度{rate:g}°/s当前参数预计含缓冲转角{travel:.1f}°，超出设置的预算{p.travel_budget:g}°')
    return p


def precheck(p):
    from devices import Turntable,IMU
    tt,imu=Turntable(demo=False),IMU(demo=False)
    try:
        tt.open(p.tt_port)
        s=tt.wait_initial_state_ready(require_stationary=True,observer=say)
        say(f'转台已连接；内轴{s["inner"]:.3f}°、外轴{s["outer"]:.3f}°；使能=({s["inner_enabled"]},{s["outer_enabled"]})')
        imu.open(p.imu_port)
        t=time.monotonic()+6
        while time.monotonic()<t:
            v=imu.preview()
            if v and v.get('valid') and v.get('rate',0)>0:
                say(f'IMU连接成功，有效帧率={v["rate"]:.1f} fps；原始Gyro={v.get("gyro")}')
                return 0
            time.sleep(.15)
        raise RuntimeError('等待IMU有效数据超时')
    finally:
        try:imu.close()
        except Exception as ex:say('IMU关闭异常：'+str(ex))
        try:tt.close()
        except Exception as ex:say('转台关闭异常：'+str(ex))


def main(argv=None):
    p=cli(argv)
    if not p.live and not p.precheck:
        say('默认不会使能和运动。使用“双击开始真实实验.bat”运行，或执行 python 脚本.py --live。')
        return 2
    p.tt_port=(p.tt_port or ask('输入转台实际串口号（以设备管理器为准）','COM1')).upper().strip()
    p.imu_port=(p.imu_port or ask('输入PCB/IMU实际串口号（以设备管理器为准）','COM6')).upper().strip()
    import re
    if not re.fullmatch('COM[0-9]+',p.tt_port) or not re.fullmatch('COM[0-9]+',p.imu_port) or p.tt_port==p.imu_port:
        raise ValueError('COM串口号无效或转台与IMU设置成相同端口')
    if p.precheck:
        return precheck(p)
    if not p.live:
        say('默认不会使能和运动。使用“双击开始真实实验.bat”运行，或执行 python 脚本.py --live。')
        return 2
    from vendor.production_calibration import load_profile
    from core import load_gyro_calibration
    from gyro_engine import GyroExperiment
    from gyro_reports import export_gyro
    from devices import Turntable,IMU
    from safety_gate import LIVE_AUTHORIZED,AUTH_MESSAGE
    profile=load_profile(str(ROOT/'vendor'))
    if not LIVE_AUTHORIZED:
        raise RuntimeError(AUTH_MESSAGE)
    p=collect(p,profile)
    cal=load_gyro_calibration(p.calibration)
    cases=cases_build(p.axes,p.rates,p.directions,p.repeats)
    say(f'读取真实标定矩阵：设备={cal.device_serial}；模型={cal.axis_model}；不改变此文件。')
    say(f'连接设置：转台={p.tt_port}、IMU={p.imu_port}')
    say('预定实验（每一行都是实机指令，顺序执行）：')
    for c in cases:
        say(f'  {c["id"]:02d}. {c["direction"]}轴 {c["target_rate_dps"]:+g}°/s  重复 {c["repeat"]}')
    say(f'运动加速度={p.accel}°/s²，稳定采样={p.sample}s，共{len(cases)}组。')
    say('原标定转台调用：OpenPort → 两轴使能 → 逐轴找零 → 位置预置 → SetAxisVelocity → 当前轴SetAxisStop → 停稳确认。')
    say('注意：2026-10-26 曾发生 +7.5°/s 的 STOP 未生效，软件不能保证物理停车；现场必须有独立急停。')
    phrase=ask('确认设备编号对应、夹具/线缆安全、STOP已现场独立验收且专人值守，输入“开始真实多速率实验”')
    if phrase!='开始真实多速率实验':
        say('没有确认，未连接设备，不下发运动命令');return 2
    stop_event=threading.Event()
    watch_done=threading.Event()
    def watch_gui_stop():
        """GUI 与真实实验进程不共享内存；仅传递取消请求，停车仍由原硬件引擎执行。"""
        target=Path(p.stop_file) if p.stop_file else None
        while target is not None and not watch_done.wait(.10):
            if target.exists():
                say('收到界面软件停止请求，通知原实验引擎收尾并核查STOP；不等于硬件急停')
                stop_event.set()
                return
    if p.stop_file:
        threading.Thread(target=watch_gui_stop,daemon=True,name='gui_stop_watch').start()
    def on_abort(signum,frame):
        stop_event.set()
        say('收到中断请求。程序将尝试发送原标定 STOP；若实际未减速，请按现场规程使用硬件急停！')
    signal.signal(signal.SIGINT,on_abort)
    if hasattr(signal,'SIGBREAK'):signal.signal(signal.SIGBREAK,on_abort)

    tt,imu=Turntable(demo=False),IMU(demo=False)
    exp=None;result_code=1
    try:
        # 先保证IMU实际可接收数据，随后严格以原标定的 OpenPort -> 两轴使能 -> 开轮询 顺序连接转台。
        # 之前多个独立验证版本采用“开轮询 -> 初始状态核验 -> 再使能”的不同顺序，可能在使能前被拦截。
        from devices import HardwareError
        imu.open(p.imu_port)
        deadline=time.monotonic()+8
        while time.monotonic()<deadline:
            v=imu.preview()
            if v and v.get('valid') and v.get('rate',0)>=20:break
            time.sleep(.2)
        else:raise HardwareError('IMU有效采样率<20fps，拒绝使能')
        if stop_event.is_set():raise RuntimeError('启动前已取消')
        say('按原标定顺序连接转台：OpenPort → 使能内轴0 → 使能外轴2 → 延时 → 开始反馈轮询')
        tt.open(p.tt_port,original_calibration_startup=True)
        status=tt.wait_initial_state_ready(require_stationary=True,observer=say)
        tt.validate_state(status,need_enabled=True)
        for axis in ('inner','outer'):
            if abs(status[axis+'_speed'])>=.05:raise HardwareError(f'{axis}不静止，禁止起动')
            if status[axis+'_locked']:raise HardwareError(f'{axis}机械锁状态，禁止运动')
        say('原标定顺序使能反馈：内轴={}，外轴={}'.format(status['inner_enabled'],status['outer_enabled']))
        def evt(event,value):
            if event=='log':print(value,flush=True)
            elif event=='status':say('状态：'+str(value))
            elif event=='progress':say('进度：'+str(value))
            elif event=='done':say('任务结束：'+str(value))
        exp=GyroExperiment(tt,imu,cal,profile,cases,p.settle,p.sample,p.out,p.position_speed,
                           evt,stop_event,demo=False,accel_dps2=p.accel,max_travel_deg=p.travel_budget,
                           zero_seconds=p.zero,high_speed_approved=False)
        exp.run()
        if exp.completed and exp.stop_confirmed and not tt.safety_fault_latched and len(exp.rows)==len(cases):
            result=export_gyro(exp)
            say('✅ 全部实际工况完成，报告：'+str(result))
            result_code=0
        else:
            say('❌ 实验不完整；请检查本次文件夹的日志、自动暂存和STOP证据。')
            result_code=4
    except BaseException as exc:
        say('⚠️ 硬件实验异常：'+type(exc).__name__+'：'+str(exc))
        traceback.print_exc()
        result_code=5
        if tt.connected and not tt.safety_fault_latched:
            try:
                st=tt.read()
                if max(abs(st['inner_speed']),abs(st['outer_speed']))>=.05:
                    say('异常时检测到机械运动，尝试按原标定接口下发双轴STOP；软件无法替代硬急停！')
                    tt.stop(observer=say)
                    if exp is not None: exp._wait_stop()
                    else: tt.latch_fault('异常收尾虽已发送 STOP，但缺少独立停车确认；必须现场核查')
            except Exception as e:
                tt.latch_fault('异常退出 STOP 未确认：'+str(e))
                say('严重告警：STOP未确认，必须现场按操作规程处理硬件急停！')
    finally:
        watch_done.set()
        try:imu.close()
        except Exception as ex:say('IMU关闭异常：'+str(ex))
        if tt.connected:
            try:
                st=tt.read()
                still=max(abs(st['inner_speed']),abs(st['outer_speed']))<.05
                modes=st['inner_mode'] in ('空闲','静止','停止') and st['outer_mode'] in ('空闲','静止','停止')
                if still and modes and not tt.safety_fault_latched and (exp is None or exp.stop_confirmed):
                    if st['inner_enabled'] or st['outer_enabled']:
                        # 可能首次只使能了一轴；仅在静止确认后才解除使能。
                        tt.disable()
                    if tt.enabled:tt.enabled=False
                    tt.close()
                    say('两轴静止反馈正常，已解除使能并断开转台端口')
                else:
                    say('存在未确认的运动/故障或还未完成停车确认，未自动断开转台，请现场核查机械安全状态')
            except Exception as e:
                say('清理硬件异常：'+str(e)+'；请现场确认')
        if exp is not None:say('实测数据路径：'+str(exp.folder))
    return result_code

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:
        say('未启动/无法继续：'+type(exc).__name__+'：'+str(exc))
        sys.exit(3)
