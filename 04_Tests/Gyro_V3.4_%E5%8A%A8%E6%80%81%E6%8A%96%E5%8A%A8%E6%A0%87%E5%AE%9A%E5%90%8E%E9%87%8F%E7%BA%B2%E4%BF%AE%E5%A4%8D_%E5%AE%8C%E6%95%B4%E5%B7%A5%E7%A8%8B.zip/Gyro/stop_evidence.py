# -*- coding: utf-8 -*-
"""Write-once diagnostic evidence for a *real* turntable STOP attempt.

This module does not import the vendor DLL and sends no control command.
It merely records observations made by the existing Gyro control path.
A successful DLL return is NOT proof of physical standstill. Host poll sequence
is NOT a controller frame counter.
"""
from __future__ import annotations
import json
import math
import time
from datetime import datetime
from pathlib import Path


class StopEvidence:
    def __init__(self, folder, case):
        self.case = {k: case.get(k) for k in ('id', 'direction', 'axis', 'target_rate_dps', 'repeat')}
        self.path = Path(folder) / '停车链路证据' / ('工况_%03d_STOP.jsonl' % int(case['id']))
        self.path.parent.mkdir(exist_ok=True, parents=True)
        self.error = None
        self._last_poll_seq = None
        self._start = time.monotonic()
        self.write('start', note='主机观测证据；不等于控制器独立应答或物理停车验收')

    def write(self, event, **data):
        row = {'event':event,
               'wall_time':datetime.now().isoformat(timespec='milliseconds'),
               'host_elapsed_s':round(time.monotonic()-self._start, 6),
               'case':self.case, **data}
        try:
            with self.path.open('a', encoding='utf-8') as f:
                f.write(json.dumps(row, ensure_ascii=False, allow_nan=False, default=str)+'\n')
                f.flush()
        except (OSError, ValueError, TypeError) as exc:
            # Logging may not disrupt an already-running stop sequence.
            self.error = f'{type(exc).__name__}: {exc}'
        return row

    def snapshot(self, state, event='feedback', unique_poll=True):
        """Persist each host-poll observation at most once unless explicitly requested."""
        seq = state.get('host_query_seq')
        if unique_poll and seq is not None and seq == self._last_poll_seq:
            return False
        self._last_poll_seq = seq
        keys = ('inner', 'outer', 'inner_speed', 'outer_speed',
                'inner_mode', 'outer_mode', 'inner_normal', 'outer_normal',
                'host_query_seq', 'host_poll_age_ms', 'read_duration_ms',
                'controller_frame_freshness_verified')
        data = {k: state.get(k) for k in keys}
        self.write(event, **data)
        return True
