import math
import re
from pathlib import Path
from rate_protocol import resolve_rate_params, estimated_turn_deg

def validate_entries(config: dict, profile_max: float=10.0):
    """仅文本预检：原生产工艺上限10；超限仅在逐次现场放行后可到转台手册60。"""
    port_pattern = re.compile(r'COM[1-9][0-9]*$', re.I)
    tt = config['tt_port'].strip().upper()
    imu = config['imu_port'].strip().upper()
    if not (port_pattern.fullmatch(tt) and port_pattern.fullmatch(imu)):
        raise ValueError('转台和 IMU 串口应填 COM1、COM6 等格式，请以设备管理器为准。')
    if tt == imu:
        raise ValueError('转台和 IMU 必须是两个不同的串口。')
    axes = ''.join(x for x in 'XYZ' if x in config['axes'])
    if not axes:
        raise ValueError('至少选择一个 X / Y / Z 测试轴。')
    json_path=Path(config['json_path'].strip().strip('"'))
    if not json_path.is_file():
        raise ValueError('找不到 gyro_calibration.json，请选择当前 PCB 对应的真实标定文件。')
    rates_text=config['rates'].strip().replace('，',',')
    tokens=[s.strip() for s in rates_text.split(',')]
    if not tokens or any(not t for t in tokens):
        raise ValueError('速率输入应为逗号分隔的正数，例如 1,2,3.5。')
    try:
        rates=[float(t) for t in tokens]
    except ValueError as exc:
        raise ValueError('速率必须为数字，例如 1,2,3.5。') from exc
    hardware_range=60.0  # 2TD-600 手册内、外轴速率上限；不是计量精度保证
    if any(not math.isfinite(n) or n<0.01 or n>hardware_range for n in rates):
        raise ValueError(f'目标速率须在 0.01–{hardware_range:g} °/s；超过手册范围不运行。')
    approved=config.get('high_speed_approved',False) is True
    if max(rates)>profile_max and not approved:
        raise ValueError(f'目标速率高于既有{profile_max:g}°/s工艺范围。须先现场独立验收停车/急停、加减速、线缆和连续旋转，再勾选本次高速实验确认；默认禁止运动。')
    if len(set(rates))!=len(rates):
        raise ValueError('速率不能重复。')
    if config['direction'] not in ('双向','正向','反向'):
        raise ValueError('方向应选双向、正向或反向。')
    try:
        repeats=int(config['repeats'])
        nums={key:float(config[key]) for key in ('accel','sample','settle','zero','position_speed','travel_budget')}
    except ValueError as exc:
        raise ValueError('重复次数和实验时间、速度、加速度参数需要输入数字。') from exc
    if not 1<=repeats<=20:
        raise ValueError('重复次数范围 1–20。')
    limits={'accel':(.05,20),'sample':(1,30),'settle':(1,30),'zero':(20,120),
            'position_speed':(.1,5),'travel_budget':(20,600)}
    for k,(lo,hi) in limits.items():
        if not math.isfinite(nums[k]) or not lo<=nums[k]<=hi:
            raise ValueError(f'{k} 必须在 {lo:g}–{hi:g} 范围内。')
    use_profiles=config.get('use_rate_profiles',False) is True
    extended_approved=config.get('extended_rotation_approved',False) is True
    extended_needed=[]
    for rate in rates:
        accel,sample=resolve_rate_params(rate,use_profiles,nums['accel'],nums['sample'])
        travel=estimated_turn_deg(rate,accel,sample)
        if travel>nums['travel_budget']:
            raise ValueError(f'{rate:g}°/s：加速度{accel:g}°/s²、稳态采样{sample:g}s，'
                             f'预计含减速和余量的转角{travel:.1f}°，超过软件运动预算{nums["travel_budget"]:g}°。'
                             '请先确认可用旋转行程和线缆条件，不要简单提高预算。')
        if travel>360.:
            extended_needed.append((rate,travel))
    if (nums['travel_budget']>360. or extended_needed) and not extended_approved:
        details=('；'.join(f'{r:g}°/s约{t:.1f}°' for r,t in extended_needed)
                 if extended_needed else f'设置的软件运动预算{nums["travel_budget"]:g}°')
        raise ValueError('包含超过360°的单工况旋转需求：'+details+'。'
                         '必须确认转台该姿态允许连续旋转、滑环/线缆允许多圈运动、'
                         '且每轮重新定位不会累积缠线；完成现场核验后再勾选“超过一圈旋转许可”。')
    direction_count=2 if config['direction']=='双向' else 1
    return dict(config,tt_port=tt,imu_port=imu,axes=axes,rates=','.join(f'{x:g}' for x in rates),
                high_speed_approved=approved,use_rate_profiles=use_profiles,
                extended_rotation_approved=extended_approved,
                repeats=repeats,number_cases=len(axes)*len(rates)*direction_count*repeats)

