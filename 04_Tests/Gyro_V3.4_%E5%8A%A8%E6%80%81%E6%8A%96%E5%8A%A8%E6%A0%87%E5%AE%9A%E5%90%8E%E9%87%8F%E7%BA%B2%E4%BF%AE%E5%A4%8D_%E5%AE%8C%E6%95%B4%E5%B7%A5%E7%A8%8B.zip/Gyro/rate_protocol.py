# -*- coding: utf-8 -*-
"""实验候选的逐速率采样方案；纯配置，不连接硬件。

和 V3.1.1 原转台控制/停车 DLL 分离。该表是研发建议，不是已验收的转台加速度能力。
"""
from math import isfinite

RATE_PROTOCOL={
    15.0:(5.0,5.0),
    20.0:(5.0,5.0),
    30.0:(5.0,5.0),
    45.0:(20.0,5.0),
    60.0:(20.0,5.0),
}
RATE_GROUPS={
    '阶段一 15/20':'15,20',
    '阶段二 30/45/60':'30,45,60',
    '全方案 15–60':'15,20,30,45,60',
}

def resolve_rate_params(rate, use_protocol=False, fallback_accel=5., fallback_sample=5.):
    """返回 (accel °/s², steady_sampling_s)，未配置档位使用当前UI参数。"""
    value=float(rate)
    return RATE_PROTOCOL.get(value,(float(fallback_accel),float(fallback_sample))) if use_protocol else (float(fallback_accel),float(fallback_sample))

def estimated_turn_deg(rate,accel,sample):
    """理想加减速+0.5秒稳定判定+10°余量；仅供预检，非机械安全保障。"""
    speed, a, t=abs(float(rate)),float(accel),float(sample)
    if not all(isfinite(v) for v in (speed,a,t)) or a<=0:raise ValueError('运动预算参数无效')
    return speed*speed/a+speed*(t+0.5)+10.0

def add_rate_params(cases,use_protocol=False,default_accel=5.,default_sample=5.):
    """为各工况附加不同加速度和采样秒数；不改变坐标轴/STOP流程。"""
    for c in cases:
        acc, duration=resolve_rate_params(abs(c['target_rate_dps']),use_protocol,default_accel,default_sample)
        c['accel_dps2']=acc
        c['sample_seconds']=duration
        c['estimated_turn_deg']=round(estimated_turn_deg(c['target_rate_dps'],acc,duration),2)
        c['rate_profile']='rate_protocol_v2_5s' if use_protocol and abs(c['target_rate_dps']) in RATE_PROTOCOL else 'gui_manual'
    return cases
