# -*- coding: utf-8 -*-
"""Gyro 单独多速率测试。参照用户提供的 IMU_100位置修订版 Qt 主界面。

沿用原标定的 2TD600 DLL / IMU采集代码；由单一长驻进程管理使能、找零和Gyro多速率实测。
界面启动只显示UI；必须主动点击按钮、现场确认后才发送硬件控制命令。
"""
from __future__ import annotations
import os
import json
import re
import sys
import uuid
import threading
from datetime import datetime
from pathlib import Path
try:
    from PySide6.QtCore import Qt, QProcess, QProcessEnvironment, QThread, QTimer, Signal
    from PySide6.QtGui import QFont, QPixmap
    from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QHBoxLayout,QVBoxLayout,QGridLayout,
       QGroupBox,QLabel,QPushButton,QComboBox,QSpinBox,QDoubleSpinBox,QLineEdit,QPlainTextEdit,
       QFileDialog,QMessageBox,QProgressBar,QDialog,QScrollArea,QCheckBox,QTableWidget,QTableWidgetItem,
       QHeaderView)
except ImportError:
    from PyQt5.QtCore import Qt,QProcess,QProcessEnvironment,QThread,QTimer,pyqtSignal as Signal
    from PyQt5.QtGui import QFont,QPixmap
    from PyQt5.QtWidgets import (QApplication,QMainWindow,QWidget,QHBoxLayout,QVBoxLayout,QGridLayout,
       QGroupBox,QLabel,QPushButton,QComboBox,QSpinBox,QDoubleSpinBox,QLineEdit,QPlainTextEdit,
       QFileDialog,QMessageBox,QProgressBar,QDialog,QScrollArea,QCheckBox,QTableWidget,QTableWidgetItem,
       QHeaderView)
from ui_validators import validate_entries
from rate_protocol import RATE_PROTOCOL, resolve_rate_params, estimated_turn_deg

ROOT=Path(__file__).resolve().parent
BACKEND=ROOT/'Gyro多速率_原标定调用_实机测试.py'
SESSION_BACKEND=ROOT/'turntable_session.py'
FAULT_FILE=ROOT/'STOP故障锁定_勿删除.json'
CONFIRM='开始真实多速率实验'
STYLE='''
QMainWindow,QDialog,QWidget {background:#F5F8FC;color:#18345D;font-family:"Microsoft YaHei","微软雅黑","Arial";font-size:12px;}
QGroupBox {border:1px solid #D8E3F4;border-radius:10px;margin-top:13px;padding:13px 10px 9px 10px;background:white;font-weight:600;}
QGroupBox::title {subcontrol-origin:margin;left:13px;padding:0 6px;color:#234F9A;}
QPushButton {border:1px solid #B7CCEF;border-radius:6px;background:#EEF5FF;color:#2057AC;padding:7px 12px;font-weight:600;}
QPushButton:hover {background:#DCEBFF;}
QPushButton:disabled {color:#9AAABD;background:#ECF0F5;}
QPushButton#primary {background:#3475DA;color:white;border:1px solid #3475DA;}
QPushButton#danger {background:#FCE9E9;color:#C32626;border:1px solid #EAB0B0;}
QLineEdit,QComboBox,QSpinBox,QDoubleSpinBox,QPlainTextEdit,QTableWidget {border:1px solid #CBD8ED;border-radius:5px;background:white;padding:5px;selection-background-color:#3475DA;}
QProgressBar {border:1px solid #D0DDF0;border-radius:5px;background:#E6EDF8;min-height:19px;text-align:center;}
QProgressBar::chunk {background:#3475DA;border-radius:5px;}
'''

class IMUThread(QThread):
    """仅预览的 IMU 接收线程；正式实验启动时由主界面自动安全释放串口。"""
    sample=Signal(object)
    info=Signal(str)
    failed=Signal(str)
    disconnected=Signal()
    def __init__(self,port,parent=None):
        super().__init__(parent);self.port=port;self.halt=threading.Event();self.release_ok=False
    def run(self):
        from devices import IMU
        imu=IMU(demo=False)
        try:
            imu.open(self.port)
            self.info.emit('IMU 已打开：'+self.port+'（仅预览，不进入正式实验）')
            while not self.halt.wait(.24):
                value=imu.preview()
                if value is not None:self.sample.emit(value)
        except BaseException as exc:
            self.failed.emit(type(exc).__name__+': '+str(exc))
        finally:
            try:
                if imu.connected:imu.close()
                # 当前采集线程的设备所有权必须正常释放，GUI 才可移交给正式实验进程。
                self.release_ok=not imu.connected
            except BaseException as exc:
                self.release_ok=False
                self.failed.emit('关闭 IMU 串口异常：'+str(exc))
            self.disconnected.emit()

class Preview(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent);self.setWindowTitle('IMU 实时数据预览 — Gyro 为主');self.resize(560,300)
        ly=QVBoxLayout(self)
        self.status=QLabel('等待有效 IMU 帧');ly.addWidget(self.status)
        self.gyro=QLabel('Gyro X / Y / Z：—');self.gyro.setStyleSheet('font-size:17px;font-weight:600;color:#2057AC;');ly.addWidget(self.gyro)
        self.acc=QLabel('ACC X / Y / Z：—');ly.addWidget(self.acc)
        self.temp=QLabel('温度：—');ly.addWidget(self.temp)
        self.meta=QLabel('帧率：—');ly.addWidget(self.meta)
        note=QLabel('这里仅显示原始 IMU 预览；点击开始测试后将自动移交串口，实验后端重新连接并采集正式数据。')
        note.setWordWrap(True);ly.addWidget(note)
        btn=QPushButton('关闭预览窗口（IMU连接保持）');btn.clicked.connect(self.close);ly.addWidget(btn)
    def receive(self,v):
        ok=bool(v.get('valid',False));self.status.setText('● 有效实时数据' if ok else '● 无有效新帧 / 通信异常')
        self.status.setStyleSheet('color:#168044' if ok else 'color:#C32626')
        if 'gyro' in v:
            self.gyro.setText('Gyro (°/s)： X {:+.5f}    Y {:+.5f}    Z {:+.5f}'.format(*v['gyro']))
        if 'acc' in v:self.acc.setText('ACC (g)：  X {:+.5f}    Y {:+.5f}    Z {:+.5f}'.format(*v['acc']))
        self.temp.setText('温度：{:.2f} °C'.format(float(v.get('temp',0))))
        self.meta.setText('接收帧率：{:.1f} fps  |  累计帧：{}  |  最近有效帧：{:.2f} s'.format(
            float(v.get('rate',0)),v.get('frames',0),float(v.get('age',0))))

class ConfirmDialog(QDialog):
    def __init__(self,number,requires_extended_rotation=False,parent=None):
        super().__init__(parent)
        self.setWindowTitle('确认真实 Gyro 多速率实验');self.resize(610,360)
        lay=QVBoxLayout(self)
        title=QLabel(f'本次将实际控制 2TD-600 转台执行 {number} 组工况')
        title.setStyleSheet('font-size:16px;font-weight:600;');lay.addWidget(title)
        body=QLabel('本次将复用当前已连接、使能且完成双轴找零的转台控制会话；不会重复打开串口或重复找零。'
                    '自动执行：IMU采集 → 转台定位 → 多档匀速运动 → 当前轴STOP → 双轴停稳反馈。\n\n'
                    '历史设备曾出现 STOP 后仍继续运动。只有现场确认软件停车功能、机械限位与独立硬件急停均有效后，才允许运行。\n'
                    '检查 PCB 夹具、转台双轴、电缆缠绕风险，并始终有人值守。')
        body.setWordWrap(True);lay.addWidget(body)
        if requires_extended_rotation:
            warning=QLabel('【超过360°的旋转】本次存在多圈运动：已确认实际安装姿态、滑环/线缆走线可安全连续旋转，且反复定位不会累积缠线；'
                           '600°只是软件每段角度预算，不是机械限位或厂家能力认证。')
            warning.setWordWrap(True);warning.setStyleSheet('color:#B52323;font-weight:700;')
            lay.addWidget(warning)
        lay.addWidget(QLabel(f'请输入「{CONFIRM}」后才能启动：'))
        self.entry=QLineEdit();lay.addWidget(self.entry)
        buttons=QHBoxLayout();lay.addLayout(buttons)
        cancel=QPushButton('取消');cancel.clicked.connect(self.reject)
        proceed=QPushButton('确认并启动');proceed.setObjectName('primary');proceed.clicked.connect(self.accept_if_valid)
        buttons.addStretch();buttons.addWidget(cancel);buttons.addWidget(proceed)
    def accept_if_valid(self):
        if self.entry.text().strip()!=CONFIRM:
            QMessageBox.warning(self,'输入不匹配','未启动真实转台运动。')
            return
        self.accept()

class Main(QMainWindow):
    def __init__(self):
        super().__init__();self.setWindowTitle('IMU Gyro 多速率独立验证 — 2TD600 实机测试');self.resize(1510,900)
        self.setStyleSheet(STYLE)
        self.proc=None;self.proc_mode=None;self.pending='';self.log_path=None;self.stop_file=None
        self.imu_worker=None;self.preview=None;self.last_folder=None;self.cal=None;self.progress_cases=0
        self.pending_live_cfg=None  # 等待 IMU 预览线程完全退出后再交给正式采集后端
        self.live_command_pending=False  # 等待正式测试后台接收/处理，防止重复提交
        self.last_error='';self.out_root=ROOT/'实测结果'
        self.session_proc=None;self.session_pending='';self.session_after_ready=None
        self.session_ready=False;self.session_connected=False;self.session_enabled=False;self.session_any_enabled=False
        self.session_homed=False;self.session_busy=False;self.session_testing=False
        self.session_action='';self.session_abnormal=False
        base=QWidget();self.setCentralWidget(base);horizontal=QHBoxLayout(base)
        horizontal.setContentsMargins(14,12,14,12)
        scroll=QScrollArea();scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame if hasattr(QScrollArea,'Shape') else QScrollArea.NoFrame)
        center=QWidget();self.left=QVBoxLayout(center);self.left.setSpacing(9);scroll.setWidget(center)
        horizontal.addWidget(scroll,4)
        g=QGroupBox('运行日志 / 转台状态反馈 / IMU采集信息');rl=QVBoxLayout(g)
        self.logs=QPlainTextEdit();self.logs.setReadOnly(True);self.logs.setMaximumBlockCount(6000);rl.addWidget(self.logs)
        clear=QPushButton('清空显示日志');clear.clicked.connect(self.logs.clear);rl.addWidget(clear)
        horizontal.addWidget(g,2)
        self.make_title();self.make_json();self.make_devices();self.make_config();self.make_plan();self.make_save();self.make_actions();self.make_results()
        self.left.addStretch()
        self.log('Gyro 多速率验证 Qt 界面已启动；没有发送使能、找零、运动命令。')
        self.log('和 ACC 100位置工程使用相似的分区布局，但实验项目已替换为 Gyro 多速率。')
        self.log('转台准备及实测均由单一后台会话管理：一次连接、独立使能/回零，不重复打开 COM。')
        self.refresh_ports();self.refresh_plan();self.update_turntable_buttons()
    def group(self,title):
        group=QGroupBox(title);self.left.addWidget(group);return group
    def btn(self,name,handler,kind=None):
        b=QPushButton(name)
        if kind:b.setObjectName(kind)
        b.clicked.connect(handler);return b
    def make_title(self):
        title=QLabel('IMU 陀螺仪多速率独立验证')
        title.setStyleSheet('font-size:22px;font-weight:700;color:#193D71;margin:3px;')
        self.left.addWidget(title)
        sub=QLabel('参照 ACC 多位置界面布局  |  本工程仅测 Gyro：X/Y/Z · 多速度 · 正反转 · 重复性 · 校正误差')
        sub.setStyleSheet('color:#587196;');self.left.addWidget(sub)
    def make_json(self):
        g=self.group('1. Gyro 标定参数文件');ly=QHBoxLayout(g)
        self.json_edit=QLineEdit();self.json_edit.setPlaceholderText('请选择当前 PCB 对应的 gyro_calibration.json（不重新标定）')
        ly.addWidget(self.json_edit,1);ly.addWidget(self.btn('选择 JSON…',self.choose_json));ly.addWidget(self.btn('加载并校验',self.import_json))
        self.cal_status=QLabel('未加载');ly.addWidget(self.cal_status)
    def make_devices(self):
        wrap=QWidget();w=QHBoxLayout(wrap);w.setContentsMargins(0,0,0,0);self.left.addWidget(wrap)
        g=QGroupBox('2. 转台控制 (2TD600)');w.addWidget(g,1);gl=QGridLayout(g)
        self.ttport=QComboBox();self.ttport.setEditable(True);self.ttport.addItem('COM1')
        gl.addWidget(QLabel('转台串口'),0,0);gl.addWidget(self.ttport,0,1)
        gl.addWidget(self.btn('刷新串口',self.refresh_ports),0,2)
        self.conn_btn=self.btn('连接转台',self.connect_turntable,'primary')
        self.state_btn=self.btn('读取状态',self.session_read_status)
        gl.addWidget(self.conn_btn,1,0,1,2);gl.addWidget(self.state_btn,1,2)
        self.enable_btn=self.btn('双轴使能',lambda:self.manual_action('enable'))
        self.disable_btn=self.btn('解除使能',lambda:self.manual_action('disable'))
        gl.addWidget(self.enable_btn,2,0,1,2);gl.addWidget(self.disable_btn,2,2)
        self.home_inner_btn=self.btn('内轴找零',lambda:self.manual_action('home_inner'))
        self.home_outer_btn=self.btn('外轴找零',lambda:self.manual_action('home_outer'))
        gl.addWidget(self.home_inner_btn,3,0,1,2);gl.addWidget(self.home_outer_btn,3,2)
        self.home_both_btn=self.btn('双轴依次找零并返回0°',lambda:self.manual_action('home_both'))
        gl.addWidget(self.home_both_btn,4,0,1,3)
        self.check_btn=self.btn('只读检查设备连接',self.check_devices)
        gl.addWidget(self.check_btn,5,0,1,3)
        self.ttstatus=QLabel('未连接｜打开界面不发送使能和运动指令')
        self.ttstatus.setWordWrap(True);gl.addWidget(self.ttstatus,6,0,1,3)
        self.axis_state={}
        for row,key,title in [(7,'inner','内轴 0'),(8,'outer','外轴 2')]:
            lbl=QLabel(title+'：使能— / 找零— / 角度— / 速度—')
            lbl.setWordWrap(True);self.axis_state[key]=lbl;gl.addWidget(lbl,row,0,1,3)
        note=QLabel('先连接→使能→找零→启动实验。使能、找零须专人现场确认；软件STOP不能替代硬件急停。')
        note.setWordWrap(True);gl.addWidget(note,9,0,1,3)
        g2=QGroupBox('3. IMU 串口连接与实时预览');w.addWidget(g2,1);rl=QGridLayout(g2)
        self.imuport=QComboBox();self.imuport.setEditable(True);self.imuport.addItem('COM6')
        rl.addWidget(QLabel('PCB / IMU 串口'),0,0);rl.addWidget(self.imuport,0,1)
        rl.addWidget(self.btn('刷新串口',self.refresh_ports),0,2)
        self.imu_btn=self.btn('打开串口',self.toggle_imu);rl.addWidget(self.imu_btn,1,0)
        self.preview_btn=self.btn('实时数据预览',self.show_preview);rl.addWidget(self.preview_btn,1,1,1,2)
        self.imu_status=QLabel('未连接');rl.addWidget(self.imu_status,2,0,1,3)
        lbl=QLabel('说明：可保持 IMU 预览连接。点击开始测试后软件会自动关闭预览、释放 PCB 串口，然后由实验后端重新连接并持续采集。')
        lbl.setWordWrap(True);lbl.setStyleSheet('color:#65778D;');rl.addWidget(lbl,3,0,1,3)
    def make_config(self):
        g=self.group('4. Gyro 多速率实验参数（替代 ACC 100位置姿态计划）');ly=QGridLayout(g)
        self.axes={}
        ly.addWidget(QLabel('测试方向'),0,0)
        af=QWidget();row=QHBoxLayout(af);row.setContentsMargins(0,0,0,0)
        for a in 'XYZ':
            b=QCheckBox(a);b.setChecked(True);b.toggled.connect(self.refresh_plan);self.axes[a]=b;row.addWidget(b)
        ly.addWidget(af,0,1)
        ly.addWidget(QLabel('方向'),0,2)
        self.directions=QComboBox();self.directions.addItems(['双向','正向','反向']);self.directions.currentTextChanged.connect(self.refresh_plan)
        ly.addWidget(self.directions,0,3)
        ly.addWidget(QLabel('每档重复次数'),0,4)
        self.repeats=QSpinBox();self.repeats.setRange(1,20);self.repeats.setValue(3);self.repeats.valueChanged.connect(self.refresh_plan)
        ly.addWidget(self.repeats,0,5)
        ly.addWidget(QLabel('速率列表 (°/s)'),1,0)
        self.rates=QLineEdit('15,20');self.rates.setPlaceholderText('例如：15,20,30,45,60；正反转在方向栏选择')
        self.rates.textChanged.connect(self.refresh_plan);ly.addWidget(self.rates,1,1,1,5)
        nums=[('运动加速度 °/s²','accel',5.,.05,20.),('稳定采样 s','sample',5.,1.,30.),
              ('预置姿态静置 s','settle',3.,1.,30.),('零速复核 s','zero',30.,20.,120.),
              ('定位速度 °/s','position_speed',5.,.1,5.),('单工况软件运动预算 °','travel_budget',360.,20.,600.)]
        self.numeric={}
        for j,(lab,key,default,lo,hi) in enumerate(nums):
            r=2+j//3;c=2*(j%3)
            ly.addWidget(QLabel(lab),r,c)
            spin=QDoubleSpinBox();spin.setDecimals(2);spin.setRange(lo,hi);spin.setValue(default)
            spin.setSingleStep(.5 if key not in ('accel','position_speed') else .1)
            self.numeric[key]=spin;ly.addWidget(spin,r,c+1)
        # 预设仅填写参数，不会自动使能或运动；高转速设置必须单独现场授权。
        preset=QWidget(); presets=QHBoxLayout(preset);presets.setContentsMargins(0,0,0,0)
        presets.addWidget(QLabel('预设工况：'))
        for label,values,accel,sample in [
            ('已测7.5/10复核','7.5,10',1.,5.),
            ('阶段一15/20','15,20',5.,5.),
            ('阶段二30/45/60','30,45,60',5.,5.),
            ('全部15–60','15,20,30,45,60',5.,5.),
            ('单独60','60',20.,5.)]:
            b=self.btn(label,lambda _=False, v=values, a=accel, t=sample:self.use_rate_preset(v,a,t))
            presets.addWidget(b)
        ly.addWidget(preset,4,0,1,6)
        self.per_rate_cb=QCheckBox('使用统一5秒稳态采样（推荐）：15/20/30→5°/s²；45/60→20°/s²；各速率均采5秒；其他速率用手动参数')
        self.per_rate_cb.setChecked(True);self.per_rate_cb.toggled.connect(self.refresh_plan)
        self.per_rate_cb.setToolTip('预设15/20/30/45/60°/s都采5秒有效匀速段。加速度仅为候选实验值，现场必须确认。')
        ly.addWidget(self.per_rate_cb,5,0,1,6)
        self.high_speed_cb=QCheckBox('仅本次：已完成高于10°/s的停车/急停、连续旋转、电缆和加减速现场安全验收（不等于硬件保障）')
        self.high_speed_cb.setChecked(False);self.high_speed_cb.toggled.connect(self.refresh_plan)
        ly.addWidget(self.high_speed_cb,6,0,1,6)
        self.extended_rotation_cb=QCheckBox('仅本次：已核实超过360°多圈旋转的姿态限制、滑环/线缆及重复定位不缠绕（需单独现场验收）')
        self.extended_rotation_cb.setChecked(False);self.extended_rotation_cb.toggled.connect(self.refresh_plan)
        ly.addWidget(self.extended_rotation_cb,7,0,1,6)
        msg=QLabel('所有计划速率统一采集5秒稳态数据。60°/s约需520°运动预算（含加减速、稳定确认和10°余量）；'
                   '600°是软件监测阈值，不是机械许可或限位。\n'
                   '默认按轴X→Y→Z、每速率正负交替重复3次；每工况按原V3控制定位、STOP、停车确认，不重新拟合矩阵。')
        msg.setWordWrap(True);msg.setStyleSheet('color:#806119;');ly.addWidget(msg,8,0,1,6)
        self.case_count=QLabel('工况预览：—');ly.addWidget(self.case_count,9,0,1,6)
    def make_plan(self):
        g=self.group('5. 测试工况预览（无 ACC 100位置）');ly=QVBoxLayout(g)
        self.case_table=QTableWidget(0,8)
        self.case_table.setHorizontalHeaderLabels(['序号','Gyro方向','转台驱动轴','目标速率 °/s','重复号','加速度 °/s²','稳态采样 s','预计行程 °'])
        self.case_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers if hasattr(QTableWidget,'EditTrigger') else QTableWidget.NoEditTriggers)
        self.case_table.setMaximumHeight(172)
        h=self.case_table.horizontalHeader();h.setSectionResizeMode(QHeaderView.ResizeMode.Stretch if hasattr(QHeaderView,'ResizeMode') else QHeaderView.Stretch)
        ly.addWidget(self.case_table)
    def make_save(self):
        g=self.group('6. 结果保存设置');ly=QHBoxLayout(g)
        self.out_edit=QLineEdit(str(self.out_root));ly.addWidget(QLabel('结果保存目录'));ly.addWidget(self.out_edit,1)
        ly.addWidget(self.btn('选择路径…',self.choose_out))
    def make_actions(self):
        g=self.group('7. 多速率实验操作');ly=QVBoxLayout(g);r=QHBoxLayout();ly.addLayout(r)
        self.start_btn=self.btn('▶ 开始 Gyro 多速率验证（使用已准备好的转台）',self.start_live,'primary')
        self.stop_btn=self.btn('■ 请求停止（非硬急停）',self.stop_live,'danger')
        self.stop_btn.setEnabled(False)
        self.folder_btn=self.btn('打开结果目录',self.open_folder)
        for b in [self.start_btn,self.stop_btn,self.folder_btn]:r.addWidget(b)
        self.progress=QProgressBar();self.progress.setValue(0);ly.addWidget(self.progress)
        self.status=QLabel('等待就绪：请加载标定 JSON，检查设备连接');ly.addWidget(self.status)
    def make_results(self):
        g=self.group('8. 验证结果预览（角速度误差 / 正反转 / 轴间耦合）');ly=QVBoxLayout(g)
        r=QHBoxLayout();ly.addLayout(r)
        self.chart_cb=QComboBox();self.chart_cb.currentIndexChanged.connect(self.update_chart)
        self.chart_cb.addItem('完成测试后显示结果图');r.addWidget(self.chart_cb)
        r.addWidget(self.btn('刷新结果图',self.load_images))
        self.chart=QLabel('完成实机测试并生成图表后，在此预览校正角速度与转台参考的比较。')
        self.chart.setAlignment(Qt.AlignCenter);self.chart.setMinimumHeight(180)
        ly.addWidget(self.chart)
    def log(self,s):
        msg=str(s);prefix='' if msg.startswith('[') else f'[{datetime.now():%H:%M:%S}] '
        self.logs.appendPlainText(prefix+msg)
    def alert(self,e):
        self.log('错误：'+str(e));QMessageBox.warning(self,'操作失败',str(e))
    def choose_json(self):
        p,_=QFileDialog.getOpenFileName(self,'选择 Gyro 标定 JSON','','JSON Files (*.json)')
        if p:self.json_edit.setText(p);self.import_json()
    def import_json(self):
        try:
            from core import load_gyro_calibration
            self.cal=load_gyro_calibration(self.json_edit.text().strip().strip('"'))
            self.cal_status.setText('已加载 | '+self.cal.device_serial+' | '+self.cal.axis_model)
            self.log('已读取 Gyro 原标定矩阵（不重拟合）：'+self.cal.source)
            self.log('矩阵形状 3×3，Gyro 零偏长度3；设备编号请与实际 PCB 核实。')
        except BaseException as e:
            self.cal=None;self.cal_status.setText('未校验');self.alert(e)
    def refresh_ports(self):
        try:
            import serial.tools.list_ports
            ports=[p.device for p in serial.tools.list_ports.comports()]
        except ImportError:ports=[]
        for cb,default in [(self.ttport,'COM1'),(self.imuport,'COM6')]:
            old=cb.currentText().strip() or default
            cb.clear();cb.addItems(ports or [old]);cb.setEditText(old)
    # 所有真实转台操作使用同一个长驻后台进程，避免使能后实验又重新 OpenPort。
    def _session_running(self):
        if self.session_proc is None:return False
        idle=QProcess.ProcessState.NotRunning if hasattr(QProcess,'ProcessState') else QProcess.NotRunning
        return self.session_proc.state()!=idle

    def _session_send(self,payload):
        if not self._session_running():
            self.alert('转台会话未运行，请先连接转台');return False
        try:
            data=(json.dumps(payload,ensure_ascii=False)+'\n').encode('utf-8')
            count=self.session_proc.write(data)
            if count<0:raise RuntimeError('QProcess 写入失败')
            return True
        except Exception as exc:
            self.alert('发送会话命令失败：'+str(exc));return False

    def connect_turntable(self):
        if self.session_busy or self._is_running():return
        if self.session_connected:
            if not self.session_any_enabled:
                self.manual_action('disconnect')
            else:
                self.alert('请先确认双轴停车，点击“解除使能”，然后断开转台。')
            return
        if self._session_running():
            self._session_send({'cmd':'connect','port':self.ttport.currentText().strip().upper()})
            return
        port=self.ttport.currentText().strip().upper()
        if not re.fullmatch(r'COM[1-9][0-9]*',port):self.alert('转台串口格式应如COM1');return
        if port==self.imuport.currentText().strip().upper():self.alert('转台与IMU不能共用COM口');return
        py=Path(sys.executable)
        if py.name.lower()=='pythonw.exe' and py.with_name('python.exe').exists():py=py.with_name('python.exe')
        proc=QProcess(self);self.session_proc=proc
        proc.setWorkingDirectory(str(ROOT))
        proc.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels if hasattr(QProcess,'ProcessChannelMode') else QProcess.MergedChannels)
        env=QProcessEnvironment.systemEnvironment();env.insert('PYTHONUTF8','1');env.insert('PYTHONIOENCODING','utf-8')
        proc.setProcessEnvironment(env)
        proc.readyReadStandardOutput.connect(self.read_session)
        proc.errorOccurred.connect(self.session_error)
        proc.finished.connect(self.session_finished)
        self.session_after_ready={'cmd':'connect','port':port}
        self.conn_btn.setEnabled(False)
        self.ttstatus.setText('正在创建转台后台会话（尚未使能）...')
        self.log('启动唯一控制会话：无自动使能 / 回零；待连接指令')
        proc.start(str(py),['-u',str(SESSION_BACKEND),'--live'])

    def session_error(self,_error):
        if self.session_proc is not None:
            self.log('转台会话进程异常：'+self.session_proc.errorString())

    def session_finished(self,code,_status):
        self.read_session()
        self.log(f'转台后台会话退出：代码{code}。若非主动退出，务必现场核查转台状态。')
        if self.session_connected or self.session_any_enabled:
            self.session_abnormal=True
            self.ttstatus.setText('⚠️ 后台连接丢失，转台物理状态未知！现场核查硬件急停')
        self.session_proc=None;self.session_ready=False;self.session_connected=False
        self.session_enabled=False;self.session_any_enabled=False;self.session_homed=False;self.session_busy=False;self.session_testing=False
        self.session_action='';self.session_after_ready=None
        self.live_command_pending=False;self.pending_live_cfg=None
        self.update_turntable_buttons()

    def read_session(self):
        if self.session_proc is None:return
        try:content=bytes(self.session_proc.readAllStandardOutput()).decode('utf-8',errors='replace')
        except Exception:return
        self.session_pending+=content
        while '\n' in self.session_pending:
            line,self.session_pending=self.session_pending.split('\n',1)
            if not line.strip():continue
            if line.startswith('@@TT@@'):
                try:self.session_event(json.loads(line[len('@@TT@@'):]))
                except Exception as exc:self.log('无法解析转台事件：'+str(exc))
            else:self.log('后台：'+line.strip())

    def session_event(self,event):
        kind=event.get('kind')
        if kind=='ready':
            self.session_ready=True;self.log(event.get('message','会话准备就绪'))
            if self.session_after_ready:
                command=self.session_after_ready;self.session_after_ready=None
                self._session_send(command)
        elif kind=='state':
            self.session_connected=bool(event.get('connected'))
            self.session_enabled=bool(event.get('enabled'))
            self.session_any_enabled=bool(event.get('inner',{}).get('enabled') or event.get('outer',{}).get('enabled'))
            self.session_homed=bool(event.get('homed'))
            if self.session_connected:
                self.ttstatus.setText('● 转台已连接｜双轴使能：{}｜双轴归零：{}'.format(
                    '是' if self.session_enabled else '否','是' if self.session_homed else '否'))
                for name,title in [('inner','内轴 0'),('outer','外轴 2')]:
                    s=event.get(name,{})
                    self.axis_state[name].setText('{}：使能{} / 找零{} / 位置{:+.3f}° / 速率{:+.3f}°/s / {}'.format(
                        title,'是' if s.get('enabled') else '否','是' if s.get('homed') else '否',
                        float(event.get(name+'_deg',0)),float(s.get('speed',0)),s.get('mode','未知')))
            else:
                self.ttstatus.setText('未连接（打开界面不会使能或运动）')
                for name,title in [('inner','内轴 0'),('outer','外轴 2')]:self.axis_state[name].setText(title+'：使能— / 找零— / 角度— / 速度—')
            self.update_turntable_buttons()
        elif kind=='busy':
            self.session_busy=bool(event.get('busy'))
            self.session_testing=bool(event.get('testing'))
            self.session_action=str(event.get('action','')) if self.session_busy else ''
            if self.session_busy:self.status.setText('转台正在执行：'+self.session_action)
            self.update_turntable_buttons()
        elif kind=='log':self.log(event.get('message',''))
        elif kind=='error':
            if event.get('action')=='run':self.live_command_pending=False
            self.log('操作失败 [{}]：{}'.format(event.get('action',''),event.get('message','')))
            self.status.setText('转台操作失败，请检查日志和设备状态')
        elif kind=='fatal':
            self.session_abnormal=True
            self.log('⚠️ 严重硬件异常：'+event.get('message',''))
            self.ttstatus.setText('严重告警：'+event.get('message',''))
        elif kind=='status_error':self.log('反馈状态异常：'+event.get('message',''))
        elif kind=='done':
            if event.get('action')=='run':self.live_command_pending=False
            if event.get('success') and event.get('action')=='run':
                self.log('本次实验进程已返回，检查报告及停稳反馈')
            elif event.get('success'):self.log('操作完成：'+str(event.get('action')))
        elif kind=='progress':
            current,total=int(event.get('current',0)),max(1,int(event.get('total',1)))
            self.progress.setValue(int(100*current/total))
            self.status.setText(f'Gyro多速率：完成 {current}/{total} 组')
        elif kind=='progress_text':self.status.setText(event.get('message','测试中'))
        elif kind=='imu_state':
            phase=event.get('phase','')
            port=event.get('port','')
            if phase=='acquiring':
                self.imu_status.setText('● 正式采集已连接 {} | {:.1f} 帧/秒'.format(port,float(event.get('fps',0))))
                self.log('IMU 正式采集正在接收数据；预览窗口关闭不影响实验采集。')
            elif phase=='closed':
                self.imu_status.setText('本次正式采集已结束（端口释放）')
        elif kind=='result':
            f=event.get('folder')
            if f:self.last_folder=Path(f)
            self.log('Gyro 任务结果：'+str(event))
        elif kind=='finished':
            f=event.get('folder')
            if f:self.last_folder=Path(f)
            success=bool(event.get('success'))
            self.status.setText('Gyro多速率测试已完成' if success else 'Gyro多速率测试不完整；需排查')
            if success:self.progress.setValue(100)
            self.load_images()

    def update_turntable_buttons(self):
        if not hasattr(self,'conn_btn'):return
        idle=not self.session_busy and not self._is_running()
        ready=idle and self.session_connected
        self.conn_btn.setText('断开转台' if self.session_connected else '连接转台')
        self.conn_btn.setEnabled(idle and (self.session_proc is None or self.session_ready))
        self.ttport.setEnabled(not self.session_connected and idle)
        self.state_btn.setEnabled(self.session_connected)
        self.enable_btn.setEnabled(ready and not self.session_any_enabled and not self.session_abnormal)
        self.disable_btn.setEnabled(ready and self.session_any_enabled)
        for btn in (self.home_inner_btn,self.home_outer_btn,self.home_both_btn):
            btn.setEnabled(ready and self.session_enabled and not self.session_abnormal)
        self.start_btn.setEnabled(ready and self.session_enabled and self.session_homed and not self.session_abnormal and not self.live_command_pending)
        self.stop_btn.setEnabled(self.session_busy and self.session_action in ('run','home_inner','home_outer','home_both'))
        self.check_btn.setEnabled(idle and not self.session_connected)
        self.imu_btn.setEnabled(not self.session_testing and not self._is_running() and self.pending_live_cfg is None)
        if self.pending_live_cfg is not None or self.live_command_pending:self.start_btn.setEnabled(False)

    def session_read_status(self):
        if self.session_connected:
            # A long operation continuously publishes status; no extra control calls needed.
            if not self.session_busy:self._session_send({'cmd':'status'})
        else:self.alert('请先点击连接转台')

    def manual_action(self,action):
        if not self.session_connected or self.session_busy:return
        if action.startswith('home_') or action=='enable':
            if FAULT_FILE.exists():self.alert('存在 STOP 故障锁，禁止使能/找零');return
            if QMessageBox.question(self,'现场设备操作确认',
                '该操作将向真实转台下发'+('找零/移动指令' if action.startswith('home_') else '双轴使能指令')+'。\n'
                '请确认原厂软件已关闭、夹具和线缆无干涉，软件STOP和独立硬件急停已现场验收。\n'
                '是否执行？')!=QMessageBox.Yes:return
        elif action in ('disable','disconnect'):
            if QMessageBox.question(self,'现场转台状态确认',
                 '执行前应通过实时反馈及现场观察确认两轴已停车。\n是否继续？')!=QMessageBox.Yes:return
        self._session_send({'cmd':action})

    def _is_running(self):
        if self.proc is None:return False
        idle=QProcess.ProcessState.NotRunning if hasattr(QProcess,'ProcessState') else QProcess.NotRunning
        return self.proc.state()!=idle
    def check_devices(self):
        if self.session_connected:
            self.session_read_status();self.log('转台已由本程序连接；如需同时检查IMU，可使用右侧“打开串口/实时预览”。');return
        if self._session_running():self.alert('请先结束后台转台会话，避免重复打开DLL端口。');return
        if self._is_running():return
        if self.imu_worker is not None and self.imu_worker.isRunning():
            self.alert('请先关闭 IMU 实时预览串口，然后执行双串口只读检查。');return
        tt=self.ttport.currentText().strip().upper();im=self.imuport.currentText().strip().upper()
        if not self._valid_ports(tt,im):return
        self.ttstatus.setText('正在只读检查转台和 IMU，不发送使能指令...')
        self.start_proc('precheck',['--precheck','--tt-port',tt,'--imu-port',im])
    def _valid_ports(self,tt,im):
        if not re.fullmatch(r'COM[1-9][0-9]*',tt) or not re.fullmatch(r'COM[1-9][0-9]*',im) or tt==im:
            self.alert('请填写不同的有效 COM 端口号（例如转台 COM1、PCB COM6）。');return False
        return True
    def toggle_imu(self):
        if self.pending_live_cfg is not None:
            self.alert('IMU 串口正在自动交接给正式实验程序，请勿重复操作。');return
        if self._is_running() or self.session_testing:
            self.alert('后台正在检查或正式采集，无法同时打开IMU预览串口。');return
        if self.imu_worker is not None and self.imu_worker.isRunning():
            self.imu_worker.halt.set();self.imu_btn.setEnabled(False);self.imu_status.setText('正在关闭 IMU 串口...')
            return
        port=self.imuport.currentText().strip().upper()
        if not re.fullmatch(r'COM[1-9][0-9]*',port):self.alert('IMU 串口应为 COM6 等格式');return
        self.imu_worker=IMUThread(port,self)
        self.imu_worker.sample.connect(self.on_imu)
        self.imu_worker.info.connect(self.on_imu_info)
        self.imu_worker.failed.connect(self.on_imu_error)
        self.imu_worker.disconnected.connect(self.on_imu_closed)
        self.imu_worker.finished.connect(self.on_imu_finished)
        self.imu_btn.setText('关闭串口');self.imu_status.setText('正在连接 IMU...')
        self.imu_worker.start()
    def on_imu_info(self,s):self.log(s);self.imu_status.setText('IMU 已打开，正在接收...')
    def on_imu_error(self,s):self.log('IMU 连接/接收异常：'+s);self.imu_status.setText('IMU 通信异常：'+s)
    def on_imu(self,v):
        if v.get('valid'):
            self.imu_status.setText('● Gyro 实时接收正常  | {:.1f} 帧/秒'.format(float(v.get('rate',0))))
        else:self.imu_status.setText('● IMU 已打开但无有效新数据')
        if self.preview is not None and self.preview.isVisible():self.preview.receive(v)
    def on_imu_finished(self):
        worker=self.imu_worker
        release_ok=bool(worker is not None and worker.release_ok)
        self.imu_worker=None
        if worker is not None:worker.deleteLater()
        if self.pending_live_cfg is not None:
            if not release_ok:
                self.pending_live_cfg=None
                self.log('❌ IMU 预览串口释放没有得到确认，禁止启动正式实验。请检查通信日志和设备管理器。')
                self.imu_status.setText('串口释放失败；未开始实验')
                self.update_turntable_buttons()
                return
            self.log('IMU 预览采集线程已结束、串口资源已释放；即将由 Gyro 实测模块重新连接。')
            # 让 Windows 端口句柄释放处理完成。设备后端还会单独校验帧率，才允许转台运动。
            QTimer.singleShot(400,self._finish_imu_handoff)
        else:
            self.update_turntable_buttons()
    def on_imu_closed(self):
        if self.pending_live_cfg is not None:
            self.log('IMU 预览采集已退出，等待释放完成后交给正式采集模块。')
            self.imu_status.setText('正在移交 IMU 串口…')
        else:
            self.log('IMU 预览串口已关闭。')
            self.imu_status.setText('预览已关闭')
        self.imu_btn.setText('打开串口')
        self.update_turntable_buttons()
    def _finish_imu_handoff(self):
        cfg=self.pending_live_cfg
        if cfg is None:return
        self.pending_live_cfg=None
        if self.imu_worker is not None:
            self.log('❌ IMU 预览采集线程仍在运行，取消启动，防止COM串口重复占用。')
            self.update_turntable_buttons();return
        self._launch_live(cfg)
    def _handoff_timeout(self):
        if self.pending_live_cfg is None:return
        self.pending_live_cfg=None
        self.log('❌ IMU 预览线程15秒内未正常释放端口，取消实验启动；没有下发速率运动命令。')
        self.imu_status.setText('IMU 预览释放超时；实验未启动')
        self.update_turntable_buttons()
    def show_preview(self):
        if self.imu_worker is None or not self.imu_worker.isRunning():
            self.alert('请先点击“打开串口”，确认 IMU 能持续接收真实 Gyro 帧。');return
        if self.preview is None:self.preview=Preview(self)
        self.preview.show();self.preview.raise_()
    def use_rate_preset(self, values, accel, sample):
        # 仅修改UI编辑框；不下发任何控制命令。现场授权每次启动前仍需人工勾选。
        self.rates.setText(values)
        self.numeric['accel'].setValue(accel)
        self.numeric['sample'].setValue(sample)
        self.numeric['travel_budget'].setValue(600. if any(float(t)>=60. for t in values.split(',')) else 360.)
        self.per_rate_cb.setChecked(True)
        self.high_speed_cb.setChecked(False)
        self.extended_rotation_cb.setChecked(False)
        self.refresh_plan()
        self.log('已加载速率计划示例 {}°/s；各档预设统一5秒，候选加速度待现场核准。'
                 '运动预算={:g}°；多圈旋转现场确认默认未勾选，未下发运动。'.format(
                     values,self.numeric['travel_budget'].value()))

    def refresh_plan(self,*_):
        axes=[a for a in 'XYZ' if a in self.axes and self.axes[a].isChecked()]
        tokens=[s.strip() for s in self.rates.text().replace('，',',').split(',') if s.strip()] if hasattr(self,'rates') else []
        try:rates=[float(r) for r in tokens]
        except ValueError:rates=[]
        signs=(1,-1) if self.directions.currentText()=='双向' else ((1,) if self.directions.currentText()=='正向' else (-1,))
        plans=[]
        for a in axes:
            for r in rates:
                accel,sample=resolve_rate_params(r,self.per_rate_cb.isChecked(),
                    self.numeric['accel'].value(),self.numeric['sample'].value())
                for n in range(1,self.repeats.value()+1):
                    for sign in signs:
                        plans.append((len(plans)+1,a,'内轴' if a=='Z' else '外轴',
                            f'{r*sign:+g}',n,f'{accel:g}',f'{sample:g}',
                            f'{estimated_turn_deg(r,accel,sample):.1f}'))
        max_rate=max(rates,default=0.)
        auth_note=('高于10°/s：已勾选本次现场核查' if self.high_speed_cb.isChecked() else '高于10°/s：尚未授权，禁止运动') if max_rate>10 else '既有≤10°/s档'
        need_ext=any(estimated_turn_deg(r,*resolve_rate_params(r,self.per_rate_cb.isChecked(),
                            self.numeric['accel'].value(),self.numeric['sample'].value()))>360. for r in rates)
        ext_note=('需确认多圈旋转：已勾选现场核验' if self.extended_rotation_cb.isChecked()
                  else '需确认多圈旋转：尚未授权') if (need_ext or self.numeric['travel_budget'].value()>360) else '预计不超过一圈'
        self.case_count.setText(f'工况预览：{len(plans)} 组  |  测试方向：{",".join(axes) or "未选"}  |  {auth_note}  |  {ext_note}')
        self.case_table.setRowCount(min(100,len(plans)))
        for i,plan in enumerate(plans[:100]):
            for j,val in enumerate(plan):self.case_table.setItem(i,j,QTableWidgetItem(str(val)))
        if len(plans)>100:self.case_count.setText(self.case_count.text()+'（表格显示前100组，实际将执行全部计划）')
    def config(self):
        return dict(tt_port=self.ttport.currentText().strip(),imu_port=self.imuport.currentText().strip(),
                    json_path=self.json_edit.text().strip(), axes=''.join(a for a in 'XYZ' if self.axes[a].isChecked()),
                    rates=self.rates.text(),direction=self.directions.currentText(),repeats=str(self.repeats.value()),
                    high_speed_approved=self.high_speed_cb.isChecked(),
                    extended_rotation_approved=self.extended_rotation_cb.isChecked(),
                    use_rate_profiles=self.per_rate_cb.isChecked(),
                    **{k:str(v.value()) for k,v in self.numeric.items()}, output_dir=self.out_edit.text().strip())
    def choose_out(self):
        p=QFileDialog.getExistingDirectory(self,'选择结果保存目录',self.out_edit.text())
        if p:self.out_edit.setText(p)
    def start_live(self):
        if self._is_running() or self.session_busy or self.live_command_pending:return
        if FAULT_FILE.exists():
            self.alert('检测到历史 STOP 故障锁：'+str(FAULT_FILE)+'；须先由设备负责人排查并完成现场验收。');return
        if not self.session_connected or not self.session_enabled or not self.session_homed:
            self.alert('请按“连接转台→双轴使能→双轴依次找零”准备设备，并确认双轴回到0°，再开始测试。');return
        if self.session_abnormal:self.alert('转台会话曾发生严重异常，不允许继续运动');return
        if self.pending_live_cfg is not None:
            self.alert('IMU 正在交接给正式采集后端，请等待状态确认。');return
        try:
            cfg=validate_entries(self.config())
            from core import load_gyro_calibration
            self.cal=load_gyro_calibration(cfg['json_path'])
            if not cfg['output_dir'].strip():raise ValueError('请选择结果保存根目录')
            if not self._valid_ports(cfg['tt_port'].strip().upper(),cfg['imu_port'].strip().upper()):return
        except BaseException as exc:self.alert(exc);return
        confirm=ConfirmDialog(cfg['number_cases'],requires_extended_rotation=float(cfg['travel_budget'])>360.,parent=self)
        confirm.setWindowTitle('高于10°/s：受控扩展转速验证（必须现场监护）' if max(float(x) for x in cfg['rates'].split(','))>10 else 'Gyro原速率验证')
        accepted=confirm.exec() if hasattr(confirm,'exec') else confirm.exec_()
        if not accepted:return
        # 现场授权仅对当前这一轮cfg有效；不在GUI中留存可复用的高速授权。
        if cfg.get('high_speed_approved',False):
            self.high_speed_cb.setChecked(False)
        if cfg.get('extended_rotation_approved',False):
            self.extended_rotation_cb.setChecked(False)
        output=Path(cfg['output_dir']).expanduser()
        try:output.mkdir(parents=True,exist_ok=True)
        except BaseException as exc:self.alert('输出目录无法创建：'+str(exc));return
        self.out_root=output
        self.progress_cases=cfg['number_cases'];self.progress.setValue(0)
        if self.imu_worker is not None:
            self.pending_live_cfg=cfg
            self.start_btn.setEnabled(False);self.imu_btn.setEnabled(False)
            self.status.setText('IMU 串口交接中：停止预览，待正式采集重新连接…')
            self.imu_status.setText('预览 → 正式采集：正在释放串口')
            self.log('自动交接 IMU 串口：停止预览线程并等待完全关闭，随后由后台重新打开并检查实际帧率。')
            self.imu_worker.halt.set()
            QTimer.singleShot(15000,self._handoff_timeout)
            return
        self._launch_live(cfg)

    def _launch_live(self,cfg):
        if self.session_busy or not self.session_connected or not self.session_enabled or not self.session_homed or self.session_abnormal or FAULT_FILE.exists():
            self.log('❌ 转台准备状态已改变或存在故障锁，取消提交实验命令。')
            self.update_turntable_buttons();return
        if self.imu_worker is not None:
            self.log('❌ IMU 预览线程尚未完全释放，取消正式测试。')
            self.update_turntable_buttons();return
        self.imu_status.setText('正式实验后端正在连接 PCB / 等待真实 Gyro 帧…')
        self.log('启动同一转台会话内的 Gyro 多速率验证：不重新 OpenPort / 使能 / 找零；IMU由正式采集模块重新打开。')
        self.live_command_pending=True
        self.start_btn.setEnabled(False)
        if not self._session_send({'cmd':'run','config':cfg}):
            self.live_command_pending=False
            self.imu_status.setText('正式实验启动失败；IMU 未交给后台')
            self.update_turntable_buttons()

    def start_proc(self,mode,args):
        if self._is_running():return
        self.proc_mode=mode;self.pending='';self.last_error=''
        d=ROOT/'GUI_运行日志';d.mkdir(exist_ok=True)
        self.log_path=d/f'GUI_{mode}_{datetime.now():%Y%m%d_%H%M%S}.log'
        py=Path(sys.executable)
        if py.name.lower()=='pythonw.exe' and py.with_name('python.exe').exists():py=py.with_name('python.exe')
        proc=QProcess(self);self.proc=proc;proc.setWorkingDirectory(str(ROOT))
        proc.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels if hasattr(QProcess,'ProcessChannelMode') else QProcess.MergedChannels)
        env=QProcessEnvironment.systemEnvironment();env.insert('PYTHONUTF8','1');env.insert('PYTHONIOENCODING','utf-8')
        proc.setProcessEnvironment(env)
        proc.readyReadStandardOutput.connect(self.read_proc)
        proc.errorOccurred.connect(self.process_error)
        proc.finished.connect(self.proc_finished)
        self.start_btn.setEnabled(False);self.check_btn.setEnabled(False)
        self.imu_btn.setEnabled(False);self.stop_btn.setEnabled(mode=='live')
        self.status.setText('真实 Gyro 实验运行中' if mode=='live' else '只读通信检查中')
        self.log('正在启动原标定后端：'+('只读双串口检查'))
        proc.start(str(py),['-u',str(BACKEND),*args])
        # 等待 Python 创建进程，仅确认子进程已启动；不代表真实设备使能成功。
        if not proc.waitForStarted(3500):
            self.log('子进程未能启动：'+proc.errorString())
            self.proc=None;self.set_idle();return
        proc.closeWriteChannel()  # 该子进程仅用于只读双串口预检
    def read_proc(self):
        if self.proc is None:return
        try:data=bytes(self.proc.readAllStandardOutput()).decode('utf-8',errors='replace')
        except BaseException:return
        self.pending+=data
        while '\n' in self.pending:
            ln,self.pending=self.pending.split('\n',1)
            if ln.strip():self.on_line(ln.strip())
    def on_line(self,line):
        self.log(line)
        if self.log_path:
            with self.log_path.open('a',encoding='utf-8') as f:f.write(line+'\n')
        m=re.search(r'工况\s*(\d+)\s*/\s*(\d+)',line)
        if m:
            now,total=int(m.group(1)),int(m.group(2))
            self.progress.setValue(int(100*max(0,now-1)/max(1,total)))
            self.status.setText(f'Gyro 速率测试：第 {now}/{total} 组')
        if '完成工况' in line:
            p=re.search(r'完成工况\s*(\d+)',line)
            if p:self.progress.setValue(int(100*int(p.group(1))/max(1,self.progress_cases)))
        if '转台已连接' in line:self.ttstatus.setText(line[-115:])
        if 'IMU连接成功' in line:self.imu_status.setText('只读检查通过：'+line[-110:])
        if '原标定顺序使能反馈' in line:self.ttstatus.setText(line[-110:])
        if '实测数据路径：' in line:
            self.last_folder=Path(line.split('实测数据路径：',1)[1].strip())
            self.load_images()
        if '全部实际工况完成' in line:self.progress.setValue(100)
        if ('⚠️' in line or '❌' in line or '严重告警' in line):self.last_error=line
    def process_error(self,_error):
        if self.proc is not None:self.log('后端进程异常：'+self.proc.errorString())
    def proc_finished(self,code,_status):
        self.read_proc()
        if self.pending.strip():self.on_line(self.pending.strip());self.pending=''
        self.log(f'进程结束：返回码 {code}。日志文件：{self.log_path}')
        if self.proc_mode=='precheck':
            self.ttstatus.setText('只读检查通过（未使能）' if code==0 else '只读检查失败，查看右侧日志')
        if code==0 and self.proc_mode=='live':
            self.progress.setValue(100);self.status.setText('Gyro 多速率实机测试全部完成，结果已保存')
        elif code==0:self.status.setText('只读双串口检查通过')
        else:self.status.setText(f'任务中止或失败（代码 {code}）；请先确认转台已安全停车')
        self.proc=None;self.set_idle();self.load_images()
    def set_idle(self):
        self.start_btn.setEnabled(True);self.check_btn.setEnabled(True)
        self.imu_btn.setEnabled(True);self.stop_btn.setEnabled(False)
        self.update_turntable_buttons()
    def stop_live(self):
        if not self.session_busy or self.session_action not in ('run','home_inner','home_outer','home_both'):return
        if QMessageBox.question(self,'软件停止请求',
          '将通知当前转台控制会话取消找零/停止后续实验，并尝试原厂DLL停车与反馈检查。\n\n'
          '这不是硬件急停；如果转台仍旋转，必须现场使用独立急停。\n确认请求停止？')!=QMessageBox.Yes:return
        self._session_send({'cmd':'stop'})
        self.stop_btn.setEnabled(False)
        self.log('已发出停止请求；软件返回并不代表电机实际停稳。')

    def open_folder(self):
        p=self.last_folder if self.last_folder and self.last_folder.exists() else Path(self.out_edit.text().strip())
        if not p.exists():self.alert('输出目录尚未生成：'+str(p));return
        try:
            import subprocess
            if os.name=='nt':os.startfile(str(p))
            elif sys.platform=='darwin':subprocess.Popen(['open',str(p)])
            else:subprocess.Popen(['xdg-open',str(p)])
        except BaseException as e:self.alert(e)
    def load_images(self):
        if self.last_folder is None or not self.last_folder.exists():return
        imgs=sorted((self.last_folder/'对比图').glob('*.png'))
        self.chart_cb.blockSignals(True);self.chart_cb.clear()
        if not imgs:self.chart_cb.addItem('未发现可预览图表（实验可能未完成）')
        for image in imgs:self.chart_cb.addItem(image.name,str(image))
        self.chart_cb.blockSignals(False);self.update_chart()
    def update_chart(self,*_):
        p=self.chart_cb.currentData()
        if p and Path(p).exists():
            pix=QPixmap(p)
            self.chart.setPixmap(pix.scaled(840,300,Qt.KeepAspectRatio,Qt.SmoothTransformation))
    def closeEvent(self,event):
        if self.pending_live_cfg is not None:
            QMessageBox.warning(self,'IMU 正在交接','正式测试正在等待 IMU 预览串口释放；请等待交接结束后再关闭软件。')
            event.ignore();return
        if self._is_running() or self.session_busy:
            QMessageBox.warning(self,'操作尚未结束','后台仍在进行检查、找零或实验。请先受控停止、确认两轴停稳后再关闭。')
            event.ignore();return
        if self.session_connected or self.session_any_enabled:
            QMessageBox.warning(self,'转台仍被连接','请先确认停稳，解除双轴使能，再点击“断开转台”。不能在连接状态下直接关闭软件。')
            event.ignore();return
        if self.imu_worker is not None and self.imu_worker.isRunning():
            self.imu_worker.halt.set()
            if not self.imu_worker.wait(5000):
                QMessageBox.warning(self,'IMU 尚未停止','串口采集线程未退出，请排查。')
                event.ignore();return
        if self._session_running():
            self._session_send({'cmd':'exit'})
            self.session_proc.closeWriteChannel()
            if not self.session_proc.waitForFinished(2500):
                QMessageBox.warning(self,'后台未退出','转台后台会话尚未正常退出，请检查状态，避免强制关闭。')
                event.ignore();return
        event.accept()

def main():
    app=QApplication.instance() or QApplication(sys.argv)
    app.setFont(QFont('Microsoft YaHei',10))
    w=Main();w.show()
    sys.exit(app.exec() if hasattr(app,'exec') else app.exec_())

if __name__=='__main__':main()
