# -*- coding: utf-8 -*-
"""Software-only regression, no COM / DLL activity."""
from __future__ import annotations
import sys,time,math,json,tempfile
from pathlib import Path
import numpy as np
from devices import Turntable
from vendor.production_calibration import load_profile,robust_segment
from gyro_engine import build_gyro_cases

def static_qc(noise=0.47, drift=0):
    profile=load_profile(Path(__file__).parent/'vendor')
    assert profile['quality']['static_gyro_std_max_dps']==0.45
    times=np.arange(0,30,0.02)
    rng=np.random.default_rng(2244)
    raw=rng.normal(0,noise,(len(times),3)) + np.linspace(0,drift,len(times))[:,None]
    frames=[{'acc':[0.,0.,1.], 'gyro':raw[j].tolist(),'inner_rate_dps':0,
             'outer_rate_dps':0,'inner_deg':0,'outer_deg':0,'temp_c':25,
             'sample_time_s':float(t)} for j,t in enumerate(times)]
    report=robust_segment(frames,'static',profile,static_sensor='gyro',expected_seconds=30)
    return report

s=static_qc(.47,0)
assert s['gyro_zero_quality']['decision']=='ACCEPT_WITH_NOISE_WARNING',s
assert s['gyro_zero_quality']['noise_warning']
try:
    static_qc(.47,1.5)
except ValueError as exc:
    assert '均值' in str(exc) or '零偏' in str(exc),str(exc)
else:
    raise AssertionError('QC should reject large drift')
assert len(build_gyro_cases((4.5,6),1))==12

class FakeDLL:
    def __init__(self,tt):self.tt=tt;self.calls=[]
    def twoTD600_SetAxisEnable(self,axis):
        self.calls.append(('en',axis));self.tt.state['inner_enabled' if axis==0 else 'outer_enabled']=True;return True
    def twoTD600_SetAxisDisable(self,axis):
        self.calls.append(('dis',axis));self.tt.state['inner_enabled' if axis==0 else 'outer_enabled']=False;return True

t=Turntable(demo=False)
t.connected=True
t.state={f'{a}_{flag}':False for a in ('inner','outer') for flag in ['enabled','locked','up_limit','down_limit','over_speed','over_diff','driver_fault','over_voltage']}
t.state.update(inner_speed=0.,outer_speed=0.,inner_mode='静止',outer_mode='静止',inner_normal=True,outer_normal=True)
t.read=lambda :t.state.copy()
t.require_motion_authorized=lambda: None
t.wait_initial_state_ready=lambda **kw:t.read()
t._pause_feedback_for_original_calibration_command=lambda: None
t._restart_feedback_after_original_calibration_command=lambda: None
t._wait_enabled_flags=lambda expect,timeout=5.: t.state.copy() if all(t.state[x+'_enabled']==expect for x in ['inner','outer']) else (_ for _ in ()).throw(RuntimeError('bad flags'))
t.m=FakeDLL(t)
t.enable()
assert t.m.calls==[('en',0),('en',2)],t.m.calls
assert t.enabled
t.disable()
assert t.m.calls[-2:]==[('dis',0),('dis',2)]
assert not t.enabled
# Partial disable: ensure it doesn't wrongly treat still-enabled axis as disabled.
t.state['inner_enabled']=True;t.state['outer_enabled']=False;t.enabled=True
t.disable()
assert t.m.calls[-1]==('dis',0)
assert not t.enabled
print('PASS: calibrated static QC warning vs drift rejection; plan 12; original axis enable/disable order, partial state')
