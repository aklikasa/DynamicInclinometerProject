# -*- coding: utf-8 -*-
"""V3.3 统一5秒匀速采样计划：纯离线检查，绝不打开 COM、转台 DLL 或电机。"""
from pathlib import Path
from tempfile import TemporaryDirectory
from ui_validators import validate_entries
from rate_protocol import RATE_PROTOCOL, add_rate_params, estimated_turn_deg,resolve_rate_params
from gyro_engine import build_gyro_cases


def rejected(config,required_fragment=None):
    try:
        validate_entries(config)
    except ValueError as exc:
        if required_fragment:
            assert required_fragment in str(exc),(required_fragment,str(exc))
        return str(exc)
    raise AssertionError('A forbidden config was accepted')

with TemporaryDirectory() as tmp:
    cfg=dict(tt_port='COM1',imu_port='COM6',axes='XYZ',json_path=str(Path(tmp)/'gyro_calibration.json'),
             direction='双向',repeats='3',accel='5',sample='5',settle='3',zero='30',
             position_speed='5',travel_budget='600',rates='15,20,30,45,60',
             high_speed_approved=True,extended_rotation_approved=True,use_rate_profiles=True)
    Path(cfg['json_path']).write_text('{}',encoding='utf-8')
    valid=validate_entries(cfg)
    assert valid['number_cases']==90
    assert valid['use_rate_profiles'] and valid['extended_rotation_approved']
    cases=build_gyro_cases([15,20,30,45,60],3)
    assert len(cases)==90
    assert [x['direction'] for x in cases[:30]]==['X']*30
    assert [x['direction'] for x in cases[30:60]]==['Y']*30
    assert [x['direction'] for x in cases[60:]]==['Z']*30
    assert [(x['target_rate_dps'],x['repeat']) for x in cases[:6]]==[
            (15.,1),(-15.,1),(15.,2),(-15.,2),(15.,3),(-15.,3)]
    add_rate_params(cases,True)
    expected={15.:(5.,5.),20.:(5.,5.),30.:(5.,5.),45.:(20.,5.),60.:(20.,5.)}
    assert RATE_PROTOCOL==expected
    for c in cases:
        r=abs(c['target_rate_dps'])
        assert (c['accel_dps2'],c['sample_seconds'])==expected[r]
        assert c['rate_profile']=='rate_protocol_v2_5s'
        assert c['estimated_turn_deg']==round(estimated_turn_deg(r,c['accel_dps2'],c['sample_seconds']),2)
        assert estimated_turn_deg(r,c['accel_dps2'],c['sample_seconds'])<=600
    assert estimated_turn_deg(60,20,5)==520.
    assert estimated_turn_deg(45,20,5)==358.75
    assert estimated_turn_deg(30,5,5)==355.

    # Two independent gates: high speed and multi-turn physical installation.
    rejected(dict(cfg,high_speed_approved=False),'高于既有10')
    rejected(dict(cfg,extended_rotation_approved=False),'超过360°')
    rejected(dict(cfg,travel_budget='360'),'超过软件运动预算360')
    rejected(dict(cfg,rates='100'),'目标速率须在')
    rejected(dict(cfg,rates='60',travel_budget='519'),'超过软件运动预算519')
    rejected(dict(cfg,travel_budget='601'),'travel_budget 必须在')

    # Stage 1 and stage 2 without 60 do not need multi-turn authorization.
    s1=dict(cfg,rates='15,20',travel_budget='360',extended_rotation_approved=False)
    assert validate_entries(s1)['number_cases']==36
    s2=dict(cfg,rates='30,45',travel_budget='360',extended_rotation_approved=False)
    assert validate_entries(s2)['number_cases']==36
    # Explicit max software budget is an additional physical approval condition.
    rejected(dict(s1,travel_budget='600'),'超过360°')
    # 60 5-second steady motion requires >360-degree motion budget.
    rejected(dict(cfg,rates='60',travel_budget='360'),'超过软件运动预算360')
    # Manual 5-second 60, with insufficient accel or budget, also fails.
    rejected(dict(cfg,rates='60',use_rate_profiles=False,travel_budget='600',accel='5'),'超过软件运动预算600')
    # Previously verified speeds remain available under the original <=10 dps rule.
    old=dict(cfg,rates='7.5,10',accel='1',travel_budget='360',
             use_rate_profiles=False,high_speed_approved=False,extended_rotation_approved=False)
    assert validate_entries(old)['number_cases']==36
    assert resolve_rate_params(7.5,True,1,5)==(1.,5.)
print('PASS: 90 cases at 5s, 520° max-plan estimate, two separate safety gates, no hardware access')
