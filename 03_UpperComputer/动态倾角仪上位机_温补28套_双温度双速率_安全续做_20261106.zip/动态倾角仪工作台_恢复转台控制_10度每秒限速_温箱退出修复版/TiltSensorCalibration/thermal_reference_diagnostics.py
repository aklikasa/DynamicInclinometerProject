# -*- coding: utf-8 -*-
"""Pure WK feedback diagnostics. No device commands and no relaxation of quality limits.

Position timestamps are host read interval bounds, NOT device sampling times.
If the feedback cannot resolve the configured 0.18 deg/s volatility, we report
UNCERTAIN rather than manufacturing a pass from a smoothed velocity trace.
"""
import math
import numpy as np


def inspect_feedback(samples, axis, target, max_error=0.30, max_std=0.18):
    if axis not in ('inner', 'outer'):
        raise ValueError('unknown turntable axis')
    records=[]
    for s in samples:
        a=int(s.get(axis+'_position_read_start_ns') or 0)
        b=int(s.get(axis+'_position_read_end_ns') or 0)
        angle=float(s.get(axis+'_position_deg',float('nan')))
        if not (a>0 and b>=a and math.isfinite(angle)):
            continue
        records.append((0.5*(a+b)*1e-9,angle,(b-a)*1e-9))
    records.sort(key=lambda x:x[0])
    # Only independent encoder polls; never reweight duplicate values per IMU frame.
    unique=[]
    for x in records:
        if not unique or x[0]-unique[-1][0] > 0.001:
            unique.append(x)
    result={'status':'INSUFFICIENT_REFERENCE', 'sample_count':len(unique),
            'target_dps':float(target), 'certified':False,
            'reason':'有效独立位置反馈不足，无法判断匀速'}
    if len(unique)<7:
        return result
    t=np.asarray([x[0] for x in unique],dtype=float)
    dt=np.diff(t)
    if np.any(dt<=0) or np.max(dt)>1.2:
        result['reason']='位置反馈间隔过长或时间戳不递增'
        return result
    raw=np.asarray([x[1] for x in unique],dtype=float)
    increments=(np.diff(raw)+180.0)%360.0-180.0
    # Continuous rotation can move >180deg between polls; refuse ambiguous unwrap.
    if np.any(np.abs(dt*target)>=165.0) or np.any(np.abs(increments)>=175.0):
        result['reason']='角度反馈间隔可能跨越半圈，无法安全展开'
        return result
    theta=np.concatenate(([0.0],np.cumsum(increments)))
    x=t-t[0]
    coeff=np.polyfit(x,theta,1)
    mean=float(coeff[0]); residual=theta-np.polyval(coeff,x)
    # Independent poll-only raw derivative, for diagnosis (not IMU-frame replication).
    raw_diff=increments/dt
    std=float(np.std(raw_diff))
    # Check difference between two temporal slopes; cannot detect unobserved HF jitter.
    middle=len(x)//2
    left=float(np.polyfit(x[:middle+1],theta[:middle+1],1)[0])
    right=float(np.polyfit(x[middle:],theta[middle:],1)[0])
    rms=float(np.sqrt(np.mean(residual**2)))
    max_latency=max(s[2] for s in unique)
    result.update(sample_count=len(unique),duration_s=float(x[-1]),mean_dps=mean,
                  raw_diff_std_dps=std,first_half_dps=left,second_half_dps=right,
                  position_residual_rms_deg=rms,max_read_duration_s=max_latency)
    if x[-1]<2.0:
        result['reason']='独立反馈覆盖时长不足2秒'
    elif abs(mean-target)>max_error:
        result['status']='SPEED_ERROR';result['reason']='独立角度回归平均转速偏离目标'
    elif std>max_std:
        result['status']='REFERENCE_JITTER';result['reason']='独立角度反馈差分速度波动超限（可能含测速噪声）'
    elif abs(left-right)>2*max_std:
        result['status']='ACCELERATION_DETECTED';result['reason']='前后半段角速度趋势不一致'
    else:
        # Polling at 2-3Hz cannot prove sub-0.18dps true instantaneous stability.
        result['status']='POLLING_PASS_RESEARCH_ONLY'
        result['certified']=True
        result['reason']='通过现有反馈分辨率下的工程质检；不代表独立计量认证'
    return result
