# -*- coding: utf-8 -*-
"""2FDT600WK temperature-compensation experiment page.

Real 2FDT motor DLL + real live MCU IMU frames; no simulated success path.
The field-proven original Snap7 PLC chamber is the default automatic path.
Manual control is an explicit fallback; unknown RS232 commands are never sent.
"""
import copy
import ctypes
import csv
import datetime
import json
import math
import os
from pathlib import Path
import queue
import time
import numpy as np
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
    QLabel, QPushButton, QCheckBox, QComboBox, QLineEdit, QDoubleSpinBox,
    QSpinBox, QPlainTextEdit, QProgressBar, QFileDialog, QMessageBox, QScrollArea)

from turntable_data_get import (turntableComm, turntableData, turntableState,
    turntable_feedback_queue_set, turntable_feedback_get_nowait,
    turntable_feedback_queue_drop_count_get)
from turntable_2FDT600WK_comm import (INNER_ROTATION_AXIS, OUTER_ROTATION_AXIS,
    twoFDT600WK_SetAxisVelocity, twoFDT600WK_SetAxisStop)
from tilt_sensor_asm330_data_get import (tiltSensorComm, tiltSensorRawData,
    tilt_sensor_calibration_queue_set, tilt_sensor_calibration_frame_get_nowait,
    tilt_sensor_calibration_queue_drop_count_get)
from temperature_chamber_data_get import tcData, tcState, tcComm
from temperature_chamber_comm import tc_set_fixed_value_mode, tc_sp_set, tc_fixed_value_startup, tc_fixed_value_stop
from chamber_auto_guard import require_live_chamber, require_setpoint_ack, ChamberSafetyError
from debug import OFFLINE_DEBUG
from production_calibration import (load_profile, acc_fit_steps, acc_verify_steps,
    gyro_fit_steps, gyro_verify_steps, frame_average_sanitized, robust_segment)
from form_imu_calibration import _platform_gravity_vector, _platform_angular_rate
from thermal_variable_temperature import (parse_temperatures, temperature_splits,
    separate_temperature_plan, steps_for_temperature,
    save_variable_models, save_optional_gyro_bias)
from thermal_excel_report import export_thermal_xlsx
from thermal_model_selection import run_thermal_model_selection
from thermal_run_resume import (RESUME_SCHEMA, atomic_write_json, validate_resume,
                                validate_appendable_raw_files)
from thermal_chip_stability import chip_stability_status
from thermal_chamber_stability import (chamber_stability_status, chamber_band_status)
from thermal_gyro_multirate import (
    FIT_RATES_DPS, VERIFY_RATES_DPS, PILOT_FIT_RATES_DPS, PILOT_VERIFY_RATES_DPS, configure_thermal_gyro_profile,
    wk_signed_velocity, conservative_sweep_degrees,
    parse_rate_list, validate_rate_lists)
import turntable_2FDT600WK_comm as wk_comm
from thermal_runtime_guard import ThermalRuntimeGuard
from thermal_reference_diagnostics import inspect_feedback
from thermal_incomplete_report import export_incomplete_xlsx

ROOT = Path(__file__).resolve().parents[1]
LOCKABLE = ('button_TurntableCommPortOpen', 'comboBox_TurntableModelSelect',
    'pushButton_InnerReturnZero','pushButton_OuterReturnZero','pushButton_AllReturnZero',
    'pushButton_InnerRun','pushButton_OuterRun','pushButton_AllRun',
    'pushButton_InnerRunForSpeedMode','pushButton_OuterRunForSpeedMode',
    'pushButton_InnerRunForSwayMode','pushButton_OuterRunForSwayMode')


def _angle_error(a,b):
    return (float(a)-float(b)+180) % 360-180


class FormThermalCompensation:
    def __init__(self, ui, turntable_form, ambient_form):
        self.ui, self.turntable_form, self.ambient_form = ui, turntable_form, ambient_form
        self.task = None
        self._wk_rate_guard = None
        self._raw_file = None
        self._raw_jsonl = None
        self._feedback_jsonl = None
        self._locked_buttons = {}
        self._locked_tc_buttons = {}
        self._locked_ambient_buttons = {}
        self.page = QWidget()
        self.page.setObjectName('page_ImuThermalCompensation')
        self._make_ui()
        ui.tabWidget_CalMain.addTab(self.page, 'IMU 自动温补')
        self.timer = QTimer(self.page)
        self.timer.setInterval(100)
        self.timer.timeout.connect(self._tick)
        self.timer.start()

    def _make_ui(self):
        outer = QVBoxLayout(self.page)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        body = QWidget()
        layout = QVBoxLayout(body)
        scroll.setWidget(body)
        outer.addWidget(scroll)

        desc = QLabel('2FDT600WK 温补。优先复用已在本机实测设温成功的 Snap7/PLC 温箱接口：自动设温、回读确认、等待PV和芯片热平衡、真实转台/IMU采集。'
                      '仅在PLC不可用且操作员主动选择时使用人工设温。拟合结果为研发候选，不覆盖常温参数。')
        desc.setWordWrap(True)
        desc.setStyleSheet('color:#795c26;background:#fbf4e5;padding:8px;border-radius:7px')
        layout.addWidget(desc)
        box = QGroupBox('实验配置（拟合/独立验证温度分别输入，自动合并升序执行）')
        g = QGridLayout(box)
        g.addWidget(QLabel('PCB 唯一编号'),0,0)
        self.sn = QLineEdit()
        self.sn.setPlaceholderText('连接后自动填入；不支持UID时手动输入')
        self.sn.setToolTip('与IMU标定页自动同步PCB编号；温补记录也保存此编号')
        g.addWidget(self.sn,0,1)
        g.addWidget(QLabel('拟合温度工况 ℃'),1,0)
        self.fit_temperatures = QLineEdit('-20, 0, 25, 70')
        self.fit_temperatures.setObjectName('thermal_fit_temperatures')
        self.fit_temperatures.setToolTip('只在这些温度执行ACC/GYRO标定和独立工况测试；逗号分隔、升序、不重复。一次/二次/三次模型至少需要3/4/5个拟合温度点。')
        g.addWidget(self.fit_temperatures,1,1,1,3)
        g.addWidget(QLabel('独立验证温度 ℃'),2,0)
        self.validation_temperatures = QLineEdit('45')
        self.validation_temperatures.setObjectName('thermal_validation_temperatures')
        self.validation_temperatures.setToolTip('只执行ACC/GYRO独立测试工况；不参与PV校正、温补拟合或模型选型。须位于拟合温度范围内，不能与拟合温度重复。')
        g.addWidget(self.validation_temperatures,2,1,1,3)
        self.temperature_plan_note = QLabel('拟合温度：完整标定+独立工况测试；独立验证温度：仅采独立测试工况。合并后从低温向高温运行，每点保温门槛相同。28套模型=A0+T0/T1/T2×B/C/D×1/2/3次；至少5个拟合温度点才能可靠比较三次模型。')
        self.temperature_plan_note.setWordWrap(True)
        self.temperature_plan_note.setStyleSheet('color:#795c26')
        g.addWidget(self.temperature_plan_note,13,0,1,4)
        g.addWidget(QLabel('预期 GYRO 量程（仅核对，不写入设备）'),14,0)
        self.expected_gyro_fs = QComboBox()
        for value in (125,250,500,1000,2000,4000):
            self.expected_gyro_fs.addItem(f'±{value}°/s',value)
        self.expected_gyro_fs.setCurrentIndex(self.expected_gyro_fs.findData(250))
        g.addWidget(self.expected_gyro_fs,14,1)
        self.gyro_fs_note = QLabel('你已将陀螺仪设置为±250 dps，启动时核对实时数据换算量程；更改此处不会修改MCU。')
        self.gyro_fs_note.setWordWrap(True)
        g.addWidget(self.gyro_fs_note,14,2,1,2)
        g.addWidget(QLabel('温箱方式'),3,0)
        self.chamber_mode = QComboBox()
        self.chamber_mode.addItem('自动控温：使用原上位机已验证的 Snap7/PLC 温箱（推荐）', 'plc')
        self.chamber_mode.addItem('人工设温：仅限PLC不可用时（逐点确认）', 'manual')
        g.addWidget(self.chamber_mode,3,1,1,3)
        self.chamber_mode.currentIndexChanged.connect(self._on_chamber_mode_changed)
        g.addWidget(QLabel('原温箱实测 PV ℃'),4,0)
        self.manual_pv = QDoubleSpinBox()
        self.manual_pv.setRange(-45,110)
        self.manual_pv.setDecimals(2)
        self.manual_pv.setValue(25)
        g.addWidget(self.manual_pv,4,1)
        self.confirm_temp = QPushButton('确认本温度点已到温')
        self.confirm_temp.setEnabled(False)
        self.confirm_temp.clicked.connect(self._confirm_temperature)
        g.addWidget(self.confirm_temp,4,2,1,2)
        self.plc_telemetry = QLabel('PLC 反馈：等待连接；自动模式禁止使用离线/缓存温度')
        self.plc_telemetry.setWordWrap(True)
        g.addWidget(self.plc_telemetry,9,0,1,4)
        g.addWidget(QLabel('共同热平衡时间 (秒)'),5,0)
        self.dwell = QSpinBox(); self.dwell.setRange(300,7200); self.dwell.setValue(1800)
        g.addWidget(self.dwell,5,1)
        self.chip_stability_only = QCheckBox('快速模式：跳过正式热浸与温箱两级稳定判据（仅流程测试用）')
        self.chip_stability_only.setToolTip('快速模式仅用于自动流程/转台联调：PLC PV在目标±1℃连续30秒后，再检查芯片最近60秒真实新帧波动≤0.2℃；跳过正式30分钟共同热平衡和最终PV±0.1℃/5分钟检查。正式温补请取消勾选。')
        self.chip_stability_only.setChecked(False)
        self.chip_stability_only.toggled.connect(self._on_thermal_mode_changed)
        g.addWidget(self.chip_stability_only,15,0,1,4)
        g.addWidget(QLabel('每工况采样 (秒)'),5,2)
        self.sample_seconds = QSpinBox(); self.sample_seconds.setRange(5,120); self.sample_seconds.setValue(5)
        g.addWidget(self.sample_seconds,5,3)
        g.addWidget(QLabel('静置等待 (秒)'),6,0)
        self.settle = QSpinBox(); self.settle.setRange(3,60); self.settle.setValue(3)
        g.addWidget(self.settle,6,1)
        g.addWidget(QLabel('姿态运动速度 °/s'),6,2)
        self.move_speed = QDoubleSpinBox(); self.move_speed.setRange(0.2,5); self.move_speed.setValue(2)
        g.addWidget(self.move_speed,6,3)
        self.dynamic = QCheckBox('GYRO 多速率标定（默认低中速≤30°/s；60°/s为单独可选高速模式）')
        self.dynamic.setChecked(True)
        g.addWidget(self.dynamic,7,0,1,4)
        self.gyro_rate_mode = QComboBox()
        self.gyro_rate_mode.addItem('推荐：低中速 ≤30°/s；拟合 1/5/15/30，验证 1.5/3.5/10/20/25', 'pilot')
        self.gyro_rate_mode.addItem('高速研发：≤60°/s；拟合 1/5/15/30/60，验证 1.5/3.5/10/20/45', 'full')
        self.gyro_rate_mode.addItem('自定义：拟合与独立验证速率分别输入（单位°/s，自动正反转）', 'custom')
        self.gyro_rate_mode.setToolTip('预设可直接使用；选择自定义后，两组速率都可编辑。实验启动后锁定并写入断点续做配置。')
        g.addWidget(self.gyro_rate_mode, 16, 0, 1, 4)
        g.addWidget(QLabel('GYRO拟合速率 °/s'),17,0)
        self.gyro_fit_rates = QLineEdit('1, 5, 15, 30')
        self.gyro_fit_rates.setObjectName('thermal_gyro_fit_rates')
        self.gyro_fit_rates.setToolTip('输入正速率幅值，用逗号分隔；每个速率自动做正反向和三轴。可设0.1～60°/s。')
        g.addWidget(self.gyro_fit_rates,17,1,1,3)
        g.addWidget(QLabel('GYRO独立验证速率 °/s'),18,0)
        self.gyro_verify_rates = QLineEdit('1.5, 3.5, 10, 20, 25')
        self.gyro_verify_rates.setObjectName('thermal_gyro_verify_rates')
        self.gyro_verify_rates.setToolTip('独立验证速率不可与拟合速率重复；建议处于拟合速度覆盖区间内。')
        g.addWidget(self.gyro_verify_rates,18,1,1,3)
        self.gyro_rate_mode.currentIndexChanged.connect(self._on_gyro_rate_mode_changed)
        self._on_gyro_rate_mode_changed()
        g.addWidget(QLabel('GYRO 转动加速度 °/s²'),11,0)
        self.gyro_accel = QSpinBox(); self.gyro_accel.setRange(1,50); self.gyro_accel.setValue(30)
        self.gyro_accel.setToolTip('仅用于温补动态GYRO；外轴额定最大50°/s²。')
        g.addWidget(self.gyro_accel,11,1)
        # 温补GYRO不设固定累计转角上限；只保留真实反馈、方向、超时与停车保护。
        self.gyro_safety_note = QLabel('普通数据质检失败只进入有限补测队列；不会放宽任何ACC/GYRO或WK速度质量阈值。'
                                      '高速模式含60°/s连续旋转风险，必须实机验证滑环、线缆、装夹和急停。')
        self.gyro_safety_note.setWordWrap(True)
        self.gyro_safety_note.setStyleSheet('color:#8a5421')
        g.addWidget(self.gyro_safety_note,12,0,1,4)
        self.return_ambient = QCheckBox('PLC自动控温完成后自动回到 25°C，确认PV到温后再结束任务')
        self.return_ambient.setChecked(True)
        g.addWidget(self.return_ambient,10,0,1,4)
        g.addWidget(QLabel('保存目录'),8,0)
        self.output = QLineEdit(str(Path.home()/'IMU_Thermal_Experiments'))
        g.addWidget(self.output,8,1,1,2)
        browse = QPushButton('选择…'); browse.clicked.connect(self._browse)
        g.addWidget(browse,8,3)
        layout.addWidget(box)

        stability_box = QGroupBox('正式温补温箱稳定判据（PLC自动控温模式）')
        sg = QGridLayout(stability_box)
        sg.addWidget(QLabel('初步到温观察时间 (秒)'),0,0)
        self.pv_initial_seconds = QSpinBox(); self.pv_initial_seconds.setRange(60,1800); self.pv_initial_seconds.setValue(300)
        sg.addWidget(self.pv_initial_seconds,0,1)
        sg.addWidget(QLabel('初步PV极差上限 (°C)'),0,2)
        self.pv_initial_range = QDoubleSpinBox(); self.pv_initial_range.setRange(0.05,2.0); self.pv_initial_range.setDecimals(2); self.pv_initial_range.setSingleStep(0.05); self.pv_initial_range.setValue(0.30)
        sg.addWidget(self.pv_initial_range,0,3)
        sg.addWidget(QLabel('初步PV斜率上限 (°C/min)'),1,0)
        self.pv_initial_slope = QDoubleSpinBox(); self.pv_initial_slope.setRange(0.005,1.0); self.pv_initial_slope.setDecimals(3); self.pv_initial_slope.setSingleStep(0.005); self.pv_initial_slope.setValue(0.05)
        sg.addWidget(self.pv_initial_slope,1,1)
        sg.addWidget(QLabel('最终PV允许偏差 (°C)'),1,2)
        self.pv_final_tolerance = QDoubleSpinBox(); self.pv_final_tolerance.setRange(0.05,1.0); self.pv_final_tolerance.setDecimals(2); self.pv_final_tolerance.setSingleStep(0.05); self.pv_final_tolerance.setValue(0.10)
        sg.addWidget(self.pv_final_tolerance,1,3)
        sg.addWidget(QLabel('最终PV连续稳定时间 (秒)'),2,0)
        self.pv_final_seconds = QSpinBox(); self.pv_final_seconds.setRange(60,1800); self.pv_final_seconds.setValue(300)
        sg.addWidget(self.pv_final_seconds,2,1)
        self.formal_gate_note = QLabel('正式PLC模式：PV进入目标±1°C后，连续观察5分钟（极差≤0.30°C、线性斜率≤0.05°C/min）；再累计共同热平衡1800秒；最后PV在目标±0.10°C内连续5分钟，并通过芯片60秒波动≤0.20°C检查。')
        self.formal_gate_note.setWordWrap(True)
        self.formal_gate_note.setStyleSheet('color:#795c26')
        sg.addWidget(self.formal_gate_note,3,0,1,4)
        layout.addWidget(stability_box)
        recovery_temp_note = QLabel('运行时温漂保护：温箱PV连续15秒偏差>0.3℃或芯片60秒极差>0.2℃时，安全停车并暂缓新工况；'
                                    '短时温漂恢复后只重新检查120秒，不盲目重做1800秒热浸；PV持续30秒偏差>1℃须重新完整热浸。'
                                    '这些阈值属研发试运行判据；一般质检失败会自动待补测，无法补齐则标记不完整，绝不伪装合格。')
        recovery_temp_note.setWordWrap(True)
        recovery_temp_note.setStyleSheet('color:#795c26')
        layout.addWidget(recovery_temp_note)

        group = QGroupBox('启动条件与安全确认')
        gh = QVBoxLayout(group)
        self.check_axis = QCheckBox('已在实机核对 2FDT 内/外轴与 P 坐标系的方向、零位、正转定义；已完成找零')
        self.check_safe = QCheckBox('已确认装夹、配平、线缆、机械范围、门禁和硬件急停；全过程安排人员监护')
        self.check_sensor = QCheckBox('已核对 MCU 量程/ODR 不变、温度传感器有效，且现有常温标定不会被覆盖')
        for w in (self.check_axis,self.check_safe,self.check_sensor): gh.addWidget(w)
        self.check_highspeed = QCheckBox('高速速率 >30°/s：已核实温箱内线缆、滑环及对应速率的连续运行安全')
        self.check_highspeed.setToolTip('勾选不代表设备厂家已批准。需要实测确认能在当前装夹和温箱内安全旋转。')
        gh.addWidget(self.check_highspeed)
        self.check_plc = QCheckBox('已在这台如洋温箱上实测验证：原温箱页面能读取PV、设定SP，并确实发生升/降温（PLC自动模式必选）')
        gh.addWidget(self.check_plc)
        self._on_chamber_mode_changed()
        layout.addWidget(group)
        recovery_box = QGroupBox('正式实验前检查 / 失败后续做（不重做已完成工况）')
        recovery_layout = QGridLayout(recovery_box)
        self.preflight_button = QPushButton('预检查全部速率与预计转角（不让设备运动）')
        self.preflight_button.clicked.connect(self._preview_preflight)
        recovery_layout.addWidget(self.preflight_button,0,0,1,4)
        self.resume_checkbox = QCheckBox('从已有未完成实验继续（需要同一PCB、温度点与全部原始配置）')
        recovery_layout.addWidget(self.resume_checkbox,1,0,1,4)
        self.resume_directory = QLineEdit()
        self.resume_directory.setPlaceholderText('选择之前生成的 THERM_年月日_时间 实验文件夹')
        recovery_layout.addWidget(self.resume_directory,2,0,1,3)
        self.resume_browse = QPushButton('选择未完成实验目录…')
        self.resume_browse.clicked.connect(self._browse_resume)
        recovery_layout.addWidget(self.resume_browse,2,3)
        hint = QLabel('每个成功工况立即存档。续做重新设温并检查芯片热平衡，仅跳过已完成的合格工况；正在运行/异常工况会重做。')
        hint.setWordWrap(True)
        recovery_layout.addWidget(hint,3,0,1,4)
        layout.addWidget(recovery_box)
        self.reanalyze_button = QPushButton('离线重新分析已有完整温补实验（不控制设备）')
        self.reanalyze_button.setToolTip('选择已完成实验目录，创建新的分析子目录；不覆盖原始采集数据或直接下发补偿参数。')
        self.reanalyze_button.clicked.connect(self._reanalyze_saved_run)
        layout.addWidget(self.reanalyze_button)
        row = QHBoxLayout()
        self.start_button = QPushButton('启动自动温补实验')
        self.start_button.clicked.connect(self.start)
        self.stop_button = QPushButton('中止并停车')
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(lambda: self._abort('操作员主动中止'))
        row.addWidget(self.start_button,2); row.addWidget(self.stop_button,1)
        layout.addLayout(row)
        self.label = QLabel('状态：空闲');self.label.setWordWrap(True)
        layout.addWidget(self.label)
        self.progress = QProgressBar(); layout.addWidget(self.progress)
        self.selection_result = QLabel('28套温补候选：待完成实验；PV仅供拟合温度校正，运行时仅依赖芯片温度；独立温度不参与排名。')
        self.selection_result.setWordWrap(True)
        layout.addWidget(self.selection_result)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True);self.log.setMinimumHeight(145)
        layout.addWidget(self.log)
        layout.addStretch(1)

    def _reanalyze_saved_run(self):
        '''Reprocess a completed snapshot offline; never accesses the motor or PLC.'''
        if self.task is not None:
            QMessageBox.warning(self.page,'离线分析不可用','温补采集进行中，禁止同时处理实验文件。')
            return
        folder=QFileDialog.getExistingDirectory(self.page,'选择已完成温补实验文件夹',
                                                 self.output.text())
        if not folder:
            return
        try:
            root=Path(folder)
            checkpoint=json.loads((root/'temperature_measurements.json').read_text(encoding='utf-8'))
            if checkpoint.get('status')!='COMPLETED':
                raise ValueError('仅允许重新分析标记为COMPLETED的完整实验，避免将未完成数据当成标定结果。')
            rows=checkpoint.get('rows')
            if not isinstance(rows,list) or not rows:
                raise ValueError('实验缺少逐工况测量数据。')
            temps=sorted(set(float(r['temperature_target_c']) for r in rows))
            config_file=root/'experiment_config.json'
            if config_file.is_file():
                saved=json.loads(config_file.read_text(encoding='utf-8'))
                expected=saved.get('temperature_split') or {}
                for r in rows:
                    target=float(r['temperature_target_c'])
                    role=expected.get(str(target),expected.get(f'{target:g}'))
                    if role is not None and r.get('temperature_split')!=role:
                        raise ValueError('保存的温度角色与工况数据不一致，拒绝混合复算')
            sensors=('acc','gyro') if any(r.get('sensor')=='gyro' for r in rows) else ('acc',)
            # Output to a distinct path, so an existing report remains traceable.
            stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            output=root/('模型优选离线复算_'+stamp)
            baseline_result=save_variable_models(output,rows,temps,sensors)
            baseline_result['model_selection']=run_thermal_model_selection(output,rows,temps,sensors,source_folder=root)
            path=export_thermal_xlsx(output,rows,baseline_result)
            text='；'.join(f'{k.upper()}：{v.get("selected_id") or "未选出"} / {v.get("status_text",v.get("status"))}'
                          for k,v in baseline_result['model_selection']['sensors'].items())
            self.selection_result.setText('离线分析：'+text)
            self._log('离线模型比较已保存：'+path)
            QMessageBox.information(self.page,'离线复算完成',
                                    '报告：'+path+'\n'+text+'\n结果仅供研发，未自动写入传感器。')
        except Exception as exc:
            self._log('离线分析失败：'+str(exc))
            QMessageBox.warning(self.page,'离线分析失败',str(exc))

    def _on_thermal_mode_changed(self, *args):
        # 快速模式跳过正式热浸与两级温箱稳定判据；人工模式无法读取连续PLC PV，保留人工确认路径。
        quick = self.chip_stability_only.isChecked()
        self.dwell.setEnabled(self.task is None and not quick)
        formal_plc = (self.task is None and not quick and self.chamber_mode.currentData() == 'plc')
        for widget in (self.pv_initial_seconds, self.pv_initial_range, self.pv_initial_slope,
                       self.pv_final_tolerance, self.pv_final_seconds):
            widget.setEnabled(formal_plc)
        if hasattr(self, 'formal_gate_note'):
            if quick:
                self.formal_gate_note.setText('当前为快速流程测试模式：跳过正式共同热平衡和最终PV精确稳定检查，不建议将该模式数据直接用于正式温补模型。')
            elif self.chamber_mode.currentData() == 'manual':
                self.formal_gate_note.setText('当前为人工设温模式：无法连续读取PLC PV，因此不执行两级温箱PV判据；采用人工确认、共同热平衡时间及芯片温度稳定检查。正式温补建议使用PLC自动模式。')
            else:
                self.formal_gate_note.setText('正式PLC模式：PV进入目标±1°C后，连续观察5分钟（极差≤0.30°C、线性斜率≤0.05°C/min）；再累计共同热平衡1800秒；最后PV在目标±0.10°C内连续5分钟，并通过芯片60秒波动≤0.20°C检查。')

    def _on_chamber_mode_changed(self, *args):
        auto = self.chamber_mode.currentData()=='plc'
        self.manual_pv.setEnabled(not auto)
        self.check_plc.setEnabled(auto)
        if auto:
            self.confirm_temp.setEnabled(False)
            self.plc_telemetry.setText('PLC自动控温：任务启动前检查PV/SP/运行/报警读取新鲜度；写SP后必须回读确认。')
        else:
            self.plc_telemetry.setText('人工模式：必须逐温度点在面板设温和确认PV，不发送任何未知RS-232命令。')
        self._on_thermal_mode_changed()

    @staticmethod
    def _plc_snapshot():
        return {'connected':tcComm.is_connected,
            'data_available':tcData.is_tc_data_available,
            'pv_failed':tcComm.is_pv_get_failed,
            'pv':float(tcData.pv), 'sp':float(tcData.sp),
            'pv_updated':tcData.pv_update_monotonic,
            'sp_updated':tcData.sp_update_monotonic,
            'alarm':tcState.alarm_value, 'fault':tcState.is_device_fault,
            'alarm_updated':tcState.alarm_update_monotonic,
            'fault_updated':tcState.fault_update_monotonic,
            'running':tcState.is_device_running,
            'fixed_started':tcState.is_fixed_value_startup,
            'fixed_mode':tcState.is_fixed_value_mode,
            'run_updated':tcState.run_update_monotonic,
            'started_updated':tcState.fixed_start_update_monotonic,
            'mode_updated':tcState.mode_update_monotonic}

    def _require_plc(self, now):
        data=self._plc_snapshot()
        require_live_chamber(data,now)
        return data

    def _issue_plc_setpoint(self, target):
        if OFFLINE_DEBUG:
            raise RuntimeError('离线调试模式禁止向温箱发自动设温命令')
        self._require_plc(time.monotonic())
        with tcComm.thread_lock:
            # Exactly the same proven PLC writes as the original temperature page.
            # No RS232 vendor command is guessed here.
            ok_mode=tc_set_fixed_value_mode()
            ok_sp=tc_sp_set(float(target)) if ok_mode else False
            ok_start=tc_fixed_value_startup() if ok_sp else False
        if not (ok_mode and ok_sp and ok_start):
            raise RuntimeError('PLC定值模式/设温/启动写入失败（不能继续温补）')

    def _browse(self):
        path = QFileDialog.getExistingDirectory(self.page,'选择实验根目录',self.output.text())
        if path:self.output.setText(path)

    def _browse_resume(self):
        path = QFileDialog.getExistingDirectory(self.page, '选择未完成的THERM实验目录',
                                                self.resume_directory.text() or self.output.text())
        if path:
            self.resume_directory.setText(path)
            self.resume_checkbox.setChecked(True)

    def _on_gyro_rate_mode_changed(self, *_args):
        mode = self.gyro_rate_mode.currentData()
        if mode in ('pilot', 'full'):
            fit, verify = ((FIT_RATES_DPS, VERIFY_RATES_DPS) if mode == 'full'
                           else (PILOT_FIT_RATES_DPS, PILOT_VERIFY_RATES_DPS))
            self.gyro_fit_rates.setText(', '.join(f'{v:g}' for v in fit))
            self.gyro_verify_rates.setText(', '.join(f'{v:g}' for v in verify))
        editable = mode == 'custom' and self.task is None
        self.gyro_fit_rates.setReadOnly(not editable)
        self.gyro_verify_rates.setReadOnly(not editable)

    def _selected_rates(self):
        """Use exactly the displayed plan, not hidden hard-coded speed points."""
        mode = self.gyro_rate_mode.currentData()
        if mode == 'custom':
            return validate_rate_lists(
                parse_rate_list(self.gyro_fit_rates.text(), 'GYRO拟合速率'),
                parse_rate_list(self.gyro_verify_rates.text(), 'GYRO独立验证速率'))
        if mode == 'full':
            return FIT_RATES_DPS, VERIFY_RATES_DPS
        return PILOT_FIT_RATES_DPS, PILOT_VERIFY_RATES_DPS

    def _preview_preflight(self):
        """仅作速度参数校验和转角风险提示；不发送电机或PLC指令。"""
        try:
            if not self.dynamic.isChecked():
                QMessageBox.information(self.page,'温补预检查','当前未启用GYRO动态多速率；仅做ACC/静态GYRO采集。')
                return
            accel = int(self.gyro_accel.value())
            sample_seconds = int(self.sample_seconds.value())
            rates_fit,rates_val=self._selected_rates()
            speeds = sorted(set(rates_fit + rates_val))
            # 预检查只展示风险/可行性，不发送运动命令，故不要求安全勾选。
            # 真正启动时任何大于30°/s的自定义/预设工况都必须先人工确认。
            lines=['各目标速率的保守单段累计转角估算（仅供安全评估，不作为软件限额）：',
                   '本次拟合：'+str(rates_fit)+'；独立验证：'+str(rates_val),
                   '（包含加减速、至少1秒稳速等待及0.5秒余量）','']
            for speed in speeds:
                # 检查两轴额定角速度及整数加速度范围，负转使用相同幅值。
                for axis in ('inner','outer'):
                    wk_signed_velocity(+speed,accel,axis)
                    wk_signed_velocity(-speed,accel,axis)
                degrees=conservative_sweep_degrees(speed,accel,sample_seconds)
                lines.append(f'{speed:g}°/s：预计约 {degrees:.1f}°；无固定累计角度拦截')
            lines.append('')
            if speeds[-1] > 30:
                lines.append('高速风险：本次含>30°/s工况，正式启动前必须勾选高速安全确认。')
            if rates_val[0] < rates_fit[0] or rates_val[-1] > rates_fit[-1]:
                lines.append('警告：部分独立验证速率超出拟合范围，属于外推验证，不代表区间内性能。')
            lines.append('结果：当前速率与加速度参数检查通过。')
            lines.append('此检查不证明温箱内的线缆/装夹、制动距离、负转及急停已经实机验收。')
            lines.append('正式实验前须核实连续多圈运动条件；运行中保留反馈/方向/超时/停车保护。')
            QMessageBox.information(self.page,'WK 温补启动前参数检查','\n'.join(lines))
        except Exception as exc:
            QMessageBox.warning(self.page,'温补预检查失败',str(exc))

    def _resume_immutable(self, temperatures, profile, splits=None):
        return {
            'device_sn':self.sn.text().strip(),
            'temperature_model_degree':3,
            'temperature_fit_split':{str(float(temp)):role for temp,role in (splits if splits is not None else temperature_splits(temperatures)).items()},
            'temperature_setpoints_c':temperatures,
            'temperature_schedule_kind':'separate_fit_validation_v1' if splits is not None else 'legacy_automatic_split',
            'fit_temperature_setpoints_c':[v for v in temperatures if splits is not None and splits[v]=='fit'],
            'validation_temperature_setpoints_c':[v for v in temperatures if splits is not None and splits[v]=='validate'],
            'chamber_control':self.chamber_mode.currentData(),
            'gyro_dynamic':bool(self.dynamic.isChecked()),
            'gyro_rate_mode':str(self.gyro_rate_mode.currentData()),
            'quality_profile':profile,
            'gyro_fit_rates_dps':list(self._selected_rates()[0]),
            'gyro_verify_rates_dps':list(self._selected_rates()[1]),
            'gyro_acceleration_dps2':int(self.gyro_accel.value()),
            'chamber_plc_ip':str(tcComm.ip) if self.chamber_mode.currentData()=='plc' else None,
            'return_to_25c_on_success':bool(self.return_ambient.isChecked()),
            'sample_seconds':int(self.sample_seconds.value()),
            'thermal_stability_seconds':int(self.dwell.value()),
            'thermal_gate_mode': ('quick_chip_only' if self.chip_stability_only.isChecked() else
                                  'plc_staged_v1' if self.chamber_mode.currentData()=='plc' else 'manual_legacy'),
            'pv_initial_window_seconds':int(self.pv_initial_seconds.value()),
            'pv_initial_range_c':float(self.pv_initial_range.value()),
            'pv_initial_slope_c_per_min':float(self.pv_initial_slope.value()),
            'pv_final_tolerance_c':float(self.pv_final_tolerance.value()),
            'pv_final_stable_seconds':int(self.pv_final_seconds.value()),
            'chip_stability_window_seconds':60,
            'chip_stability_range_c':0.2,
            **({'chip_stability_only_60s':True} if self.chip_stability_only.isChecked() else {}),
            'settle_seconds':int(self.settle.value()),
            'acc_move_speed_dps':float(self.move_speed.value()),
            'axis_model':'outer_x_inner_z',
            'gyro_expected_fs_dps': int(self.expected_gyro_fs.currentData()),
            'imu_sensor_config': {key:value for key,value in self._sensor_config_snapshot().items()
                                  if key != 'gyro_fs_reported_by_mcu'},
        }

    @staticmethod
    def _sensor_config_snapshot():
        # Do not rely on software's default 2000 dps when the chip was changed to 250 dps.
        with tiltSensorRawData.data_lock:
            return {'acc_fs_g':int(tiltSensorRawData.acc_fs),
                    'gyro_fs_dps':int(tiltSensorRawData.gyro_fs),
                    'data_odr':int(tiltSensorRawData.data_odr),
                    'gyro_fs_reported_by_mcu':bool(tiltSensorRawData.gyro_fs_ever_valid)}

    def _log(self, message):
        self.log.appendPlainText(datetime.datetime.now().strftime('%H:%M:%S')+' '+message)
        if self.task:
            self.task['events'].append({'timestamp':datetime.datetime.now().isoformat(), 'message':message})

    def _valid_device(self):
        if turntableComm.turntable_model != '2FDT600WK':
            raise ValueError('必须在转台页连接 2FDT600WK；严禁错用 2TD600')
        if not turntableData.is_turntable_data_available or time.time()-turntableData.last_update_time_sec>3:
            raise ValueError('转台实测反馈离线/超时')
        if not (turntableState.is_inner_axis_in_enable and turntableState.is_outer_axis_in_enable):
            raise ValueError('两轴没有全部使能')
        if not (turntableState.is_inner_axis_normal and turntableState.is_outer_axis_normal):
            raise ValueError('转台报警或未处于正常状态')
        if (turntableState.is_inner_axis_over_diff or turntableState.is_outer_axis_over_diff or
                turntableState.is_inner_axis_driver_fault or turntableState.is_outer_axis_driver_fault):
            raise ValueError('转台伺服超差/驱动故障')
        # 串口线程允许一次轮询出现空帧；is_data_valid/is_data_available 是瞬时状态，
        # 不可拿来当自动温补每100ms的硬中止条件。必须看最近真实有效帧的时间。
        # 无效帧不会增加 data_update_count，也不会入标定队列。
        if not tiltSensorComm.is_serial_opened:
            raise ValueError('IMU 串口未连接')
        if self.ambient_form._auto_task is not None or self.ambient_form.recording:
            raise ValueError('常温自动任务或原始记录运行中；不能并行启动')
        with tiltSensorRawData.data_lock:
            imu_count = int(tiltSensorRawData.data_update_count)
        last_success = float(getattr(tiltSensorComm, 'last_success_time_sec', 0.0) or 0.0)
        age = time.time() - last_success
        if imu_count <= 0 or not math.isfinite(age) or last_success <= 0.0 or age > 5.0 or age < -1.0:
            raise ValueError('IMU 连续超过5秒没有真实有效的新测量数据，'
                             '或尚未收到有效帧；检查串口、MCU FIFO 与数据采样')

    def _motion_status(self):
        self._valid_device()
        if not np.all(np.isfinite([turntableData.inner_axis_position, turntableData.outer_axis_position,
                                   turntableData.inner_axis_speed, turntableData.outer_axis_speed])):
            raise ValueError('转台反馈包含 NaN/Inf')

    def _stopped(self):
        return abs(turntableData.inner_axis_speed) < 0.05 and abs(turntableData.outer_axis_speed) < 0.05

    @staticmethod
    def _wk_thermal_position_plan(current_angle, target_angle):
        """仅用于 WK 自动温补姿态定位：普通单圈目标，选择最短弧及厂家方向码。"""
        current = float(current_angle)
        target = float(target_angle)
        if (not math.isfinite(current) or not math.isfinite(target)
                or not 0.0 <= current <= 360.0 or not 0.0 <= target <= 360.0):
            raise ValueError('WK 姿态角反馈/目标必须在 0～360° 且为有限值')
        # WK 角位置命令只接受 [0,360)，与手动位置控制一样将 360 规范化为 0。
        current %= 360.0
        target = round(target % 360.0, 4) % 360.0
        clockwise = (target - current) % 360.0
        anticlockwise = (current - target) % 360.0
        return target, (0 if clockwise <= anticlockwise else 1), min(clockwise, anticlockwise)

    def _move(self, inner, outer):
        """WK温补专用有向姿态定位；按已验证的ACC流程分轴发送并确认启动。"""
        if bool(getattr(self.turntable_form, '_speed_limit_tripped', False)):
            raise ValueError('转台超速已触发，禁止温补运动。')
        if not self._stopped():
            raise ValueError('两轴未停车，不允许发送定位命令')
        if not all(math.isfinite(float(v)) and 0 <= float(v) <= 360 for v in (inner, outer)):
            raise ValueError('目标角超出已审核 0–360° 工况范围')
        speed = float(self.move_speed.value())
        if not math.isfinite(speed) or not 0.2 <= speed <= 5.0:
            raise ValueError('温补姿态速度必须为 0.2～5°/s')

        # 先读取两轴状态并生成计划。距离不超过0.2°时视为已在目标附近，
        # 不向该轴发送零转角位置指令，避免无意义指令干扰另一轴的运动启动。
        candidates = []
        skipped = []
        with turntableComm.thread_lock:
            for axis, name, requested in ((INNER_ROTATION_AXIS, '内轴', inner),
                                          (OUTER_ROTATION_AXIS, '外轴', outer)):
                alarm, state, actual, error = [0], [0], [0.0], [0]
                read_ok = wk_comm.twoFDT600WK_getAxisStateInfo(
                    axis, alarm, state, actual, error)
                if not read_ok or alarm[0] != 0 or state[0] != 1:
                    raise RuntimeError(f'WK温补{name}定位前状态不允许运行：'
                                       f'状态={state[0]} 报警={alarm[0]} DLL={error[0]}')
                target, direction, travel = self._wk_thermal_position_plan(actual[0], requested)
                port = wk_comm.axisPorts[axis]
                if not port:
                    raise RuntimeError(f'WK温补{name}没有有效串口')
                if travel <= 0.2:
                    skipped.append((name, actual[0], target, travel))
                    continue
                candidates.append((axis, name, port, requested))

        for name, current, target, travel in skipped:
            self._log(f'温补姿态{name}：当前位置 {current:.4f}°，目标 {target:.4f}°，'
                      f'差值 {travel:.4f}°≤0.2°，跳过无效位置指令')

        func = wk_comm.turntableDll.SetAxisPosition
        func.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint8,
                         ctypes.c_uint16, ctypes.c_float, ctypes.c_float]
        func.restype = ctypes.c_int
        watch = {}
        for index, (axis, name, port, requested) in enumerate(candidates):
            # 与已有ACC自动定位流程保持一致：每轴单独加锁发送，轴间留出100ms。
            # 发送前再次读取本轴状态，避免把旧状态当作当前状态。
            with turntableComm.thread_lock:
                alarm, state, actual, error = [0], [0], [0.0], [0]
                read_ok = wk_comm.twoFDT600WK_getAxisStateInfo(
                    axis, alarm, state, actual, error)
                if not read_ok or alarm[0] != 0 or state[0] != 1:
                    raise RuntimeError(f'WK温补{name}发送位置指令前状态变化：'
                                       f'状态={state[0]} 报警={alarm[0]} DLL={error[0]}')
                target, direction, travel = self._wk_thermal_position_plan(actual[0], requested)
                if travel <= 0.2:
                    self._log(f'温补姿态{name}：发送前已进入目标附近，跳过位置指令')
                    continue
                result = int(func(port, axis, direction, 10, speed, target))
            if result != 0:
                raise RuntimeError(f'WK温补{name}位置指令失败：DLL={result}')

            sent_at = time.monotonic()
            watch[axis] = {
                'name': name,
                'start_angle': float(actual[0]),
                'target': float(target),
                'sent_at': sent_at,
                'started': False,
            }
            self._log(f'温补姿态{name}：{float(actual[0]):.4f}°→{target:.4f}°，'
                      f'{"顺时针" if direction == 0 else "逆时针"} {travel:.4f}°，'
                      f'速度 {speed:g}°/s；DLL返回0，等待控制器确认启动')
            if index < len(candidates) - 1:
                time.sleep(0.1)

        if self.task is not None:
            self.task['position_watch'] = watch
        if not watch and not skipped:
            self._log('温补姿态：两轴均无需运动，跳过位置指令')

    def _check_position_command_started(self, now):
        """DLL返回成功后，短时确认WK已进入位置运动或反馈角度确实变化。"""
        if self.task is None:
            return
        watch = self.task.get('position_watch') or {}
        for axis, spec in watch.items():
            if spec.get('started'):
                continue
            alarm, state, angle, error = [0], [0], [0.0], [0]
            with turntableComm.thread_lock:
                ok = wk_comm.twoFDT600WK_getAxisStateInfo(axis, alarm, state, angle, error)
            elapsed = float(now) - float(spec['sent_at'])
            if not ok:
                raise RuntimeError(f'WK温补{spec["name"]}定位启动确认失败：状态读取DLL={error[0]}')
            if alarm[0] != 0:
                raise RuntimeError(f'WK温补{spec["name"]}定位启动时控制器报警={alarm[0]}')

            current = float(angle[0])
            state_code = int(state[0])
            alarm_code = int(alarm[0])
            moved = abs(_angle_error(current, spec['start_angle'])) > 0.05
            reached = abs(_angle_error(current, spec['target'])) <= 0.2
            axis_speed = (turntableData.inner_axis_speed if axis == INNER_ROTATION_AXIS
                          else turntableData.outer_axis_speed)
            if state_code == 3 or moved or abs(float(axis_speed)) >= 0.05 or reached:
                spec['started'] = True
                self._log(f'温补姿态{spec["name"]}定位启动已确认：状态={state_code}，'
                          f'反馈角度={current:.4f}°，目标={spec["target"]:.4f}°')
                continue
            if state_code != 1 and elapsed >= 0.5:
                raise RuntimeError(f'WK温补{spec["name"]}位置指令后出现非预期状态={state_code}，'
                                   f'报警={alarm_code}，当前角度={current:.4f}°')
            if state_code == 1 and elapsed >= 2.0:
                raise RuntimeError(f'WK温补{spec["name"]}位置指令DLL返回0，但2秒后仍为1#伺服待命，'
                                   f'角度未变化（起始={spec["start_angle"]:.4f}°，'
                                   f'当前={current:.4f}°，目标={spec["target"]:.4f}°）；'
                                   '已提前判定指令未启动，不再空等240秒')

    def _rate_command(self,axis,rate):
        if bool(getattr(self.turntable_form, '_speed_limit_tripped', False)):
            raise ValueError('转台超速已触发，禁止温补运动。')
        if self.task is None or self.task.get('phase') not in ('settle',):
            raise ValueError('非温补动态工况阶段，禁止发送速率指令')
        direction, acceleration, speed = wk_signed_velocity(float(rate), int(self.gyro_accel.value()), axis)
        if not self._stopped():
            raise ValueError('两轴尚未停车，禁止温补速率运动')
        axis_id = INNER_ROTATION_AXIS if axis == 'inner' else OUTER_ROTATION_AXIS
        with turntableComm.thread_lock:
            # 仅温补动态GYRO使用本路径；原WK封装固定 direction=0 不支持负速率。
            alarm, state, actual, error = [0], [0], [0.0], [0]
            ok_state = wk_comm.twoFDT600WK_getAxisStateInfo(axis_id, alarm, state, actual, error)
            if not ok_state or alarm[0] != 0 or state[0] != 1:
                raise RuntimeError(f'WK{axis}未处于1#伺服待命/无报警状态：state={state[0]}, alarm={alarm[0]}, DLL={error[0]}')
            port = wk_comm.axisPorts[axis_id]
            if not port:
                raise RuntimeError(f'WK{axis}尚未设置有效串口')
            func = wk_comm.turntableDll.SetAxisVelocity
            func.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint8,
                             ctypes.c_uint16, ctypes.c_float]
            func.restype = ctypes.c_int
            code = func(port, axis_id, direction, acceleration, speed)
        if code != 0:
            raise RuntimeError(f'WK{axis}动态速率指令失败（DLL={code}，速度={rate:g}°/s）')
        self._wk_rate_guard = {
            'axis':axis, 'last_feedback_count':int(turntableData.update_count),
            'started':time.monotonic()}
        self._log(f'GYRO速率命令：{axis}方向码={direction}，实际传参速率={speed:g}°/s，'
                  f'加速度={acceleration}°/s²，计划签名速率={rate:+g}°/s')

    def _check_rate_feedback(self):
        """速率工况编码器反馈看门狗，不按累计转角限制正常多圈运动。"""
        guard = self._wk_rate_guard
        if guard is None:
            return
        # 设备运行期间必须持续收到真实编码器反馈；无反馈应立即进入异常停车路径。
        if not turntableData.is_turntable_data_available or time.monotonic() - (
                float(turntableData.last_update_monotonic_ns)*1e-9) > 0.75:
            raise ValueError('温补高速工况转台反馈陈旧/无效，发起停车')
        count = int(turntableData.update_count)
        if count == guard['last_feedback_count']:
            if time.monotonic()-guard['started']>0.75:
                raise ValueError('温补速率运动期间编码器反馈未更新，发起停车')
            return
        guard['last_feedback_count'] = count
        guard['started'] = time.monotonic()
        observed_speed = float(turntableData.inner_axis_speed if guard['axis']=='inner'
                               else turntableData.outer_axis_speed)
        if not math.isfinite(observed_speed):
            raise ValueError('速率反馈非有限值，请求停车')

    def _stop_axes(self):
        results=[]
        with turntableComm.thread_lock:
            for axis in (INNER_ROTATION_AXIS,OUTER_ROTATION_AXIS):
                code=[0]
                try: results.append(bool(twoFDT600WK_SetAxisStop(axis,code)))
                except Exception:results.append(False)
        self._wk_rate_guard = None
        return all(results)

    def _wk_stop_confirmed(self, task, now):
        """核实速率段停车完成，防止 8# 停车执行中被误认为 1# 可定位。

        GetStateInfo 返回的是厂家的实机状态。必须有停车指令之后的新编码器反馈，
        两轴速度均接近零，且两轴都连续 0.5s 确认为 1#、无报警。
        8# 只允许等待，不发送使能/位置/速率命令；状态异常由上层安全中止。
        """
        count = int(turntableData.update_count)
        baseline = task.get('stop_feedback_count')
        if baseline is not None and count <= baseline:
            task['stop_ready_since'] = None
            return False, '停车指令之后尚未收到新的转台编码器反馈'
        last_ns = int(getattr(turntableData, 'last_update_monotonic_ns', 0) or 0)
        if last_ns <= 0 or now - last_ns * 1e-9 > 1.0:
            task['stop_ready_since'] = None
            return False, '等待新的转台编码器状态反馈（反馈尚未更新）'

        observed = []
        with turntableComm.thread_lock:
            for axis, label in ((INNER_ROTATION_AXIS, '内轴'),
                                (OUTER_ROTATION_AXIS, '外轴')):
                alarm, state, angle, error = [0], [0], [0.0], [0]
                ok = wk_comm.twoFDT600WK_getAxisStateInfo(
                    axis, alarm, state, angle, error)
                if not ok:
                    task['stop_ready_since'] = None
                    return False, f'{label}控制器停车反馈暂不可用（DLL={error[0]}）'
                if int(alarm[0]) != 0:
                    raise RuntimeError(f'WK停车确认发现{label}报警={alarm[0]}，禁止下一项运动')
                code = int(state[0])
                if code not in (1, 4, 5, 8):
                    raise RuntimeError(f'WK停车后{label}状态={code}，不是可等待的伺服/速率/停车状态；禁止下一项运动')
                observed.append((label, code))

        status = '，'.join(f'{label}={code}#' for label, code in observed)
        if not self._stopped() or any(code != 1 for _, code in observed):
            task['stop_ready_since'] = None
            return False, status + '，等待速度归零且两轴均返回1#伺服待命'
        if task.get('stop_ready_since') is None:
            task['stop_ready_since'] = now
            return False, status + '，正在连续确认1#伺服待命'
        if now - task['stop_ready_since'] < 0.5:
            return False, status + '，等待1#伺服待命持续0.5秒'
        return True, status + '，停车已确认'

    def _begin_wk_stop_wait(self, task, now, retry=False):
        """只在已下发停车指令后调用。下一项不能提前越过厂家8#状态。"""
        task['phase'] = 'wait_stop_retry' if retry else 'wait_stop'
        task['phase_start'] = now
        task['stop_feedback_count'] = int(turntableData.update_count)
        task['stop_ready_since'] = None
        task['stop_wait_last_state'] = None

    def _lock_ui(self, locked):
        for w in (self.sn,self.fit_temperatures,self.validation_temperatures,self.chamber_mode,self.dwell,self.chip_stability_only,self.sample_seconds,
                  self.pv_initial_seconds,self.pv_initial_range,self.pv_initial_slope,
                  self.pv_final_tolerance,self.pv_final_seconds,
                  self.settle,self.move_speed,self.dynamic,self.gyro_rate_mode,self.gyro_fit_rates,
                  self.gyro_verify_rates,self.output,self.return_ambient,
                  self.gyro_accel,self.expected_gyro_fs,self.resume_checkbox,
                  self.resume_directory,self.resume_browse,self.preflight_button):
            w.setEnabled(not locked)
        if not locked:
            self._on_chamber_mode_changed()
            self._on_thermal_mode_changed()
            self._on_gyro_rate_mode_changed()
        if locked:
            for name in LOCKABLE:
                w=getattr(self.turntable_form,name,None)
                if w is not None:
                    self._locked_buttons[name]=w.isEnabled()
                    w.setEnabled(False)
            for name in ('button_accel_plan','button_gyro_plan','button_compare_acc',
                         'button_compare_gyro','button_alignment_check','button_record_start'):
                w=getattr(self.ambient_form,name,None)
                if w is not None:
                    self._locked_ambient_buttons[name]=w.isEnabled()
                    w.setEnabled(False)
            if self.chamber_mode.currentData()=='plc':
                for name in ('pushButton_Set','pushButton_RunStop','pushButton_ConnectTC'):
                    w=getattr(self.ui,name,None)
                    if w is not None:
                        self._locked_tc_buttons[name]=w.isEnabled()
                        w.setEnabled(False)
        else:
            for name,old in self._locked_ambient_buttons.items():
                w=getattr(self.ambient_form,name,None)
                if w is not None:w.setEnabled(old)
            self._locked_ambient_buttons.clear()
            for name,old in self._locked_tc_buttons.items():
                w=getattr(self.ui,name,None)
                if w is not None:w.setEnabled(old)
            self._locked_tc_buttons.clear()
            for name,old in self._locked_buttons.items():
                w=getattr(self.turntable_form,name,None)
                if w is not None:w.setEnabled(old)
            self._locked_buttons.clear()

    @staticmethod
    def _steps(dynamic,profile):
        steps=[]
        for row in acc_fit_steps()+acc_verify_steps():
            steps.append({**row,'sensor':'acc', 'reference_kind':'gravity'})
        # At each temperature collect zero rate at two independent orientations.
        for split, name in (('fit','GYRO_ZERO_FIT'),('validate','GYRO_ZERO_VAL')):
            steps.append({'mode':'static','step_id':name,'split':split,'sensor':'gyro',
                          'inner_deg':0.0,'outer_deg':0.0,'sample_seconds':max(20 if split=='fit' else 10,
                                                      float(profile['timing']['gyro_zero_seconds'] if split=='fit' else 10))})
        if dynamic:
            for row in gyro_fit_steps(profile)+gyro_verify_steps(profile):
                if row['mode']=='rate': steps.append({**row,'sensor':'gyro'})
        return steps

    def start(self):
        if self.task is not None:return
        # 不复用上一次已关闭的原始文件句柄；启动校验失败时也能安全记录中止。
        self._raw_file=None
        self._raw_jsonl=None
        try:
            self._valid_device()
            if not all(w.isChecked() for w in (self.check_axis,self.check_safe,self.check_sensor)):
                raise ValueError('必须确认全部安全项、坐标系和标定配置')
            if OFFLINE_DEBUG:raise ValueError('禁止在OFFLINE_DEBUG下启动真实温补实验')
            if not self._stopped():raise ValueError('开始前两轴必须静止')
            plan=separate_temperature_plan(self.fit_temperatures.text(),self.validation_temperatures.text())
            temperatures=plan['temperature_setpoints_c']
            splits=plan['temperature_split']
            sensor_config=self._sensor_config_snapshot()
            if sensor_config['gyro_fs_dps'] != int(self.expected_gyro_fs.currentData()):
                raise ValueError('GYRO 实时数据换算量程为 ±{0} dps，但本次预期 ±{1} dps。'
                                 '请先确认 MCU 实际量程、上位机解析比例及串口状态，不能混用。'.format(
                                  sensor_config['gyro_fs_dps'], self.expected_gyro_fs.currentData()))
            profile=copy.deepcopy(load_profile(str(ROOT)))
            # 仅覆盖本次温补的工况副本；常温标定质量配置与速度点完全不改。
            rates_fit,rates_val=self._selected_rates()
            high_speed=max(rates_fit+rates_val)>30.0
            configure_thermal_gyro_profile(profile, fit_rates=rates_fit, verify_rates=rates_val)
            if self.dynamic.isChecked():
                if high_speed and not self.check_highspeed.isChecked():
                    raise ValueError('拟合或独立验证速率超过30°/s：必须确认WK温箱内线缆、滑环及连续多圈运行安全')
                # 不设置人为累计角度上限；仍在启动前验证两轴速率/加速度参数。
                accel = int(self.gyro_accel.value())
                for rate in rates_fit + rates_val:
                    for axis in ('inner','outer'):
                        wk_signed_velocity(+rate,accel,axis)
                        wk_signed_velocity(-rate,accel,axis)
            profile['quality']['temperature_min_c']=-45.0
            profile['quality']['temperature_max_c']=90.0
            profile['quality']['temperature_span_max_c']=0.5
            # GYRO 参考速度不从指令猜测，而来自转台编码器角度差分。
            if self.dynamic.isChecked() and not turntableData.is_turntable_data_available:
                raise ValueError('动态温补没有可用的转台反馈测速')
            if self.chamber_mode.currentData()=='plc':
                if not self.check_plc.isChecked():
                    raise ValueError('PLC自动控温前必须确认原上位机在本设备上实测设温成功')
                if OFFLINE_DEBUG:raise ValueError('OFFLINE_DEBUG 模式禁止真实自动控温实验')
                self._require_plc(time.monotonic())
            if not self.sn.text().strip():raise ValueError('PCB 唯一编号必填')
            all_steps=self._steps(self.dynamic.isChecked(),profile)
            steps=[steps_for_temperature(all_steps,splits[target]) for target in temperatures]
            immutable=self._resume_immutable(temperatures,profile,splits)
            resume_state=None
            continuing=self.resume_checkbox.isChecked()
            if continuing:
                name=self.resume_directory.text().strip()
                if not name:raise ValueError('请选择需要续做的 THERM_ 实验目录')
                folder=Path(name).expanduser().resolve()
                if not folder.is_dir():raise ValueError('续做实验目录不存在')
                if not folder.name.startswith('THERM_'):
                    raise ValueError('续做目录必须为原程序创建的 THERM_... 目录')
                config=json.loads((folder/'experiment_config.json').read_text(encoding='utf-8'))
                checkpoint=json.loads((folder/'temperature_measurements.json').read_text(encoding='utf-8'))
                resume_state=validate_resume(config,checkpoint,immutable,temperatures,steps)
                validate_appendable_raw_files(folder,len(resume_state['rows']))
            else:
                folder=Path(self.output.text().strip()).expanduser().resolve()/('THERM_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
                folder.mkdir(parents=True,exist_ok=False)
            recovered_rows=resume_state['rows'] if resume_state else []
            recovered_events=resume_state['events'] if resume_state else []
            recovered_count=resume_state['frame_count'] if resume_state else 0
            recovered_temp=resume_state['temp_index'] if resume_state else 0
            recovered_step=resume_state['step_index'] if resume_state else 0
            restored_progress=resume_state.get('task_progress',{}) if resume_state else {}
            # Preserve original run config and raw units; never overwrite ambient calibration.
            self.task={'run_dir':str(folder),'device_sn':self.sn.text().strip(),
                'temps':temperatures,'temp_i':recovered_temp,
                'steps_by_temperature':steps,
                'steps':steps[recovered_temp] if recovered_temp<len(temperatures) else [],'step_i':0,
                'resume_temp_index':recovered_temp if continuing else None,
                'resume_step_index':recovered_step if continuing else 0,
                'rows':list(recovered_rows), 'events':list(recovered_events),
                'profile':profile,'phase':'next_temperature',
                'phase_start':time.monotonic(),'stable_since':None,'frames':[],
                'frame_count':recovered_count,'last_frame':None,'chip_trace':[], 'retry_count':0,
                'baseline_config':(tiltSensorRawData.acc_fs,tiltSensorRawData.gyro_fs,tiltSensorRawData.data_odr),
                'last_imu_count':int(tiltSensorRawData.data_update_count),'last_imu_change':time.monotonic(),
                'dynamic':self.dynamic.isChecked(),'manual':self.chamber_mode.currentData()=='manual',
                'chip_stability_only':self.chip_stability_only.isChecked(),
                'thermal_gate_mode': ('quick_chip_only' if self.chip_stability_only.isChecked() else
                                      'plc_staged_v1' if self.chamber_mode.currentData()=='plc' else 'manual_legacy'),
                'pv_initial_seconds':int(self.pv_initial_seconds.value()),
                'pv_initial_range_c':float(self.pv_initial_range.value()),
                'pv_initial_slope_c_per_min':float(self.pv_initial_slope.value()),
                'pv_final_tolerance_c':float(self.pv_final_tolerance.value()),
                'pv_final_seconds':int(self.pv_final_seconds.value()),
                'pv_initial_trace':[], 'pv_initial_since':None, 'pv_initial_last_update':None,
                'pv_final_trace':[], 'pv_final_last_update':None,
                'thermal_elapsed_s':0.0, 'thermal_last_tick':None, 'thermal_pv_in_range':False,
                'temperature_wait_started':None,
                'return_ambient':self.return_ambient.isChecked(),
                'axis_model':'outer_x_inner_z', 'thermal_gyro_acceleration_dps2':int(self.gyro_accel.value()),
                'temperature_split_by_setpoint':splits,
                'deferred_by_temp':dict(restored_progress.get('deferred_by_temp',{})),
                'replay_mode':bool(restored_progress.get('replay_mode',False)),
                'replay_queue':list(restored_progress.get('replay_queue',[])),
                'unresolved':list(restored_progress.get('unresolved',[])),
                'hold_count':int(restored_progress.get('thermal_hold_count',0)),
                'group_rechecks':dict(restored_progress.get('group_rechecks',{})),
                'guard':None,'rate_preflight_feedback':[], 'rate_sample_feedback':[]}
            if not continuing:
                atomic_write_json(folder/'experiment_config.json', {
                    'resume_schema_version':RESUME_SCHEMA,
                    'resume_immutable_config':immutable,
                    'device_sn':self.task['device_sn'],'temperature_setpoints_c':temperatures,
                    'fit_temperature_setpoints_c':plan['fit_temperatures_c'],
                    'validation_temperature_setpoints_c':plan['validation_temperatures_c'],
                    'temperature_schedule_kind':'separate_fit_validation_v1',
                    'temperature_split':self.task['temperature_split_by_setpoint'],
                    'steps_per_temperature':[len(part) for part in steps],
                    'gyro_expected_full_scale_dps':int(self.expected_gyro_fs.currentData()),
                    'imu_sensor_config':sensor_config,
                    'temperature_polynomial_degree':3,
                    'thermal_stability_mode': ('quick_chip_only' if self.chip_stability_only.isChecked() else
                                              'plc_staged_v1' if self.chamber_mode.currentData()=='plc' else 'manual_legacy'),
                    'thermal_stability_seconds':int(self.dwell.value()),
                    'pv_initial_window_seconds':int(self.pv_initial_seconds.value()),
                    'pv_initial_range_c':float(self.pv_initial_range.value()),
                    'pv_initial_slope_c_per_min':float(self.pv_initial_slope.value()),
                    'pv_final_tolerance_c':float(self.pv_final_tolerance.value()),
                    'pv_final_stable_seconds':int(self.pv_final_seconds.value()),
                    'chip_stability_window_seconds':60,
                    'chip_stability_range_c':0.2,
                    'temperature_plan_note': 'independent_holdout_tests_only_with_separate_temperature_inputs',
                    'axis_model_confirmed_by_operator':True,'chamber_control':self.chamber_mode.currentData(),
                    'gyro_dynamic':self.dynamic.isChecked(),'quality_profile':profile,
                    'gyro_fit_rates_dps':list(rates_fit),'gyro_verify_rates_dps':list(rates_val),
                    'gyro_rate_mode':self.gyro_rate_mode.currentData(),
                    'gyro_acceleration_dps2':int(self.gyro_accel.value()),
                    'chamber_control_verified_by_operator':self.check_plc.isChecked(),
                    'chamber_plc_ip':str(tcComm.ip) if self.chamber_mode.currentData()=='plc' else None,
                    'return_to_25c_on_success':bool(self.return_ambient.isChecked()),
                    'production_release':False})
            self._raw_file=(folder/'imu_frame_means.csv').open('a' if continuing else 'w',
                                                               newline='',encoding='utf-8' if continuing else 'utf-8-sig')
            self._raw_writer=csv.writer(self._raw_file)
            self._raw_jsonl=(folder/'imu_full_frames.jsonl').open('a' if continuing else 'w',encoding='utf-8')
            if not continuing:
                self._raw_writer.writerow(['utc','target_temp_c','step','frame_update_count','imu_temp_c',
                    'chamber_pv_c','inner_deg','outer_deg','inner_rate_dps','outer_rate_dps',
                    'acc_x_g','acc_y_g','acc_z_g','gyro_x_dps','gyro_y_dps','gyro_z_dps','feedback_age_ms'])
            self._feedback_jsonl=(folder/'wk_independent_position_feedback.jsonl').open(
                'a' if continuing else 'w',encoding='utf-8')
            turntable_feedback_queue_set(True,clear=True)
            tilt_sensor_calibration_queue_set(True,clear=True)
            self._lock_ui(True)
            self.start_button.setEnabled(False);self.stop_button.setEnabled(True)
            self._log(('续做未完成实验，已完成工况 '+str(len(recovered_rows))+' 项：' if continuing else '任务已启动：')+str(folder))
            self._log(f'本次选择{len(temperatures)}个温度点：{temperatures}；'
                      f'拟合温度={plan["fit_temperatures_c"]}（完整工况）；独立验证温度={plan["validation_temperatures_c"]}（仅测试）；实测GYRO量程±{sensor_config["gyro_fs_dps"]} dps；'
                      f'MCU报告确认={sensor_config["gyro_fs_reported_by_mcu"]}')
            if not sensor_config['gyro_fs_reported_by_mcu']:
                self._log('警告：MCU未明确报告GYRO量程；本次仅供研发，不可作为正式发布参数。')
            self._log('温补GYRO多速率拟合：'+str(rates_fit)+'；独立验证：'+str(rates_val))
            if self.task['chip_stability_only']:
                self._log('温度模式=快速流程测试：PLC PV在目标±1℃连续30秒后，芯片60秒真实新帧范围≤0.2℃即开始；跳过正式共同热平衡和最终PV精确稳定检查。')
            elif self.task['manual']:
                self._log(f'温度模式=人工设温：人工确认到温后共同热平衡{self.dwell.value()}秒，并检查芯片最近60秒波动≤0.2℃；不执行连续PLC PV趋势门槛。')
            else:
                self._log('温度模式=正式PLC分阶段：初步PV±1℃连续观察{}秒（极差≤{:.2f}℃、斜率≤{:.3f}℃/min），共同热平衡{}秒，最终PV±{:.2f}℃连续{}秒，芯片60秒波动≤0.2℃。'.format(
                    self.pv_initial_seconds.value(),self.pv_initial_range.value(),self.pv_initial_slope.value(),
                    self.dwell.value(),self.pv_final_tolerance.value(),self.pv_final_seconds.value()))
            # 在任何转台/PLC运动前记录初始检查点；首次工况失败同样可以续做。
            self._save_partial('RUNNING','实验已启动；等待首个温度/恢复温度确认')
            self._tick()
        except Exception as exc:
            if self.task is not None:self._abort('启动失败：'+str(exc))
            else:QMessageBox.warning(self.page,'未能启动温补',str(exc))

    def _confirm_temperature(self):
        t=self.task
        if not t or t['phase']!='wait_manual':return
        target=t['temps'][t['temp_i']]
        actual=float(self.manual_pv.value())
        if abs(actual-target)>2.0:
            QMessageBox.warning(self.page,'温度未达到','手动输入的温箱 PV 与目标相差超过 2℃')
            return
        t['manual_confirmed_pv']=actual
        t['phase']='thermal_stability'
        t['phase_start']=time.monotonic()
        t['chip_trace']=[]
        self.confirm_temp.setEnabled(False)
        self._log(f'人工到温确认：目标 {target}℃；实测 {actual}℃。开始 IMU 内温稳定检查')

    def _frame_sample(self,frame):
        t=self.task
        if t is None:return
        stamp=int(frame.get('monotonic_time_ns',0) or 0)
        fb=int(turntableData.last_update_monotonic_ns or 0)
        if stamp<=0 or fb<=0 or abs(stamp-fb)>250_000_000:return
        if stamp*1e-9 < t['sample_start']:return
        if frame.get('data_odr')!=t['baseline_config'][2] or (frame.get('acc_fs'),frame.get('gyro_fs'))!=t['baseline_config'][:2]:
            raise ValueError('实验中途 IMU 量程或 ODR 发生变化')
        acc,nacc,naccok=frame_average_sanitized(frame['acc_g_arr'],3.,True)
        gyro,ngyr,ngyrok=frame_average_sanitized(frame['gyr_dps_arr'],6.,True)
        if acc is None or gyro is None:return
        pv=t['manual_confirmed_pv'] if t['manual'] else tcData.pv
        sample={'acc':acc.tolist(),'gyro':gyro.tolist(),
                'acc_raw_samples':nacc,'acc_accepted_samples':naccok,
                'gyro_raw_samples':ngyr,'gyro_accepted_samples':ngyrok,
                'inner_deg':float(turntableData.inner_axis_position),
                'outer_deg':float(turntableData.outer_axis_position),
                'inner_rate_dps':float(turntableData.inner_axis_speed),
                'outer_rate_dps':float(turntableData.outer_axis_speed),
                'temp_c':float(frame.get('temp_c')),
                'feedback_age_ms':abs(stamp-fb)/1.e6}
        t['frames'].append(sample)
        self._raw_jsonl.write(json.dumps({'frame':frame,'step_id':t['steps'][t['step_i']]['step_id'],
            'target_temp_c':t['temps'][t['temp_i']]},ensure_ascii=False)+'\n')
        self._raw_writer.writerow([datetime.datetime.now(datetime.timezone.utc).isoformat(),
            t['temps'][t['temp_i']],t['steps'][t['step_i']]['step_id'],frame.get('frame_update_count'),
            sample['temp_c'],pv,sample['inner_deg'],sample['outer_deg'],
            sample['inner_rate_dps'],sample['outer_rate_dps'],*sample['acc'],*sample['gyro'],sample['feedback_age_ms']])
        t['frame_count']+=1

    def _collect(self):
        # Drain a limited number every tick; the recording queue is bounded and drop-checking is mandatory.
        t=self.task
        for _ in range(200):
            try:f=tilt_sensor_calibration_frame_get_nowait()
            except queue.Empty:break
            if t['phase']=='sample':self._frame_sample(f)

    def _request_final_stop(self, now, reason):
        """Successful completion requires real 1# servo standstill confirmation."""
        t=self.task
        if not self._stop_axes():
            raise ValueError('任务结束WK停车命令失败，请立即现场处理')
        self._begin_wk_stop_wait(t,now)
        t['phase']='final_stop_wait'
        t['finish_success_reason']=reason
        self._log('采集流程结束；正在确认WK两轴已真实停车，尚未标记实验完成')

    def _step_key(self, temp_index, step_index):
        t=self.task
        return (float(t['temps'][temp_index]),
                t['steps_by_temperature'][temp_index][step_index]['step_id'])

    def _accepted_step_keys(self):
        return {(float(r['temperature_target_c']),r['step_id']) for r in self.task['rows']}

    def _next_step_after_result(self, now):
        """Advance one planned position, or the next one-off deferred retry."""
        t=self.task
        t['retry_count']=0
        if t.get('replay_mode'):
            queue=t.get('replay_queue',[])
            t['step_i']=queue.pop(0) if queue else len(t['steps'])
        else:
            t['step_i']+=1
        t['phase']='position';t['phase_start']=now

    def _defer_current_step(self, now, reason):
        """Only quality/steady-speed failures reach here; motor/PLC faults abort."""
        t=self.task
        step=t['steps'][t['step_i']]
        entry={'temp_index':int(t['temp_i']),'step_index':int(t['step_i']),
               'temperature_target_c':float(t['temps'][t['temp_i']]),
               'step_id':step['step_id'],'sensor':step['sensor'],
               'rotation_axis':step.get('rotation_axis'),
               'target_rate_dps':step.get('target_rate_dps'),'reason':str(reason)}
        if t.get('replay_mode'):
            t['unresolved'].append(entry)
            self._log('补测仍不合格，列入缺失清单：'+str(entry['step_id'])+'；'+str(reason))
        else:
            by_temp=t['deferred_by_temp'].setdefault(str(t['temp_i']),[])
            if t['step_i'] not in by_temp:
                by_temp.append(t['step_i'])
            self._log('本工况重试耗尽，已记入本温度末尾待补测：'+step['step_id']+'；'+str(reason))
        t['retry_count']=0
        t['frames']=[]
        t.pop('pending_dynamic_row',None)
        # Dynamic segments cannot be skipped until both axes are ACTUALLY stopped.
        if step['mode']=='rate':
            if not self._stop_axes():
                raise ValueError('质量失败后停车命令失败：必须现场安全中止')
            self._begin_wk_stop_wait(t,now)
            t['phase']='wait_stop_defer'
        else:
            self._next_step_after_result(now)
            self._save_partial('RUNNING','待补测：'+step['step_id'])

    def _start_temperature_hold(self, now, reason, full_soak=False):
        t=self.task
        if t.get('phase') in ('wait_stop_thermal','thermal_pause'):
            return
        t['hold_requires_soak']=bool(full_soak)
        t['hold_reason']=str(reason)
        t['hold_count']=int(t.get('hold_count',0))+1
        t['frames']=[]
        t.pop('pending_dynamic_row',None)
        self._log('温度质量暂停（工况不提交）：'+str(reason)+'；开始WK停车确认，不清空已接受工况')
        if not self._stop_axes():
            raise ValueError('温漂暂停停车命令发送失败')
        self._begin_wk_stop_wait(t,now)
        t['phase']='wait_stop_thermal'

    def _audit_current_temperature_groups(self):
        """Do not silently fit one sensor matrix from thermally inconsistent poses.

        At most ONE same-temperature recapture per sensor/split group. Original
        raw frames remain in the append-only log; invalidated summary rows are
        removed from model inputs, but recorded as events.
        """
        t=self.task
        i=t['temp_i']
        temp=float(t['temps'][i])
        steps=t['steps']
        by_group={}
        for j,step in enumerate(steps):
            by_group.setdefault((step['sensor'],step['split']),[]).append(j)
        accepted=self._accepted_step_keys()
        for (sensor,split),indices in by_group.items():
            group_rows=[r for r in t['rows'] if float(r['temperature_target_c'])==temp
                        and r['sensor']==sensor and r['split']==split]
            if len(group_rows)<2:
                continue
            temps=[float(r['temperature_mean_c']) for r in group_rows]
            if max(temps)-min(temps)<=0.6:
                continue
            key=f'{i}:{sensor}:{split}'
            prior=int(t['group_rechecks'].get(key,0))
            # Remove rows so a cross-temperature batch can never enter the fit.
            invalid_ids={r['step_id'] for r in group_rows}
            t['rows']=[r for r in t['rows'] if not (
                float(r['temperature_target_c'])==temp and r['step_id'] in invalid_ids)]
            if prior==0:
                t['group_rechecks'][key]=1
                pending=t['deferred_by_temp'].setdefault(str(i),[])
                for j in indices:
                    if j not in pending:pending.append(j)
                self._log(f'{temp:g}℃ {sensor}/{split}跨工况芯片温差'
                          f'{max(temps)-min(temps):.3f}℃>0.6℃；该组已失效并加入一次有限补测')
            else:
                self._log(f'{temp:g}℃ {sensor}/{split}重复采集后温度仍不一致；'
                          '该组全部记录为不完整，不参加温补参数拟合')
                for j in indices:
                    step=steps[j]
                    item={'temp_index':i,'step_index':j,'temperature_target_c':temp,
                          'step_id':step['step_id'],'sensor':sensor,
                          'rotation_axis':step.get('rotation_axis'),
                          'target_rate_dps':step.get('target_rate_dps'),
                          'reason':'跨工况芯片温度跨度>0.6℃，有限重采仍不一致'}
                    if not any(x['temp_index']==i and x['step_index']==j for x in t['unresolved']):
                        t['unresolved'].append(item)
            self._save_partial('RUNNING','温度批次一致性审计，剔除异常数据')
            return True
        return False

    def _advance_temperature(self, now):
        t=self.task
        t['temp_i']+=1
        t['step_i']=0
        t['replay_mode']=False
        t['replay_queue']=[]
        t['guard']=None
        t['phase']='next_temperature';t['phase_start']=now
        t['steps']=(t['steps_by_temperature'][t['temp_i']]
                    if t['temp_i']<len(t['temps']) else [])
        self._save_partial('RUNNING','完成一个温度点（可能有待补测工况）')

    def _poll_reference_feedback(self):
        t=self.task
        # Collect each independent controller poll, not each repeated IMU frame.
        for _ in range(500):
            try:sample=turntable_feedback_get_nowait()
            except queue.Empty:break
            if not sample.get('monotonic_time_ns'):
                continue
            phase=t.get('phase')
            if phase in ('wait_rate','sample'):
                if phase=='sample' and (int(sample['monotonic_time_ns'])
                        < int(float(t.get('sample_start',0))*1e9)):
                    continue
                target='rate_preflight_feedback' if phase=='wait_rate' else 'rate_sample_feedback'
                t.setdefault(target,[]).append(sample)
                if phase=='wait_rate':
                    cutoff=time.perf_counter_ns()-10_000_000_000
                    t[target]=[x for x in t[target] if int(x['monotonic_time_ns'])>=cutoff]
            if self._feedback_jsonl:
                data={'temp_c':float(t['temps'][t['temp_i']]) if t['temp_i']<len(t['temps']) else None,
                      'phase':phase,'step_id':(t['steps'][t['step_i']]['step_id']
                         if t['step_i']<len(t['steps']) else None), 'feedback':sample}
                self._feedback_jsonl.write(json.dumps(data,ensure_ascii=False)+'\n')

    def _save_partial(self, status, reason):
        t=self.task
        if not t:return
        folder=Path(t['run_dir'])
        # 先确保原始帧落盘，再原子提交“已确认完成”的统计工况。
        for obj in (self._raw_file,self._raw_jsonl,getattr(self,'_feedback_jsonl',None)):
            if obj:
                obj.flush()
                os.fsync(obj.fileno())
        checkpoint={'status':status,'reason':reason,'device_sn':t['device_sn'],
            'rows':t['rows'],'events':t['events'],'imu_frame_count':t['frame_count'],
            'imu_queue_drops':tilt_sensor_calibration_queue_drop_count_get(),
            'task_progress':{'temp_index':t['temp_i'],'step_index':t['step_i'],
                'replay_mode':bool(t.get('replay_mode')),'replay_queue':list(t.get('replay_queue',[])),
                'deferred_by_temp':t.get('deferred_by_temp',{}),
                'unresolved':t.get('unresolved',[]),'thermal_hold_count':t.get('hold_count',0),
                'group_rechecks':t.get('group_rechecks',{})}}
        # 先写CSV临时文件，再提交JSON检查点；断电时最多丢失最近未提交的一步。
        csv_path=folder/'temperature_measurements.csv'
        csv_tmp=folder/'temperature_measurements.csv.new'
        with csv_tmp.open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f)
            w.writerow(['target_temperature_c','temperature_split','step_id','sensor','mode','split',
                        'target_rate_dps','rotation_axis','temperature_mean_c',
                        'reference_x','reference_y','reference_z','measured_x','measured_y','measured_z','accepted_frames'])
            for row in t['rows']:
                measure=row.get('acc_raw_mean_g') if row['sensor']=='acc' else row.get('gyro_raw_mean_dps')
                w.writerow([row['temperature_target_c'],row['temperature_split'],row['step_id'],row['sensor'],
                            row['mode'],row['split'],row.get('target_rate_dps'),row.get('rotation_axis'),
                            row['temperature_mean_c'],*row['reference'],*measure,row['accepted_frames']])
            f.flush();os.fsync(f.fileno())
        os.replace(csv_tmp,csv_path)
        atomic_write_json(folder/'temperature_measurements.json',checkpoint)

    def _finish(self, success, reason):
        t=self.task
        if t is None:return
        stopped=(True if t.get('final_stop_confirmed') else self._stop_axes())
        # Final completion is never confused with data completeness.
        incomplete=bool(t.get('unresolved'))
        if success and incomplete:
            reason=reason+f'；缺失{len(t["unresolved"])}项，已生成待补测报告，禁止正式模型推荐'
        if not success and not t['manual'] and not t.get('plc_stop_requested'):
            # Stop PLC fixed-temperature control on abort; a failed command is
            # never treated as proof that the heater/cooler is safely off.
            try:
                with tcComm.thread_lock:
                    chamber_stopped=bool(tc_fixed_value_stop()) if tcComm.is_connected else False
                self._log('异常中止：已尝试停止PLC温箱定值运行，返回='+str(chamber_stopped)+
                          '。必须在原温箱面板现场确认状态。')
            except Exception as stop_exc:
                self._log('PLC温箱停止指令异常：'+str(stop_exc)+'；请现场确认/采取安全措施')
        try:
            self._log('结束：'+reason+'；WK实际停车状态'+
                      ('已确认' if t.get('final_stop_confirmed') else
                       '仅已发送停车指令，尚未获得真实状态确认' if stopped else
                       '停车指令失败（需现场硬件急停）'))
            status=('PARTIAL_COMPLETED' if incomplete else 'COMPLETED') if success and stopped else 'INCOMPLETE'
            self._save_partial(status,reason)
            if incomplete:
                export_incomplete_xlsx(t['run_dir'],t['rows'],t['unresolved'],t['temps'],reason)
                self._log('数据不完整，已输出thermal_incomplete_data_report.xlsx；不得视为28套模型验证通过')
                # Do not waste valid ACC data just because a GYRO dynamic
                # segment failed, or vice versa. Evaluate ONLY sensors whose
                # entire planned fit+validation grid was accepted. Keep the
                # research-only output in a conspicuously separate directory.
                accepted=self._accepted_step_keys()
                fully_complete=[]
                for sensor in ('acc','gyro'):
                    if sensor=='gyro' and not t['dynamic']:continue
                    planned={(float(temp),step['step_id'])
                             for temp,steps in zip(t['temps'],t['steps_by_temperature'])
                             for step in steps if step['sensor']==sensor}
                    if planned and planned.issubset(accepted):fully_complete.append(sensor)
                if fully_complete:
                    try:
                        subfolder=Path(t['run_dir'])/'PARTIAL_ONLY_COMPLETE_SENSORS_RESEARCH'
                        subfolder.mkdir(exist_ok=True)
                        sensors=tuple(fully_complete)
                        preliminary=save_variable_models(subfolder,t['rows'],t['temps'],sensors)
                        preliminary['model_selection']=run_thermal_model_selection(
                            subfolder,t['rows'],t['temps'],sensors,source_folder=t['run_dir'])
                        preliminary['partial_run_warning']=('其他传感器有未补齐工况；'
                            '本子目录只分析全部工况齐全的传感器，严禁作为整机发布结果。')
                        export_thermal_xlsx(subfolder,t['rows'],preliminary)
                        atomic_write_json(subfolder/'NOT_FOR_RELEASE.json',{
                            'status':'PARTIAL_OTHER_SENSOR_MISSING','complete_sensors':fully_complete,
                            'production_release':False,'warning':preliminary['partial_run_warning']})
                        self._log('已保留完整传感器的单独研发分析：'+', '.join(fully_complete)+
                                  '；仍须补齐所有缺失工况才允许整机最终验收')
                    except Exception as partial_exc:
                        self._log('部分传感器研发分析失败（原始数据与缺失报告已保留）：'+str(partial_exc))
            if success and stopped and not incomplete:
                # Candidate fitting cannot overwrite or replace ambient data.
                result=save_variable_models(t['run_dir'],t['rows'],t['temps'],
                     ('acc','gyro') if t['dynamic'] else ('acc',))
                try:
                    save_optional_gyro_bias(t['run_dir'],t['rows'],t['temps'])
                except ValueError as exc:self._log('GYRO静态偏置拟合不通过：'+str(exc))
                # Pure-data selection; neither PLC nor motor code is touched.
                # Failure to fit models must never turn a safe acquisition into a
                # falsely claimed validated calibration.
                try:
                    selected = run_thermal_model_selection(
                        t['run_dir'], t['rows'], t['temps'],
                        ('acc','gyro') if t['dynamic'] else ('acc',))
                    result['model_selection'] = selected
                    display=[]
                    for sensor, item in selected['sensors'].items():
                        display.append(f'{sensor.upper()}: {item.get("selected_id") or "未选出"} / {item.get("status_text",item["status"])}')
                    self.selection_result.setText('模型优选（研发候选）：'+'；'.join(display))
                    self._log(self.selection_result.text())
                except Exception as selection_exc:
                    # Record a diagnostic, not a success claim, while keeping
                    # the original cubic fit and data report usable.
                    result['model_selection'] = {'sensors': {}, 'status':'SELECTION_FAILED',
                                                 'reason': str(selection_exc)}
                    self.selection_result.setText('模型优选失败：'+str(selection_exc))
                    self._log(self.selection_result.text())
                export_thermal_xlsx(t['run_dir'],t['rows'],result)
                self._log('温补候选模型：'+str(result['sensors']))
        finally:
            tilt_sensor_calibration_queue_set(False)
            turntable_feedback_queue_set(False)
            self._lock_ui(False)
            self.start_button.setEnabled(True);self.stop_button.setEnabled(False)
            self.confirm_temp.setEnabled(False)
            self.task=None
            for obj in (getattr(self,'_raw_file',None),getattr(self,'_raw_jsonl',None),getattr(self,'_feedback_jsonl',None)):
                try:
                    if obj:obj.close()
                except Exception:pass
            self.label.setText(('采集部分完成：有待补测工况，见缺失报告' if incomplete else
                '采集已完成（模型仅为研发候选，是否通过验证见报告）') if success and stopped else '中止/未完成：'+reason)
            if not stopped:
                QMessageBox.critical(self.page,'停车未确认','软件停车命令失败，请立即使用现场硬件急停并排查')

    def _abort(self,reason):
        t=self.task
        if t is None or t.get('phase')=='abort_stop_wait':return
        # Stop chamber control immediately on failure; NEVER assume its actual
        # heater/refrigerator state from an accepted PLC command alone.
        if not t['manual']:
            try:
                with tcComm.thread_lock:
                    ok=bool(tc_fixed_value_stop()) if tcComm.is_connected else False
                t['plc_stop_requested']=True
                self._log('故障中止PLC停止请求='+str(ok)+'；须在温箱现场确认真实状态')
            except Exception as exc:
                self._log('PLC停止请求失败：'+str(exc)+'，必须现场核查')
        if not self._stop_axes():
            self._finish(False,reason+'；WK停车命令失败')
            return
        self._begin_wk_stop_wait(t,time.monotonic())
        t['phase']='abort_stop_wait'
        t['abort_reason']=reason
        self.label.setText('安全中止停车确认中；请现场监护WK两轴和温箱')


    def _tick(self):
        t=self.task
        if t is None:return
        now=time.monotonic()
        # Controlled emergency stop must not be blocked by missing PLC/IMU
        # feedback that originally triggered the abort.
        if t.get('phase')=='abort_stop_wait':
            try:
                ready,detail=self._wk_stop_confirmed(t,now)
                if ready:
                    t['final_stop_confirmed']=True
                    self._finish(False,t.get('abort_reason','安全中止'))
                    return
                if now-t['phase_start']>30:
                    self._finish(False,t.get('abort_reason','安全中止')+
                                 '；30秒内未确认实际停车，必须现场急停')
                    return
                self.label.setText('WK停车确认中：'+detail)
            except Exception as exc:
                self._finish(False,t.get('abort_reason','安全中止')+
                             '；停车状态无法确认：'+str(exc))
            return
        try:
            self._motion_status()
            if tilt_sensor_calibration_queue_drop_count_get()>0:
                raise ValueError('IMU记录队列丢帧；拒绝继续温补实验')
            with tiltSensorRawData.data_lock:
                imu_count=int(tiltSensorRawData.data_update_count)
                config_now=(tiltSensorRawData.acc_fs,tiltSensorRawData.gyro_fs,tiltSensorRawData.data_odr)
            if config_now!=t['baseline_config']:
                raise ValueError('IMU 量程或 ODR 变化')
            if imu_count!=t['last_imu_count']:
                t['last_imu_count']=imu_count
                t['last_imu_change']=now
            elif now-t['last_imu_change']>5.0:
                raise ValueError('IMU 数据更新已停止超过 5 秒，拒绝把旧温度当作热平衡')
            if getattr(self,'_feedback_jsonl',None) is not None:
                self._poll_reference_feedback()
                if turntable_feedback_queue_drop_count_get()>0:
                    raise ValueError('WK独立编码器反馈队列溢出，拒绝用缺失参考数据标定')
            self._collect()
            if not t['manual']:
                chamber=self._require_plc(now)
                # PLC采集线程可能刚好在本tick取now之后刷新PV时间戳；以快照之后的时刻作为状态机时刻。
                now=time.monotonic()
                target=t['temps'][t['temp_i']] if t['temp_i']<len(t['temps']) else None
                if target is not None and t['phase'] not in ('next_temperature','verify_plc_sp'):
                    require_setpoint_ack(chamber,target)
            # A quality pause is NOT a safety abort. Global motor/PLC/IMU faults
            # above are still hard errors. No new samples are accepted during hold.
            running_phases=('position','wait_position','settle','wait_rate','sample')
            if not t['manual'] and not t.get('chip_stability_only') and t['phase'] in running_phases:
                if t.get('guard') is None:
                    t['guard']=ThermalRuntimeGuard(t['temps'][t['temp_i']])
                with tiltSensorRawData.data_lock:
                    chip_now=float(tiltSensorRawData.temp_c)
                    chip_count_now=int(tiltSensorRawData.data_update_count)
                action,thermal_reason=t['guard'].observe(now,float(chamber['pv']),
                    float(chamber['pv_updated']),chip_now,chip_count_now)
                if action=='safety':
                    raise ValueError('温度传感器不可信：'+thermal_reason)
                if action in ('hold','resoak'):
                    self._start_temperature_hold(now,thermal_reason,action=='resoak')
                    return
            if t['phase']=='next_temperature':
                if t['temp_i']>=len(t['temps']):
                    if not t['manual'] and t['return_ambient']:
                        self._issue_plc_setpoint(25.0)
                        t['phase']='verify_return'
                        t['phase_start']=now
                        t['pv_stable_since']=None
                        self._log('全部工况已完成：PLC自动回温25℃，等待SP回读和PV稳定后结束')
                        return
                    self._request_final_stop(now,'全部温度点与独立验证采集完成（人工模式或未启用自动回25℃）')
                    return
                if not self._stopped():raise ValueError('换温前两轴未静止')
                # On resume, don't re-heat and re-soak already complete setpoints.
                needed=({self._step_key(t['temp_i'],i)
                          for i in range(len(t['steps_by_temperature'][t['temp_i']]))}
                        if 'steps_by_temperature' in t else None)
                if needed and needed.issubset(self._accepted_step_keys()):
                    self._log(f'恢复运行：温度{t["temps"][t["temp_i"]]}℃全部工况已完成，跳过重复热浸')
                    self._advance_temperature(now)
                    return
                target=t['temps'][t['temp_i']]
                if 'steps_by_temperature' in t:
                    t['steps']=t['steps_by_temperature'][t['temp_i']]
                if not t['manual']:
                    self._issue_plc_setpoint(target)
                    t['phase']='verify_plc_sp'
                    self._log(f'已通过原PLC驱动请求设温 {target}℃；等待SP回读及运行状态确认')
                else:
                    t['phase']='wait_manual'
                    self._log(f'请在原温箱控制面板手工设为 {target}℃，读取实测 PV 并输入，达到目标后点击确认。不会自动发送未知 RS232 指令。')
                t['phase_start']=now
                self.confirm_temp.setEnabled(t['manual'])
            elif t['phase']=='final_stop_wait':
                ready, detail=self._wk_stop_confirmed(t,now)
                if ready:
                    t['final_stop_confirmed']=True
                    self._finish(True,t['finish_success_reason'])
                    return
                if now-t['phase_start']>30:
                    raise ValueError('结束阶段30秒未确认WK两轴1#待命，请现场检查：'+detail)
                self.label.setText('结束前WK真实停车确认：'+detail)
                return
            elif t['phase']=='verify_return':
                try:
                    require_setpoint_ack(chamber,25.0)
                except ChamberSafetyError:
                    if now-t['phase_start']>90:
                        raise ValueError('自动回25℃时SP回读/运行状态90秒未确认')
                    return
                t['phase']='wait_return'
                t['phase_start']=now
                t['pv_stable_since']=None
            elif t['phase']=='wait_return':
                require_setpoint_ack(chamber,25.0)
                if abs(chamber['pv']-25.0)<=1.0:
                    if t['pv_stable_since'] is None:t['pv_stable_since']=now
                    if now-t['pv_stable_since']>=30.0:
                        self._request_final_stop(now,'全部温补工况完成，并已自动回到25℃±1℃持续30秒')
                        return
                else:t['pv_stable_since']=None
                if now-t['phase_start']>21600:
                    raise ValueError('结束回25℃超时6小时')
            elif t['phase']=='verify_plc_sp':
                chamber=self._require_plc(now)
                try:
                    require_setpoint_ack(chamber,t['temps'][t['temp_i']])
                except ChamberSafetyError:
                    if now-t['phase_start']>90:
                        raise ValueError('温箱SP回读/运行状态在90秒内未确认，停止自动温补')
                    self.label.setText(f'等待温箱SP回读：目标{t["temps"][t["temp_i"]]}℃，回读{chamber["sp"]:.2f}℃')
                    return
                t['phase']='wait_plc';t['phase_start']=now;t['pv_stable_since']=None
                t['temperature_wait_started']=now
                t['pv_initial_since']=None;t['pv_initial_trace']=[];t['pv_initial_last_update']=None
                self._log(f'温箱SP回读匹配、运行模式确认；实测PV={chamber["pv"]:.2f}℃')
            elif t['phase']=='wait_manual':
                self.label.setText(f'温度 {t["temp_i"]+1}/{len(t["temps"])}：等待人工确认 {t["temps"][t["temp_i"]]}℃')
                return
            elif t['phase']=='wait_plc':
                if tcState.is_device_fault or not tcData.is_tc_data_available or not tcComm.is_connected:
                    raise ValueError('PLC温箱故障或通信丢失')
                pv=float(chamber['pv'])
                target=float(t['temps'][t['temp_i']])
                pv_stamp=min(float(chamber['pv_updated']),now)
                pv_age=now-pv_stamp
                pv_fresh=(0.0<=pv_age<=2.0)
                if t.get('chip_stability_only',False):
                    # 旧快速流程保留：PV±1℃连续30秒后，仅检查芯片60秒稳定。
                    if pv_fresh and abs(pv-target)<=1.0+1e-9:
                        if t.get('pv_stable_since') is None:t['pv_stable_since']=now
                        if now-t['pv_stable_since']>=30.0:
                            t['phase']='thermal_stability';t['phase_start']=now;t['chip_trace']=[]
                            t['last_chip_trace_count']=None
                            self._log('快速模式：PLC实时PV连续30秒在目标±1℃内，开始芯片60秒稳定检查（正式热浸已跳过）')
                    elif pv_fresh:
                        t['pv_stable_since']=None
                    self.label.setText(f'快速模式：等待温箱PV进入 {target:.2f}±1.00℃，当前PV={pv:.2f}℃'+
                                       ('' if pv_fresh else '（等待新鲜PV反馈）'))
                else:
                    # 正式PLC模式：进入±1℃只开启5分钟观察窗；还需极差与线性趋势同时合格。
                    if pv_fresh and abs(pv-target)<=1.0+1e-9:
                        if t.get('pv_initial_since') is None:
                            t['pv_initial_since']=now
                            t['pv_initial_trace']=[]
                            t['pv_initial_last_update']=None
                            self._log(f'温箱PV首次进入目标±1℃，开始初步稳定观察：{target:.2f}±1.00℃')
                        if pv_stamp>float(t.get('pv_initial_last_update') or 0.0):
                            t['pv_initial_trace'].append((pv_stamp,pv))
                            t['pv_initial_last_update']=pv_stamp
                        window=float(t['pv_initial_seconds'])
                        t['pv_initial_trace']=[x for x in t['pv_initial_trace'] if now-x[0]<=window+20.0]
                        pv_stable,covered,pv_span,pv_slope=chamber_stability_status(
                            t['pv_initial_trace'],now,window_seconds=window,
                            max_range_c=t['pv_initial_range_c'],
                            max_abs_slope_c_per_min=t['pv_initial_slope_c_per_min'])
                        observed=max(0.0,now-float(t['pv_initial_since']))
                        self.label.setText(
                            f'初步到温观察：{observed:.0f}/{window:.0f}s；PV={pv:.2f}℃；'
                            f'窗口覆盖={covered:.0f}s；极差={pv_span:.3f}/{t["pv_initial_range_c"]:.2f}℃；'
                            f'斜率={pv_slope:+.3f}/{t["pv_initial_slope_c_per_min"]:.3f}℃/min')
                        if observed>=window and pv_stable:
                            t['phase']='thermal_soak';t['phase_start']=now
                            t['thermal_elapsed_s']=0.0;t['thermal_last_tick']=now;t['thermal_pv_in_range']=True
                            t['chip_trace']=[];t['last_chip_trace_count']=None
                            self._log(f'初步温箱稳定通过：窗口极差={pv_span:.3f}℃、斜率={pv_slope:+.3f}℃/min；开始共同热平衡计时')
                    elif pv_fresh:
                        if t.get('pv_initial_since') is not None:
                            self._log(f'初步到温观察重置：PV={pv:.2f}℃已离开目标±1℃范围')
                        t['pv_initial_since']=None;t['pv_initial_trace']=[];t['pv_initial_last_update']=None
                        self.label.setText(f'等待温箱初步到温：目标 {target:.2f}±1.00℃，当前PV={pv:.2f}℃')
                    else:
                        self.label.setText(f'初步到温观察：等待新鲜PLC PV反馈（当前反馈年龄{pv_age:.1f}s）')
                wait_start=float(t.get('temperature_wait_started') or t['phase_start'])
                if now-wait_start>21600:raise ValueError('温箱初步到温/稳定等待超时 6 小时')
            elif t['phase']=='thermal_soak':
                if not self._stopped():raise ValueError('共同热平衡阶段转台发生运动')
                pv=float(chamber['pv']);target=float(t['temps'][t['temp_i']])
                pv_age=now-min(float(chamber['pv_updated']),now)
                pv_fresh=(0.0<=pv_age<=2.0)
                in_band=pv_fresh and abs(pv-target)<=1.0+1e-9
                last_tick=float(t.get('thermal_last_tick') or now)
                dt=max(0.0,now-last_tick)
                t['thermal_last_tick']=now
                if in_band:
                    if not t.get('thermal_pv_in_range',False):
                        t['thermal_pv_in_range']=True
                        self._log(f'温箱PV恢复到目标±1℃内，继续累计共同热平衡（已累计{t["thermal_elapsed_s"]:.0f}s）')
                    else:
                        # QTimer周期约100ms；限制单次补记，避免界面卡顿后把停顿时间算入热浸。
                        t['thermal_elapsed_s']+=min(dt,1.0)
                else:
                    if t.get('thermal_pv_in_range',False):
                        if not pv_fresh:
                            self._log('温箱PV反馈超过2秒未更新，共同热平衡暂停累计；收到新鲜反馈后继续')
                        else:
                            self._log(f'温箱PV={pv:.2f}℃超出目标±1℃，共同热平衡暂停累计；恢复后继续')
                    t['thermal_pv_in_range']=False
                with tiltSensorRawData.data_lock:
                    chip=float(tiltSensorRawData.temp_c)
                    chip_frame_count=int(tiltSensorRawData.data_update_count)
                if not math.isfinite(chip) or not -45<=chip<=90:
                    raise ValueError('IMU 内温读数异常')
                if chip_frame_count!=t.get('last_chip_trace_count'):
                    t['chip_trace'].append((now,chip));t['last_chip_trace_count']=chip_frame_count
                t['chip_trace']=[v for v in t['chip_trace'] if now-v[0]<=120]
                wait_start=float(t.get('temperature_wait_started') or t['phase_start'])
                if now-wait_start>21600:raise ValueError('共同热平衡阶段超过6小时仍未完成')
                self.label.setText(f'共同热平衡：有效累计 {t["thermal_elapsed_s"]:.0f}/{self.dwell.value()}s；'
                                   f'PV={pv:.2f}℃；目标={target:.2f}℃；'
                                   + ('温箱在范围内，计时中' if in_band else
                                      'PV反馈超过2秒未更新，计时暂停' if not pv_fresh else
                                      '温箱超出±1℃，计时暂停'))
                if t['thermal_elapsed_s']>=self.dwell.value():
                    t['phase']='final_stability';t['phase_start']=now
                    t['pv_final_trace']=[];t['pv_final_last_update']=None
                    self._log('共同热平衡有效累计时间已满足；开始最终温箱±偏差连续稳定检查及芯片稳定检查')
            elif t['phase']=='final_stability':
                if not self._stopped():raise ValueError('最终温度稳定检查阶段转台发生运动')
                pv=float(chamber['pv']);target=float(t['temps'][t['temp_i']])
                final_tol=float(t['pv_final_tolerance_c']);final_window=float(t['pv_final_seconds'])
                pv_stamp=min(float(chamber['pv_updated']),now)
                pv_age=now-pv_stamp
                pv_fresh=(0.0<=pv_age<=2.0)
                if pv_fresh and abs(pv-target)>1.0+1e-9:
                    self._log(f'最终稳定检查期间PV={pv:.2f}℃超出目标±1℃；重新执行30分钟共同热平衡')
                    t['phase']='thermal_soak';t['phase_start']=now
                    t['thermal_elapsed_s']=0.0;t['thermal_last_tick']=now;t['thermal_pv_in_range']=False
                    t['pv_final_trace']=[];t['pv_final_last_update']=None
                    return
                if pv_fresh and abs(pv-target)<=final_tol+1e-9:
                    if pv_stamp>float(t.get('pv_final_last_update') or 0.0):
                        t['pv_final_trace'].append((pv_stamp,pv))
                        t['pv_final_last_update']=pv_stamp
                else:
                    if t['pv_final_trace']:
                        reason=('PLC PV反馈超过2秒未更新' if not pv_fresh else
                                f'PV={pv:.2f}℃超出目标±{final_tol:.2f}℃')
                        self._log('最终PV精确稳定计时重置：'+reason)
                    t['pv_final_trace']=[];t['pv_final_last_update']=None
                t['pv_final_trace']=[x for x in t['pv_final_trace'] if now-x[0]<=final_window+20.0]
                pv_final_ok,pv_covered,pv_max_dev=chamber_band_status(
                    t['pv_final_trace'],now,target_c=target,tolerance_c=final_tol,
                    window_seconds=final_window)
                with tiltSensorRawData.data_lock:
                    chip=float(tiltSensorRawData.temp_c)
                    chip_frame_count=int(tiltSensorRawData.data_update_count)
                if not math.isfinite(chip) or not -45<=chip<=90:
                    raise ValueError('IMU 内温读数异常')
                if chip_frame_count!=t.get('last_chip_trace_count'):
                    t['chip_trace'].append((now,chip));t['last_chip_trace_count']=chip_frame_count
                t['chip_trace']=[v for v in t['chip_trace'] if now-v[0]<=120]
                chip_ok,chip_covered,chip_span=chip_stability_status(t['chip_trace'],now)
                wait_start=float(t.get('temperature_wait_started') or t['phase_start'])
                if now-wait_start>21600:raise ValueError('最终温度稳定/芯片稳定检查超过6小时')
                self.label.setText(f'最终检查：PV={pv:.2f}℃，目标偏差窗口 {pv_covered:.0f}/{final_window:.0f}s，'
                                   f'最大偏差={pv_max_dev:.3f}/{final_tol:.2f}℃；'
                                   f'芯片={chip:.2f}℃，60秒窗口={chip_covered:.0f}s，极差={chip_span:.3f}/0.2℃')
                if pv_final_ok and chip_ok and abs(chip-pv)<=10.0:
                    t['guard']=None  # new epoch; old temperature history is no longer relevant
                    if t.get('resume_temp_index')==t['temp_i']:
                        t['step_i']=t.pop('resume_step_index',0);t['resume_temp_index']=None
                        self._log(f'恢复点温度稳定检查通过，从本温度第{t["step_i"]+1}项继续（之前合格工况跳过）')
                    else:t['step_i']=0
                    t['phase']='position';t['phase_start']=now
                    self._log(f'正式温度门槛全部通过：共同热平衡={t["thermal_elapsed_s"]:.0f}s，'
                              f'PV最大偏差={pv_max_dev:.3f}℃，芯片60秒极差={chip_span:.3f}℃；开始本温度点标定')
            elif t['phase']=='thermal_stability':
                if not self._stopped():raise ValueError('温度稳定等待时转台发生运动')
                pv=t['manual_confirmed_pv'] if t['manual'] else float(chamber['pv'])
                if abs(pv-t['temps'][t['temp_i']])>2:
                    raise ValueError('温箱实际温度已偏离目标 ±2℃')
                if t.get('chip_stability_only',False) and not t['manual'] and abs(pv-t['temps'][t['temp_i']])>1:
                    # 快速模式温箱PV重新偏离目标±1℃：回到快速PV门槛。
                    t['phase']='wait_plc';t['phase_start']=now;t['pv_stable_since']=None
                    t['chip_trace']=[];t['last_chip_trace_count']=None
                    self._log('快速模式：温箱PV重新偏离目标±1℃，重置30秒PV与60秒芯片稳定计时')
                    return
                if t.get('chip_stability_only',False) and t['manual'] and abs(pv-t['temps'][t['temp_i']])>1:
                    raise ValueError('人工模式输入PV偏离目标±1℃；请重新确认温箱实际温度')
                with tiltSensorRawData.data_lock:
                    chip=float(tiltSensorRawData.temp_c)
                    chip_frame_count=int(tiltSensorRawData.data_update_count)
                if not math.isfinite(chip) or not -45<=chip<=90:
                    raise ValueError('IMU 内温读数异常')
                if now-t['phase_start']>21600:
                    raise ValueError('芯片温度无法在 6 小时内达到热平衡')
                # 避免短暂空帧时，把上一帧旧芯片温度重复算作新的稳定性测量。
                if chip_frame_count != t.get('last_chip_trace_count'):
                    t['chip_trace'].append((now,chip))
                    t['last_chip_trace_count']=chip_frame_count
                t['chip_trace']=[v for v in t['chip_trace'] if now-v[0]<=120]
                stable, observed_s, span_c = chip_stability_status(t['chip_trace'], now)
                stable = stable and (now - t['phase_start'] >= 60.0)
                quick=bool(t.get('chip_stability_only',False))
                enough=quick or now-t['phase_start']>=self.dwell.value()
                # 刚到温时即使芯片暂时不变，也必须先收集完整60秒真实温度新样本；
                # PLC PV重新偏离目标±1℃时不允许在快速模式下开始标定。
                pv_ok=(abs(pv-t['temps'][t['temp_i']])<=1.0 if quick else True)
                if quick:
                    self.label.setText(f'温度 {t["temps"][t["temp_i"]]}℃：芯片 {chip:.2f}℃；稳定窗口 {observed_s:.0f}/60s，'
                                       f'波动 {span_c:.3f}/0.2℃；温箱PV={pv:.2f}℃'+
                                       ('（等待PV恢复至±1℃）' if not pv_ok else ''))
                else:
                    self.label.setText(f'温度 {t["temps"][t["temp_i"]]}℃：芯片 {chip:.2f}℃，'
                                       f'保温 {now-t["phase_start"]:.0f}/{self.dwell.value()}s，'
                                       f'完整60s窗口波动 {span_c:.3f}℃')
                if enough and stable and pv_ok and abs(chip-pv)<=10:
                    if t.get('resume_temp_index') == t['temp_i']:
                        t['step_i']=t.pop('resume_step_index',0)
                        t['resume_temp_index']=None
                        self._log(f'恢复点温度重新热平衡通过，从本温度第 {t["step_i"]+1} 项继续（之前成功项跳过）')
                    else:
                        t['step_i']=0
                    t['phase']='position';t['phase_start']=now
                    self._log((f'芯片连续60秒稳定，芯片={chip:.2f}℃，PV={pv:.2f}℃，窗口温差={span_c:.3f}℃；'
                               + ('已忽略固定保温时长，开始本温度工况' if quick else
                                  '固定最短保温也已满足，开始本温度工况')))
            elif t['phase']=='thermal_pause':
                if not self._stopped():raise ValueError('温度暂停期间转台没有安全停止')
                g=t.get('guard')
                with tiltSensorRawData.data_lock:
                    chip=float(tiltSensorRawData.temp_c)
                    chip_count=int(tiltSensorRawData.data_update_count)
                pv=float(chamber['pv'])
                if g is None:
                    g=t['guard']=ThermalRuntimeGuard(t['temps'][t['temp_i']])
                action,_=g.observe(now,pv,float(chamber['pv_updated']),chip,chip_count)
                if action=='resoak':
                    t['resume_temp_index']=t['temp_i'];t['resume_step_index']=t['step_i']
                    t['thermal_elapsed_s']=0.0;t['thermal_last_tick']=now;t['thermal_pv_in_range']=False
                    t['temperature_wait_started']=now
                    t['phase']='thermal_soak';t['phase_start']=now
                    self._log('温度持续偏差严重，重新共同热平衡1800秒；之前合格工况保留待复核')
                    return
                if g.recovery_ready(now,pv,chip):
                    t['phase']='position';t['phase_start']=now
                    t['retry_count']=0
                    self._log('PV连续120秒及芯片60秒温度重新稳定，通过恢复门槛；重采受影响工况')
                    return
                self.label.setText('温漂安全暂停：PV={:.2f}℃ 芯片={:.2f}℃；等待120秒稳定'.format(pv,chip))
                if now-t['phase_start']>3600:
                    # Still incomplete: preserve remaining work, do not continue
                    # motion at a temperature which never re-stabilized.
                    for idx in range(t['step_i'],len(t['steps'])):
                        k=self._step_key(t['temp_i'],idx)
                        if k not in self._accepted_step_keys():
                            st=t['steps'][idx]
                            t['unresolved'].append({'temp_index':t['temp_i'],'step_index':idx,
                                'temperature_target_c':t['temps'][t['temp_i']],
                                'step_id':st['step_id'],'sensor':st['sensor'],
                                'rotation_axis':st.get('rotation_axis'),
                                'target_rate_dps':st.get('target_rate_dps'),
                                'reason':'温漂暂停1小时仍未恢复'})
                    self._log('当前温度暂停超时：标记未测工况，保存其他温度的数据')
                    self._advance_temperature(now)
            elif t['phase']=='position':
                if t['step_i']>=len(t['steps']):
                    # At the end of the full pass and again after the deferred
                    # pass, validate that each fit/validation group is at one
                    # comparable chip temperature before model input commits.
                    if self._audit_current_temperature_groups():
                        if t.get('replay_mode'):
                            t['replay_mode']=False
                        # Newly invalidated group entries will be recovered by
                        # the same once-per-temperature back-fill queue below.
                    pending=t['deferred_by_temp'].get(str(t['temp_i']),[])
                    accepted=self._accepted_step_keys()
                    forbidden={(m['temp_index'],m['step_index']) for m in t['unresolved']}
                    pending=[i for i in pending if self._step_key(t['temp_i'],i) not in accepted
                             and (t['temp_i'],i) not in forbidden]
                    if not t.get('replay_mode') and pending:
                        t['replay_mode']=True
                        t['replay_queue']=sorted(set(pending))
                        t['step_i']=t['replay_queue'].pop(0)
                        t['retry_count']=0
                        self._log(f'本温度正常工况已巡检，开始补测{len(pending)}个未通过工况；不重做1800秒热浸')
                        self._save_partial('RUNNING','准备补测')
                        return
                    self._advance_temperature(now)
                    return
                if self._step_key(t['temp_i'],t['step_i']) in self._accepted_step_keys():
                    self._next_step_after_result(now)
                    return
                step=t['steps'][t['step_i']]
                self._move(step['inner_deg'],step['outer_deg'])
                t['phase']='wait_position';t['phase_start']=now;t['stable_since']=None
                self._log(f'姿态运动 {step["step_id"]} -> 内 {step["inner_deg"]} / 外 {step["outer_deg"]}°')
            elif t['phase']=='wait_position':
                step=t['steps'][t['step_i']]
                self._check_position_command_started(now)
                in_place=(self._stopped() and turntableState.is_inner_axis_in_place and turntableState.is_outer_axis_in_place
                     and abs(_angle_error(turntableData.inner_axis_position,step['inner_deg']))<=0.2
                     and abs(_angle_error(turntableData.outer_axis_position,step['outer_deg']))<=0.2)
                if in_place:
                    if t['stable_since'] is None:t['stable_since']=now
                    if now-t['stable_since']>=1.0:
                        t.pop('position_watch',None)
                        t['phase']='settle';t['phase_start']=now
                else:t['stable_since']=None
                if now-t['phase_start']>240:raise ValueError('转台姿态到位超时')
            elif t['phase']=='settle':
                if not self._stopped():raise ValueError('静置阶段转台仍在运动')
                if now-t['phase_start']>=self.settle.value():
                    step=t['steps'][t['step_i']]
                    if step['mode']=='rate':
                        self._rate_command(step['rotation_axis'],step['target_rate_dps'])
                        t['phase']='wait_rate';t['phase_start']=now;t['stable_since']=None;t['wrong_sign_since']=None
                        t['rate_preflight_feedback']=[]
                    else:self._begin_sample(now)
            elif t['phase']=='wait_rate':
                self._check_rate_feedback()
                step=t['steps'][t['step_i']]
                speed=turntableData.inner_axis_speed if step['rotation_axis']=='inner' else turntableData.outer_axis_speed
                ref=step['target_rate_dps']
                # 正负转向必须和编码器反馈一致；在明显反向时尽快停车，而不是等待30秒。
                if speed*ref < 0 and abs(speed) >= max(0.4,abs(ref)*0.08):
                    if t.get('wrong_sign_since') is None:t['wrong_sign_since']=now
                    elif now-t['wrong_sign_since']>=0.4:
                        raise ValueError(f'WK温补{step["rotation_axis"]}实际转向与目标{ref:+g}°/s相反（实测{speed:+.3f}°/s），请求停车')
                else:t['wrong_sign_since']=None
                if abs(speed-ref)<=max(.2,abs(ref)*.15):
                    if t['stable_since'] is None:t['stable_since']=now
                    if now-t['stable_since']>=1:
                        recent=[x for x in t.get('rate_preflight_feedback',[])
                                if (now-float(x['monotonic_time_ns'])*1e-9)<=4.5]
                        checked=inspect_feedback(recent,step['rotation_axis'],ref,
                            max_error=t['profile']['quality']['rate_reference_error_max_dps'],
                            max_std=t['profile']['quality']['rate_reference_std_max_dps'])
                        if checked.get('certified'):
                            self._begin_sample(now)
                else:t['stable_since']=None
                # No 30-second uncontrolled high-speed sweep if reference polling
                # cannot certify 0.18 dps. It is a recoverable quality failure.
                max_wait=8.0 if abs(ref)>=30 else 12.0
                if now-t['phase_start']>max_wait:
                    self._defer_current_step(now,'匀速窗口在限定时间内未通过独立转台反馈检查')
                    return
            elif t['phase']=='sample':
                step=t['steps'][t['step_i']]
                if step['mode']=='rate':
                    self._check_rate_feedback()
                dur=float(step.get('sample_seconds',self.sample_seconds.value()))
                if now-t['sample_start']>=dur:
                    try:
                        diag=None
                        if step['mode']=='rate' and 'rate_sample_feedback' in t:
                            diag=inspect_feedback(t.get('rate_sample_feedback',[]),
                                step['rotation_axis'],step['target_rate_dps'],
                                max_error=t['profile']['quality']['rate_reference_error_max_dps'],
                                max_std=t['profile']['quality']['rate_reference_std_max_dps'])
                        stats=robust_segment(t['frames'],step['mode'],t['profile'],
                            target_rate=step.get('target_rate_dps'),axis=step.get('rotation_axis'),
                            static_sensor=step['sensor'], reference_diagnostic=diag)
                    except ValueError as exc:
                        # 与常温自动标定共用同一份工艺质量配置：静态最多5次重试，
                        # 动态最多3次重试。只改变重试机会，绝不降低稳健采样质检阈值。
                        retry_key = ('rate_sample_max_retries' if step['mode']=='rate'
                                     else 'static_sample_max_retries')
                        max_retries = int(t['profile']['quality'].get(
                            retry_key, 3 if step['mode']=='rate' else 5))
                        if t['retry_count']>=max_retries:
                            self._defer_current_step(now,
                                f'质量检查共{max_retries + 1}次仍不合格：{exc}')
                            return
                        t['retry_count']+=1
                        self._log(
                            f'{step["step_id"]} 采样质量拒绝，重试{t["retry_count"]}/{max_retries}：'
                            f'{exc}；准备重新采样')
                        if step['mode']=='rate':
                            if not self._stop_axes():raise ValueError('重试前停车命令失败')
                            self._begin_wk_stop_wait(t,now,retry=True)
                        else:
                            t['phase']='wait_position';t['phase_start']=now;t['stable_since']=None
                        t['frames']=[]
                        return
                    t['retry_count']=0
                    if step['mode']=='rate':
                        ref=_platform_angular_rate(stats['inner_actual_mean_deg'],stats['outer_actual_mean_deg'],
                            stats['inner_rate_mean_dps'],stats['outer_rate_mean_dps'],t['axis_model'])
                    elif step['sensor']=='acc':
                        ref=_platform_gravity_vector(stats['inner_actual_mean_deg'],stats['outer_actual_mean_deg'],t['axis_model'])
                    else:ref=np.zeros(3)
                    row={**stats,'reference':ref.tolist(),'step_id':step['step_id'],
                        'target_rate_dps':step.get('target_rate_dps'),
                        'rotation_axis':step.get('rotation_axis'),
                        'split':step['split'],'mode':step['mode'],'sensor':step['sensor'],
                        'temperature_split':t['temperature_split_by_setpoint'][t['temps'][t['temp_i']]],
                        'temperature_target_c':t['temps'][t['temp_i']]}
                    self._log(f'采样完成 {step["step_id"]}；有效帧 {stats["accepted_frames"]}/{stats["frame_count"]}')
                    if step['mode']=='rate':
                        # 动态工况必须确认停车才能提交有效工况；停车失败则续做重测。
                        t['pending_dynamic_row']=row
                        if not self._stop_axes():raise ValueError('动态段停车命令失败')
                        self._begin_wk_stop_wait(t,now)
                    else:
                        t['rows'].append(row)
                        self._next_step_after_result(now)
                        self._save_partial('RUNNING',f'逐工况存档：{step["step_id"]}')
            elif t['phase'] in ('wait_stop','wait_stop_retry','wait_stop_defer','wait_stop_thermal'):
                ready, detail = self._wk_stop_confirmed(t, now)
                if not ready:
                    # 状态8#是厂家停车执行中；不能只凭速度接近零就提前定位。
                    # 只在状态文字变化时写日志，避免100ms轮询刷屏。
                    if detail != t.get('stop_wait_last_state'):
                        t['stop_wait_last_state'] = detail
                        self._log('WK等待停车完成：'+detail)
                    self.label.setText('GYRO停车确认：'+detail)
                    if now-t['phase_start']>30:
                        raise ValueError('WK停车超过30秒仍未返回两轴1#伺服待命：'+detail+
                                         '；保留未确认工况，禁止自动重复使能或定位，请现场检查')
                    return
                if t['phase']=='wait_stop':
                    completed=t.pop('pending_dynamic_row',None)
                    if completed is None:raise ValueError('缺少确认停车的动态工况结果，禁止推进进度')
                    t['rows'].append(completed)
                    self._next_step_after_result(now)
                    self._save_partial('RUNNING',f'逐工况存档：{completed["step_id"]}')
                elif t['phase']=='wait_stop_defer':
                    self._next_step_after_result(now)
                    self._save_partial('RUNNING','当前不合格工况已安全停车，进入下一项')
                elif t['phase']=='wait_stop_thermal':
                    if t.get('hold_requires_soak'):
                        # Must re-run the entire thermal gate. Preserve position.
                        t['resume_temp_index']=t['temp_i'];t['resume_step_index']=t['step_i']
                        t['thermal_elapsed_s']=0.0;t['thermal_last_tick']=now
                        t['thermal_pv_in_range']=False
                        t['phase']='thermal_soak';t['phase_start']=now
                        t['temperature_wait_started']=now
                    else:
                        t['phase']='thermal_pause';t['phase_start']=now
                    self._save_partial('RUNNING','温漂停车已确认，等待恢复')
                else:
                    t['phase']='position';t['phase_start']=now
                self._log('WK停车已确认：'+detail+'；允许执行后续安全状态')
            if not t['manual'] and t['phase'] not in ('next_temperature','verify_plc_sp'):
                self.plc_telemetry.setText(f'PLC实时：PV={chamber["pv"]:.2f}℃ / SP={chamber["sp"]:.2f}℃；运行={chamber["running"]}；报警={chamber["alarm"]}')
            if t['phase'] in ('verify_return','wait_return'):
                self.progress.setValue(99)
                self.label.setText(f'采集完成，正在自动回25℃：PV={chamber["pv"]:.2f}℃，SP={chamber["sp"]:.2f}℃')
                return
            # Compatibility with older state-machine fixtures, which use a
            # homogeneous step schedule; production runs always carry the
            # explicit per-temperature plan.
            schedule=t.get('steps_by_temperature')
            if schedule is None:
                schedule=[t['steps'] for _ in t['temps']]
            steps_total=sum(len(part) for part in schedule)
            done=sum(len(part) for part in schedule[:t['temp_i']])+t['step_i']
            self.progress.setValue(int(100*done/max(steps_total,1)))
            if t['phase'] not in ('thermal_stability','wait_manual','wait_plc','thermal_soak','final_stability'):
                self.label.setText(f'温度 {t["temp_i"]+1}/{len(t["temps"])}：{t["temps"][t["temp_i"]]}℃，'
                                  f'工况 {t["step_i"]+1}/{len(t["steps"])}，阶段 {t["phase"]}')
        except Exception as exc:
            self._abort(f'自动温补中止：{exc}')

    def _begin_sample(self,now):
        t=self.task
        t['rate_sample_feedback']=[]
        t['phase']='sample';t['sample_start']=now;t['frames']=[]
        self._log('开始采集 '+t['steps'][t['step_i']]['step_id'])

    def shutdown(self):
        # Qt event loop is about to stop: asynchronous abort_stop_wait cannot
        # finish. Preserve the checkpoint synchronously and alert that hardware
        # stop has NOT been verified by the process-exit path.
        if self.task is not None:
            self._finish(False,'程序退出：已请求停车，但进程退出无法确认最终伺服状态；请现场检查')
        self.timer.stop()
