# -*- coding: utf-8 -*-
"""Research-only thermal calibration workbook; no automatic release gate."""
from pathlib import Path
import json
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill


def export_thermal_xlsx(folder, rows, summary):
    root=Path(folder)
    wb=Workbook()
    overview=wb.active;overview.title='温补总览'
    overview.append(['动态倾角仪 IMU 自动温补报告（研发验证，不可直接量产放行）'])
    overview.append(['类别','状态','温补后 RMSE','单位','25℃固定矩阵 RMSE','备注'])
    for sensor in ('acc','gyro'):
        d=summary.get('sensors',{}).get(sensor,{})
        stat=d.get('temperature_holdout',{})
        overview.append([sensor.upper(),d.get('status','not_estimated'),
                          stat.get('vector_rmse'),stat.get('unit'),
                          d.get('fixed_25c_holdout',{}).get('vector_rmse'),d.get('reason','')])
    overview.append(['旧版三次模型','该状态仅为保留的旧版三次完整矩阵诊断文件；28套自动选优结果以《模型自动比较》为准（默认4个拟合温度不推荐三次纯插值）。'])
    overview.append(['注意','温箱PLC IP通信保持原工程方式；设备联调和高转速连续行程必须单独实机验证。'])
    overview.append(['安全','报告不代表已通过设备联调、温度计量或量产验收。'])
    overview.append(['对照说明','25℃固定矩阵指温补拟合曲线在25℃的参数固定使用，不等于原常温C方案文件。'])
    if summary.get('model_selection'):
        overview.append(['28套联合优选','A0固定参数+T0/T1/T2温度输入 × B/C/D参数结构 × 一二三次温补；无有效PV时T1/T2标记为不可用。'])
        overview.append(['温度输入定义','T0原始芯片温度；T1 PV等效线性校正；T2 PV等效二次校正，最终MCU只使用芯片温度。'])
        overview.append(['优选模型比较','详细结果见《模型自动比较》《芯片温度校正》《逐温度误差比较》《静态倾角精度对比》。'])
        for sensor, data in summary['model_selection'].get('sensors',{}).items():
            overview.append([sensor.upper()+' 自动模型优选',
                             data.get('selected_id') or '未选出',data.get('status_text',data.get('status')),
                             '最终独立温度验证只用于验收，未参与模型排名'])
    if summary.get('model_selection'):
        schedule=wb.create_sheet('温度工况计划')
        schedule.append(['温箱目标温度℃','温度角色','ACC标定工况数','ACC独立测试数',
                         'GYRO标定工况数','GYRO独立测试数','数据用途'])
        by_temp={}
        for record in rows:
            key=float(record['temperature_target_c'])
            info=by_temp.setdefault(key,{'role':record.get('temperature_split'),
                                          'acc_fit':0,'acc_validate':0,'gyro_fit':0,'gyro_validate':0})
            if info['role']!=record.get('temperature_split'):
                raise ValueError(f'温度 {key:g}℃ 同时被标记为拟合和独立验证，拒绝生成报告')
            field=f'{record["sensor"]}_{record["split"]}'
            if field in info:
                info[field]+=1
        for setpoint,info in sorted(by_temp.items()):
            role=info['role']
            schedule.append([setpoint,'模型拟合' if role=='fit' else '独立温度验证',
                             info['acc_fit'],info['acc_validate'],
                             info['gyro_fit'],info['gyro_validate'],
                             '拟合参数+模型选型' if role=='fit' else '只用于最终温度验收，不参与拟合或排名'])
        schedule.append(['备注','这张表为已完成并保存的工况统计，不能代表未完成工况的计划数量。'])
        schedule.append(['安全','验证温度与拟合温度采用相同的PLC、PV和芯片温度稳定检查。'])
    ws=wb.create_sheet('逐工况测量')
    ws.append(['温度设定°C','拟合/温度验证','工况编号','ACC/GYRO','姿态/动态','拟合/工况验证',
               '芯片温度°C','内轴角°','外轴角°','内轴速率°/s','外轴速率°/s',
               '参考X','参考Y','参考Z','实测X','实测Y','实测Z','有效帧','总帧',
               '目标速率°/s','转动轴','实测减目标°/s','温补后向量误差°/s','25°C固定矩阵误差°/s','评价数据口径'])
    gyro_model=None
    model_path=root/'thermal_gyro_candidate.json'
    if model_path.exists():
        with model_path.open('r',encoding='utf-8') as f:
            gyro_model=json.load(f)
    for r in rows:
        measure=r.get('acc_raw_mean_g') if r.get('sensor')=='acc' else r.get('gyro_raw_mean_dps')
        target=r.get('target_rate_dps')
        axis=r.get('rotation_axis')
        measured_rate=(r.get('inner_rate_mean_dps') if axis=='inner' else
                       r.get('outer_rate_mean_dps') if axis=='outer' else None)
        deviation=(float(measured_rate)-float(target)) if target is not None and measured_rate is not None else None
        thermal_error=None
        fixed_error=None
        scope=''
        if r.get('sensor')=='gyro' and r.get('mode')=='rate':
            ts, cs=r.get('temperature_split'),r.get('split')
            scope=('拟合温度/拟合速率(训练数据)' if ts=='fit' and cs=='fit' else
                   '拟合温度/独立速率验证' if ts=='fit' and cs=='validate' else
                   '独立温度/独立速率验证' if ts=='validate' and cs=='validate' else
                   '独立温度/拟合速率(仅诊断)')
            if gyro_model is not None:
                # 报告诊断值；主评价依然以热补模型 JSON 的独立验证结果为准。
                from thermal_compensation import _eval_poly
                temp=float(r['temperature_mean_c'])
                F=np.asarray(_eval_poly(gyro_model['forward_coeff'],temp),float)
                b=np.asarray(_eval_poly(gyro_model['bias_coeff'],temp),float)
                F25=np.asarray(_eval_poly(gyro_model['forward_coeff'],25.0),float)
                b25=np.asarray(_eval_poly(gyro_model['bias_coeff'],25.0),float)
                raw=np.asarray(measure,float)
                ref=np.asarray(r['reference'],float)
                thermal_error=float(np.linalg.norm(np.linalg.solve(F,raw-b)-ref))
                fixed_error=float(np.linalg.norm(np.linalg.solve(F25,raw-b25)-ref))
        ws.append([r['temperature_target_c'],r['temperature_split'],r['step_id'],r['sensor'],r['mode'],
                   r['split'],r['temperature_mean_c'],r['inner_actual_mean_deg'],r['outer_actual_mean_deg'],
                   r['inner_rate_mean_dps'],r['outer_rate_mean_dps'],*r['reference'],*measure,
                   r['accepted_frames'],r['frame_count'],target,axis,deviation,
                   thermal_error,fixed_error,scope])
    # The comparison sheets are appended only for the upgraded workstation;
    # legacy report clients that pass a plain summary retain the old layout.
    selection=summary.get('model_selection')
    if selection:
        best=wb.create_sheet('模型自动比较')
        best.append(['传感器','候选编号','补偿模型','温度阶数','选型工况RMSE','选型工况最大误差',
                     '复杂度评分','独立温度RMSE','独立温度最大误差','误差单位','是否被选中','状态/不可用原因',
                     '温度输入编号','温度输入描述'])
        for sensor in ('acc','gyro'):
            detail=selection.get('sensors',{}).get(sensor,{})
            if not detail.get('candidates'):
                best.append([sensor.upper(),'', '未完成比较',None,None,None,None,None,None,
                             'g' if sensor=='acc' else 'deg/s','否',detail.get('reason',detail.get('status','无数据')),'',''])
                continue
            for item in detail['candidates']:
                train=item.get('selection_condition_validation',{})
                test=item.get('independent_temperature_verification',{})
                best.append([sensor.upper(),item['id'],item['name'],item['degree'],
                             train.get('vector_rmse'),train.get('vector_max'),
                             item.get('selection_score'),test.get('vector_rmse'),
                             test.get('vector_max'), 'g' if sensor=='acc' else 'deg/s',
                             (('独立温度验证改善' if detail.get('status')=='INDEPENDENT_TEMPERATURE_IMPROVEMENT_CONFIRMED_RESEARCH_ONLY'
                               else '固定参数排名第一' if detail.get('status')=='BASELINE_PREFERRED_NO_TEMPERATURE_COMPENSATION'
                               else '排名第一但最终未通过') if item['id']==detail.get('selected_id') else ''),
                             item.get('reason',item.get('status')),
                             item.get('temperature_input_id'),item.get('temperature_input_name')])
        # Temperature input choices: PV is reference data during lab fitting ONLY.
        # None of these formulas needs PV at runtime.
        transforms=selection.get('temperature_input_candidates',{})
        tw=wb.create_sheet('芯片温度校正')
        tw.append(['温度输入编号','说明','拟合状态','校正阶数','芯片温度中心°C','归一化尺度°C',
                   '系数c0','系数c1','系数c2','PV拟合RMSE°C','有效芯片温区°C','说明/异常'])
        for key in ('T0','T1','T2'):
            value=transforms.get(key,{})
            coeff=value.get('coefficients_c',[])
            tw.append([key,value.get('name'),('不可用' if value.get('error') else '可用'),
                       value.get('degree'),value.get('temperature_center_c'),
                       value.get('temperature_scale_c'),
                       *(coeff+[None]*3)[:3],value.get('pv_fit_rmse_c'),
                       str(value.get('chip_temperature_fit_range_c','')),
                       value.get('error',value.get('warning',value.get('formula')))])
        tw.append([])
        tw.append(['数据来源','原始实验 imu_frame_means.csv 中每帧同步记录的 chamber_pv_c / imu_temp_c'])
        tw.append(['PV适用范围','仅拟合温度、仅标定工况用于计算校正系数；独立温度PV不参与校正训练'])
        tw.append(['重要提示','PV等效温度不是芯片结温绝对真值；线性校正与直接用原始芯片温度的同阶多项式表达能力等价。'])
        raw_status=selection.get('pv_telemetry',{})
        tw.append(['PV原始记录状态',raw_status.get('status'), '匹配工况数',raw_status.get('matched'),
                   '无效帧数',raw_status.get('invalid_raw_frames')])
        tw.append([])
        tw.append(['训练温度点°C','芯片实测°C','温箱实测PV°C','T1预测°C','T2预测°C','差值PV-芯片°C'])
        from thermal_temperature_inputs import map_chip_temperature
        pairs=transforms.get('T1',{}).get('fit_training_pairs',[]) or transforms.get('T2',{}).get('fit_training_pairs',[])
        for record in pairs:
            chip=float(record['chip_temperature_c'])
            pv=float(record['pv_temperature_c'])
            predicted=[]
            for tid in ('T1','T2'):
                transform=transforms.get(tid,{})
                try:
                    predicted.append(None if transform.get('error') else map_chip_temperature(transform,chip))
                except (ValueError,KeyError,TypeError):
                    predicted.append(None)
            tw.append([record['setpoint_c'],chip,pv,*predicted,pv-chip])
        compare=wb.create_sheet('逐温度误差比较')
        compare.append(['传感器','数据口径','温度设定°C','固定参数RMSE','优选温补RMSE','RMSE改善率',
                        '固定参数最大误差','优选温补最大误差','最大误差改善率','单位','模型编号','验证状态'])
        tilt=wb.create_sheet('静态倾角精度对比')
        tilt.append(['数据口径','温度设定°C','固定参数重力方向角RMSE(°)',
                     '优选温补重力方向角RMSE(°)','角RMSE改善率',
                     '固定参数最大角误差(°)','优选温补最大角误差(°)',
                     '评价说明'])
        for sensor in ('acc','gyro'):
            detail=selection.get('sensors',{}).get(sensor,{})
            candidates={x['id']:x for x in detail.get('candidates',[])}
            baseline=candidates.get('A0',{})
            chosen=candidates.get(detail.get('selected_id'),{})
            for scope,field in (('拟合温度/独立工况（用于选型）','selection_condition_validation'),
                                ('独立温度/独立工况（最终验收）','independent_temperature_verification')):
                bm=baseline.get(field,{})
                cm=chosen.get(field,{})
                bp=bm.get('per_setpoint',{})
                cp=cm.get('per_setpoint',{})
                for t in sorted(set(bp)|set(cp),key=float):
                    old,new=bp.get(t,{}),cp.get(t,{})
                    v0,v1=old.get('vector_rmse'),new.get('vector_rmse')
                    x0,x1=old.get('vector_max'),new.get('vector_max')
                    change=100*(v0-v1)/v0 if v0 is not None and v1 is not None and v0>0 else None
                    max_change=100*(x0-x1)/x0 if x0 is not None and x1 is not None and x0>0 else None
                    compare.append([sensor.upper(),scope,float(t),v0,v1,change,x0,x1,max_change,
                                    'g' if sensor=='acc' else 'deg/s',
                                    detail.get('selected_id'),detail.get('status_text',detail.get('status'))])
                    if sensor=='acc':
                        av0,av1=(old.get('static_gravity_direction_angle_rmse_deg'),
                                 new.get('static_gravity_direction_angle_rmse_deg'))
                        mx0,mx1=(old.get('static_gravity_direction_angle_max_deg'),
                                 new.get('static_gravity_direction_angle_max_deg'))
                        ac=100*(av0-av1)/av0 if av0 is not None and av1 is not None and av0>0 else None
                        tilt.append([scope,float(t),av0,av1,ac,mx0,mx1,
                                     '静态ACC重力矢量方向夹角；不是整机融合算法动态倾角'])
        desc=wb.create_sheet('结论与数据边界')
        desc.append(['项目','结论/限制'])
        desc.append(['排名口径','只用拟合温度下的独立工况验证；独立温度数据不参与模型选型'])
        desc.append(['模型','A0固定参数；T0原始芯片温度；T1/T2通过拟合温度下PV建立等效温度关系；B仅零偏；C零偏及比例因子；D完整矩阵'])
        desc.append(['候选模型','ACC/GYRO各28套（A0 + T0/T1/T2 × B/C/D × 1/2/3次）；数据不足时列为不可用，不强行推荐'])
        desc.append(['过拟合保护','一二三次温补分别要求至少3/4/5个拟合温度点，三次不能用4个点纯插值并宣称最优'])
        desc.append(['部署温度输入','真正运行只需要芯片温度，选T1/T2时先做PV等效校正；永远不需要温箱PV'])
        desc.append(['温度校正参考','温箱PV不一定等于真实芯片温度；非线性转换须检查单调性和可部署范围'])
        desc.append(['参考基准','A0不等于从外部常温标定JSON读取的参数；以报表具体基准测量温度为准'])
        desc.append(['温度范围','严格限制在参与拟合温度点的芯片实测温度区间，拒绝外推'])
        desc.append(['最终状态','推荐候选不等于温度独立验证通过，更不等于量产放行'])
        desc.append(['静态倾角','静态加速度计重力方向夹角误差可以从现有姿态数据计算；用于评估ACC静态方向精度'])
        desc.append(['动态倾角','现有逐工况统计不足以给出融合算法的动态倾角误差；需同步时序ACC/GYRO/参考姿态和明确的产品解算算法'])
        desc.append(['硬件验证','本软件结果不代替温箱、转台、硬件急停及全温区实机联调'])
        for sensor, data in selection.get('sensors',{}).items():
            desc.append([sensor.upper()+'选型',
                         str(data.get('selected_id'))+' / '+str(data.get('status_text',data.get('status')))])
            if data.get('baseline_definition'):
                desc.append([sensor.upper()+'基准',data['baseline_definition']])
        deployment=wb.create_sheet('MCU部署说明')
        deployment.append(['项目','内容'])
        deployment.append(['重要','研发候选！本工具不自动向MCU写入参数，不是生产批准。'])
        deployment.append(['温度输入','运行时唯一温度输入为IMU芯片温度（°C），不读取温箱PV。'])
        deployment.append(['校正温度公式','若选T1/T2：T_effective = 25 + Σ c[k] * ((T_chip - 25)/50)^k'])
        deployment.append(['标定参数公式','p(T_effective) = Σ p_coeff[k] * (T_effective - 25)^k'])
        deployment.append(['校正测量公式','reference = inverse(F(T_effective)) @ (raw - b(T_effective))'])
        deployment.append(['芯片温度范围','必须限制在fit_temperature_range_c，超出拒绝外推。'])
        deployment.append(['参数文件','thermal_acc_selected_candidate.json；thermal_gyro_selected_candidate.json'])
        for sensor in ('acc','gyro'):
            info=selection.get('sensors',{}).get(sensor,{})
            deployment.append([sensor.upper()+'选中模型',info.get('selected_id') or '无；数据不足'])
            deployment.append([sensor.upper()+'验收状态',info.get('status_text',info.get('status'))])
            deployment.append([sensor.upper()+'温度输入',info.get('selected_temperature_input_id') or ''])
        deployment.append(['额外前提','写入MCU前需量程、轴定义、矩阵可逆性、系数精度和代码计算一致性验证。'])
        for tab in (best,compare,tilt,desc,tw,deployment):
            tab.auto_filter.ref=f'A1:{tab.cell(1,tab.max_column).column_letter}{tab.max_row}'
        # Remove a candidate from highlighting if it has not actually passed
        # the final independent temperature check; keep selection visible.
        for row in best.iter_rows(min_row=2):
            if row[10].value:
                for cell in row:
                    cell.fill=PatternFill('solid',fgColor='E3EDF4')
    for tab in wb.worksheets:
        tab.freeze_panes='A3' if tab is overview else 'A2'
        tab.auto_filter.ref=f'A1:Y{tab.max_row}' if tab is ws else None
        tab.row_dimensions[1].height=26
        for cell in tab[1]:
            cell.font=Font(name='微软雅黑',size=11,bold=True,color='FFFFFF')
            cell.fill=PatternFill('solid',fgColor='254B67')
            cell.alignment=Alignment(vertical='center')
        for col in tab.columns:
            key=col[0].column_letter
            tab.column_dimensions[key].width=(20 if tab==ws else (24 if tab.title=='模型自动比较' else 28))
        for row in tab.iter_rows(min_row=2):
            for cell in row:
                if isinstance(cell.value,float):
                    cell.number_format='0.000000'
                cell.alignment=Alignment(vertical='center',wrap_text=(tab.title=='结论与数据边界'))
        if tab.title=='结论与数据边界':
            tab.column_dimensions['A'].width=22
            tab.column_dimensions['B'].width=100
        if tab.title=='模型自动比较':
            tab.column_dimensions['C'].width=29
            tab.column_dimensions['L'].width=48
            tab.column_dimensions['M'].width=16
            tab.column_dimensions['N'].width=24
        if tab.title in ('芯片温度校正','MCU部署说明','温度工况计划'):
            tab.column_dimensions['A'].width=25
            tab.column_dimensions['B'].width=40
            if tab.title=='芯片温度校正':
                tab.column_dimensions['L'].width=72
        if tab.title=='静态倾角精度对比':
            tab.column_dimensions['H'].width=68

    path=root/'thermal_calibration_report.xlsx'
    wb.save(path)
    return str(path)
