# -*- coding: utf-8 -*-
"""Conservative live chamber/chip quality guard for long thermal experiments.

Only raises a soft hold (never disables hardware safety). Operates on fresh PV
and fresh IMU temperature samples, and never counts repeated cached values.
"""
from collections import deque
import math
import numpy as np

class ThermalRuntimeGuard:
    def __init__(self, target, pv_pause_c=0.3, chip_span_c=0.2,
                 chip_slope_c_per_min=0.05):
        self.target=float(target)
        self.pv_pause_c=float(pv_pause_c)
        self.chip_span_c=float(chip_span_c)
        self.chip_slope_c_per_min=float(chip_slope_c_per_min)
        self.pv=deque()
        self.chip=deque()
        self.last_pv_stamp=None
        self.last_chip_count=None
        self.high_pv_since=None
        self.large_pv_since=None

    def observe(self, now, pv, pv_stamp, chip, chip_count):
        if not (math.isfinite(now) and math.isfinite(pv) and math.isfinite(chip)):
            return 'safety', '非有限的温度反馈'
        if pv_stamp is None or now-pv_stamp>2.0 or now<pv_stamp-0.5:
            # PLC's global fault monitor stays authoritative; do not accept stale PV.
            return 'hold', '温箱PV未在2秒内刷新'
        if pv_stamp!=self.last_pv_stamp:
            self.pv.append((float(pv_stamp),float(pv)))
            self.last_pv_stamp=pv_stamp
        if chip_count!=self.last_chip_count:
            self.chip.append((float(now),float(chip)))
            self.last_chip_count=chip_count
        while self.pv and now-self.pv[0][0]>600:self.pv.popleft()
        while self.chip and now-self.chip[0][0]>600:self.chip.popleft()
        error=abs(pv-self.target)
        if error>1.0:
            if self.large_pv_since is None:self.large_pv_since=now
            if now-self.large_pv_since>=30:
                return 'resoak','温箱PV持续偏离目标超过1℃，需要重新热浸'
        else:self.large_pv_since=None
        if error>self.pv_pause_c:
            if self.high_pv_since is None:self.high_pv_since=now
            if now-self.high_pv_since>=15:
                return 'hold',f'温箱PV偏离目标超过{self.pv_pause_c:.2f}℃持续15秒'
        else:self.high_pv_since=None
        selected=[(t,v) for t,v in self.chip if now-t<=60]
        if len(selected)>=3 and selected[-1][0]-selected[0][0]>=55:
            if max(v for _,v in selected)-min(v for _,v in selected)>self.chip_span_c:
                return 'hold','芯片60秒温度波动超过0.2℃'
        selected=[(t,v) for t,v in self.chip if now-t<=300]
        if len(selected)>=5 and selected[-1][0]-selected[0][0]>=285:
            ts=np.asarray([x[0] for x in selected]); vals=np.asarray([x[1] for x in selected])
            slope=float(np.polyfit((ts-ts[0])/60.0,vals,1)[0])
            if abs(slope)>self.chip_slope_c_per_min:
                return 'hold',f'芯片5分钟斜率{float(slope):+.4f}℃/min超限'
        return 'ok',''

    def recovery_ready(self, now, pv, chip, seconds=120.0):
        """Require an observed 120s PV band and real 60s chip trace; no full soak here."""
        span=[(t,v) for t,v in self.pv if now-t<=seconds]
        tc=[(t,v) for t,v in self.chip if now-t<=60]
        if not (span and tc and span[-1][0]-span[0][0]>=seconds-5
                and tc[-1][0]-tc[0][0]>=55):return False
        long=[(t,v) for t,v in self.chip if now-t<=300]
        slope_ok=True
        if len(long)>=5 and long[-1][0]-long[0][0]>=285:
            ts=np.asarray([x[0] for x in long]);v=np.asarray([x[1] for x in long])
            slope_ok=abs(float(np.polyfit((ts-ts[0])/60.0,v,1)[0]))<=self.chip_slope_c_per_min
        return (all(abs(v-self.target)<=self.pv_pause_c for _,v in span)
                and max(v for _,v in tc)-min(v for _,v in tc)<=self.chip_span_c
                and abs(pv-self.target)<=self.pv_pause_c
                and abs(chip-tc[-1][1])<0.1 and slope_ok)
