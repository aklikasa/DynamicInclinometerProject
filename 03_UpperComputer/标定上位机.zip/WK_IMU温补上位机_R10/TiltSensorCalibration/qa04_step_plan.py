# -*- coding: utf-8 -*-
"""Pure finite two-endpoint step-setpoint planner for QA04.

No PLC/Qt I/O.  One *round-trip cycle* means two directed legs:
  both:         low -> high -> low
  both_cooling: high -> low -> high
One-way options are exactly one leg.  Repeated one-way legs without return
would require a hidden, user-unrequested extra leg, so this is prohibited.
"""
from __future__ import annotations

import math


def build_step_plan(low, high, mode='both', cycles=1):
    low,high=float(low),float(high)
    if not all(map(math.isfinite,(low,high))) or not (-40 <= low < high <= 85):
        raise ValueError('最低温度必须小于最高温度，且在温箱允许设置范围内')
    mode=str(mode)
    if mode not in {'both','both_cooling','warming','cooling'}:
        raise ValueError('未知的升降温模式')
    if type(cycles) is not int or not 1 <= cycles <= 99:
        raise ValueError('循环次数须为1～99的整数')
    if mode in ('warming','cooling') and cycles!=1:
        raise ValueError('单程试验只做一段；需要重复运行请选先升后降或先降后升的往返循环')
    start_c=high if mode in ('both_cooling','cooling') else low
    start_name='高温端点' if start_c==high else '低温端点'
    legs=[]
    if mode=='warming': pattern=[(high,'warming')]
    elif mode=='cooling': pattern=[(low,'cooling')]
    elif mode=='both': pattern=[(high,'warming'),(low,'cooling')]
    else: pattern=[(low,'cooling'),(high,'warming')]
    for c in range(cycles):
        for t,d in pattern:
            legs.append({'cycle':c+1,'direction':d,'target_c':t})
    return {'low_c':low,'high_c':high,'mode':mode,
            'start_c':start_c,'start_name':start_name,
            'cycles':cycles,'legs':legs,
            'analysis_direction':mode if mode in ('warming','cooling') else 'both'}


def describe_step_plan(plan):
    nodes=[plan['start_c']]+[leg['target_c'] for leg in plan['legs']]
    chain=' → '.join(f'{n:g}℃' for n in nodes)
    if len(nodes)>10:
        chain=' → '.join(f'{n:g}℃' for n in nodes[:5])+' → … → '+f'{nodes[-1]:g}℃'
    return f'共{plan["cycles"]}次循环／{len(plan["legs"])}段；{chain}'
