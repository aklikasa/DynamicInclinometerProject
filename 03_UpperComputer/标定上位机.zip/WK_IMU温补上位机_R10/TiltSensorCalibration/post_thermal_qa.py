# -*- coding: utf-8 -*-
"""R10 post-thermal QA 01/02 — frozen-coefficient, read-only offline evaluation.

01: Re-evaluate raw independent ACC/GYRO conditions using exactly the previous
    calibration JSON. Never calls a fitter and never touches physical hardware.
02: Static ACC-derived roll/pitch vs the original M3 software-P gravity frame;
    NOT a firmware/fusion output and NOT a certified angle reference.

No inferred auto matching: both the coefficient file and its complete research
result must match byte-independent model contents, board ID, and M3 reference.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import html
import json
import math
from collections import defaultdict
from pathlib import Path

import numpy as np

from production_cycle_analysis import (apply_geometry, forward_matrix,
                                       locate_runs, select_rows)

VERSION = 'QA01_02_OFFLINE_R1_20261119'
MODEL_NAME = '统一温补研究参数_未经生产批准.json'
RESULT_NAME = '全量研究结果_不得直接烧录.json'
FIELDS = {'acc': 'acc_raw_mean_g', 'gyro': 'gyro_raw_mean_dps'}


class ValidationError(ValueError):
    pass


def _read_json(path):
    path = Path(path)
    if not path.is_file():
        raise ValidationError(f'找不到文件：{path}')
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (UnicodeError, ValueError) as exc:
        raise ValidationError(f'JSON解析失败：{path}：{exc}') from exc


def _sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load_frozen(parameters_path, result_path=None):
    """Model object + source provenance, with strict cross-file comparison."""
    parameters_path = Path(parameters_path).resolve()
    result_path = (Path(result_path) if result_path else
                   parameters_path.with_name(RESULT_NAME)).resolve()
    params = _read_json(parameters_path)
    result = _read_json(result_path)
    for kind in ('acc', 'gyro'):
        model = params.get(kind)
        if not isinstance(model, dict) or model.get('sensor') != kind:
            raise ValidationError(f'{kind.upper()}参数缺失或传感器类别不匹配')
        if model.get('phase') is not False:
            raise ValidationError(f'{kind.upper()}为升降温方向相关模型，当前验收拒绝自动使用')
        if model.get('raw_units') != ('g' if kind == 'acc' else 'deg/s'):
            raise ValidationError(f'{kind.upper()}单位未确认')
        if model != result.get('models', {}).get(kind, {}).get('model'):
            raise ValidationError(f'{kind.upper()}参数JSON与原始研究结果JSON不一致；禁止跨批次混用')
        limits = model.get('temperature_domain_c')
        if not isinstance(limits, list) or len(limits) != 2 or not all(math.isfinite(float(x)) for x in limits):
            raise ValidationError(f'{kind.upper()}温度域损坏')
        if not float(limits[0]) < float(limits[1]):
            raise ValidationError(f'{kind.upper()}有效温区不合法')
        coeff = model.get('coeff')
        if not isinstance(coeff, list) or len(coeff) != 3 or any(not isinstance(row, list) for row in coeff):
            raise ValidationError(f'{kind.upper()}系数维度损坏')
        if not all(math.isfinite(float(v)) for row in coeff for v in row):
            raise ValidationError(f'{kind.upper()}系数包含NaN或无穷大')
        for chip in np.linspace(float(limits[0]), float(limits[1]), 41):
            try:
                F, b = forward_matrix(model, {'temperature_mean_c': float(chip),
                                               '_direction': 'warming', 'reference': [0., 0., 1.]})
                if not np.all(np.isfinite(F)) or not np.all(np.isfinite(b)):
                    raise ValidationError(f'{kind.upper()}校准矩阵/零偏包含非有限值')
                if abs(np.linalg.det(F)) < 1e-7 or np.linalg.cond(F) > 60:
                    raise ValidationError(f'{kind.upper()}有效温区内矩阵奇异/病态，禁止验收')
            except (TypeError, KeyError, ValueError, np.linalg.LinAlgError) as exc:
                raise ValidationError(f'{kind.upper()}参数无法安全计算：{exc}') from exc
    if not result.get('device_sn') or not result.get('batch_id'):
        raise ValidationError('原始研究结果缺失PCB编号或批次编号')
    if params.get('coordinate_frame') is None:
        raise ValidationError('温补参数缺失参考坐标说明')
    geometry = result.get('geometry', {}).get('selected', {})
    if geometry.get('name') != 'M3' or len(geometry.get('params_deg', [])) != 2:
        raise ValidationError('原始结果缺少M3等效几何参数，不允许重拟合代替')
    return {'params': params, 'result': result, 'parameters_path': parameters_path,
            'research_result_path': result_path, 'parameters_sha256': _sha256(parameters_path),
            'research_sha256': _sha256(result_path),
            'delta_epsilon_deg': list(map(float, geometry['params_deg']))}


def _load_independent_rows(folder, provenance, batch_id=None):
    """Use the existing R8 completed-run integrity checks, NO fitting."""
    pair = locate_runs(folder, batch_id=batch_id)
    passes = pair.get('_all_passes') or [pair['warming'], pair['cooling']]
    old_id = str(provenance['result']['batch_id'])
    source_sn = str(provenance['result']['device_sn'])
    batches = {str(r['config'].get('production_batch_id')) for r in passes}
    sns = {str(r['config'].get('device_sn')) for r in passes}
    if sns != {source_sn}:
        raise ValidationError(f'PCB不一致：参数属于{source_sn}，验证数据属于{sorted(sns)}')
    if len(batches) != 1:
        raise ValidationError('验证文件夹混合了多个批次')
    batch = batches.pop()
    if batch_id and batch != batch_id:
        raise ValidationError('指定批次ID与完整采集文件不一致')
    same_batch = batch == old_id
    rows = []
    for direction in ('warming', 'cooling'):
        rows.extend([{**r, '_direction': direction} for r in pair[direction]['rows']])
    refs = apply_geometry(rows, provenance['delta_epsilon_deg'])
    # Same batch => original untouched independent-TEMPERATURE holdout only.
    # Different batch => any held-out posture is fully new relative to frozen model;
    # retain temperature-split label in report and use validation poses only.
    selected = [r for r in refs if r.get('split') == 'validate' and
                (not same_batch or r.get('temperature_split') == 'validate') and
                (r.get('sensor') != 'acc' or r.get('mode') == 'static')]
    if not selected or not any(r.get('sensor') == 'acc' for r in selected) or not any(r.get('sensor') == 'gyro' for r in selected):
        raise ValidationError('没有足够的ACC/GYRO独立姿态或转速测试行')
    snapshots = []
    for r in passes:
        folder_i = Path(r['folder'])
        snapshots.append({'direction': r['direction'], 'folder': str(folder_i),
                          'config_sha256': _sha256(folder_i / 'experiment_config.json'),
                          'data_sha256': _sha256(folder_i / 'temperature_measurements.json')})
    return selected, {'validation_batch_id': batch, 'originating_batch_id': old_id,
                       'source_kind': 'ORIGINAL_HOLDOUT' if same_batch else 'NEW_BATCH_VALIDATION',
                       'same_batch': same_batch, 'inputs': snapshots,
                       'reference': 'M3软件P参考（非独立计量基准）'}


def _signed_diff_deg(deg, reference):
    return (deg - reference + 180.) % 360. - 180.


def static_roll_pitch(unit):
    """ACC-derived tilt under one DECLARED conventional software-P definition.

    Roll = atan2(y,z); pitch = atan2(-x,sqrt(y²+z²)). Near pitch +/-90°
    roll is ill-defined, so do not falsely score it.
    """
    v = np.asarray(unit, dtype=float)
    if v.shape != (3,) or not np.all(np.isfinite(v)) or np.linalg.norm(v) < 0.5:
        raise ValidationError('ACC方向向量非法')
    x, y, z = v / np.linalg.norm(v)
    transverse = math.hypot(y, z)
    roll = math.degrees(math.atan2(y, z)) if transverse >= 0.1 else None
    pitch = math.degrees(math.atan2(-x, transverse))
    return roll, pitch


def _summary(values):
    arr = np.asarray(values, dtype=float)
    if not len(arr):
        return {'count': 0, 'rmse': None, 'mean_abs': None, 'p95_abs': None, 'max_abs': None}
    if not np.all(np.isfinite(arr)):
        raise ValidationError('测试误差包含非有限值')
    a = abs(arr)
    return {'count': len(arr), 'rmse': float(np.sqrt(np.mean(arr*arr))),
            'mean_abs': float(np.mean(a)), 'p95_abs': float(np.percentile(a,95)),
            'max_abs': float(np.max(a))}


def evaluate_records(rows, provenance, mode='01'):
    """Testable pure evaluation; never invokes any calibrator or model selector."""
    if mode not in ('01', '02'):
        raise ValidationError('只能选择01或02')
    metrics, drops = [], []
    for r in rows:
        sensor = str(r.get('sensor'))
        if sensor not in ('acc', 'gyro') or (mode == '02' and sensor != 'acc'):
            continue
        model = provenance['params'][sensor]
        temp = float(r['temperature_mean_c'])
        domain = list(map(float, model['temperature_domain_c']))
        if not (domain[0] <= temp <= domain[1]):
            drops.append({'sensor': sensor, 'reason': 'OUT_OF_TEMPERATURE_DOMAIN',
                          'chip_c': temp, 'step_id': r.get('step_id')})
            continue
        try:
            F, b = forward_matrix(model, r)
            y = np.asarray(r[FIELDS[sensor]], dtype=float)
            reference = np.asarray(r['reference'], dtype=float)
            if y.shape != (3,) or reference.shape != (3,) or not np.all(np.isfinite(y)):
                raise ValidationError('三轴原始数据格式错误')
            corrected = np.linalg.solve(F, y - b)
            difference = corrected - reference
            out = {'sensor': sensor, 'direction': r.get('_direction'),
                   'step_id': str(r.get('step_id', '')),
                   'setpoint_c': float(r['temperature_target_c']),
                   'temperature_split': r.get('temperature_split'),
                   'chip_c': temp, 'mode': r.get('mode'),
                   'vector_error': float(np.linalg.norm(difference)),
                   'corrected_x': float(corrected[0]),
                   'corrected_y': float(corrected[1]),
                   'corrected_z': float(corrected[2])}
            if sensor == 'acc':
                cosang = np.dot(corrected,reference)/(np.linalg.norm(corrected)*np.linalg.norm(reference))
                out['direction_error_deg'] = math.degrees(math.acos(float(np.clip(cosang,-1.,1.))))
                out['norm_error_mg'] = 1000*(float(np.linalg.norm(corrected))-1.)
                if mode == '02':
                    roll, pitch = static_roll_pitch(corrected)
                    ref_roll, ref_pitch = static_roll_pitch(reference)
                    if roll is not None and ref_roll is not None:
                        out['roll_error_deg'] = _signed_diff_deg(roll, ref_roll)
                    else:
                        out['roll_error_deg'] = None
                    out['pitch_error_deg'] = pitch - ref_pitch
            metrics.append(out)
        except (ValueError, TypeError, KeyError, np.linalg.LinAlgError, ZeroDivisionError) as exc:
            drops.append({'sensor': sensor, 'reason': 'INVALID_ROW_'+str(exc)[:100],
                          'chip_c': temp, 'step_id': r.get('step_id')})
    counts = {}
    for sensor in (('acc',) if mode == '02' else ('acc','gyro')):
        used = [m for m in metrics if m['sensor'] == sensor]
        missing = [d for d in drops if d['sensor'] == sensor]
        n = len(used) + len(missing)
        if n == 0 or len(used) < 0.9*n:
            raise ValidationError(f'{sensor.upper()}没有有效数据或缺失/超温超过10%：有效{len(used)}/{n}')
        counts[sensor] = {'eligible': n, 'used': len(used), 'excluded': len(missing)}
    acc = [m for m in metrics if m['sensor']=='acc']
    gyro = [m for m in metrics if m['sensor']=='gyro']
    summary = {'mode':mode,'counts':counts,
               'acc_direction_deg':_summary([m['direction_error_deg'] for m in acc]),
               'acc_vector_mg':_summary([1000*m['vector_error'] for m in acc]),
               'acc_norm_mg':_summary([m['norm_error_mg'] for m in acc]),
               'gyro_vector_dps':_summary([m['vector_error'] for m in gyro])}
    if mode == '02':
        summary['roll_deg'] = _summary([m['roll_error_deg'] for m in acc if m.get('roll_error_deg') is not None])
        summary['pitch_deg'] = _summary([m['pitch_error_deg'] for m in acc])
        summary['roll_unobservable_count'] = sum(m.get('roll_error_deg') is None for m in acc)
    grouped = defaultdict(list)
    for m in metrics:
        grouped[(m['sensor'],m['direction'],m['setpoint_c'])].append(m)
    summary['per_direction_and_setpoint'] = [
        {'sensor':k[0],'direction':k[1],'setpoint_c':k[2],
         'count':len(v),
         'vector_rmse':_summary([r['vector_error'] for r in v])['rmse'],
         'direction_rmse_deg':_summary([r['direction_error_deg'] for r in v])['rmse'] if k[0]=='acc' else None,
         'roll_rmse_deg':_summary([r['roll_error_deg'] for r in v if r.get('roll_error_deg') is not None])['rmse'] if mode=='02' else None,
         'pitch_rmse_deg':_summary([r['pitch_error_deg'] for r in v])['rmse'] if mode=='02' else None}
        for k, v in sorted(grouped.items(),key=lambda z:str(z[0]))]
    return summary, metrics, drops


def _fmt(v, unit='', digits=5):
    return '未评价' if v is None else f'{v:.{digits}f}{unit}'


def make_report(out, summary, manifest):
    def esc(value):
        return html.escape(str(value))
    def rstat(label, key, unit):
        d = summary[key]
        return '<tr>' + ''.join('<td>'+esc(x)+'</td>' for x in
             (label, d['count'], _fmt(d['rmse'],unit), _fmt(d['mean_abs'],unit),
              _fmt(d['p95_abs'],unit), _fmt(d['max_abs'],unit))) + '</tr>'
    stats = [rstat('ACC三维向量误差','acc_vector_mg',' mg'),
             rstat('ACC重力方向夹角','acc_direction_deg','°'),
             rstat('ACC模长误差','acc_norm_mg',' mg')]
    if summary['mode']=='01':
        stats.append(rstat('GYRO三维向量误差','gyro_vector_dps',' °/s'))
    else:
        stats.append(rstat('ACC推算Roll误差','roll_deg','°'))
        stats.append(rstat('ACC推算Pitch误差','pitch_deg','°'))
    provenance = '原批次独立温度留出姿态：旧数据冻结参数复算，不属于新采集复验' if manifest['source']['same_batch'] else '新批次冻结参数复验：不拟合温补系数，仍使用M3软件参考'
    contents = f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<title>温补后验收 {summary['mode']}</title><style>
body{{max-width:1050px;margin:30px auto;padding:0 24px;font:15px/1.7 "Microsoft YaHei",sans-serif;color:#243144;background:#fff}}
h1{{font-size:26px}}h2{{font-size:19px;margin-top:26px}}.sub{{color:#657283}}.notice{{border-left:4px solid #b17932;background:#fffaf0;padding:13px 18px}}
table{{border-collapse:collapse;width:100%}}td,th{{border-bottom:1px solid #e5e9ee;padding:10px;text-align:left}}th{{background:#f5f7f9}}
code{{overflow-wrap:anywhere}}.num{{font-weight:700;color:#204868}}</style></head><body>
<h1>温补后验收 {summary['mode']} · 冻结参数测试报告</h1>
<p class="sub">{esc(manifest['created_utc'])}　PCB：{esc(manifest['device_sn'])}　原拟合批次：{esc(manifest['source']['originating_batch_id'])}　验证批次：{esc(manifest['source']['validation_batch_id'])}</p>
<p class="notice"><b>来源判定：</b>{esc(provenance)}。所有结果相对于<b>M3软件P参考</b>，不是独立机械计量精度。02是ACC重力方向推导的静态Roll/Pitch，不是固件或融合算法的产品输出。</p>
<h2>指标统计</h2><table><tr><th>指标</th><th>有效工况</th><th>RMSE</th><th>平均绝对误差</th><th>P95绝对误差</th><th>最大绝对误差</th></tr>{''.join(stats)}</table>
<h2>冻结依据与数据质量</h2>
<p>参数模型 ACC {esc(manifest['models']['acc'])} / GYRO {esc(manifest['models']['gyro'])}；M3 δ={manifest['delta_epsilon_deg'][0]:.6f}°，ε={manifest['delta_epsilon_deg'][1]:.6f}°。</p>
<p>参数SHA256：<code>{esc(manifest['parameters_sha256'])}</code>。结果SHA256：<code>{esc(manifest['research_sha256'])}</code>。</p>
<p>每行是一个独立工况均值，不是IMU逐样本；不得把工况数称作样本帧数。验收只做反向矩阵校正，不做任何新拟合；温度超模型有效域的工况剔除并记录，剔除超过10%则拒绝评级。</p>
<p>Roll定义：atan2(g_y,g_z)；Pitch定义：atan2(-g_x,sqrt(g_y²+g_z²))。当Roll接近奇异（|cosPitch|＜0.1）时不评分；存在±180°包角时Roll使用环绕差。该定义须与最终成品安装坐标和输出定义复核。</p>
<h2>结论边界</h2><p>当前仍需用新实验及独立标准参考验证整机的静态/动态Roll/Pitch绝对精度。旧批次留出集不能冒充第二次温补后的新采集重复性测试。</p>
<p class="sub">另存：明细CSV、分温度JSON、剔除工况CSV和不可更改的来源摘要JSON。研发分析，不自动烧录MCU，不控制任何设备。</p></body></html>'''
    Path(out).write_text(contents,encoding='utf-8')


def execute(data_folder, parameters_path, research_result_path=None,
            mode='01', batch_id=None, output_root=None):
    provenance = load_frozen(parameters_path, research_result_path)
    rows, source = _load_independent_rows(data_folder, provenance, batch_id)
    summary, metrics, drops = evaluate_records(rows,provenance,mode)
    root = Path(output_root or data_folder).resolve()
    root.mkdir(parents=True,exist_ok=True)
    when = dt.datetime.now(dt.timezone.utc)
    dest = root / ('QA' + mode + '_' + when.strftime('%Y%m%d_%H%M%S_%f'))
    dest.mkdir(parents=False,exist_ok=False)
    manifest = {'software_version': VERSION, 'created_utc': when.isoformat(),
                'mode':mode,'status':'RESEARCH_EVALUATION_ONLY',
                'device_sn':provenance['result']['device_sn'],
                'source':source,'models':{s:provenance['params'][s]['id'] for s in ('acc','gyro')},
                'parameters_path':str(provenance['parameters_path']),
                'research_result_path':str(provenance['research_result_path']),
                'parameters_sha256':provenance['parameters_sha256'],
                'research_sha256':provenance['research_sha256'],
                'delta_epsilon_deg':provenance['delta_epsilon_deg'],
                'scope':'NO_REFIT, NO_HARDWARE, software M3-P reference only'}
    (dest/'run_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    (dest/'statistics.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    def write_csv(name,items):
        if not items:return
        names=list(dict.fromkeys(k for row in items for k in row))
        with (dest/name).open('w',encoding='utf-8-sig',newline='') as f:
            wr=csv.DictWriter(f,fieldnames=names);wr.writeheader();wr.writerows(items)
    write_csv('独立工况明细.csv',metrics)
    write_csv('未评价工况.csv',drops)
    write_csv('分温度分方向统计.csv',summary['per_direction_and_setpoint'])
    make_report(dest/'报告.html',summary,manifest)
    return dest, summary, manifest


def main():
    parser=argparse.ArgumentParser(description='R10 温补后01/02冻结参数离线验证。严格不操作硬件、不重新拟合。')
    parser.add_argument('--mode',choices=['01','02'],required=True)
    parser.add_argument('--parameters',required=True)
    parser.add_argument('--research-result',default=None)
    parser.add_argument('--data',required=True,help='已经完成的升温/降温实验父目录')
    parser.add_argument('--batch-id',default=None)
    parser.add_argument('--output-root',default=None)
    args=parser.parse_args()
    try:
        dest,summary,manifest=execute(args.data,args.parameters,args.research_result,
                                     args.mode,args.batch_id,args.output_root)
    except (ValidationError,OSError,KeyError,TypeError,ValueError) as exc:
        parser.exit(2,'验收未执行/拒绝评级：'+str(exc)+'\n')
    print('SUCCESS: 冻结参数只读验收完成')
    print('DATA_KIND: '+manifest['source']['source_kind'])
    print('ACC_DIRECTION_RMSE_DEG: '+str(summary['acc_direction_deg']['rmse']))
    if args.mode=='02':
        print('ROLL_RMSE_DEG: '+str(summary['roll_deg']['rmse']))
        print('PITCH_RMSE_DEG: '+str(summary['pitch_deg']['rmse']))
    else:
        print('GYRO_VECTOR_RMSE_DPS: '+str(summary['gyro_vector_dps']['rmse']))
    print('RESULT_PATH='+str(dest/'报告.html'))


if __name__=='__main__':
    main()
