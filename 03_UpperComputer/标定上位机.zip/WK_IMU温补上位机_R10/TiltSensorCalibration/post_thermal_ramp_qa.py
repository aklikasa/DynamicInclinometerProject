# -*- coding: utf-8 -*-
"""QA04 — stationary thermal-ramp evaluation using frozen ACC/GYRO coefficients.

This is a READ-ONLY analyser.  It never drives the chamber or turntable, never
refits coefficients, and never treats a stationary drift number as absolute tilt
accuracy.  Intended for CSVs captured by the existing field-checked R5 recorder.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import html
import json
import math
from pathlib import Path

import numpy as np

from post_thermal_qa import ValidationError, load_frozen, static_roll_pitch, _signed_diff_deg, _summary
from production_cycle_analysis import forward_matrix
from production_ramp import load_ramp_rows, classify_ramp

VERSION = 'QA04_FROZEN_R2_SOFT_MODEL_DOMAIN_20261119'


def _hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as file:
        for block in iter(lambda: file.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _calc(model, temp, xyz):
    F, b = forward_matrix(model, {'temperature_mean_c': float(temp),
                                  '_direction': 'warming', 'reference': [0., 0., 1.]})
    if not np.all(np.isfinite(F)) or not np.all(np.isfinite(b)) or abs(np.linalg.det(F)) < 1e-7 or np.linalg.cond(F) > 60:
        raise ValidationError('固定模型矩阵数值异常/病态')
    return np.linalg.solve(F, np.asarray(xyz, float) - b)


def _vec_angle_deg(vec, ref):
    u = vec / np.linalg.norm(vec)
    v = ref / np.linalg.norm(ref)
    return math.degrees(math.acos(float(np.clip(np.dot(u, v), -1., 1.))))


def _f(value, digs=5):
    return '未评价' if value is None else f'{value:.{digs}f}'


def _polyline(rows, x, y, color, x0, y0, w, h, xmin, xmax, ymin, ymax):
    coords = []
    for row in rows:
        a, b = row.get(x), row.get(y)
        if a is None or b is None or not all(math.isfinite(float(z)) for z in (a, b)):
            continue
        px = x0 + (float(a) - xmin) / max(xmax-xmin, 1e-9)*w
        py = y0 + h - (float(b) - ymin) / max(ymax-ymin, 1e-9)*h
        coords.append(f'{px:.1f},{py:.1f}')
    if len(coords) < 2:
        return ''
    return f'<polyline points="{" ".join(coords)}" fill="none" stroke="{color}" stroke-width="1.9" vector-effect="non-scaling-stroke"/>'


def _chart(rows, columns, title, unit):
    """Draw a small self-contained SVG; all plotted points are measured records."""
    if not rows:
        return ''
    xmin = min(r['elapsed_min'] for r in rows)
    xmax = max(r['elapsed_min'] for r in rows)
    numbers = [float(r[k]) for r in rows for k, _, _ in columns if r.get(k) is not None and math.isfinite(float(r[k]))]
    if not numbers:
        return ''
    ymin, ymax = min(numbers), max(numbers)
    margin = max((ymax-ymin)*.12, .0005)
    ymin -= margin; ymax += margin
    x0,y0,w,h = 65,28,850,225
    lines = ''.join(_polyline(rows,'elapsed_min',key,color,x0,y0,w,h,xmin,xmax,ymin,ymax)
                    for key, _, color in columns)
    legend = ''.join(f'<span style="margin-right:24px"><i style="display:inline-block;width:19px;border-top:3px solid {color};vertical-align:middle"></i> {html.escape(label)}</span>'
                     for _, label, color in columns)
    return (f'<section class="chart"><h3>{html.escape(title)}</h3><div class="sub">单位 {html.escape(unit)}　·　横轴：实验经过时间（分钟）</div>'
            f'<svg viewBox="0 0 960 278" role="img"><rect x="{x0}" y="{y0}" width="{w}" height="{h}" fill="#fafbfd" stroke="#d5dce4"/>'
            f'<text x="7" y="36" font-size="13">{ymax:.3f}</text><text x="7" y="252" font-size="13">{ymin:.3f}</text>'
            f'<text x="{x0}" y="274" font-size="13">{xmin:.1f}</text><text x="{x0+w-35}" y="274" font-size="13">{xmax:.1f}</text>'
            f'{lines}</svg><div class="legend">{legend}</div></section>')


def _write_csv(path, rows):
    if not rows:
        return
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with Path(path).open('w', newline='', encoding='utf-8-sig') as f:
        wr = csv.DictWriter(f, fieldnames=fields)
        wr.writeheader()
        wr.writerows(rows)


def _metric(series, key):
    return _summary([row[key] for row in series if row.get(key) is not None])


def _evaluate_ramp(samples, prov, *, direction='both', requested_low=None, requested_high=None,
                   requested_rate=None, min_coverage_c=10.0):
    if direction not in ('both','warming','cooling'):
        raise ValidationError('方向应为both/warming/cooling')
    serial = str(prov['result']['device_sn'])
    chip_domains = {k: list(map(float, prov['params'][k]['temperature_domain_c'])) for k in ('acc','gyro')}
    for row in samples:
        # Original R5 loader validates measurement data and fixed orientation.
        # Fit temperature endpoints do not define permissible TEST temperatures.
        if str(row.get('device_sn',serial)) != serial:
            raise ValidationError('R5设备SN与冻结模型的PCB编号不同')
    if requested_low is not None and requested_high is not None and not float(requested_low) < float(requested_high):
        raise ValidationError('最低温度必须低于最高温度')
    # Requested low/high are CHAMBER endpoint SP, not silicon temperature.
    # QA04 verifies physical chamber PV at each endpoint before switching.
    # Silicon temperature may lag PV, especially during step-setpoint cycles.
    # Report chip-T domain coverage as metadata, not an experiment or report gate.
    # Outside-domain corrected values are EXTRAPOLATIONS and marked per frame.
    if requested_rate is not None and not (.1 <= float(requested_rate) <= 2.0):
        raise ValidationError('计划温度速率仅允许0.1～2℃/min（不代表PLC实际速率）')

    raw_acc = np.asarray([[r[f'acc_{k}_g'] for k in 'xyz'] for r in samples],float)
    raw_gyro = np.asarray([[r[f'gyro_{k}_dps'] for k in 'xyz'] for r in samples],float)
    corr_acc = np.array([_calc(prov['params']['acc'],r['chip_c'],v) for r,v in zip(samples,raw_acc)])
    corr_gyro = np.array([_calc(prov['params']['gyro'],r['chip_c'],v) for r,v in zip(samples,raw_gyro)])
    # In the new fixed-SP step protocol the natural chip heating/cooling rate
    # is measured, not set by the user; it may exceed the old R5 2 C/min gate.
    # Keep the original 2 C/min bound when a rate-controlled legacy study is
    # explicitly requested; step mode accepts measured rates up to 20 C/min.
    tags, slopes = classify_ramp(samples, max_abs_rate_c_min=(20.0 if requested_rate is None else 2.0))

    # Do not silently infer fixed orientation from a fitted reference.  The two
    # baselines are taken from the same initial capture interval for a fair
    # raw-vs-corrected drift comparison.
    baseline_n = min(30,max(5,len(samples)//20))
    raw_base = np.mean(raw_acc[:baseline_n],axis=0)
    corr_base = np.mean(corr_acc[:baseline_n],axis=0)
    if min(np.linalg.norm(raw_base), np.linalg.norm(corr_base)) < .6:
        raise ValidationError('ACC初始固定姿态重力向量无效')
    roll_ref, pitch_ref = static_roll_pitch(corr_base)
    raw_roll_ref, raw_pitch_ref = static_roll_pitch(raw_base)
    begin=float(samples[0]['unix_s'])
    per=[]
    for i,r in enumerate(samples):
        roll,pitch=static_roll_pitch(corr_acc[i]); raw_roll,raw_pitch=static_roll_pitch(raw_acc[i])
        row={'unix_s':r['unix_s'],'elapsed_min':(float(r['unix_s'])-begin)/60.,
             'chip_c':r['chip_c'],'pv_c':r['pv_c'],
             'acc_inside_fit_domain':chip_domains['acc'][0]<=float(r['chip_c'])<=chip_domains['acc'][1],
             'gyro_inside_fit_domain':chip_domains['gyro'][0]<=float(r['chip_c'])<=chip_domains['gyro'][1],
             'model_extrapolation':(not all(bounds[0]<=float(r['chip_c'])<=bounds[1]
                                            for bounds in chip_domains.values())),
             'direction':('warming' if tags[i]==1 else 'cooling' if tags[i]==-1 else 'transition'),
             'measured_chip_slope_c_min':None if not math.isfinite(float(slopes[i])) else float(slopes[i]),
             'frame_count':r['frame_count'],
             'raw_acc_vector_drift_mg':float(np.linalg.norm(raw_acc[i]-raw_base)*1e3),
             'corrected_acc_vector_drift_mg':float(np.linalg.norm(corr_acc[i]-corr_base)*1e3),
             'raw_acc_direction_drift_deg':_vec_angle_deg(raw_acc[i],raw_base),
             'corrected_acc_direction_drift_deg':_vec_angle_deg(corr_acc[i],corr_base),
             'corrected_acc_norm_error_mg':float((np.linalg.norm(corr_acc[i])-1.)*1e3),
             'raw_acc_norm_error_mg':float((np.linalg.norm(raw_acc[i])-1.)*1e3),
             'raw_gyro_norm_dps':float(np.linalg.norm(raw_gyro[i])),
             'corrected_gyro_norm_dps':float(np.linalg.norm(corr_gyro[i])),
             'raw_roll_drift_deg':_signed_diff_deg(raw_roll,raw_roll_ref) if raw_roll is not None and raw_roll_ref is not None else None,
             'raw_pitch_drift_deg':raw_pitch-raw_pitch_ref,
             'roll_drift_deg':_signed_diff_deg(roll,roll_ref) if roll is not None and roll_ref is not None else None,
             'pitch_drift_deg':pitch-pitch_ref}
        for kind, a, b in [('acc',raw_acc[i],corr_acc[i]),('gyro',raw_gyro[i],corr_gyro[i])]:
            for index,k in enumerate('xyz'):
                row[f'{kind}_{k}_raw']=float(a[index]);row[f'{kind}_{k}_corrected']=float(b[index])
        per.append(row)
    requested_directions=['warming','cooling'] if direction=='both' else [direction]
    counts={};metric_by_dir={}
    for d in requested_directions:
        seg=[r for r in per if r['direction']==d]
        coverage=float(max((r['chip_c'] for r in seg),default=0) - min((r['chip_c'] for r in seg),default=0)) if seg else 0
        counts[d]={'fresh_frames':len(seg),'chip_temperature_span_c':coverage,
                   'meets_legacy_research_coverage':len(seg)>=100 and coverage>=min_coverage_c}
        # Insufficient chip-temperature coverage is described, NOT fatal; the
        # chamber PV controls leg completion and silicon can lag considerably.
        metric_by_dir[d]={k:_metric(seg,k) for k in ('raw_acc_vector_drift_mg','corrected_acc_vector_drift_mg',
          'raw_acc_direction_drift_deg','corrected_acc_direction_drift_deg',
          'corrected_acc_norm_error_mg','raw_gyro_norm_dps','corrected_gyro_norm_dps',
          'roll_drift_deg','pitch_drift_deg')}
    selected=[r for r in per if r['direction'] in requested_directions]
    metrics={k:_metric(selected,k) for k in ('raw_acc_vector_drift_mg','corrected_acc_vector_drift_mg',
          'raw_acc_direction_drift_deg','corrected_acc_direction_drift_deg',
          'corrected_acc_norm_error_mg','raw_gyro_norm_dps','corrected_gyro_norm_dps',
          'roll_drift_deg','pitch_drift_deg')}

    paired=[]
    if direction=='both':
        grouped={'warming':{},'cooling':{}}
        for row in selected:
            d=row['direction']
            idx=int(round(row['chip_c']*2))  # 0.5℃ measured chip-temperature bins
            grouped[d].setdefault(idx,[]).append(row)
        for idx in sorted(set(grouped['warming'])&set(grouped['cooling'])):
            a=grouped['warming'][idx];b=grouped['cooling'][idx]
            if min(len(a),len(b))<3:continue
            mean_a=float(np.mean([x['chip_c'] for x in a]));mean_b=float(np.mean([x['chip_c'] for x in b]))
            if abs(mean_a-mean_b)>.25:continue
            def mean(k,group):return float(np.mean([x[k] for x in group]))
            entry={'chip_bin_c':idx/2,'warming_chip_mean_c':mean_a,'cooling_chip_mean_c':mean_b,
                   'chip_mean_difference_c':mean_a-mean_b,'warming_count':len(a),'cooling_count':len(b)}
            for key in ('acc_x_corrected','acc_y_corrected','acc_z_corrected','gyro_x_corrected','gyro_y_corrected','gyro_z_corrected'):
                entry['cool_minus_warm_'+key]=mean(key,b)-mean(key,a)
            entry['acc_xyz_hysteresis_mg']=1000*math.sqrt(sum(entry['cool_minus_warm_acc_'+k+'_corrected']**2 for k in 'xyz'))
            entry['gyro_xyz_hysteresis_dps']=math.sqrt(sum(entry['cool_minus_warm_gyro_'+k+'_corrected']**2 for k in 'xyz'))
            paired.append(entry)
    measured_rates={}
    for d in requested_directions:
        rate_values=[abs(r['measured_chip_slope_c_min']) for r in per
                     if r['direction']==d and r['measured_chip_slope_c_min'] is not None]
        measured_rates[d]=float(np.median(rate_values)) if rate_values else None
    out_of_fit=[r for r in per if r['model_extrapolation']]
    selected_in_fit=[r for r in selected if not r['model_extrapolation']]
    metric_keys=tuple(metrics)
    summary={'status':'EVALUATED_WITH_EXTRAPOLATION' if out_of_fit else 'EVALUATED',
        'source_count':len(samples),'scored_count':len(selected),
        'model_temperature_domains_chip_c':chip_domains,
        'model_extrapolation_samples':len(out_of_fit),
        'model_extrapolation_scored_samples':sum(bool(r['model_extrapolation']) for r in selected),
        'model_in_domain_scored_samples':len(selected_in_fit),
        'metrics_in_fit_domain_only':{k:_metric(selected_in_fit,k) for k in metric_keys},
        'chip_coverage_notice_only':True,
        'observed_median_chip_rate_c_min':measured_rates,
        'temperature_observed_chip_c':[float(min(r['chip_c'] for r in samples)),float(max(r['chip_c'] for r in samples))],
        'temperature_observed_pv_c':[float(min(r['pv_c'] for r in samples)),float(max(r['pv_c'] for r in samples))],
        'direction_counts':counts,'metrics':metrics,'metrics_by_direction':metric_by_dir,
        'matched_chip_bins_count':len(paired),'matched_hysteresis_acc_mg':_summary([v['acc_xyz_hysteresis_mg'] for v in paired]),
        'matched_hysteresis_gyro_dps':_summary([v['gyro_xyz_hysteresis_dps'] for v in paired]),
        'requested':{'direction':direction,'low_c':requested_low,'high_c':requested_high,'rate_c_min':requested_rate},
        'scope':'same fixed orientation, baseline-relative drift; not absolute angle accuracy or dynamic-axis alignment',
        'no_refit':True,'reference':'same-run initial corrected stationary gravity, no independent angle standard'}
    return summary,per,paired


def make_html(path, summary, rows, matched, manifest):
    def table(label,metric,unit):
        v=summary['metrics'][metric]
        return '<tr>'+''.join(f'<td>{html.escape(str(x))}</td>' for x in (label,v['count'],_f(v['rmse'])+' '+unit,
                          _f(v['mean_abs'])+' '+unit,_f(v['p95_abs'])+' '+unit,_f(v['max_abs'])+' '+unit))+'</tr>'
    metrics=''.join([table('ACC三维向量漂移·原始','raw_acc_vector_drift_mg','mg'),
      table('ACC三维向量漂移·补偿','corrected_acc_vector_drift_mg','mg'),
      table('ACC方向漂移·原始','raw_acc_direction_drift_deg','°'),
      table('ACC方向漂移·补偿','corrected_acc_direction_drift_deg','°'),
      table('ACC补偿后模长误差','corrected_acc_norm_error_mg','mg'),
      table('GYRO零速输出模长·原始','raw_gyro_norm_dps','°/s'),
      table('GYRO零速输出模长·补偿','corrected_gyro_norm_dps','°/s'),
      table('静态Roll漂移·补偿','roll_drift_deg','°'),
      table('静态Pitch漂移·补偿','pitch_drift_deg','°')])
    tabs=''.join(f'<tr><td>{html.escape(k)}</td><td>{v["fresh_frames"]}</td><td>{v["chip_temperature_span_c"]:.3f}℃</td><td>{_f(summary["observed_median_chip_rate_c_min"][k],3)}℃/min</td></tr>' for k,v in summary['direction_counts'].items())
    domain_note=(f'补偿模型原拟合温区：{html.escape(str(summary["model_temperature_domains_chip_c"]))}；'
                 f'模型温区外样本 {summary["model_extrapolation_samples"]} / {summary["source_count"]}。'
                 '即使芯片温度超出原拟合温区，04仍完成采集与计算；该部分补偿系外推，'
                 '仅供研究参考，不应视为原拟合域内已验证的精度。'
                 f'参与全程漂移统计的区内样本 {summary["model_in_domain_scored_samples"]}，'
                 f'区外样本 {summary["model_extrapolation_scored_samples"]}；'
                 '逐帧CSV中已分别标记ACC/GYRO拟合域内状态。')
    chips=_chart(rows,[('chip_c','芯片实际温度','#C76B20'),('pv_c','温箱PV','#176D98')],'温度实测轨迹','℃')
    gyro=_chart(rows,[('raw_gyro_norm_dps','原始GYRO模长','#B77B56'),('corrected_gyro_norm_dps','补偿后GYRO模长','#237D72')],'GYRO静止零速输出模长','°/s')
    acc=_chart(rows,[('raw_acc_vector_drift_mg','原始ACC漂移','#B77B56'),('corrected_acc_vector_drift_mg','补偿后ACC漂移','#237D72')],'ACC固定姿态向量漂移','mg')
    roll=_chart(rows,[('roll_drift_deg','Roll漂移','#176D98'),('pitch_drift_deg','Pitch漂移','#9C4F9F')],'ACC推算静态Roll/Pitch漂移','°')
    if matched:
        hyst=f'<p>同实际芯片温度配对：{len(matched)}个0.5℃温度箱，只有升温/降温芯片均温差≤0.25℃且各至少3帧才配对；配对的ACC向量差RMSE {summary["matched_hysteresis_acc_mg"]["rmse"]:.4f} mg，GYRO向量差RMSE {summary["matched_hysteresis_gyro_dps"]["rmse"]:.5f} °/s。<b>仍可能包含采样不同步、热梯度和随时间变化，不是纯粹材料热滞后。</b></p>'
    else:hyst='<p>当前未获得足够满足芯片温度匹配条件的升降温配对点；不报告纯热滞后数值。</p>'
    source=html.escape(str(manifest['ramp_csv']))
    content=f'''<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><title>04连续变温静态漂移验收</title>
<style>body{{font:15px/1.65 'Microsoft YaHei',Arial,sans-serif;color:#253044;max-width:1110px;padding:28px;margin:auto;background:#fff}}h1{{font-size:25px}}h2{{font-size:19px;margin-top:30px}}h3{{font-size:16px}}.muted,.sub{{color:#68778a}}.warning{{background:#fff8e8;border-left:4px solid #c58b3b;padding:12px 16px}}table{{width:100%;border-collapse:collapse;font-size:13px}}td,th{{padding:10px;border-bottom:1px solid #e4e8ed;text-align:left}}th{{background:#f4f7f9}}.chart{{margin:22px 0;border:1px solid #e1e6eb;padding:12px 16px;border-radius:9px}}svg{{width:100%}}.legend{{font-size:13px}}code{{word-break:break-all}}</style></head><body>
<h1>04｜连续变温静态漂移验证</h1><p class="muted">研究性验收 · 固定温补参数 · {html.escape(manifest['created_utc'])} · PCB {html.escape(manifest['device_sn'])}</p>
<div class="warning"><b>本报告不等于绝对倾角精度。</b>IMU与转台保持静止，静态Roll/Pitch与ACC方向变化均以本次记录初始固定姿态为参考。温度动态过程中的噪声、热应力、夹具微动会一并影响指标；未参与拟合、不校正基准。</div>
<div class="warning"><b>芯片温度超出原温补训练区间不会阻断实验。</b>{domain_note}</div>
<h2>采集与来源</h2><p>温箱设定温度计划：{html.escape(str(manifest.get('chamber_sp_plan_c',{})))}；温箱PV与芯片T分别实测，不把设定温度误认为芯片温度。</p><p>样本总数 {summary['source_count']}，用于斜坡统计 {summary['scored_count']}；测得芯片温区 {summary['temperature_observed_chip_c'][0]:.2f}～{summary['temperature_observed_chip_c'][1]:.2f}℃；PLC PV {summary['temperature_observed_pv_c'][0]:.2f}～{summary['temperature_observed_pv_c'][1]:.2f}℃。</p>
<p>已冻结ACC模型 <b>{html.escape(manifest['acc_model'])}</b>、GYRO模型 <b>{html.escape(manifest['gyro_model'])}</b>；系数SHA256：<code>{manifest['parameters_sha256']}</code>；采集文件SHA256：<code>{manifest['ramp_sha256']}</code>。</p>
<table><thead><tr><th>方向</th><th>有效帧</th><th>芯片实际温度跨度</th><th>实测芯片温度速率中位数</th></tr></thead><tbody>{tabs}</tbody></table>
<h2>补偿前后同口径指标</h2><table><thead><tr><th>指标</th><th>帧数</th><th>RMSE</th><th>平均绝对值</th><th>P95绝对值</th><th>最大绝对值</th></tr></thead><tbody>{metrics}</tbody></table>
<p class="muted">ACC原始/补偿向量漂移均相对各自前{min(30,max(5,summary['source_count']//20))}帧的平均初始值；GYRO直接相对理论零角速度。RMSE=sqrt(mean(error²))，P95为绝对值95百分位。统计单位已按指标列标明。</p>
<h2>温度与补偿曲线（真实采样数据）</h2>{chips}{acc}{gyro}{roll}
<h2>升降温匹配与热滞后证据</h2>{hyst}
<h2>解释边界及注意事项</h2><p>没有独立姿态标准，不能声称Roll/Pitch绝对精度；单姿态不能验证ACC的全部三轴参数。离线报告计算本身不发送PLC指令；若R10前端使用PLC自动控制，必须另行核对控制日志和PLC真实回读。温箱设定斜坡速率不等于芯片实测速率，后者见表。</p>
<p>固定参数未重新拟合；原模型温区外计算标记为外推，仅供研究参考；样本来自<code>{source}</code>。本报告不包含实机温箱速率控制验收，严禁用软件报告替代现场设备联锁验证。</p></body></html>'''
    Path(path).write_text(content,encoding='utf-8')


def execute(ramp_csv, parameters_path, research_result_path=None, *, output_root=None,
            direction='both', low=None, high=None, rate=None, min_coverage_c=10.0,
            sp_low=None, sp_high=None):
    prov=load_frozen(parameters_path,research_result_path)
    if isinstance(ramp_csv,(str,Path)):
        ramp_files=[Path(ramp_csv).resolve()]
    else:ramp_files=[Path(p).resolve() for p in ramp_csv]
    if not ramp_files or any(not p.is_file() for p in ramp_files):
        raise ValidationError('R5 CSV不存在')
    samples=load_ramp_rows(ramp_files,min_samples=2)  # QA04 always exports a report; short data flagged in statistics.
    # load_ramp_rows does not retain device_sn/batch_id; check raw source file explicitly.
    with ramp_files[0].open('r',encoding='utf-8-sig',newline='') as f:
        ident=next(csv.DictReader(f),None) or {}
    sn=str(ident.get('device_sn',''));batch=str(ident.get('batch_id',''))
    if sn!=str(prov['result']['device_sn']):
        raise ValidationError(f'PCB不一致：温补参数{prov["result"]["device_sn"]}；R5斜坡{sn}')
    if not batch:raise ValidationError('斜坡CSV没有批次ID')
    for fpath in ramp_files[1:]:
        with fpath.open('r',encoding='utf-8-sig',newline='') as fp:
            ident_i=next(csv.DictReader(fp),None) or {}
        if str(ident_i.get('device_sn'))!=sn or str(ident_i.get('batch_id'))!=batch:
            raise ValidationError('斜坡文件混合设备/批次；拒绝验收')
    summary,detail,paired=_evaluate_ramp(samples,prov,direction=direction,requested_low=low,
             requested_high=high,requested_rate=rate,min_coverage_c=min_coverage_c)
    now=dt.datetime.now(dt.timezone.utc)
    dest=Path(output_root or ramp_files[0].parent).resolve()/('QA04_'+now.strftime('%Y%m%d_%H%M%S_%f'))
    dest.mkdir(parents=True,exist_ok=False)
    manifest={'version':VERSION,'created_utc':now.isoformat(),'device_sn':sn,
      'chamber_sp_plan_c':{'low':sp_low,'high':sp_high},
      'ramp_batch_id':batch,'originating_fit_batch_id':str(prov['result']['batch_id']),
      'ramp_csv':[str(p) for p in ramp_files], 'ramp_sha256':_hash(ramp_files[0]),
      'all_ramp_sha256':{str(p):_hash(p) for p in ramp_files},
      'parameters_path':str(prov['parameters_path']), 'research_result_path':str(prov['research_result_path']),
      'parameters_sha256':prov['parameters_sha256'],'research_sha256':prov['research_sha256'],
      'acc_model':prov['params']['acc']['id'],'gyro_model':prov['params']['gyro']['id'],
      'temperature_domain_chip_c':{k:prov['params'][k]['temperature_domain_c'] for k in ('acc','gyro')},
      'angle_reference':'initial stationary ACC vector, not an independent reference',
      'software_P_reference':'M3 is software P, not a certified mechanical reference',
      'no_refit':True,'no_plc_control_in_analysis':True}
    (dest/'固定参数与来源审计.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    (dest/'统计结果.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    _write_csv(dest/'连续变温逐帧补偿数据.csv',detail)
    _write_csv(dest/'同芯片温度升降温配对.csv',paired)
    make_html(dest/'04_连续变温静态漂移报告.html',summary,detail,paired,manifest)
    return dest,summary,manifest


def main():
    p=argparse.ArgumentParser(description='R10 04 冻结参数连续变温静态漂移验收（只读，不控制设备）')
    p.add_argument('--ramp',required=True)
    p.add_argument('--parameters',required=True)
    p.add_argument('--research-result')
    p.add_argument('--output-root')
    p.add_argument('--direction',choices=['both','warming','cooling'],default='both')
    p.add_argument('--low',type=float)
    p.add_argument('--high',type=float,help='Legacy chip-T coverage constraint; not the chamber SP')
    p.add_argument('--sp-low',type=float,help='Planned chamber setpoint minimum')
    p.add_argument('--sp-high',type=float,help='Planned chamber setpoint maximum')
    p.add_argument('--rate',type=float)
    p.add_argument('--min-coverage',type=float,default=10.0)
    args=p.parse_args()
    try:
        dest,summary,provenance=execute(args.ramp,args.parameters,args.research_result,
           output_root=args.output_root,direction=args.direction,low=args.low,high=args.high,
           rate=args.rate,min_coverage_c=args.min_coverage,
           sp_low=args.sp_low,sp_high=args.sp_high)
    except (ValidationError,OSError,ValueError,KeyError,TypeError,np.linalg.LinAlgError) as exc:
        p.exit(2,'04拒绝评级：'+str(exc)+'\n')
    print('SUCCESS: 固定温补参数静态斜坡验收完成；无重新拟合、无设备控制')
    print('EVALUATED_FRAMES='+str(summary['scored_count']))
    print('ACC_DRIFT_RMSE_MG='+str(summary['metrics']['corrected_acc_vector_drift_mg']['rmse']))
    print('GYRO_ZERO_RMSE_DPS='+str(summary['metrics']['corrected_gyro_norm_dps']['rmse']))
    print('RESULT_PATH='+str(dest/'04_连续变温静态漂移报告.html'))


if __name__=='__main__':main()
