# -*- coding: utf-8 -*-
"""01/02 frozen-parameter OFFLINE acceptance tab for R10.

The two actions do not connect to or move WK/PLC/IMU hardware. New automatic
measurement acquisition is a separate, not-yet-commissioned feature.
"""
from pathlib import Path
import os
import sys
import webbrowser

from PySide6.QtCore import QProcess, QProcessEnvironment
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QGridLayout,QHBoxLayout,
    QLabel,QLineEdit,QPushButton,QGroupBox,QFileDialog,QPlainTextEdit,QMessageBox)

ROOT = Path(__file__).resolve().parents[1]


class FormPostThermalQA:
    def __init__(self, ui):
        self.page = QWidget()
        self.page.setObjectName('page_PostThermalQA01_02')
        self.process = None
        self._out_bytes = bytearray()
        self._err_bytes = bytearray()
        self.last_report = None
        layout = QVBoxLayout(self.page)
        title = QLabel('01 / 02 · 温补后固定参数验证（第一阶段：已有数据离线复算）')
        title.setStyleSheet('font-size:16px;font-weight:600;margin:6px 0')
        layout.addWidget(title)
        notice = QLabel('两项按钮均为只读离线验证：不拟合新系数、不移动WK、不控制温箱、也不烧录MCU。'
                        '01检验冻结参数在已采集独立工况的表现；02用校准ACC计算静态Roll/Pitch，'
                        '其参考是M3软件P轴，并非已认证的成品绝对倾角。'
                        '若使用原拟合批次，报告会明确标注“原批次独立温度留出集”，不能称为第二次新实验。')
        notice.setWordWrap(True)
        notice.setStyleSheet('color:#785021;background:#fff8e8;padding:10px;border-radius:5px')
        layout.addWidget(notice)
        self.ui=ui
        nav=QPushButton('▶ 去04：连续升降温静态漂移测试（不要在本页填04参数）')
        nav.setStyleSheet('font-size:14px;font-weight:600;padding:8px')
        nav.clicked.connect(self._go_to_04)
        layout.addWidget(nav)

        group=QGroupBox('数据与冻结参数（请选择原研究结果，或新的已完成实验数据）')
        grid=QGridLayout(group)
        self.parameter=QLineEdit()
        self.parameter.setPlaceholderText('选择 统一温补研究参数_未经生产批准.json')
        self.research=QLineEdit()
        self.research.setPlaceholderText('同目录 全量研究结果_不得直接烧录.json；可自动填入')
        self.data=QLineEdit()
        self.data.setPlaceholderText('包含已完成升温/降温THERM目录的父文件夹')
        self.batch=QLineEdit()
        self.batch.setPlaceholderText('验证批次ID（可选；多批次时必须填写）')
        self.output=QLineEdit()
        self.output.setPlaceholderText('输出目录（可留空，默认写入验证数据父目录）')
        inputs=[('旧温补参数JSON（必选）',self.parameter,True),
                ('已完成验证数据父目录（必选）',self.data,False)]
        for i,(label,edit,file_choice) in enumerate(inputs):
            grid.addWidget(QLabel(label),i,0)
            grid.addWidget(edit,i,1)
            btn=QPushButton('浏览…')
            btn.clicked.connect(lambda checked=False,e=edit,f=file_choice:self._browse(e,f))
            grid.addWidget(btn,i,2)
        self.advanced_toggle=QPushButton('高级设置：配套研究结果/批次/输出目录 ▾')
        self.advanced_toggle.setCheckable(True)
        self.advanced_toggle.toggled.connect(self._toggle_advanced)
        grid.addWidget(self.advanced_toggle,2,0,1,3)
        layout.addWidget(group)
        self.advanced_group=QGroupBox('高级设置（默认可不填）')
        ga=QGridLayout(self.advanced_group)
        for i,(label,edit,file_choice) in enumerate([
                ('配套研究结果JSON',self.research,True),
                ('验证批次ID',self.batch,None),
                ('输出根目录',self.output,False)]):
            ga.addWidget(QLabel(label),i,0)
            ga.addWidget(edit,i,1)
            if file_choice is not None:
                btn=QPushButton('浏览…')
                btn.clicked.connect(lambda checked=False,e=edit,f=file_choice:self._browse(e,f))
                ga.addWidget(btn,i,2)
        self.advanced_group.setVisible(False)
        layout.addWidget(self.advanced_group)
        self.parameter.editingFinished.connect(self._autofill_research)
        row=QHBoxLayout()
        self.one=QPushButton('01 ▶ 固定参数独立复验（不重新拟合）')
        self.two=QPushButton('02 ▶ 现有静态姿态Roll/Pitch分项复核')
        self.one.clicked.connect(lambda:self._start('01'))
        self.two.clicked.connect(lambda:self._start('02'))
        row.addWidget(self.one);row.addWidget(self.two)
        layout.addLayout(row)
        footer=QHBoxLayout()
        self.open_report=QPushButton('打开最近报告')
        self.open_report.setEnabled(False)
        self.open_report.clicked.connect(self._open_report)
        footer.addWidget(self.open_report)
        self.status=QLabel('就绪。此阶段不启动任何物理采集；新批次可通过原R8流程完成后再读取。')
        self.status.setWordWrap(True)
        footer.addWidget(self.status,1)
        layout.addLayout(footer)
        self.log=QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText('报告存放路径、工况数及遇到的校验问题将在这里显示。')
        layout.addWidget(self.log,1)
        # Embedded by main.py in the unified post-thermal module.

    def _go_to_04(self):
        action=getattr(self,'_open_04',None)
        if callable(action):action()
        else:QMessageBox.warning(self.page,'入口未就绪','04模块尚未完成初始化。')

    def _toggle_advanced(self, visible):
        self.advanced_group.setVisible(bool(visible))
        self.advanced_toggle.setText('高级设置：收起 ▴' if visible else '高级设置：配套研究结果/批次/输出目录 ▾')

    def _autofill_research(self):
        p=Path(self.parameter.text().strip()).expanduser()
        if p.is_file() and not self.research.text().strip():
            result=p.with_name('全量研究结果_不得直接烧录.json')
            if result.is_file():self.research.setText(str(result))

    def _browse(self, edit, file_choice):
        if file_choice:
            path,_=QFileDialog.getOpenFileName(self.page,'选择JSON',str(ROOT),'JSON (*.json)')
        else:
            path=QFileDialog.getExistingDirectory(self.page,'选择已完成实验目录',str(ROOT))
        if path:
            edit.setText(path)
            if edit is self.parameter and not self.research.text().strip():
                related=Path(path).with_name('全量研究结果_不得直接烧录.json')
                if related.is_file():self.research.setText(str(related))
            if edit is self.parameter:self._autofill_research()

    def _start(self, mode):
        self._autofill_research()
        if self.process is not None and self.process.state()!=QProcess.NotRunning:
            QMessageBox.warning(self.page,'任务正在运行','请等当前任务结束后再执行另一项。')
            return
        ramp=getattr(self,'_ramp',None)
        if ramp is not None and (ramp.live is not None or ramp.process is not None):
            QMessageBox.warning(self.page,'运行冲突','04温度斜坡任务正在运行，结束后再使用01/02。')
            return
        parm=self.parameter.text().strip()
        research=self.research.text().strip()
        data=self.data.text().strip()
        if not parm or not Path(parm).is_file() or not data or not Path(data).is_dir():
            QMessageBox.warning(self.page,'参数未就绪','请先选择存在的冻结温补JSON和已完成的实验父目录。')
            return
        if research and not Path(research).is_file():
            QMessageBox.warning(self.page,'研究结果未找到','配套研究结果JSON路径不存在。')
            return
        self.last_report=None;self.open_report.setEnabled(False)
        self.log.clear();self._out_bytes=bytearray();self._err_bytes=bytearray()
        args=[str(ROOT/'post_thermal_qa.py'),'--mode',mode,
              '--parameters',parm,'--data',data]
        if research:args.extend(['--research-result',research])
        if self.batch.text().strip():args.extend(['--batch-id',self.batch.text().strip()])
        if self.output.text().strip():args.extend(['--output-root',self.output.text().strip()])
        process=QProcess(self.page)
        env=QProcessEnvironment.systemEnvironment()
        env.insert('PYTHONIOENCODING','utf-8')
        process.setProcessEnvironment(env)
        process.setWorkingDirectory(str(ROOT))
        process.setProgram(sys.executable)
        process.setArguments(args)
        process.readyReadStandardOutput.connect(self._read_std_out)
        process.readyReadStandardError.connect(self._read_std_err)
        process.finished.connect(self._finished)
        process.errorOccurred.connect(self._process_error)
        self.process=process
        self.one.setEnabled(False);self.two.setEnabled(False)
        self.status.setText(f'正在运行第{mode}项离线验证（不触碰任何硬件）…')
        process.start()

    def _read_std_out(self):
        self._out_bytes.extend(bytes(self.process.readAllStandardOutput()))

    def _read_std_err(self):
        self._err_bytes.extend(bytes(self.process.readAllStandardError()))

    def _process_error(self,error):
        self.log.appendPlainText('子进程异常：'+str(error))

    def _finished(self,exit_code,exit_status):
        self._read_std_out();self._read_std_err()
        out=self._out_bytes.decode('utf-8',errors='replace')
        err=self._err_bytes.decode('utf-8',errors='replace')
        self.log.setPlainText((out+'\n'+err).strip())
        self.one.setEnabled(True);self.two.setEnabled(True)
        result=[line.split('=',1)[1].strip() for line in out.splitlines()
                if line.startswith('RESULT_PATH=')]
        if exit_code==0 and result and Path(result[-1]).is_file():
            self.last_report=Path(result[-1]);self.open_report.setEnabled(True)
            self.status.setText('完成：离线报告已生成，已冻结参数且没有重新拟合。')
        else:
            self.status.setText(f'验证未完成或未获准评级（退出码{exit_code}），请查看日志。')
        self.process=None

    def _open_report(self):
        if self.last_report and self.last_report.is_file():
            webbrowser.open(self.last_report.resolve().as_uri())
