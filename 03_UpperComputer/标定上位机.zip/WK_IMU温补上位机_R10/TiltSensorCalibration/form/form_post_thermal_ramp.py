# -*- coding: utf-8 -*-
"""04 · stationary thermal-drift validation with fixed endpoint PLC targets.

Reuses the R10 R5 stationary recorder and existing shared PLC connection.
The host writes VW2110 only when entering the start point or reversing an
endpoint, and uses chamber PV (not internal process SP VW2106) for switching.
QA04 disables residual PLC rate mode for the initial endpoint approach,
then uses the selected PLC rate during measured legs.  Target VW2110 still
changes only at actual endpoint transitions; there are no intermediate host writes.
"""
from __future__ import annotations

from qa04_step_plan import build_step_plan, describe_step_plan
import json
import datetime as dt
import math
from pathlib import Path
import sys
import time
import webbrowser

from PySide6.QtCore import QTimer, QProcess, QProcessEnvironment
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QGroupBox,
     QLabel,QLineEdit,QPushButton,QCheckBox,QDoubleSpinBox,QSpinBox,QComboBox,QFileDialog,
     QMessageBox,QPlainTextEdit,QScrollArea)

from post_thermal_qa import load_frozen, ValidationError

ROOT=Path(__file__).resolve().parents[1]


class FormPostThermalRamp:
    def __init__(self, ui, thermal, previous_qa):
        self.ui,self.thermal,self.previous_qa=ui,thermal,previous_qa
        self.page=QWidget()
        self.page.setObjectName('page_PostThermalQA04')
        self.live=None
        self._last_plc_stop_note=''
        self._plc_write_attempted=False
        self._control_log_path=None
        self.process=None
        self.last_report=None
        self._stdout=bytearray();self._stderr=bytearray()
        outer=QVBoxLayout(self.page)
        scroll=QScrollArea(self.page)
        scroll.setWidgetResizable(True)
        body=QWidget()
        layout=QVBoxLayout(body)
        scroll.setWidget(body)
        outer.addWidget(scroll)
        title=QLabel('04｜连续升降温 · 固定姿态热漂移验证')
        title.setStyleSheet('font-weight:600;font-size:17px')
        layout.addWidget(title)
        caution=QLabel('04采用固定SP端点跳变：先到起点（例如−15℃），待温箱PV进入用户设定的到温容差，'
            '再把目标SP一次改为另一个端点（例如+15℃），两端往返按循环次数执行。'
            '正式测试段可设PLC定值速率（默认2℃/min），但上位机不会连续写入中间目标；'
            '实际温箱PV变化速度可能与设定速率不同。'
            '全过程需现场监护、硬件超温及急停可用。')
        caution.setWordWrap(True)
        caution.setStyleSheet('background:#fff7e8;color:#68481f;padding:10px;border-radius:5px')
        layout.addWidget(caution)

        config=QGroupBox('步骤1｜选择以前的温补参数（其他路径自动识别）')
        g=QGridLayout(config)
        self.parameters=QLineEdit();self.parameters.setPlaceholderText('统一温补研究参数_未经生产批准.json')
        self.research=QLineEdit();self.research.setPlaceholderText('全量研究结果_不得直接烧录.json')
        self.data=QLineEdit();self.data.setPlaceholderText('R5 CSV输出目录')
        self.batch=QLineEdit();self.batch.setPlaceholderText('本次记录批次ID；与本次CSV内容完全一致')
        self.sn=QLineEdit();self.sn.setPlaceholderText('同冻结参数的PCB SN')
        # Only the calibration JSON is mandatory to choose.  The research JSON,
        # device SN, run ID and output directory are auto-discovered, but remain
        # inspectable/editable through an explicit advanced section.
        g.addWidget(QLabel('旧温补参数JSON'),0,0)
        g.addWidget(self.parameters,0,1)
        pick=QPushButton('选择温补文件…')
        pick.clicked.connect(lambda:self._browse(self.parameters,'json'))
        g.addWidget(pick,0,2)
        self.identity_info=QLabel('选择一次「统一温补研究参数_未经生产批准.json」，软件将自动识别配套文件和PCB编号。')
        self.identity_info.setWordWrap(True)
        g.addWidget(self.identity_info,1,0,1,3)
        self.advanced_button=QPushButton('高级设置：查看/修改识别结果 ▾')
        self.advanced_button.setCheckable(True)
        self.advanced_button.toggled.connect(self._toggle_advanced)
        g.addWidget(self.advanced_button,2,0,1,3)
        layout.addWidget(config)
        self.advanced_group=QGroupBox('高级设置（一般不需要填写）')
        ga=QGridLayout(self.advanced_group)
        for row,(name,control,choose) in enumerate([
                ('配套研究结果JSON',self.research,'json'),
                ('04记录/报告保存文件夹',self.data,'dir'),
                ('本次记录批次ID',self.batch,None),
                ('PCB唯一编号',self.sn,None)]):
            ga.addWidget(QLabel(name),row,0);ga.addWidget(control,row,1)
            if choose:
                btn=QPushButton('浏览…')
                btn.clicked.connect(lambda checked=False,c=control,k=choose:self._browse(c,k))
                ga.addWidget(btn,row,2)
        self.advanced_group.setVisible(False)
        layout.addWidget(self.advanced_group)
        self.parameters.editingFinished.connect(self._autofill_from_parameters)
        plan=QGroupBox('04 固定SP端点切换测试（起点到温→另一端点→按次数循环）')
        gp=QGridLayout(plan)
        self.low=QDoubleSpinBox();self.high=QDoubleSpinBox()
        for w in (self.low,self.high):
            w.setRange(-40,85);w.setDecimals(1);w.setSingleStep(1.)
        self.low.setValue(-15.);self.high.setValue(15.)
        self.tolerance=QDoubleSpinBox();self.tolerance.setRange(.1,10.);self.tolerance.setDecimals(1)
        self.tolerance.setSingleStep(.5);self.tolerance.setValue(2.)
        self.dwell=QDoubleSpinBox();self.dwell.setRange(0.,120.);self.dwell.setDecimals(0)
        self.dwell.setValue(0.)
        self.direction=QComboBox()
        self.direction.addItem('低温→高温→低温（先升后降）','both')
        self.direction.addItem('高温→低温→高温（先降后升）','both_cooling')
        self.direction.addItem('仅低温→高温（单程）','warming')
        self.direction.addItem('仅高温→低温（单程）','cooling')
        self.cycles=QSpinBox();self.cycles.setRange(1,99);self.cycles.setValue(1)
        self.direction.currentIndexChanged.connect(self._update_step_plan_preview)
        self.cycles.valueChanged.connect(self._update_step_plan_preview)
        self.low.valueChanged.connect(self._update_step_plan_preview)
        self.high.valueChanged.connect(self._update_step_plan_preview)
        self.tolerance.valueChanged.connect(self._update_step_plan_preview)
        # The rate widget is created below; connect after creation.
        gp.addWidget(QLabel('低温目标SP ℃'),0,0);gp.addWidget(self.low,0,1)
        gp.addWidget(QLabel('高温目标SP ℃'),0,2);gp.addWidget(self.high,0,3)
        gp.addWidget(QLabel('到温条件：PV±℃'),1,0);gp.addWidget(self.tolerance,1,1)
        gp.addWidget(QLabel('端点到温保持（秒）'),1,2);gp.addWidget(self.dwell,1,3)
        gp.addWidget(QLabel('先运行哪个方向'),2,0);gp.addWidget(self.direction,2,1)
        gp.addWidget(QLabel('往返循环次数'),2,2);gp.addWidget(self.cycles,2,3)
        self.rate=QDoubleSpinBox()
        self.rate.setRange(0.1,99.9)
        self.rate.setDecimals(1)
        self.rate.setSingleStep(0.1)
        self.rate.setSuffix(' ℃/min')
        self.rate.setValue(2.0)
        self.rate.valueChanged.connect(self._update_step_plan_preview)
        gp.addWidget(QLabel('正式段PLC设定速率'),3,0);gp.addWidget(self.rate,3,1)
        gp.addWidget(QLabel('仅正式升降温段启用；自动到起点不限制速率'),3,2,1,2)
        self.zero_rate_trial=QCheckBox(
            '现场试验：速率开关已开启但回读0.0时，只警告并继续核对SP/PV（设定速度未验证）')
        self.zero_rate_trial.setChecked(False)  # explicit opt-in; never silent
        gp.addWidget(self.zero_rate_trial,4,0,1,4)
        self.step_preview=QLabel('')
        self.step_preview.setWordWrap(True)
        gp.addWidget(self.step_preview,5,0,1,4)
        self.auto_plc=QCheckBox('PLC自动执行固定SP端点切换并记录；结束后请求停止定值运行')
        self.auto_plc.setChecked(True)
        gp.addWidget(self.auto_plc,6,0,1,4)
        self.approval=QCheckBox('已现场确认原定值设温/停止接口可用；WK停车、PCB固定、有人监护且硬件保护正常')
        self.approval.setChecked(False)
        gp.addWidget(self.approval,7,0,1,4)
        layout.addWidget(plan)
        self._update_step_plan_preview()
        actions=QHBoxLayout()
        self.copy_previous=QPushButton('从01/02复制冻结参数')
        self.copy_previous.clicked.connect(self._copy_previous)
        self.start=QPushButton('04 ▶ 自动到起点→固定SP往返循环→补偿报告')
        self.start.clicked.connect(self._start)
        self.cancel=QPushButton('中止04（自动模式请求温箱停机）')
        self.cancel.clicked.connect(self._cancel)
        self.cancel.setEnabled(False)
        actions.addWidget(self.copy_previous);actions.addWidget(self.start,1);actions.addWidget(self.cancel)
        layout.addLayout(actions)
        # Read-only diagnostic.  This action never writes to a PLC or starts a test.
        diagline=QHBoxLayout()
        self.plc_diagnostic=QPushButton('PLC只读诊断：查看PV/SP/模式/运行/速率（不设温）')
        self.plc_diagnostic.clicked.connect(self._read_plc_diagnostic)
        diagline.addWidget(self.plc_diagnostic)
        layout.addLayout(diagline)
        offline=QHBoxLayout()
        self.ramp_csv=QLineEdit()
        self.ramp_csv.setPlaceholderText('选择已有的 R5_RAMP_*.csv，仅离线分析')
        btn=QPushButton('选择CSV')
        btn.clicked.connect(lambda:self._browse(self.ramp_csv,'csv'))
        self.analyze=QPushButton('04 ▶ 已有CSV冻结参数验收')
        self.analyze.clicked.connect(self._offline)
        offline.addWidget(self.ramp_csv,1);offline.addWidget(btn);offline.addWidget(self.analyze)
        layout.addLayout(offline)
        bottom=QHBoxLayout()
        self.status=QLabel('04：设好两个固定目标和循环次数；PLC将直接切换端点SP，按PV到温容差换向。')
        self.status.setWordWrap(True)
        self.open_report=QPushButton('查看报告');self.open_report.setEnabled(False)
        self.open_report.clicked.connect(self._open)
        bottom.addWidget(self.status,1);bottom.addWidget(self.open_report)
        layout.addLayout(bottom)
        self.log=QPlainTextEdit();self.log.setReadOnly(True)
        self.log.setMaximumHeight(150)
        layout.addWidget(self.log)
        self.timer=QTimer(self.page)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self._monitor)
        # Parent page is integrated into the shared post-thermal QA module in main.py.

    def _update_step_plan_preview(self, *unused):
        mode=self.direction.currentData()
        single=mode in ('warming','cooling')
        if single:
            self.cycles.blockSignals(True)
            self.cycles.setValue(1)
            self.cycles.blockSignals(False)
        self.cycles.setEnabled(not single)
        try:
            plan=build_step_plan(float(self.low.value()),float(self.high.value()),mode,
                                 int(self.cycles.value()))
            self.step_preview.setText(describe_step_plan(plan)+
                f'；PV到温判据±{self.tolerance.value():.1f}℃。'
                f'；正式段PLC设定速率{self.rate.value():.1f}℃/min（仅设定，实际PV速度以测量为准）；'
                '上位机不写中间SP。')
        except ValueError as exc:
            self.step_preview.setText('参数待调整：'+str(exc))

    def _toggle_advanced(self, visible):
        self.advanced_group.setVisible(bool(visible))
        self.advanced_button.setText('高级设置：收起 ▴' if visible else '高级设置：查看/修改识别结果 ▾')

    def _autofill_from_parameters(self):
        """Infer related inputs, without silently replacing manually specified ones."""
        p=Path(self.parameters.text().strip()).expanduser()
        if not p.is_file():
            self.identity_info.setText('温补参数路径不存在，请选择有效的JSON文件。')
            return
        sibling=p.with_name('全量研究结果_不得直接烧录.json')
        if sibling.is_file() and (not self.research.text().strip() or not Path(self.research.text().strip()).is_file()):
            self.research.setText(str(sibling))
        if not self.data.text().strip():
            self.data.setText(str(p.parent/'04_连续变温验证记录'))
        if not self.batch.text().strip():
            self.batch.setText('QA04_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S'))
        sn='待验证'; info='配套研究结果：'+('已找到' if self.research.text().strip() and Path(self.research.text().strip()).is_file() else '未找到，需展开高级设置')
        if self.research.text().strip() and Path(self.research.text().strip()).is_file():
            try:
                provenance=load_frozen(str(p),self.research.text().strip())
                sn=str(provenance['result']['device_sn'])
                if not self.sn.text().strip():
                    self.sn.setText(sn)
                info=f'已核验配套研究结果与冻结系数一致 · PCB：{sn} · 默认保存：{self.data.text().strip()}'
            except Exception as exc:
                info=f'冻结参数核验未通过：{exc}。请在高级设置中确认原研究结果。'
        self.identity_info.setText(info)

    def _copy_previous(self):
        qa=self.previous_qa
        for key in ('parameter','research','data','batch'):
            src=getattr(qa,key,None)
            tgt=getattr(self,{'parameter':'parameters'}.get(key,key),None)
            if src is not None and tgt is not None and src.text().strip():
                if key == 'data':
                    tgt.setText(str(Path(src.text().strip()) / '04_连续变温验证记录'))
                else:
                    tgt.setText(src.text().strip())
        self._autofill_from_parameters()
        self.status.setText('已从01/02复制参数并自动识别配套信息；请核对PCB与温度计划。')

    def _browse(self,edit,kind):
        if kind=='dir':path=QFileDialog.getExistingDirectory(self.page,'选择目录',str(ROOT))
        else:
            pat='JSON (*.json)' if kind=='json' else 'R5斜坡记录 (*.csv)'
            path,_=QFileDialog.getOpenFileName(self.page,'选择输入文件',str(ROOT),pat)
        if path:
            edit.setText(path)
            if edit is self.parameters and not self.research.text().strip():
                related=Path(path).with_name('全量研究结果_不得直接烧录.json')
                if related.is_file():self.research.setText(str(related))
            if edit is self.parameters:self._autofill_from_parameters()

    def _validate_model(self):
        p=self.parameters.text().strip();r=self.research.text().strip()
        if not p or not r:raise ValidationError('请先选择冻结参数JSON及同批研究结果JSON')
        provenance=load_frozen(p,r)
        lo=float(self.low.value());hi=float(self.high.value())
        if hi<=lo:raise ValidationError('最高温度应高于最低温度')
        # User inputs are CHAMBER setpoints (SP), not actual chip T.
        # The stored fit temperature domain is informational only for QA04.
        # Do not reject the run because chip T lags PV or slightly exceeds fit data.
        return provenance

    def _busy(self):return self.live is not None or self.process is not None or self.previous_qa.process is not None

    def _set_busy(self, value):
        for item in (self.start,self.copy_previous,self.analyze,self.parameters,self.research,
                     self.data,self.batch,self.sn,self.low,self.high,self.tolerance,self.dwell,self.direction,self.cycles,self.rate,
                     self.approval,self.auto_plc,self.ramp_csv):
            item.setEnabled(not value)
        self.cancel.setEnabled(value and self.live is not None)

    def _append(self, msg):
        line=time.strftime('%Y-%m-%d %H:%M:%S')+' '+str(msg)
        self.log.appendPlainText(line)
        try:
            if self._control_log_path:
                with Path(self._control_log_path).open('a',encoding='utf-8') as fp:
                    fp.write(line+'\n')
        except OSError:
            pass

    def _read_chip(self):
        from tilt_sensor_asm330_data_get import tiltSensorRawData
        with tiltSensorRawData.data_lock:
            return float(tiltSensorRawData.temp_c),int(tiltSensorRawData.data_update_count)

    @staticmethod
    def _plc_state_text(snap):
        if snap is None:
            return '没有新鲜的PLC状态'
        fields=dict(snap)
        fields.setdefault('rate_enabled','未读取')
        fields.setdefault('rate_cpm',float('nan'))
        return ('PV={pv:.2f}℃，过程SP(VW2106)={sp:.2f}℃，定值速率开关={rate_enabled}，速率={rate_cpm:.1f}℃/min，'
                '定值模式={fixed_mode}，定值启动={fixed_started}，设备运行={running}，'
                '报警={alarm}，故障={fault}').format(**fields)

    def _read_plc_diagnostic(self):
        """Read-only live diagnostics; never sends any PLC command."""
        from temperature_chamber_data_get import tcComm
        import temperature_chamber_comm as chamber_driver
        from plc_comm import plc_vw_read
        from temperature_chamber_comm import (tc_pv_get,tc_sp_get,tc_fixed_value_rate_get,
            tc_fixed_value_rate_state_get,tc_run_mode_get,tc_fixed_value_state_get,
            tc_run_state_get)
        try:
            if not tcComm.is_connected:
                raise ValidationError('PLC通信未连接。请先在原设备连接区检查IP和连接状态。')
            with tcComm.thread_lock:
                pv=tc_pv_get();sp=tc_sp_get();rate=tc_fixed_value_rate_get()
                # Current driver writes target to VW2110 but reads accepted SP
                # from VW2106.  Compare the two without modifying either.
                raw_command=plc_vw_read(chamber_driver.client_instance,2110)
                rate_on=tc_fixed_value_rate_state_get()
                mode=tc_run_mode_get();started=tc_fixed_value_state_get()
                running=tc_run_state_get()
            from chamber_fixed_control import chamber_snapshot
            snap=chamber_snapshot()
            msg=(f'PLC只读诊断（没有写入任何指令）\n'
                 f'PV={pv}℃；SP回读(VW2106)={sp}℃；SP命令字(VW2110)='
                 f'{None if raw_command is None else raw_command/10.0}℃；'
                 f'设定速率回读={rate}℃/min；速率开关={rate_on}\n'
                 f'定值模式={mode is False if mode is not None else None}；'
                 f'定值启动={started}；设备运行={running}\n'
                 f'后台状态：{self._plc_state_text(snap)}')
            self._append(msg.replace('\n',' | '))
            QMessageBox.information(self.page,'04 PLC只读诊断',msg)
        except Exception as exc:
            self._append('PLC只读诊断异常：'+str(exc))
            QMessageBox.warning(self.page,'04 PLC只读诊断',str(exc))

    def _issue_plc_auto(self, target, rate=None, *, configure_rate=False,
                        allow_zero_rate_readback=False):
        """Write exactly one fixed target VW2110 per experiment endpoint.

        Preparation always uses the original R10 ordinary fixed-SP command with
        rate mode OFF.  Measured legs enable the configured controller rate
        *before* issuing the next final endpoint target.  The PLC may show a
        continuously changing internal VW2106; QA04 never writes intermediate
        targets from a host-side temperature sequence.
        """
        from chamber_fixed_control import (issue_preparation_setpoint,
            issue_rate_limited_setpoint, require_chamber_ready)
        before=require_chamber_ready(time.monotonic())
        self._append('PLC固定目标切换前：'+self._plc_state_text(before))
        self._plc_write_attempted=True
        if configure_rate:
            if rate is None:
                raise ValidationError('正式段缺少PLC设定速率，请检查04界面输入')
            if allow_zero_rate_readback:
                info=issue_rate_limited_setpoint(float(target),float(rate),
                    allow_zero_rate_readback=True)
            else:
                info=issue_rate_limited_setpoint(float(target),float(rate))
            if not info.get('rate_verified',True):
                self._append('【现场试验警告】VW2188速率读回0.0，'
                    '但速率开关已确认打开；本次只豁免速率数值回读，'
                    '实际温度变化速度无法保证为'+f'{float(rate):.1f}℃/min；'
                    '仍需VW2110目标、VW2106方向、PLC运行和PV响应确认。')
                detail=('正式段速率写入'+f'{float(rate):.1f}℃/min，'
                    '数值回读未确认（现场试验）；'+str(info)+'；')
            else:
                detail=(f'正式段速率设为{float(rate):.1f}℃/min并已回读确认：{info}；')
        else:
            info=issue_preparation_setpoint(float(target))
            detail=f'准备段速率开关已确认为关闭：{info}；'
        self._append(f'04固定SP命令已发送：目标VW2110={float(target):.1f}℃；'
                     +detail+
                     f'当前过程SP(VW2106)={float(before["sp"]):.2f}℃。'
                     '等待最终命令字及运行反馈，不要求过程SP立即等于目标。')
        return float(before['sp'])

    def _start_next_step_leg(self, run, now):
        leg=run['step_plan']['legs'][run['leg_index']]
        target=float(leg['target_c'])
        run['command_sp_before']=self._issue_plc_auto(target,run['rate'],
            configure_rate=True,
            allow_zero_rate_readback=run.get('zero_rate_trial',False))
        run['expected_rate_enabled']=True
        run['cmd_time']=time.monotonic()
        run['last_command_echo_at']=0.0
        run['last_command_echo']=None
        run['last_ack_reason']=None
        run['last_ack_log']=0.0
        run['expected_sp']=target
        run['stage']='UP_VERIFY' if leg['direction']=='warming' else 'DOWN_VERIFY'
        run['stage_started']=now
        run['end_since']=None
        self._append(f'04第{run["leg_index"]+1}/{len(run["step_plan"]["legs"])}段'
                     f'开始：直接下发固定目标SP={target:.1f}℃，不写入中间目标；'
                     f'PLC定值速率已开启，设定{run["rate"]:.1f}℃/min。')

    def _stop_chamber(self):
        """Best-effort PLC stop; report failure/unknown honestly."""
        from chamber_fixed_control import request_fixed_stop
        from debug import OFFLINE_DEBUG
        if OFFLINE_DEBUG:
            self._last_plc_stop_note='离线模式未触碰PLC'
            return False
        try:
            ok,fixed,running=request_fixed_stop()
            self._last_plc_stop_note=('PLC已确认定值停止' if ok and fixed is False and running is False
                else f'已请求PLC停机，但反馈尚未确认（命令={ok}，定值={fixed}，运行={running}）；必须现场检查')
            if ok and fixed is False and running is False:
                try:
                    from chamber_fixed_control import disable_fixed_rate_after_confirmed_stop
                    rate_cleanup=disable_fixed_rate_after_confirmed_stop()
                    self._last_plc_stop_note += '；定值速率开关已关闭：'+str(rate_cleanup)
                except Exception as cleanup_exc:
                    self._last_plc_stop_note += ('；PLC停止已确认，但速率开关清理未确认：'
                                                 +str(cleanup_exc)+'，请现场核对')
            self._append(self._last_plc_stop_note)
            return ok and fixed is False and running is False
        except Exception as exc:
            self._last_plc_stop_note=f'PLC停机请求/回读异常：{exc}；必须现场检查'
            self._append(self._last_plc_stop_note)
            return False

    def _begin_r5_recording(self,run):
        """Open the R5 file only after chamber PV reaches the selected start range."""
        self.thermal.sn.setText(run['sn'])
        self.thermal.production_batch_id.setText(run['batch'])
        self.thermal.output.setText(run['output'])
        self.thermal.ramp_approval.setChecked(True)
        self.thermal._start_r5_ramp()
        recorder=self.thermal._r5_ramp
        if recorder is None:
            raise ValidationError('R5采集器未确认启动；不能继续温箱升降温')
        # Mark the R5 recorder as owned by QA04 so failures surface once in
        # QA04, with the original exception instead of a generic placeholder.
        recorder['qa04_owned']=True
        run['csv']=recorder['path']
        run['last_count']=0
        self._append('R5真实记录开始：'+str(run['csv']))

    def _start(self):
        if self._busy():return
        self._autofill_from_parameters()
        try:
            prov=self._validate_model()
            if not self.approval.isChecked():
                raise ValidationError('请现场确认WK停车、硬件温箱保护、PLC接口现场联调和监护人员')
            sn=self.sn.text().strip();batch=self.batch.text().strip()
            if sn!=str(prov['result']['device_sn']):raise ValidationError('PCB SN与冻结参数来源不一致')
            if not batch or any(not(c.isalnum() or c in '_-.') for c in batch):
                raise ValidationError('批次ID仅可使用字母、数字、下划线、减号和小数点')
            if not self.data.text().strip():raise ValidationError('请选择04记录保存目录')
            output=Path(self.data.text().strip()).expanduser().resolve()
            output.mkdir(parents=True,exist_ok=True)
            if self.thermal.task is not None or self.thermal._r5_ramp is not None:
                raise ValidationError('原温补/R5任务尚未结束，不能并行运行')
            self.thermal._valid_device()
            if not self.thermal._stopped():raise ValidationError('WK双轴没有真实停车')
            from chamber_fixed_control import require_chamber_ready
            require_chamber_ready(time.monotonic())
            chip,imu_count=self._read_chip()
            if not math.isfinite(chip):raise ValidationError('IMU芯片温度无效')
            low=float(self.low.value());high=float(self.high.value())
            direction=self.direction.currentData()
            step_plan=build_step_plan(low,high,direction,int(self.cycles.value()))
            begin=step_plan['start_c']
            tolerance=float(self.tolerance.value())
            dwell=float(self.dwell.value())
            # Controller's configured SP ramp-rate is not guaranteed to equal
            # actual chamber PV slope.  Both are recorded as separate quantities.
            rate=float(self.rate.value())
            automatic=self.auto_plc.isChecked()
            zero_rate_control=getattr(self,'zero_rate_trial',None)
            zero_rate_trial=(bool(zero_rate_control.isChecked()) if zero_rate_control is not None else False) and automatic
            if not automatic and step_plan['mode']=='both_cooling':
                raise ValidationError('先降后升与多次循环需要04自动PLC模式；被动采集仅支持旧R5程序。')
            if not automatic and step_plan['cycles']>1:
                raise ValidationError('多次循环必须开启04自动PLC模式；被动采集不会自动控制温箱换向。')
            self.log.clear();self.last_report=None;self.open_report.setEnabled(False)
            self._plc_write_attempted=False
            self._last_plc_stop_note=''
            self._control_log_path=output / ('QA04_控制日志_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S')+'.txt')
            run={'csv':None,'started':time.monotonic(),'stage':'PREPARE_VERIFY' if automatic else 'PASSIVE',
                'expected_sp':begin,'cmd_time':time.monotonic(),'target_c':begin,
                'begin_c':begin,'direction':direction,'peak':chip,'valley':chip,
                'stage_started':time.monotonic(),'arrive_since':None,
                'last_count':0,'plan_low':low,'plan_high':high,'rate':rate,
                'expected_rate_enabled':False,
                'zero_rate_trial':zero_rate_trial,
                'step_plan':step_plan,'leg_index':0,'tolerance':tolerance,'dwell':dwell,
                'leg_timing':[],
                'max_seconds':max(14400.,(len(step_plan['legs'])+1)*14400.),
                'sn':sn,'batch':batch,'output':str(output),'auto_plc':automatic,
                'model_lo':max(float(prov['params'][k]['temperature_domain_c'][0]) for k in ('acc','gyro')),
                'model_hi':min(float(prov['params'][k]['temperature_domain_c'][1]) for k in ('acc','gyro')),
                # Model range is report metadata, NEVER a chamber-stop condition.
                'model_outside_observations':0,'model_outside_noted':False,
                'observed_chip_min_c':chip,'observed_chip_max_c':chip,
                'imu_count':imu_count,'last_imu_change':time.monotonic(),
                'end_since':None,'last_ack_reason':None,'last_ack_log':0.0}
            if automatic:
                # Initial temperature does NOT need to match the selected start point.
                # Do not open the QA recorder until chamber PV reaches the start.
                run['command_sp_before']=self._issue_plc_auto(begin,rate,configure_rate=False)
                run['cmd_time']=time.monotonic()  # command was already issued
                run['last_command_echo_at']=0.0
                run['last_command_echo']=None
                self._append(f'当前芯片{chip:.2f}℃，固定目标SP设为{begin:.1f}℃；'
                             f'待温箱PV进入±{tolerance:.1f}℃才开始第1段采样；'
                             f'完整计划：{describe_step_plan(step_plan)}')
            else:
                # Existing factory-program passive mode remains available when
                # PLC ramp-rate control has not been commissioned.
                self._begin_r5_recording(run)
                run['stage']='UP' if direction in ('warming','both') else 'DOWN'
                run['stage_started']=time.monotonic()
                self._append('被动模式：厂家程序负责温箱；软件仅记录和分析，循环换向需厂家程序执行')
            self.live=run
            self._set_busy(True)
            self.timer.start()
        except Exception as exc:
            # In an automatic start failure before live allocation, send a stop
            # only if automatic control was actually issued.
            if 'run' in locals() and run.get('auto_plc') and self._plc_write_attempted:
                self._stop_chamber()
            QMessageBox.warning(self.page,'04无法启动',str(exc))

    def _monitor(self):
        run=self.live
        if run is None:return
        now=time.monotonic()
        if now-run['started']>run['max_seconds']:
            self._fail('自动监控总时长超时：温箱未在安全限定时间内完成计划')
            return
        if (run.get('auto_plc') and run.get('stage') in ('PREPARE_WAIT','UP','DOWN')
                and now-run.get('stage_started',now)>14400):
            self._fail('单段到温超过4小时；请检查温箱实际PV和制冷/加热状态')
            return
        try:
            self.thermal._valid_device()
            if not self.thermal._stopped():raise ValidationError('WK停止状态失效')
            from chamber_fixed_control import require_chamber_ready
            snap=require_chamber_ready(now)
            temp,imu_count=self._read_chip()
            if not math.isfinite(temp):raise ValidationError('芯片温度数据无效')
            if imu_count!=run['imu_count']:
                run['imu_count']=imu_count
                run['last_imu_change']=now
            elif now-run['last_imu_change']>12:
                raise ValidationError('12秒无新IMU帧，自动中止')
            # QA04 is a MEASUREMENT experiment, not a model-domain interlock.
            # Chip temperature may lag PV or briefly exceed the fit endpoints.
            # Record one warning and let the operator's PV/cycle plan proceed.
            run['observed_chip_min_c']=min(run.get('observed_chip_min_c',temp),temp)
            run['observed_chip_max_c']=max(run.get('observed_chip_max_c',temp),temp)
            if not (run['model_lo'] <= temp <= run['model_hi']):
                run['model_outside_observations']=run.get('model_outside_observations',0)+1
                if not run.get('model_outside_noted',False):
                    self._append(f'04仅提示，不中止：芯片{temp:.2f}℃超出冻结拟合温区'
                        f'[{run["model_lo"]:.2f},{run["model_hi"]:.2f}]℃；'
                        '继续按温箱PV切换目标并完整采集，报告标记模型外推样本。')
                    run['model_outside_noted']=True
            low,high=run['plan_low'],run['plan_high']
            if run['auto_plc']:
                if run['stage'] in ('PREPARE_VERIFY','UP_VERIFY','DOWN_VERIFY'):
                    from chamber_auto_guard import require_step_setpoint_ack,ChamberSafetyError
                    try:
                        command_time=float(run.get('cmd_time',0.0))
                        if command_time>0:
                            for field,name in (('sp_updated','过程SP'),
                                    ('mode_updated','定值模式'),('started_updated','定值启动'),
                                    ('run_updated','运行状态')):
                                if float(snap.get(field,0.0))<=command_time:
                                    raise ChamberSafetyError(name+'尚无设温后的新鲜反馈')
                        if (run.get('last_command_echo_at',0.0)<=command_time or
                                now-run.get('last_command_echo_at',0.0)>=3.0 or
                                run.get('last_command_echo') is None):
                            from chamber_fixed_control import read_fixed_target_command
                            run['last_command_echo']=read_fixed_target_command()
                            run['last_command_echo_at']=time.monotonic()
                        preparing=(run['stage']=='PREPARE_VERIFY')
                        detail_ack=require_step_setpoint_ack(
                            snap,run['expected_sp'],run.get('last_command_echo'),
                            expected_rate_enabled=run.get('expected_rate_enabled',False),
                            expected_rate_cpm=(run.get('rate') if run.get('expected_rate_enabled') else None),
                            require_direct_sp_target=preparing,
                            allow_zero_rate_readback=(run.get('zero_rate_trial',False) and not preparing))
                        if not preparing:
                            # Rate mode ON: the process SP does not have to
                            # equal the final target immediately, but it MUST
                            # move in the commanded direction.  Previously
                            # the mere VW2110 echo could wrongly pass here.
                            from chamber_auto_guard import require_ramped_setpoint_ack
                            progress= require_ramped_setpoint_ack(
                                snap,run['expected_sp'],run.get('command_sp_before'),
                                run.get('last_command_echo'))
                            detail_ack += '；' + progress
                    except ChamberSafetyError as ack_exc:
                        reason=str(ack_exc)
                        detail=(f'目标SP={run["expected_sp"]:.1f}℃；'
                            +self._plc_state_text(snap)+'；未通过：'+reason)
                        if (reason!=run.get('last_ack_reason') or
                                now-run.get('last_ack_log',0.0)>10):
                            self._append('PLC固定目标命令确认中：'+detail)
                            run['last_ack_reason']=reason
                            run['last_ack_log']=now
                        if now-run['cmd_time']>90:
                            raise ValidationError('PLC在90秒内未确认固定目标命令、速率关闭或运行反馈：'
                                +detail+'；已中止，请勿反复重试')
                        self.status.setText('04等待PLC确认：'+detail)
                        return
                    if run['stage']=='PREPARE_VERIFY':
                        run['stage']='PREPARE_WAIT'
                    else:
                        run['stage']='UP' if run['stage']=='UP_VERIFY' else 'DOWN'
                    run['stage_started']=now
                    run['end_since']=None
                    # A command echo and accepted SP are NOT proof that the
                    # refrigeration/heating equipment has affected the PV.
                    # Watch real PV progress independently in each stage.
                    run['pv_watch_baseline']=float(snap['pv'])
                    run['pv_watch_started']=now
                    run['pv_watch_last_log']=now
                    self._append('PLC固定目标确认通过：'+run['stage']+'；'+detail_ack+'；'
                                 +self._plc_state_text(snap))
                if (run['stage'] in ('PREPARE_WAIT','UP','DOWN') and
                        ('expected_sp' in run or 'begin_c' in run)):
                    # Fail closed when PV has not moved in the expected
                    # direction for 15 minutes while still far from target.
                    # The check is a rolling window, so later stalls are also
                    # detected instead of waiting for the 4-hour hard limit.
                    destination=(run['begin_c'] if run['stage']=='PREPARE_WAIT' else
                        run['expected_sp'])
                    from chamber_auto_guard import require_pv_progress
                    elapsed=now-run.get('pv_watch_started',now)
                    baseline=float(run.get('pv_watch_baseline',snap['pv']))
                    require_pv_progress(baseline,float(snap['pv']),float(destination),
                        float(run['tolerance']),elapsed)
                    direction=1. if float(destination)>baseline else -1.
                    progress=direction*(float(snap['pv'])-baseline)
                    if progress>=0.3 or abs(float(snap['pv'])-float(destination))<=float(run['tolerance']):
                        run['pv_watch_baseline']=float(snap['pv'])
                        run['pv_watch_started']=now
                    if now-run.get('pv_watch_last_log',now)>=60.:
                        self._append('温箱控温响应监测：目标PV='+f'{destination:.1f}℃；'+
                            self._plc_state_text(snap)+
                            f'；当前观察窗口PV变化={progress:+.2f}℃')
                        run['pv_watch_last_log']=now
                if run['stage']=='PREPARE_WAIT':
                    near=abs(float(snap['pv'])-run['begin_c'])<=run['tolerance']
                    run['arrive_since']=(now if run['arrive_since'] is None else run['arrive_since']) if near else None
                    self.status.setText(f'04自动到起点：温箱PV {snap["pv"]:.2f}℃，'
                                        f'目标{run["begin_c"]:.1f}℃±{run["tolerance"]:.1f}℃。'
                                        '保持固定目标，等待到温。')
                    if run['arrive_since'] is None or now-run['arrive_since']<run['dwell']:
                        return
                    # PV reaching the endpoint is the only temperature condition
                    # for starting a leg.  Silicon T is measured, not an interlock.
                    self._begin_r5_recording(run)
                    self._start_next_step_leg(run,now)
                    self._append(f'起点PV已到达{run["begin_c"]:.1f}℃±{run["tolerance"]:.1f}℃，'
                                 '开始固定目标SP切换测试')
                    return
            else:
                if run['stage']=='PASSIVE':
                    return
            recorder=self.thermal._r5_ramp
            if recorder is None:
                original=getattr(self.thermal,'_r5_ramp_last_error',None)
                stop_reason=getattr(self.thermal,'_r5_ramp_last_stop_reason',None)
                detail=original or stop_reason or '记录器被意外关闭（没有保存原始错误）'
                raise ValidationError('R5采集器已停止，原始原因：'+str(detail))
            count=recorder['count']
            if count<=run['last_count']:
                return
            run['last_count']=count
            run['peak']=max(run['peak'],temp)
            run['valley']=min(run['valley'],temp)
            self.status.setText(f'04自动采集中：{count}帧，芯片{temp:.2f}℃，温箱PV {snap["pv"]:.2f}℃，阶段{run["stage"]}')
            # Endpoint switching depends on real chamber PV within the
            # operator's ± tolerance.  Do NOT require process SP VW2106 ==
            # target; PLC internal process SP can change without QA04 writing
            # intermediate targets.  VW2110 is checked during each VERIFY.
            if run['auto_plc'] and run['stage'] in ('UP','DOWN'):
                destination=run['step_plan']['legs'][run['leg_index']]['target_c']
                near=abs(float(snap['pv'])-destination)<=run['tolerance']
                run['end_since']=(now if run['end_since'] is None else run['end_since']) if near else None
                self.status.setText(f'04固定SP循环：第{run["leg_index"]+1}/'
                    f'{len(run["step_plan"]["legs"])}段，'
                    f'目标{destination:.1f}℃，PV={snap["pv"]:.2f}℃，'
                    f'芯片{temp:.2f}℃，有效帧{count}。')
                if run['end_since'] is None or now-run['end_since']<run['dwell']:
                    return
                run['leg_timing'].append({'leg_index':run['leg_index']+1,
                    'target_c':destination,'reached_pv_c':float(snap['pv']),
                    'chip_c':float(temp),'completed_at':dt.datetime.now().isoformat()})
                self._append(f'第{run["leg_index"]+1}段PV到温：'
                    f'{float(snap["pv"]):.2f}℃在{destination:.1f}±{run["tolerance"]:.1f}℃范围内')
                run['leg_index']+=1
                if run['leg_index']>=len(run['step_plan']['legs']):
                    self._complete();return
                self._start_next_step_leg(run,now)
                return
            elif not run['auto_plc']:
                if run['stage']=='UP' and temp>=high-0.5:
                    if run['direction']=='warming':self._complete();return
                    if run['direction']=='both':
                        run['stage']='WAIT_PASSIVE_DOWN';run['peak']=temp
                elif run['stage']=='WAIT_PASSIVE_DOWN' and temp<=run['peak']-0.7:
                    run['stage']='DOWN'
                    self._append('观察到厂家程序转为降温，继续记录')
                elif run['stage']=='DOWN' and temp<=low+0.5:
                    self._complete();return
        except Exception as exc:
            self._fail(str(exc))

    def _save_step_manifest(self, run, status, reason=None):
        if not run.get('auto_plc'):
            return
        try:
            result={'protocol':'QA04_FIXED_SETPOINT_STEP_V1',
                'state':status,'failure':reason,'parameters':str(self.parameters.text().strip()),
                'batch':run['batch'],'pcb_sn':run['sn'],
                'start_c':run['step_plan']['start_c'],
                'legs':run['step_plan']['legs'],
                'completed_legs':run['leg_timing'],
                'pv_tolerance_c':run['tolerance'],'dwell_seconds':run['dwell'],
                'plc_set_rate_c_per_min':run.get('rate'),
                'allow_zero_rate_readback_field_trial':run.get('zero_rate_trial',False),
                'rate_readback_validation_policy':('zero_echo_trial_opt_in' if run.get('zero_rate_trial',False) else 'strict'),
                'rate_during_preparation':False,'rate_during_measured_legs':True,
                'csv':run.get('csv'),
                'observed_chip_temperature_c':[run.get('observed_chip_min_c'),run.get('observed_chip_max_c')],
                'frozen_fit_chip_temperature_c':[run.get('model_lo'),run.get('model_hi')],
                'model_outside_observations':run.get('model_outside_observations',0),
                'note':'仅在起点/换向时写端点目标SP；准备段速率模式关闭、正式段尝试启用PLC速率模式；实际PV速率不保证等于PLC设定值。若现场试验开关开启且速率回读0.0，速度数值未验证，禁止把实验设定值视为实测速率。模型温区仅作报告标记，不中止04实验。'}
            path=Path(run['output'])/(run['batch']+'_04_固定SP循环计划.json')
            path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
            self._append('04实验计划与各段端点记录已保存：'+str(path))
        except Exception as exc:
            self._append('04计划记录保存失败：'+str(exc))

    def _complete(self):
        run=self.live
        self.timer.stop()
        self.thermal._stop_r5_ramp('04全部固定SP目标段已完成，结束静态温漂记录')
        stop_note='被动模式不控制温箱，必须现场按厂家程序结束'
        if run['auto_plc']:
            self._stop_chamber()
            stop_note=self._last_plc_stop_note
        self.live=None
        self.cancel.setEnabled(False)
        self.ramp_csv.setText(run['csv'])
        self._append('目标温区循环结束，正在执行冻结参数离线分析。'+stop_note)
        self._save_step_manifest(run,'completed')
        self.status.setText('04采集结束：'+stop_note+'；正在生成报告。')
        self._launch_analyzer(run['csv'],run['step_plan']['analysis_direction'],run['plan_low'],run['plan_high'],None)

    def _fail(self,reason):
        run=self.live
        self.timer.stop()
        if self.thermal._r5_ramp is not None:
            self.thermal._stop_r5_ramp('04异常中止：'+str(reason))
        stop_note='被动模式未发送温箱控制指令，请现场检查厂家程序'
        if run is not None and run.get('auto_plc'):
            self._stop_chamber()
            stop_note=self._last_plc_stop_note
        self.live=None
        self._set_busy(False)
        self.status.setText('04实验中止：'+str(reason)+'；'+stop_note)
        self._append(self.status.text())
        if run is not None:self._save_step_manifest(run,'aborted',str(reason))
        QMessageBox.critical(self.page,'04实验中止',self.status.text())

    def _cancel(self):
        if self.live is not None:self._fail('操作员主动终止实验')

    def _offline(self):
        if self._busy():return
        self._autofill_from_parameters()
        try:
            self._validate_model()
            csv=Path(self.ramp_csv.text().strip())
            if not csv.is_file():raise ValidationError('请先选择真实R5_RAMP CSV')
        except Exception as exc:
            QMessageBox.warning(self.page,'04离线验收未启动',str(exc));return
        self.log.clear()
        self._launch_analyzer(str(csv),('both' if self.direction.currentData()=='both_cooling' else self.direction.currentData()),float(self.low.value()),
                              float(self.high.value()),None)

    def _launch_analyzer(self,csv,direction,low,high,rate):
        if self.process is not None:return
        # User temperature bounds represent chamber SP/PV, not the actual
        # silicon-chip temperature. Never pass them as chip-coverage gates.
        args=[str(ROOT/'post_thermal_ramp_qa.py'), '--ramp',str(csv),
              '--parameters',self.parameters.text().strip(),
              '--research-result',self.research.text().strip(),
              '--direction',direction,'--sp-low',str(low),'--sp-high',str(high),
              '--min-coverage',str(min(10.0,max(0.5,0.35*(high-low))))]
        out=self.data.text().strip()
        if out:args.extend(['--output-root',out])
        process=QProcess(self.page)
        env=QProcessEnvironment.systemEnvironment()
        env.insert('PYTHONIOENCODING','utf-8')
        process.setProcessEnvironment(env)
        process.setProgram(sys.executable)
        process.setArguments(args)
        process.setWorkingDirectory(str(ROOT))
        self._stdout=bytearray();self._stderr=bytearray()
        self.process=process
        process.readyReadStandardOutput.connect(lambda:self._stdout.extend(bytes(process.readAllStandardOutput())))
        process.readyReadStandardError.connect(lambda:self._stderr.extend(bytes(process.readAllStandardError())))
        process.finished.connect(self._finished)
        self._set_busy(True)
        process.start()

    def _finished(self,exit_code,exit_status):
        process=self.process
        self._stdout.extend(bytes(process.readAllStandardOutput()))
        self._stderr.extend(bytes(process.readAllStandardError()))
        txt=self._stdout.decode('utf-8',errors='replace')+'\n'+self._stderr.decode('utf-8',errors='replace')
        self._append(txt.strip())
        paths=[s.split('=',1)[1].strip() for s in txt.splitlines() if s.startswith('RESULT_PATH=')]
        self.process=None
        self._set_busy(False)
        if exit_code==0 and paths and Path(paths[-1]).is_file():
            self.last_report=Path(paths[-1]);self.open_report.setEnabled(True)
            self.status.setText('04分析完成：报告和补偿CSV已生成；'+self._last_plc_stop_note+'。静止漂移不是绝对倾角精度。')
        else:
            self.status.setText(f'04分析未获准评级（退出码{exit_code}），请查看日志和真实采集条件。')

    def _open(self):
        if self.last_report and self.last_report.is_file():
            webbrowser.open(self.last_report.resolve().as_uri())

    def shutdown(self):
        self.timer.stop()
        if self.live is not None:
            if self.thermal._r5_ramp is not None:self.thermal._stop_r5_ramp('04页面关闭，结束采集')
            if self.live.get('auto_plc'):self._stop_chamber()
            self.live=None
