# -*- coding: utf-8 -*-
"""Shared PLC control functions for R10 thermal calibration and QA04.

Only orchestrates the already-existing temperature_chamber_comm driver.
Does NOT create a Snap7 client, guess a new PLC register, or execute
undocumented controller commands.  Caller must check live telemetry before
writing and wait for *fresh* feedback after writing.
"""

from debug import OFFLINE_DEBUG
from temperature_chamber_data_get import tcComm
from temperature_chamber_comm import (
    tc_set_fixed_value_mode, tc_sp_set, tc_fixed_value_startup,
    tc_fixed_value_stop, tc_fixed_value_state_get, tc_run_state_get,
    tc_fixed_value_rate_set, tc_fixed_value_rate_on, tc_fixed_value_rate_off,
    tc_fixed_value_rate_get, tc_fixed_value_rate_state_get,
)


class PLCCommandError(RuntimeError):
    pass


def issue_fixed_setpoint(target):
    """Exact field-proven R10 order: fixed mode -> SP -> fixed run.

    This is deliberately the same register access sequence that the original
    R10 thermal experiment used before QA04 existed.
    """
    if OFFLINE_DEBUG:
        raise PLCCommandError('离线模式禁止控制真实温箱PLC')
    if not tcComm.is_connected:
        raise PLCCommandError('PLC未连接，拒绝写入温箱目标温度')
    with tcComm.thread_lock:
        ok_mode = tc_set_fixed_value_mode()
        ok_sp = tc_sp_set(float(target)) if ok_mode else False
        ok_start = tc_fixed_value_startup() if ok_sp else False
    if not (ok_mode and ok_sp and ok_start):
        raise PLCCommandError('PLC定值模式/设温/启动写入失败（不能继续实验）')
    return True


def issue_preparation_setpoint(target):
    """QA04 initial approach to the start temperature: use *ordinary fixed SP*.

    A prior QA04 ramp may leave PLC's fixed-value-rate switch enabled.
    Merely omitting a new rate-on command does not reset that retained PLC bit.
    Explicitly read/disable it, verify the state OFF, then issue the original
    R10 mode -> SP -> fixed-run sequence under the same shared PLC lock.
    Unlike a ramp leg this is deliberate normal fixed-SP approach; physical
    chamber PV still requires time to respond and must be monitored separately.
    This function is QA04-specific: original R10 workflow is unchanged.
    """
    if OFFLINE_DEBUG:
        raise PLCCommandError('离线模式禁止控制真实温箱PLC')
    if not tcComm.is_connected:
        raise PLCCommandError('PLC未连接，拒绝准备04起点温度')
    with tcComm.thread_lock:
        rate_before = tc_fixed_value_rate_state_get()
        if rate_before is None:
            raise PLCCommandError('无法读取PLC定值速率开关，拒绝发送起点设温命令')
        if rate_before is True:
            if not tc_fixed_value_rate_off():
                raise PLCCommandError('PLC定值速率开关关闭失败，拒绝执行04起点设温')
        rate_after = tc_fixed_value_rate_state_get()
        if rate_after is not False:
            raise PLCCommandError('PLC定值速率关闭后回读未确认，拒绝执行04起点设温')
        ok_mode = tc_set_fixed_value_mode()
        ok_sp = tc_sp_set(float(target)) if ok_mode else False
        ok_start = tc_fixed_value_startup() if ok_sp else False
    if not (ok_mode and ok_sp and ok_start):
        raise PLCCommandError('04起点定值模式/设温/启动写入失败（不能继续实验）')
    return {'rate_before': bool(rate_before), 'rate_after': False, 'target':float(target)}


def disable_fixed_rate_after_confirmed_stop():
    """Remove QA04 rate mode only once fixed-value RUN has stopped.

    Prevent the next legacy steady-temperature experiment from inheriting a
    rate-enabled controller. Never switch modes while a stop is unconfirmed.
    """
    if OFFLINE_DEBUG or not tcComm.is_connected:
        raise PLCCommandError('PLC未连接或离线，无法复位04速率开关')
    with tcComm.thread_lock:
        started = tc_fixed_value_state_get()
        running = tc_run_state_get()
        if started is not False or running is not False:
            raise PLCCommandError('PLC停止状态未确认，拒绝改变速率开关')
        before = tc_fixed_value_rate_state_get()
        if before is None:
            raise PLCCommandError('PLC速率开关读取失败')
        if before is True and not tc_fixed_value_rate_off():
            raise PLCCommandError('PLC停止后清除速率状态失败')
        after = tc_fixed_value_rate_state_get()
        if after is not False:
            raise PLCCommandError('PLC停止后速率开关关闭未确认')
    return {'rate_before': bool(before), 'rate_after':False}


def configure_fixed_rate(rate):
    """QA04-specific, uncommissioned field feature. Never use for pre-cooling.

    Rate configuration is deliberately separate from issue_fixed_setpoint:
    normal R10 setpoint transitions never automatically enable this mode.
    """
    if OFFLINE_DEBUG:
        raise PLCCommandError('离线模式禁止控制真实温箱PLC')
    if not tcComm.is_connected:
        raise PLCCommandError('PLC未连接，拒绝写入温度变化速率')
    rate = float(rate)
    if not (0.1 <= rate <= 2.0):
        raise PLCCommandError('斜坡速率不在已规划范围0.1～2.0℃/min')
    with tcComm.thread_lock:
        ok_rate = bool(tc_fixed_value_rate_set(rate))
        ok_switch = bool(tc_fixed_value_rate_on()) if ok_rate else False
        read_rate = tc_fixed_value_rate_get() if ok_switch else None
        read_switch = tc_fixed_value_rate_state_get() if ok_switch else None
    info = dict(ok_rate=ok_rate, ok_switch=ok_switch,
                read_rate=read_rate, read_switch=read_switch)
    if not (ok_rate and ok_switch and read_switch is True and
            read_rate is not None and abs(float(read_rate)-rate) <= 0.051):
        raise PLCCommandError('PLC定值速率写入/回读未确认，拒绝执行自动斜坡；详情='+str(info))
    return info



def issue_rate_limited_setpoint(target, rate, *, allow_zero_rate_readback=False):
    """QA04 measured leg: set controller rate then write ONE final endpoint SP.

    Uses the same background-thread lock and existing driver/registers.  The
    normal R10 `issue_fixed_setpoint()` and QA04 preparation remain unchanged.
    Rate set/readback is required before commanding the next endpoint by default.
    A deliberately opt-in field diagnostic allows ONLY a zero numeric rate echo
    with rate-mode ON; this does not prove actual ramp speed and all other PLC
    command, alarm, status, and physical PV checks remain active.
    """
    import math
    if OFFLINE_DEBUG:
        raise PLCCommandError('离线模式禁止控制真实温箱PLC')
    if not tcComm.is_connected:
        raise PLCCommandError('PLC未连接，拒绝发送04正式段目标')
    rate=float(rate)
    if not math.isfinite(rate) or not (0.1 <= rate <= 99.9):
        raise PLCCommandError('PLC设定速率须在0.1～99.9℃/min范围内')
    with tcComm.thread_lock:
        ok_mode=bool(tc_set_fixed_value_mode())
        ok_rate=bool(tc_fixed_value_rate_set(rate)) if ok_mode else False
        ok_on=bool(tc_fixed_value_rate_on()) if ok_rate else False
        read_rate=tc_fixed_value_rate_get() if ok_on else None
        read_on=tc_fixed_value_rate_state_get() if ok_on else None
        numeric_rate_ok = (read_rate is not None and
            math.isfinite(float(read_rate)) and abs(float(read_rate)-rate)<=0.051)
        zero_echo_trial = (bool(allow_zero_rate_readback) and
            read_rate is not None and math.isfinite(float(read_rate)) and
            abs(float(read_rate))<=0.001 and not numeric_rate_ok)
        if not (ok_mode and ok_rate and ok_on and read_on is True and
                (numeric_rate_ok or zero_echo_trial)):
            raise PLCCommandError('04正式段PLC设定速率/开关回读未确认：'+str({
                'mode':ok_mode,'rate_write':ok_rate,'switch_write':ok_on,
                'rate_readback':read_rate,'switch_readback':read_on,
                'allow_zero_rate_readback':bool(allow_zero_rate_readback)}))
        ok_sp=bool(tc_sp_set(float(target)))
        ok_start=bool(tc_fixed_value_startup()) if ok_sp else False
    if not (ok_sp and ok_start):
        raise PLCCommandError('04正式段目标SP/定值启动失败')
    return {'target':float(target),'rate_c_per_min':rate,
            'rate_readback':float(read_rate),'rate_enabled':True,
            'rate_verified':bool(numeric_rate_ok),
            'zero_rate_echo_trial':bool(zero_echo_trial)}


def read_fixed_target_command():
    """QA04: independent, read-only echo of the requested target (VW2110).

    VW2106 (tc_sp_get) is the *currently ramping process SP* on this PLC.
    The two must never be treated as interchangeable when rate mode is on.
    Reuses the existing Snap7 connection and the polling-thread mutex.
    No register addresses, driver writes, or PLC connections are changed.
    """
    if OFFLINE_DEBUG or not tcComm.is_connected:
        return None
    import temperature_chamber_comm as driver
    from plc_comm import plc_vw_read
    with tcComm.thread_lock:
        raw = plc_vw_read(driver.client_instance, 2110)
    return None if raw is None else float(raw) / 10.0


def request_fixed_stop():
    """Best-effort fixed-mode stop, with an actual readback check."""
    if OFFLINE_DEBUG or not tcComm.is_connected:
        return False, None, None
    with tcComm.thread_lock:
        ok = bool(tc_fixed_value_stop())
        fixed = tc_fixed_value_state_get() if ok else None
        running = tc_run_state_get() if ok else None
    return ok, fixed, running


def chamber_snapshot():
    """A SINGLE controller-independent cached PLC snapshot for all experiments.

    Values are refreshed by the EXISTING temperature_chamber_data_get thread.
    Do not create a new Snap7 connection or a competing polling thread.
    """
    from temperature_chamber_data_get import tcData, tcState, tcComm
    return {
        'connected':tcComm.is_connected,
        'data_available':tcData.is_tc_data_available,
        'pv_failed':tcComm.is_pv_get_failed,
        'pv':float(tcData.pv), 'sp':float(tcData.sp),
        'pv_updated':tcData.pv_update_monotonic,
        'sp_updated':tcData.sp_update_monotonic,
        'rate_enabled':tcData.is_fixed_value_rate_on,
        'rate_cpm':float(tcData.temperature_rate),
        'alarm':tcState.alarm_value,
        'fault':tcState.is_device_fault,
        'alarm_updated':tcState.alarm_update_monotonic,
        'fault_updated':tcState.fault_update_monotonic,
        'running':tcState.is_device_running,
        'fixed_started':tcState.is_fixed_value_startup,
        'fixed_mode':tcState.is_fixed_value_mode,
        'run_updated':tcState.run_update_monotonic,
        'started_updated':tcState.fixed_start_update_monotonic,
        'mode_updated':tcState.mode_update_monotonic,
    }


def require_chamber_ready(now=None):
    """Common freshness/alarm interlock for both the established R10 and QA04."""
    import time
    from chamber_auto_guard import require_live_chamber
    snap=chamber_snapshot()
    require_live_chamber(snap,time.monotonic() if now is None else now)
    return snap
