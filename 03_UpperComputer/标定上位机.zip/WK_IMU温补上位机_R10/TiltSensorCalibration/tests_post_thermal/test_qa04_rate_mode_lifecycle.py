# -*- coding: utf-8 -*-
"""QA04 cached PLC rate bit must not leak between preparation and ramp legs."""
import importlib.util
from pathlib import Path
import sys
import threading
import types
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]

class TestRateLifecycle(unittest.TestCase):
    def _load(self, *, initially_on=True, allow_off=True, reported_off=True):
        events=[]
        state={'on':initially_on, 'started':False, 'running':False}
        driver=types.ModuleType('temperature_chamber_comm')
        driver.tc_set_fixed_value_mode=lambda: events.append('MODE') or True
        driver.tc_sp_set=lambda temp: events.append(('SP',temp)) or True
        driver.tc_fixed_value_startup=lambda: events.append('START') or True
        driver.tc_fixed_value_stop=lambda: events.append('STOP') or True
        driver.tc_fixed_value_state_get=lambda: state['started']
        driver.tc_run_state_get=lambda: state['running']
        driver.tc_fixed_value_rate_set=lambda v: events.append(('RATE',v)) or True
        driver.tc_fixed_value_rate_on=lambda: events.append('RATE_ON') or True
        driver.tc_fixed_value_rate_get=lambda:0.5
        def rate_read():
            events.append('RATE_READ');return state['on']
        def rate_off():
            events.append('RATE_OFF')
            if not allow_off:return False
            if reported_off:state['on']=False
            return True
        driver.tc_fixed_value_rate_state_get=rate_read
        driver.tc_fixed_value_rate_off=rate_off
        data=types.ModuleType('temperature_chamber_data_get')
        data.tcComm=types.SimpleNamespace(is_connected=True,thread_lock=threading.Lock())
        debug=types.ModuleType('debug');debug.OFFLINE_DEBUG=False
        with patch.dict(sys.modules,{'temperature_chamber_comm':driver,
                   'temperature_chamber_data_get':data,'debug':debug}):
            spec=importlib.util.spec_from_file_location('qa04_rate_lifecycle_case',ROOT/'chamber_fixed_control.py')
            mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        return mod,events,state

    def test_prior_rate_on_is_switched_off_before_preparation_setpoint(self):
        mod,events,_=self._load(initially_on=True)
        result=mod.issue_preparation_setpoint(-15)
        self.assertEqual(result['rate_before'],True)
        self.assertEqual(events,['RATE_READ','RATE_OFF','RATE_READ','MODE',('SP',-15.),'START'])

    def test_rate_already_off_no_unnecessary_write(self):
        mod,events,_=self._load(initially_on=False)
        result=mod.issue_preparation_setpoint(-15)
        self.assertFalse(result['rate_before'])
        self.assertEqual(events,['RATE_READ','RATE_READ','MODE',('SP',-15.),'START'])

    def test_off_failure_never_changes_target_sp(self):
        mod,events,_=self._load(allow_off=False)
        with self.assertRaisesRegex(mod.PLCCommandError,'关闭失败'):
            mod.issue_preparation_setpoint(-15)
        self.assertEqual(events,['RATE_READ','RATE_OFF'])

    def test_off_unconfirmed_never_changes_target_sp(self):
        mod,events,_=self._load(reported_off=False)
        with self.assertRaisesRegex(mod.PLCCommandError,'回读未确认'):
            mod.issue_preparation_setpoint(-15)
        self.assertEqual(events,['RATE_READ','RATE_OFF','RATE_READ'])

    def test_cleanup_cannot_change_running_controller(self):
        mod,events,state=self._load()
        state.update(started=True,running=True)
        with self.assertRaisesRegex(mod.PLCCommandError,'停止状态未确认'):
            mod.disable_fixed_rate_after_confirmed_stop()
        self.assertNotIn('RATE_OFF',events)

    def test_cleanup_after_stop_disables_leftover_rate(self):
        mod,events,_=self._load()
        out=mod.disable_fixed_rate_after_confirmed_stop()
        self.assertTrue(out['rate_before']);self.assertFalse(out['rate_after'])
        self.assertEqual(events,['RATE_READ','RATE_OFF','RATE_READ'])

if __name__=='__main__':unittest.main()
