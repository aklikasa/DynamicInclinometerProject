# -*- coding: utf-8 -*-
"""PV-control response watchdog; simulation only, never talks to hardware."""
import pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from chamber_auto_guard import require_pv_progress,ChamberSafetyError

class PVResponseTests(unittest.TestCase):
    def test_far_target_without_response_after_15_minutes_is_not_accepted(self):
        with self.assertRaisesRegex(ChamberSafetyError,'未朝目标有效变化'):
            require_pv_progress(21.5,21.5,-15.,2.,901.)
    def test_response_before_timeout_does_not_fail(self):
        self.assertTrue(require_pv_progress(21.5,21.5,-15.,2.,890.))
    def test_correct_direction_progress_succeeds(self):
        self.assertTrue(require_pv_progress(21.5,21.1,-15.,2.,901.))
    def test_wrong_direction_does_not_count(self):
        with self.assertRaises(ChamberSafetyError):
            require_pv_progress(21.5,22.0,-15.,2.,901.)
    def test_near_endpoint_allows_soak_even_if_slow(self):
        self.assertTrue(require_pv_progress(-14.9,-14.9,-15.,2.,5000.))

if __name__=='__main__':unittest.main()
