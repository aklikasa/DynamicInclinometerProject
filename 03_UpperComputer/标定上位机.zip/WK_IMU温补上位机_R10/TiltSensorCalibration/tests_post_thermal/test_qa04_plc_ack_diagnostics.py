# -*- coding: utf-8 -*-
"""Hardware-free regression for the new PLC observability and ACK cause."""
import ast
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'temperature_chamber'))
from chamber_auto_guard import require_setpoint_ack, ChamberSafetyError

SRC=(ROOT/'form/form_post_thermal_ramp.py').read_text('utf-8')
TREE=ast.parse(SRC)
CLS=next(x for x in TREE.body if isinstance(x,ast.ClassDef) and x.name=='FormPostThermalRamp')
METHODS={f.name:f for f in CLS.body if isinstance(f,ast.FunctionDef)}

class TestPLCObservability(unittest.TestCase):
    def test_diagnostic_function_never_writes(self):
        src=ast.unparse(METHODS['_read_plc_diagnostic'])
        self.assertIn('tc_sp_get',src)
        self.assertIn('plc_vw_read',src)
        self.assertNotIn('tc_sp_set(',src)
        self.assertNotIn('tc_fixed_value_startup(',src)
        self.assertNotIn('plc_vw_write(',src)

    def test_snapshot_mismatch_gives_precise_reason(self):
        snap={'sp':21.0,'fixed_mode':True,'fixed_started':False,'running':False}
        with self.assertRaisesRegex(ChamberSafetyError,'目标-15.00.*回读21.00'):
            require_setpoint_ack(snap,-15,tolerance=0.25)
        snap['sp']=-15.0
        with self.assertRaisesRegex(ChamberSafetyError,'运行状态'):
            require_setpoint_ack(snap,-15,tolerance=0.25)

    def test_timeout_error_contains_sp_pv_and_running_flags(self):
        # The expanded error includes telemetry instead of the old generic 50s line.
        src=ast.unparse(METHODS['_monitor'])
        self.assertIn('self._plc_state_text(snap)',src)
        self.assertIn('run.get(\'last_ack_reason\')',src)
        self.assertIn('reason',src)
        self.assertIn('90秒',src)
        self.assertIn('sp_updated',src)

    def test_original_r10_setpoint_command_retained(self):
        src=ast.unparse(METHODS['_issue_plc_auto'])
        self.assertIn('issue_preparation_setpoint(float(target))',src)
        self.assertNotIn('configure_fixed_rate(float(rate))',src)
        self.assertNotIn('self.thermal._issue_plc_setpoint',src)
        self.assertNotIn('plc_vw_read',src)

if __name__=='__main__':unittest.main()
