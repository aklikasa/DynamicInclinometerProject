# -*- coding: utf-8 -*-
"""Static wiring/safety regression; does not import Qt or proprietary DLLs."""
import ast
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]

class TestQA04Wiring(unittest.TestCase):
    def test_main_new_tab_and_shutdown_hook(self):
        text=(ROOT/'main.py').read_text(encoding='utf-8')
        self.assertIn('FormPostThermalRamp(ui, form_thermal, form_post_qa)',text)
        self.assertIn('app.aboutToQuit.connect(form_post_ramp.shutdown)',text)

    def test_04_plc_auto_guarded_state_machine(self):
        p=ROOT/'form/form_post_thermal_ramp.py'
        src=p.read_text('utf-8')
        tree=ast.parse(src)
        names=[x.func.attr if isinstance(x.func,ast.Attribute) else x.func.id
               for x in ast.walk(tree) if isinstance(x,ast.Call)
               and isinstance(x.func,(ast.Attribute,ast.Name))]
        # The new design must actually control the PLC; start-temp mismatch
        # must not be a hard preflight rejection.
        self.assertIn('_issue_plc_auto',names)
        self.assertNotIn('configure_fixed_rate',names)
        self.assertIn('issue_preparation_setpoint',names)
        self.assertIn('request_fixed_stop',names)
        self.assertNotIn('相差超过1.5℃；请先让厂家程序到起点',src)
        self.assertIn("'PREPARE_WAIT'",src)
        self.assertIn("'PREPARE_VERIFY'",src)
        self.assertIn('require_step_setpoint_ack',src)
        self.assertIn('OFFLINE_DEBUG',src)
        self.assertIn('self.thermal._stopped()',src)

    def test_r5_stationarity_and_stop_access(self):
        text=(ROOT/'form/form_thermal_compensation.py').read_text('utf-8')
        self.assertIn('self._valid_device()  # freshly checked WK and IMU feedback',text)
        self.assertIn("if not snap['running']:raise ValueError",text)
        self.assertIn("if count<r['last_counter']:",text)
        self.assertIn("if self._r5_ramp is not None",text)
        self.assertIn("('pushButton_Set','pushButton_ConnectTC') if self._r5_ramp is not None",text)

if __name__=='__main__':unittest.main()
