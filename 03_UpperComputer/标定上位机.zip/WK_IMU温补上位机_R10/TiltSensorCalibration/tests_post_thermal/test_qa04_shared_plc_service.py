# -*- coding: utf-8 -*-
"""Ensure both experiment pages share field-proven PLC commands; no actual PLC."""
import ast
import importlib.util
from pathlib import Path
import sys
import threading
import types
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]

class TestSharedPLCService(unittest.TestCase):
    def test_shared_service_same_write_order_and_rate_is_explicit(self):
        events=[]
        fake_comm=types.SimpleNamespace(is_connected=True,thread_lock=threading.Lock())
        fake_plc=types.ModuleType('temperature_chamber_comm')
        rate_enabled=[True]
        fake_plc.tc_set_fixed_value_mode=lambda:events.append('mode') or True
        fake_plc.tc_sp_set=lambda v:events.append(('SP',v)) or True
        fake_plc.tc_fixed_value_startup=lambda:events.append('start') or True
        fake_plc.tc_fixed_value_stop=lambda:events.append('stop') or True
        fake_plc.tc_fixed_value_state_get=lambda:events.append('fixed_state') or False
        fake_plc.tc_run_state_get=lambda:events.append('run_state') or False
        fake_plc.tc_fixed_value_rate_set=lambda v:events.append(('RATE',v)) or True
        def rate_on():
            events.append('rate_on');rate_enabled[0]=True;return True
        def rate_off():
            events.append('rate_off');rate_enabled[0]=False;return True
        fake_plc.tc_fixed_value_rate_on=rate_on
        fake_plc.tc_fixed_value_rate_off=rate_off
        fake_plc.tc_fixed_value_rate_get=lambda:events.append('rate_read') or 0.5
        def rate_state():
            events.append('rate_on_read');return rate_enabled[0]
        fake_plc.tc_fixed_value_rate_state_get=rate_state
        fake_data=types.ModuleType('temperature_chamber_data_get');fake_data.tcComm=fake_comm
        fake_debug=types.ModuleType('debug');fake_debug.OFFLINE_DEBUG=False
        with patch.dict(sys.modules,{'temperature_chamber_comm':fake_plc,
                  'temperature_chamber_data_get':fake_data,'debug':fake_debug}):
            spec=importlib.util.spec_from_file_location('qa_plc_test_service',ROOT/'chamber_fixed_control.py')
            m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
            self.assertTrue(m.issue_fixed_setpoint(-15))
            self.assertEqual(events,['mode',('SP',-15.),'start'])
            self.assertFalse(any('rate' in str(e).lower() for e in events))
            events.clear()
            info=m.issue_preparation_setpoint(-15.)
            self.assertTrue(info['rate_before'])
            self.assertFalse(info['rate_after'])
            self.assertEqual(events,['rate_on_read','rate_off','rate_on_read',
                                     'mode',('SP',-15.),'start'])
            events.clear()
            info=m.configure_fixed_rate(0.5)
            self.assertEqual(events,[('RATE',0.5),'rate_on','rate_read','rate_on_read'])
            self.assertTrue(info['read_switch'])
            events.clear()
            self.assertEqual(m.request_fixed_stop(),(True,False,False))
            self.assertEqual(events,['stop','fixed_state','run_state'])

    def test_r10_and_04_both_call_shared_service(self):
        old=(ROOT/'form/form_thermal_compensation.py').read_text('utf8')
        new=(ROOT/'form/form_post_thermal_ramp.py').read_text('utf8')
        self.assertIn('from chamber_fixed_control import issue_fixed_setpoint',old)
        self.assertIn('issue_preparation_setpoint',new)
        self.assertIn('issue_rate_limited_setpoint',new)
        self.assertIn('require_chamber_ready',new)
        self.assertIn('issue_fixed_setpoint(float(target))',old)
        self.assertIn('issue_preparation_setpoint(float(target))',new)
        self.assertNotIn('issue_fixed_setpoint(float(target))',new)

    def test_04_preparation_off_measured_legs_rate_on_endpoint_only(self):
        src=(ROOT/'form/form_post_thermal_ramp.py').read_text('utf8')
        self.assertIn('self._issue_plc_auto(begin,rate,configure_rate=False)',src)
        self.assertIn('configure_rate=True',src)
        self.assertIn('self._start_next_step_leg(run,now)',src)
        self.assertIn('self.rate.setValue(2.0)',src)
        self.assertIn('now-run[\'cmd_time\']>90',src)
        self.assertIn('sp_updated',src)
        self.assertNotIn('plc_vw_read(chamber_driver.client_instance,2110)',src[src.index('    def _issue_plc_auto('):src.index('    def _stop_chamber(')])

    def test_04_never_calls_thermal_page_plc_methods(self):
        src=(ROOT/'form/form_post_thermal_ramp.py').read_text('utf8')
        self.assertNotIn('self.thermal._issue_plc_setpoint',src)
        self.assertNotIn('self.thermal._require_plc',src)
        self.assertNotIn('self.thermal._plc_snapshot',src)
        self.assertIn('from chamber_fixed_control import require_chamber_ready',src)
        self.assertIn('from chamber_fixed_control import chamber_snapshot',src)

    def test_thermal_and_04_use_same_snapshot_and_guard(self):
        thermal=(ROOT/'form/form_thermal_compensation.py').read_text('utf8')
        ramp=(ROOT/'form/form_post_thermal_ramp.py').read_text('utf8')
        svc=(ROOT/'chamber_fixed_control.py').read_text('utf8')
        self.assertIn('from chamber_fixed_control import require_chamber_ready',thermal)
        self.assertIn('from chamber_fixed_control import require_chamber_ready',ramp)
        self.assertIn('require_live_chamber(snap,',svc)
        self.assertIn('tcData.pv_update_monotonic',svc)
        self.assertNotIn('tc_connect(',svc)
        self.assertNotIn('plc_connect(',svc)

    def test_04_writes_endpoint_setpoint_with_rate_only_during_leg(self):
        import ast
        src=(ROOT/'form/form_post_thermal_ramp.py').read_text('utf8')
        cls=next(x for x in ast.parse(src).body if isinstance(x,ast.ClassDef) and x.name=='FormPostThermalRamp')
        node=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='_issue_plc_auto')
        compiled=compile(ast.Module(body=[node],type_ignores=[]),'<qa04_plc_ramp>', 'exec')
        namespace={'time':types.SimpleNamespace(monotonic=lambda:42.0),'ValidationError':ValueError}
        exec(compiled,namespace)
        f=namespace['_issue_plc_auto']
        events=[]
        fake_svc=types.ModuleType('chamber_fixed_control')
        fake_svc.require_chamber_ready=lambda now:{'pv':20.0,'sp':20.0,'fixed_mode':True,
                            'fixed_started':True,'running':True,'alarm':0,'fault':False}
        fake_svc.issue_fixed_setpoint=lambda target:events.append(('SP',target))
        fake_svc.issue_preparation_setpoint=lambda target:events.append(('PREPARE_SP',target)) or {'rate_after':False}
        fake_svc.issue_rate_limited_setpoint=lambda target,rate:events.append(('RATE_SP',target,rate)) or {'rate':rate}
        fake_data=types.ModuleType('temperature_chamber_data_get')
        fake_data.tcComm=types.SimpleNamespace(is_connected=True)
        fake=types.SimpleNamespace(_plc_write_attempted=False,
                _append=lambda msg:None,
                _plc_state_text=lambda x:'status')
        with patch.dict(sys.modules,{'chamber_fixed_control':fake_svc,
                          'temperature_chamber_data_get':fake_data}):
            f(fake,-15.,0.5,configure_rate=False)
            self.assertEqual(events,[('PREPARE_SP',-15.)])
            events.clear()
            f(fake,15.,0.5,configure_rate=False)
            self.assertEqual(events,[('PREPARE_SP',15.)])
            f(fake,15.,2.0,configure_rate=True)
            self.assertEqual(events,[('PREPARE_SP',15.),('RATE_SP',15.,2.0)])

if __name__=='__main__':unittest.main()
