# -*- coding: utf-8 -*-
"""QA04 fixed-target auto protocol: no Qt/PLC; do not test obsolete rate-on behavior."""
import unittest
from test_qa04_fixed_step_protocol import Sim, CLOCK

class AutoRampProtocol(unittest.TestCase):
    def setUp(self):
        CLOCK.t=2

    def test_start_at_21C_does_not_reject_minus_15C(self):
        q=Sim(mode='both',cycles=1)
        q.tick()
        self.assertEqual(q.live['stage'],'PREPARE_WAIT')
        self.assertEqual(q.writes,[])
        q.tick(pv=-13.1,chip=-15.8)  # PV at target ±2, chip need not equal SP
        self.assertIsNone(q.fail)
        self.assertEqual(q.writes,[15.])
        self.assertEqual(q.live['stage'],'UP_VERIFY')

    def test_warm_then_cool_uses_pv_not_chip_equality(self):
        q=Sim(mode='both',cycles=1)
        q.tick();q.tick(pv=-13.1,chip=-15.8)
        q.tick();q.tick(pv=13.1,chip=12.7)
        self.assertIsNone(q.fail)
        self.assertEqual(q.writes,[15.,-15.])
        self.assertEqual(q.live['stage'],'DOWN_VERIFY')

    def test_finish_after_cooling_pv_reaches_end(self):
        q=Sim(mode='both',cycles=1)
        q.tick();q.tick(pv=-13.1,chip=-15.8)
        q.tick();q.tick(pv=13.1,chip=12.7)
        q.tick();q.tick(pv=-13.1,chip=-15.8)
        self.assertTrue(q.complete)
        self.assertIsNone(q.fail)

    def test_outside_fit_range_never_stops_chamber_or_sampling(self):
        q=Sim(mode='both',cycles=1)
        q.tick();q.tick(pv=-13.1,chip=-15.8)
        q.tick(chip=25.)
        self.assertIsNone(q.fail)
        self.assertEqual(q.live['stage'],'UP')
        self.assertGreaterEqual(q.live['model_outside_observations'],1)
        self.assertEqual(q.writes,[15.])

    def test_no_imu_new_frames_aborts(self):
        q=Sim(mode='both',cycles=1)
        q._read_chip=lambda:(-15.,0)
        CLOCK.t=40
        q.tick()
        self.assertIn('无新IMU帧',q.fail)

if __name__=='__main__':unittest.main()
