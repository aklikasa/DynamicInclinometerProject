# -*- coding: utf-8 -*-
"""QA04 process-SP slope ACK regression against actual 2026-11-19 PLC log.
No real chamber/Qt/snap7 calls. Original R10 steady-SP tests are unchanged.
"""
import ast
import math
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from chamber_auto_guard import (
    ChamberSafetyError,require_ramped_setpoint_ack,require_setpoint_ack,
)


def snap(sp,clock,**flags):
    v={'pv':21.4,'sp':sp,'fixed_mode':True,'fixed_started':True,
       'running':True,'rate_enabled':False,'sp_updated':clock,'mode_updated':clock,
       'started_updated':clock,'run_updated':clock}
    v.update(flags)
    return v

class TestRampACK(unittest.TestCase):
    def test_real_log_21_3_to_20_1_with_target_minus_15(self):
        # Reproduce the exact descending process-SP trajectory, including
        # the fact that it is *not* near the final target after 42 seconds.
        for process in [21.2,21.1,21.0,20.9,20.8,20.7,20.6,20.5,20.4,20.3,20.2,20.1]:
            msg=require_ramped_setpoint_ack(snap(process,55),-15.,21.3,-15.)
            self.assertIn('朝目标变化',msg)
        with self.assertRaisesRegex(ChamberSafetyError,'回读不一致'):
            require_setpoint_ack(snap(20.1,55),-15.)

    def test_still_waiting_immediately_after_command(self):
        with self.assertRaisesRegex(ChamberSafetyError,'尚未朝目标变化'):
            require_ramped_setpoint_ack(snap(21.3,15),-15.,21.3,-15.)

    def test_write_not_echoed_cannot_pass(self):
        for cmd in [None,21.3,15.]:
            with self.subTest(cmd=cmd),self.assertRaises(ChamberSafetyError):
                require_ramped_setpoint_ack(snap(21.2,15),-15.,21.3,cmd)

    def test_stopped_controller_cannot_pass(self):
        for flag in ['fixed_mode','fixed_started','running']:
            with self.subTest(flag=flag),self.assertRaises(ChamberSafetyError):
                require_ramped_setpoint_ack(snap(21.2,15,**{flag:False}),-15.,21.3,-15.)

    def test_upward_and_reversal(self):
        self.assertIn('朝目标变化',require_ramped_setpoint_ack(
            snap(-14.9,15),15.,-15.,15.))
        self.assertIn('朝目标变化',require_ramped_setpoint_ack(
            snap(14.8,15),-15.,15.,-15.))
        self.assertIn('达到目标',require_ramped_setpoint_ack(
            snap(15.,15),15.,-15.,15.))

    def test_wrong_direction_not_accepted(self):
        with self.assertRaisesRegex(ChamberSafetyError,'尚未朝目标变化'):
            require_ramped_setpoint_ack(snap(21.4,55),-15.,21.3,-15.)

    def test_process_sp_must_not_overshoot(self):
        with self.assertRaisesRegex(ChamberSafetyError,'越过目标温度'):
            require_ramped_setpoint_ack(snap(-15.9,55),-15.,21.3,-15.)

class TestMonitorProtocol(unittest.TestCase):
    def setUp(self):
        src=(ROOT/'form/form_post_thermal_ramp.py').read_text('utf-8')
        cls=next(n for n in ast.parse(src).body if isinstance(n,ast.ClassDef) and n.name=='FormPostThermalRamp')
        method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_monitor')
        self.clock=types.SimpleNamespace(t=50.0)
        self.logs=[]
        globals={'time':types.SimpleNamespace(monotonic=lambda:self.clock.t),
                 'math':math,'ValidationError':ValueError}
        exec(compile(ast.Module(body=[method],type_ignores=[]),str(ROOT),'exec'),globals)
        self.monitor=globals['_monitor']
        self.spy=types.SimpleNamespace(pv=21.4,sp=21.2, echo=-15.,fail=None,
            stage='PREPARE_VERIFY',writes=0)
        spy=self.spy
        self.fake_service=types.ModuleType('chamber_fixed_control')
        self.fake_service.require_chamber_ready=lambda now:snap(spy.sp,now,pv=spy.pv)
        self.fake_service.read_fixed_target_command=lambda:spy.echo
        self.thermal=types.SimpleNamespace(_valid_device=lambda:None,
            _stopped=lambda:True,_r5_ramp=None)
        self.fakeobj=types.SimpleNamespace(
            thermal=self.thermal,
            _read_chip=lambda:(21.73,int(self.clock.t)),
            _plc_state_text=lambda s:f'PV={s["pv"]} SP={s["sp"]}',
            _append=lambda msg:self.logs.append(msg),
            status=types.SimpleNamespace(setText=lambda v:None),
            _fail=lambda v:setattr(spy,'fail',str(v)),
            live={'stage':spy.stage,'started':0.,'max_seconds':5000.,
                'auto_plc':True,'cmd_time':1.,'expected_sp':-15.,
                'command_sp_before':21.3,'last_command_echo_at':0.,
                'last_command_echo':None,'last_ack_reason':None,'last_ack_log':0.,
                'imu_count':0,'last_imu_change':0.,'plan_low':-15.,
                'plan_high':15.,'begin_c':-15.,'arrive_since':None,
                'model_lo':-20.,'model_hi':19.08,'direction':'both','rate':None,
                'tolerance':2.,'dwell':0.,'leg_index':0})

    def test_preparation_cannot_accept_a_slow_old_sp_even_if_command_echoes(self):
        with patch.dict(sys.modules,{'chamber_fixed_control':self.fake_service}):
            self.monitor(self.fakeobj)
        self.assertIsNone(self.spy.fail)
        self.assertEqual(self.fakeobj.live['stage'],'PREPARE_VERIFY')
        self.assertTrue(any('设定值回读不一致' in x for x in self.logs))

    def test_preparation_uses_original_thermal_sp_confirmation(self):
        self.spy.sp=-15.0
        with patch.dict(sys.modules,{'chamber_fixed_control':self.fake_service}):
            self.monitor(self.fakeobj)
        self.assertIsNone(self.spy.fail)
        self.assertEqual(self.fakeobj.live['stage'],'PREPARE_WAIT')
        self.assertTrue(any('原温补逻辑' in x for x in self.logs))

    def test_wrong_target_echo_never_approves_ramp(self):
        self.spy.echo=21.3
        with patch.dict(sys.modules,{'chamber_fixed_control':self.fake_service}):
            self.monitor(self.fakeobj)
        self.assertIsNone(self.spy.fail)
        self.assertEqual(self.fakeobj.live['stage'],'PREPARE_VERIFY')
        self.assertTrue(any('目标回读不一致' in x for x in self.logs))

    def test_stale_post_command_data_prevents_ack(self):
        # Realistically retain stale reads even though current monitoring tick
        # executes later: the source refresh timestamps must be AFTER command.
        self.fake_service.require_chamber_ready=lambda now:snap(self.spy.sp,0.5)
        with patch.dict(sys.modules,{'chamber_fixed_control':self.fake_service}):
            self.monitor(self.fakeobj)
        self.assertEqual(self.fakeobj.live['stage'],'PREPARE_VERIFY')
        self.assertTrue(any('新鲜反馈' in x for x in self.logs))

if __name__=='__main__':unittest.main()
