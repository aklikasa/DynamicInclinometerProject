# -*- coding: utf-8 -*-
"""Start-button integration without Qt/PLC: first command must be a final endpoint SP."""
import ast
import datetime as dt
import math
import pathlib
import sys
import tempfile
import types
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from qa04_step_plan import build_step_plan,describe_step_plan

SRC=ROOT/'form/form_post_thermal_ramp.py'
CLS=next(c for c in ast.parse(SRC.read_text('utf-8')).body
         if isinstance(c,ast.ClassDef) and c.name=='FormPostThermalRamp')
NODE=next(n for n in CLS.body if isinstance(n,ast.FunctionDef) and n.name=='_start')

class Field:
    def __init__(self,v):self.v=v
    def value(self):return self.v
    def text(self):return str(self.v)
    def isChecked(self):return bool(self.v)
    def currentData(self):return self.v
    def setEnabled(self,value):pass
    def setText(self,v):self.v=v
    def clear(self):pass

class TestStartIntegration(unittest.TestCase):
    def test_both_direction_first_command_is_exact_endpoint(self):
        for direction,first_target,leg_targets in [
                ('both',-15.,[15.,-15.,15.,-15.]),
                ('both_cooling',15.,[-15.,15.,-15.,15.])]:
            with self.subTest(direction=direction),tempfile.TemporaryDirectory() as tmp:
                sent=[]
                msg=[]
                fake_chamber=types.ModuleType('chamber_fixed_control')
                fake_chamber.require_chamber_ready=lambda now:{'pv':21.5}
                saved=sys.modules.get('chamber_fixed_control')
                sys.modules['chamber_fixed_control']=fake_chamber
                try:
                    errors=types.SimpleNamespace(warning=lambda *args:msg.append(str(args[-1])))
                    namespace={'time':types.SimpleNamespace(monotonic=lambda:100.),'math':math,
                        'Path':Path,'dt':dt,'ValidationError':ValueError,
                        'QMessageBox':errors,'build_step_plan':build_step_plan,
                        'describe_step_plan':describe_step_plan}
                    exec(compile(ast.Module(body=[NODE],type_ignores=[]),str(SRC),'exec'),namespace)
                    obj=types.SimpleNamespace(
                        _busy=lambda:False,_autofill_from_parameters=lambda:None,
                        _validate_model=lambda:{'result':{'device_sn':'ABC'},
                            'params':{k:{'temperature_domain_c':[-20.,20.]}
                                      for k in ('acc','gyro')}},
                        approval=Field(True),sn=Field('ABC'),batch=Field('QA04_test'),
                        data=Field(tmp),low=Field(-15.),high=Field(15.),
                        tolerance=Field(2.),dwell=Field(0.),cycles=Field(2),rate=Field(2.),
                        direction=Field(direction),auto_plc=Field(True),
                        thermal=types.SimpleNamespace(task=None,_r5_ramp=None,
                            _valid_device=lambda:None,_stopped=lambda:True),
                        _read_chip=lambda:(21.73,31),
                        _issue_plc_auto=lambda target,*args,**kwargs:sent.append(target) or 21.5,
                        _plc_write_attempted=False,_last_plc_stop_note='',
                        log=Field(''),last_report=None,open_report=Field(''),
                        _append=lambda s:None,_set_busy=lambda v:None,
                        timer=types.SimpleNamespace(start=lambda:None),
                        _stop_chamber=lambda:None,page=None,live=None)
                    namespace['_start'](obj)
                    self.assertEqual(msg,[])
                    self.assertEqual(sent,[first_target])
                    self.assertEqual([l['target_c'] for l in obj.live['step_plan']['legs']],leg_targets)
                    self.assertEqual(obj.live['stage'],'PREPARE_VERIFY')
                    self.assertEqual(obj.live['tolerance'],2.)
                finally:
                    if saved is None:sys.modules.pop('chamber_fixed_control',None)
                    else:sys.modules['chamber_fixed_control']=saved

if __name__=='__main__':unittest.main()
