# -*- coding: utf-8 -*-
"""Synthetic-only QA04 tests.  No hardware or proprietary DLL is loaded."""
import csv
import json
import math
import tempfile
import unittest
from pathlib import Path

import numpy as np

from post_thermal_ramp_qa import execute
from post_thermal_qa import ValidationError
from production_ramp import FIELDS


class TestRampFrozen(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        acc=[[0.]*12 for _ in range(3)]
        gyro=[[0.]*16 for _ in range(3)]
        for i in range(3):
            acc[i][i]=1.;gyro[i][i]=1.
        # For D2: 3 reference terms in each temperature power, plus bias powers.
        # For SEG2: first 3 reference terms at constant part, then bias terms.
        acc[0][9]=.012      # raw ACC X thermal bias 12mg at all T
        gyro[0][12]=.027    # raw GYRO X bias 0.027°/s at all T
        self.acc={'id':'T0-D2','sensor':'acc','coeff':acc,'phase':False,'input_id':'T0',
                  'input_transform':{'id':'T0','kind':'raw_chip'},'temperature_domain_c':[-21.,19.],
                  'raw_units':'g'}
        self.gyro={'id':'T0-SEG2_0','sensor':'gyro','coeff':gyro,'phase':False,'input_id':'T0',
                   'input_transform':{'id':'T0','kind':'raw_chip'},'temperature_domain_c':[-21.,19.],
                   'raw_units':'deg/s'}
        self.param=self.root/'统一温补研究参数_未经生产批准.json'
        self.research=self.root/'全量研究结果_不得直接烧录.json'
        self.param.write_text(json.dumps({'acc':self.acc,'gyro':self.gyro,'coordinate_frame':'software P'}),encoding='utf-8')
        self.research.write_text(json.dumps({'device_sn':'DTS_FAKE_1','batch_id':'FIT',
            'models':{'acc':{'model':self.acc},'gyro':{'model':self.gyro}},
            'geometry':{'selected':{'name':'M3','params_deg':[.176,.023]}}}),encoding='utf-8')
        self.csv=self.root/'R5_RAMP_20261119.csv'
        self.make_csv()

    def tearDown(self):self.tmp.cleanup()

    def make_csv(self, sn='DTS_FAKE_1', stopped=True, out_temp=False):
        # 5s/sample, +/−0.6℃/min; 24℃ span each direction. In-domain by default.
        with self.csv.open('w',newline='',encoding='utf-8-sig') as f:
            writer=csv.DictWriter(f,fieldnames=FIELDS)
            writer.writeheader()
            temps=[-15.+.05*i for i in range(481)]+[9.-.05*i for i in range(481)]
            for i,temp in enumerate(temps):
                if out_temp and i==200:temp=40.
                writer.writerow({'unix_s':1700000000+i*5,'chip_c':temp,'pv_c':temp+.5,
                    'acc_x_g':.012,'acc_y_g':0.,'acc_z_g':1.,
                    'gyro_x_dps':.027,'gyro_y_dps':0.,'gyro_z_dps':0.,
                    'frame_count':i+1,'wk_stopped_confirmed':stopped,
                    'device_sn':sn,'batch_id':'RAMP_NEW'})

    def test_both_direction_raw_corrected_metrics(self):
        dest,summary,manifest=execute(self.csv,self.param,self.research,direction='both',low=-15,high=9,rate=.6)
        self.assertTrue((dest/'04_连续变温静态漂移报告.html').is_file())
        self.assertTrue((dest/'连续变温逐帧补偿数据.csv').is_file())
        self.assertTrue(manifest['no_refit'])
        self.assertGreater(summary['direction_counts']['warming']['fresh_frames'],100)
        self.assertGreater(summary['direction_counts']['cooling']['fresh_frames'],100)
        self.assertLess(summary['metrics']['corrected_gyro_norm_dps']['rmse'],1e-8)
        self.assertGreater(summary['metrics']['raw_gyro_norm_dps']['rmse'],.02)
        self.assertLess(summary['metrics']['corrected_acc_norm_error_mg']['rmse'],1e-7)
        self.assertGreaterEqual(summary['matched_chip_bins_count'],30)

    def test_01_cross_file_coeff_mismatch_fails(self):
        js=json.loads(self.param.read_text('utf-8'));js['gyro']['coeff'][0][12]+=.1
        self.param.write_text(json.dumps(js),encoding='utf-8')
        with self.assertRaisesRegex(ValidationError,'不一致'):
            execute(self.csv,self.param,self.research)

    def test_wrong_board_fails(self):
        self.make_csv(sn='WRONG_BOARD')
        with self.assertRaisesRegex(ValidationError,'PCB不一致'):
            execute(self.csv,self.param,self.research)

    def test_not_stationary_fails(self):
        self.make_csv(stopped=False)
        with self.assertRaisesRegex(ValueError,'停车'):
            execute(self.csv,self.param,self.research)

    def test_temperature_outside_model_is_reported_not_rejected(self):
        self.make_csv(out_temp=True)
        dest,summary,_=execute(self.csv,self.param,self.research)
        self.assertGreater(summary['model_extrapolation_samples'],0)
        self.assertEqual(summary['status'],'EVALUATED_WITH_EXTRAPOLATION')
        self.assertTrue((dest/'04_连续变温静态漂移报告.html').exists())
        import csv as csvmod
        with (dest/'连续变温逐帧补偿数据.csv').open(encoding='utf-8-sig',newline='') as f:
            rows=list(csvmod.DictReader(f))
        self.assertTrue(any(r['model_extrapolation']=='True' for r in rows))

    def test_short_observation_exports_report_with_coverage_note(self):
        # QA04 must never discard an experiment just for a legacy 100-frame gate.
        with self.csv.open(encoding='utf-8-sig',newline='') as f:
            records=list(csv.DictReader(f))[:30]
        with self.csv.open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=FIELDS)
            w.writeheader();w.writerows(records)
        dest,summary,_=execute(self.csv,self.param,self.research,direction='warming',min_coverage_c=10)
        self.assertEqual(summary['source_count'],30)
        self.assertFalse(summary['direction_counts']['warming']['meets_legacy_research_coverage'])
        self.assertTrue((dest/'04_连续变温静态漂移报告.html').is_file())

    def test_selected_direction(self):
        dest,s,_=execute(self.csv,self.param,self.research,direction='warming',low=-15,high=9,rate=.6)
        self.assertEqual(set(s['direction_counts']),{'warming'})
        self.assertEqual(s['matched_chip_bins_count'],0)

if __name__=='__main__':unittest.main()
