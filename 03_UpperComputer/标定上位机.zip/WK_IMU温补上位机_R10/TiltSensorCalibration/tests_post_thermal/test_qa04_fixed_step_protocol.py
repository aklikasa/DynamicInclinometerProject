# -*- coding: utf-8 -*-
"""QA04 fixed endpoint-SP semantics; hardware-free regression suite."""
import ast
import math
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from qa04_step_plan import build_step_plan
from chamber_auto_guard import ChamberSafetyError,require_step_setpoint_ack

SRC=ROOT/'form/form_post_thermal_ramp.py'
SRC_TEXT=SRC.read_text(encoding='utf-8')
CLASS=next(x for x in ast.parse(SRC_TEXT).body if isinstance(x,ast.ClassDef) and x.name=='FormPostThermalRamp')
CLOCK=types.SimpleNamespace(t=0.0)
G={'time':types.SimpleNamespace(monotonic=lambda:CLOCK.t),
   'math':math,'ValidationError':ValueError,'dt':__import__('datetime')}
# Inject methods into a small hardware-free object; production code is executed unchanged.
for name in ('_issue_plc_auto','_start_next_step_leg','_monitor'):
    n=next(x for x in CLASS.body if isinstance(x,ast.FunctionDef) and x.name==name)
    exec(compile(ast.Module(body=[n],type_ignores=[]),str(SRC),'exec'),G)

class PlanTests(unittest.TestCase):
    def test_warming_oneway(self):
        p=build_step_plan(-15,15,'warming',1)
        self.assertEqual(p['start_c'],-15)
        self.assertEqual([x['target_c'] for x in p['legs']],[15.])
        self.assertEqual(p['analysis_direction'],'warming')

    def test_cooling_oneway(self):
        p=build_step_plan(-15,15,'cooling',1)
        self.assertEqual(p['start_c'],15)
        self.assertEqual([x['target_c'] for x in p['legs']],[-15.])

    def test_two_up_down_cycles_exact_endpoint_commands(self):
        p=build_step_plan(-15,15,'both',2)
        self.assertEqual([x['target_c'] for x in p['legs']],[15.,-15.,15.,-15.])
        self.assertEqual(p['analysis_direction'],'both')

    def test_two_down_up_cycles_exact_endpoint_commands(self):
        p=build_step_plan(-15,15,'both_cooling',2)
        self.assertEqual(p['start_c'],15)
        self.assertEqual([x['target_c'] for x in p['legs']],[-15.,15.,-15.,15.])

    def test_oneway_multi_repeat_rejected_no_hidden_return(self):
        with self.assertRaisesRegex(ValueError,'单程'):
            build_step_plan(-15,15,'warming',2)

    def test_invalid_limits(self):
        with self.assertRaises(ValueError):build_step_plan(15,-15,'both')
        with self.assertRaises(ValueError):build_step_plan(-50,15,'both')

    def test_rate_setting_only_on_measured_legs_no_host_intermediate_sp(self):
        self.assertIn('self.rate.setValue(2.0)',SRC_TEXT)
        self.assertIn('self.rate.value()',SRC_TEXT)
        self.assertIn('issue_preparation_setpoint',SRC_TEXT)
        self.assertIn('issue_rate_limited_setpoint',SRC_TEXT)
        self.assertIn('configure_rate=True',SRC_TEXT)
        self.assertNotIn('tc_sp_set(',SRC_TEXT)

class AckTests(unittest.TestCase):
    def snapshot(self,rate=False,sp=20.4):
        return {'fixed_mode':True,'fixed_started':True,'running':True,'rate_enabled':rate,'sp':sp}

    def test_target_echo_fixed_even_if_internal_process_sp_drifts(self):
        for sp in (21.3,20.6,12.,-12.,-15.):
            self.assertIn('固定目标',require_step_setpoint_ack(self.snapshot(sp=sp),-15.,-15.))

    def test_unconfirmed_rate_off_is_rejected(self):
        for rate in (True,None):
            with self.assertRaisesRegex(ChamberSafetyError,'速率'):
                require_step_setpoint_ack(self.snapshot(rate=rate),-15,-15)

    def test_unconfirmed_target_is_rejected(self):
        with self.assertRaisesRegex(ChamberSafetyError,'不一致'):
            require_step_setpoint_ack(self.snapshot(),-15,21.3)

    def test_stopped_plc_is_rejected(self):
        s=self.snapshot();s['running']=False
        with self.assertRaisesRegex(ChamberSafetyError,'运行'):
            require_step_setpoint_ack(s,-15,-15)

class PureIOTest(unittest.TestCase):
    def test_issue_step_only_uses_preparation_path(self):
        calls=[]
        m=types.ModuleType('chamber_fixed_control')
        m.require_chamber_ready=lambda now:{'sp':21.3}
        m.issue_preparation_setpoint=lambda target:calls.append(target) or {'rate_after':False}
        m.issue_rate_limited_setpoint=lambda target,rate:None
        obj=types.SimpleNamespace(_plc_write_attempted=False,
             _append=lambda s:None,_plc_state_text=lambda s:'snapshot')
        with patch.dict(sys.modules,{'chamber_fixed_control':m}):
            out=G['_issue_plc_auto'](obj,-15.)
        self.assertEqual(calls,[-15.]);self.assertEqual(out,21.3)
        self.assertTrue(obj._plc_write_attempted)

class Sim:
    def __init__(self,mode='both',cycles=2):
        self.plan=build_step_plan(-15,15,mode,cycles)
        self.target=self.plan['start_c']
        # Initial fixed-SP was accepted by the plant before PREPARE_VERIFY.
        # The real PV is independent and may still be 21.6 C.
        self.sp=self.target
        self.pv=21.6
        self.chip=21.73
        self.count=0
        self.calls=[]
        self.writes=[]
        self.fail=None
        self.complete=False
        self.thermal=types.SimpleNamespace(_valid_device=lambda:None,
            _stopped=lambda:True,_r5_ramp=None)
        self.status=types.SimpleNamespace(setText=lambda x:None)
        self.live={'csv':None,'started':0.0,'stage':'PREPARE_VERIFY',
            'expected_sp':self.target,'cmd_time':0.1,
            'last_command_echo_at':0.,'last_command_echo':None,
            'last_ack_reason':None,'last_ack_log':0.,
            'begin_c':self.plan['start_c'],'direction':mode,
            'peak':self.chip,'valley':self.chip,'stage_started':0.,
            'arrive_since':None,'last_count':0,'plan_low':-15.,'plan_high':15.,
            'rate':2.0,'expected_rate_enabled':False,
            'step_plan':self.plan,'leg_index':0,
            'tolerance':2.,'dwell':0.,'leg_timing':[],
            'max_seconds':300000.,'sn':'X','batch':'TEST',
            'output':'/tmp','auto_plc':True,
            'model_lo':-20.43,'model_hi':18.83,
            'imu_count':0,'last_imu_change':0.,'end_since':None}
    def _plc_state_text(self,s):return 'status'
    def _append(self,s):self.calls.append(str(s))
    def _read_chip(self):self.count+=1;return self.chip,self.count
    def _begin_r5_recording(self,run):
        self.thermal._r5_ramp={'count':0}
        run['csv']='fake.csv'
    def _issue_plc_auto(self,target,rate=None,**kwargs):
        before=self.sp
        self.writes.append(target);self.target=target
        return before
    def _start_next_step_leg(self,run,now):
        G['_start_next_step_leg'](self,run,now)
    def _complete(self):self.complete=True
    def _fail(self,r):self.fail=str(r)
    def tick(self,pv=None,chip=None):
        CLOCK.t+=1
        if self.live['stage'] in ('UP_VERIFY','DOWN_VERIFY'):
            # Simulate 0.1-degree PLC process-SP progress after rate ON;
            # final VW2110 target is still commanded once per leg.
            sign=1. if self.target>self.sp else -1.
            if abs(self.target-self.sp)>0.05:self.sp+=sign*0.1
        if pv is not None:self.pv=pv
        if chip is not None:self.chip=chip
        if self.thermal._r5_ramp is not None:
            self.thermal._r5_ramp['count']+=1
        service=types.ModuleType('chamber_fixed_control')
        service.require_chamber_ready=lambda now:{
            'pv':self.pv,'sp':self.sp,'fixed_mode':True,
            'fixed_started':True,'running':True,
            'rate_enabled':self.live.get('expected_rate_enabled',False),
            'rate_cpm':2.0,
            'sp_updated':now,'mode_updated':now,
            'started_updated':now,'run_updated':now}
        service.read_fixed_target_command=lambda:self.target
        with patch.dict(sys.modules,{'chamber_fixed_control':service}):
            G['_monitor'](self)

class StateTests(unittest.TestCase):
    def setUp(self):CLOCK.t=2
    def test_pv_plus_minus_two_and_two_cycles(self):
        q=Sim()
        q.tick();self.assertEqual(q.live['stage'],'PREPARE_WAIT')
        self.assertFalse(q.writes)
        # 1.9 C from -15 is enough; no forced 20s wait.
        q.tick(pv=-13.1,chip=-13.5)
        self.assertEqual(q.writes,[15.])
        self.assertEqual(q.live['stage'],'UP_VERIFY')
        q.tick();self.assertEqual(q.live['stage'],'UP')
        q.tick(pv=13.1,chip=12.8)
        self.assertEqual(q.writes,[15.,-15.])
        q.tick();self.assertEqual(q.live['stage'],'DOWN')
        q.tick(pv=-13.1,chip=-13.4)
        self.assertEqual(q.writes,[15.,-15.,15.])
        q.tick();self.assertEqual(q.live['stage'],'UP')
        q.tick(pv=13.2,chip=12.7)
        self.assertEqual(q.writes,[15.,-15.,15.,-15.])
        q.tick();self.assertEqual(q.live['stage'],'DOWN')
        q.tick(pv=-13.2,chip=-13.5)
        self.assertTrue(q.complete)
        self.assertIsNone(q.fail)
        self.assertEqual(len(q.live['leg_timing']),4)
        self.assertEqual(len(q.writes),4)

    def test_real_log_pv_at_start_chip_19_above_fit_18_83_still_switches(self):
        q=Sim('both_cooling',1)
        q.tick()  # SP 15 / PV 21.6, ACK accepted
        q.tick(pv=15.3,chip=19.00)  # operator's actual failed case
        self.assertIsNone(q.fail)
        self.assertEqual(q.writes,[-15.])
        self.assertEqual(q.live['stage'],'DOWN_VERIFY')
        self.assertGreaterEqual(q.live['model_outside_observations'],1)
        self.assertTrue(any('仅提示' in line for line in q.calls))

    def test_pv_stuck_after_confirmed_sp_aborts_with_actionable_error(self):
        q=Sim('both',1)
        q.tick()
        self.assertEqual(q.live['stage'],'PREPARE_WAIT')
        CLOCK.t=950.
        q.tick(pv=21.6)
        self.assertIsNotNone(q.fail)
        self.assertIn('温箱实际PV',q.fail)

    def test_pv_motion_resets_rolling_watchdog(self):
        q=Sim('both',1)
        q.tick()
        CLOCK.t=850.
        q.tick(pv=21.1)
        self.assertIsNone(q.fail)
        CLOCK.t=1050.
        q.tick(pv=21.0)
        self.assertIsNone(q.fail)

    def test_many_monitor_ticks_do_not_rewrite_setpoint(self):
        q=Sim('both',1)
        for _ in range(90):
            q.tick(pv=21.6,chip=18.0)
        self.assertEqual(q.live['stage'],'PREPARE_WAIT')
        self.assertEqual(q.writes,[])
        self.assertIsNone(q.fail)

    def test_pv_outside_tolerance_must_not_switch(self):
        q=Sim('both',1)
        q.tick()
        q.tick(pv=-12.9,chip=-13.0) # distance 2.1℃ > configured ±2℃
        self.assertEqual(q.live['stage'],'PREPARE_WAIT')
        self.assertEqual(q.writes,[])
        q.tick(pv=-13.0,chip=-13.0) # exact inclusive boundary ±2℃
        self.assertEqual(q.writes,[15.])
        self.assertIsNone(q.fail)

    def test_optional_endpoint_hold_prevents_early_switch(self):
        q=Sim('both',1)
        q.live['dwell']=5.
        q.tick()
        q.tick(pv=-13.1,chip=-13.5)
        for _ in range(4):q.tick(pv=-13.1,chip=-13.5)
        self.assertEqual(q.writes,[])
        q.tick(pv=-13.1,chip=-13.5)
        self.assertEqual(q.writes,[15.])

    def test_reverse_cycles(self):
        q=Sim('both_cooling',1)
        q.tick();self.assertEqual(q.live['stage'],'PREPARE_WAIT')
        q.tick(pv=13.2,chip=13.0)
        self.assertEqual(q.writes,[-15.])
        q.tick();self.assertEqual(q.live['stage'],'DOWN')
        q.tick(pv=-13.1,chip=-13.5)
        self.assertEqual(q.writes,[-15.,15.])
        q.tick();self.assertEqual(q.live['stage'],'UP')
        q.tick(pv=13.1,chip=12.9)
        self.assertTrue(q.complete)
        self.assertIsNone(q.fail)

if __name__=='__main__':unittest.main()
