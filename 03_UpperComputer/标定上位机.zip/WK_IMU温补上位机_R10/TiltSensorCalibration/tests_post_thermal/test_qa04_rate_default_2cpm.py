# -*- coding: utf-8 -*-
"""QA04 rate control after preparation; hardware-free PLC transaction tests."""
import importlib.util, pathlib, sys, threading, types, unittest
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]

class Rate2CpmTests(unittest.TestCase):
    def _service(self, *, rate_read_override=None, on_success=True, sp_success=True):
        events=[]
        state={'rate':0.0,'enabled':False}
        driver=types.ModuleType('temperature_chamber_comm')
        driver.tc_set_fixed_value_mode=lambda:events.append('MODE') or True
        driver.tc_sp_set=lambda t:events.append(('SP',t)) or sp_success
        driver.tc_fixed_value_startup=lambda:events.append('START') or True
        driver.tc_fixed_value_stop=lambda:True
        driver.tc_fixed_value_state_get=lambda:False
        driver.tc_run_state_get=lambda:False
        def set_rate(v):
            events.append(('RATE',v));state['rate']=v;return True
        def set_on():
            events.append('RATE_ON');state['enabled']=bool(on_success);return on_success
        def set_off():
            events.append('RATE_OFF');state['enabled']=False;return True
        driver.tc_fixed_value_rate_set=set_rate
        driver.tc_fixed_value_rate_on=set_on
        driver.tc_fixed_value_rate_off=set_off
        driver.tc_fixed_value_rate_get=lambda:events.append('RATE_READ') or (state['rate'] if rate_read_override is None else rate_read_override)
        driver.tc_fixed_value_rate_state_get=lambda:events.append('RATE_STATE') or state['enabled']
        comm=types.ModuleType('temperature_chamber_data_get')
        comm.tcComm=types.SimpleNamespace(is_connected=True,thread_lock=threading.Lock())
        dbg=types.ModuleType('debug');dbg.OFFLINE_DEBUG=False
        with patch.dict(sys.modules,{'temperature_chamber_comm':driver,
                    'temperature_chamber_data_get':comm,'debug':dbg}):
            spec=importlib.util.spec_from_file_location('qa04_2cpm_plc_mock',ROOT/'chamber_fixed_control.py')
            mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        return mod,events,state

    def test_first_leg_writes_2cpm_before_only_one_endpoint_sp(self):
        mod,events,state=self._service()
        info=mod.issue_rate_limited_setpoint(15.,2.0)
        self.assertEqual(events,['MODE',('RATE',2.0),'RATE_ON',
                                  'RATE_READ','RATE_STATE',('SP',15.),'START'])
        self.assertEqual(info['rate_c_per_min'],2.0)
        self.assertTrue(state['enabled'])

    def test_reverse_leg_keeps_single_endpoint_write(self):
        mod,events,state=self._service()
        mod.issue_rate_limited_setpoint(15.,2.0)
        events.clear()
        mod.issue_rate_limited_setpoint(-15.,2.0)
        self.assertEqual([v for v in events if isinstance(v,tuple) and v[0]=='SP'],[('SP',-15.)])
        self.assertTrue(state['enabled'])

    def test_rate_readback_mismatch_never_writes_target(self):
        mod,events,_=self._service(rate_read_override=0.0)
        with self.assertRaisesRegex(mod.PLCCommandError,'回读未确认'):
            mod.issue_rate_limited_setpoint(15.,2.0)
        self.assertNotIn(('SP',15.),events)
        self.assertNotIn('START',events)

    def test_zero_rate_readback_trial_is_explicit_and_reports_unverified(self):
        mod,events,state=self._service(rate_read_override=0.0)
        info=mod.issue_rate_limited_setpoint(15.,2.0,allow_zero_rate_readback=True)
        self.assertEqual(events,['MODE',('RATE',2.0),'RATE_ON',
                                  'RATE_READ','RATE_STATE',('SP',15.),'START'])
        self.assertTrue(info['zero_rate_echo_trial'])
        self.assertFalse(info['rate_verified'])
        self.assertTrue(state['enabled'])

    def test_nonzero_rate_mismatch_even_with_trial_never_writes_target(self):
        mod,events,_=self._service(rate_read_override=1.0)
        with self.assertRaisesRegex(mod.PLCCommandError,'回读未确认'):
            mod.issue_rate_limited_setpoint(15.,2.0,allow_zero_rate_readback=True)
        self.assertNotIn(('SP',15.),events)
        self.assertNotIn('START',events)

    def test_rate_off_even_with_trial_never_writes_target(self):
        mod,events,_=self._service(rate_read_override=0.0,on_success=False)
        with self.assertRaisesRegex(mod.PLCCommandError,'回读未确认'):
            mod.issue_rate_limited_setpoint(15.,2.0,allow_zero_rate_readback=True)
        self.assertNotIn(('SP',15.),events)
        self.assertNotIn('START',events)

    def test_stage_ack_trial_accepts_only_zero_numeric_rate(self):
        from chamber_auto_guard import require_step_setpoint_ack, ChamberSafetyError
        d={'fixed_mode':True,'fixed_started':True,'running':True,
           'rate_enabled':True,'rate_cpm':0.0,'sp':1.0}
        msg=require_step_setpoint_ack(d,15.,15.,expected_rate_enabled=True,
            expected_rate_cpm=2.0,allow_zero_rate_readback=True)
        self.assertIn('速率回读0.0',msg)
        for bad in ({'rate_cpm':None},{'rate_cpm':1.5},{'rate_enabled':False},
                    {'running':False}):
            with self.subTest(bad=bad), self.assertRaises(ChamberSafetyError):
                require_step_setpoint_ack(dict(d,**bad),15.,15.,
                    expected_rate_enabled=True,expected_rate_cpm=2.0,
                    allow_zero_rate_readback=True)

    def test_rate_on_failure_never_writes_target(self):
        mod,events,_=self._service(on_success=False)
        with self.assertRaisesRegex(mod.PLCCommandError,'回读未确认'):
            mod.issue_rate_limited_setpoint(15.,2.0)
        self.assertNotIn(('SP',15.),events)

    def test_target_sp_failure_not_marked_success(self):
        mod,events,_=self._service(sp_success=False)
        with self.assertRaisesRegex(mod.PLCCommandError,'目标SP'):
            mod.issue_rate_limited_setpoint(15.,2.0)
        self.assertNotIn('START',events)

    def test_preparation_does_not_enable_rate(self):
        mod,events,state=self._service()
        mod.issue_preparation_setpoint(-15.)
        self.assertFalse(state['enabled'])
        self.assertNotIn('RATE_ON',events)
        self.assertEqual([v for v in events if isinstance(v,tuple) and v[0]=='SP'],[('SP',-15.)])

    def test_stage_ack_requires_rate_enabled_and_matching_2cpm(self):
        from chamber_auto_guard import require_step_setpoint_ack, ChamberSafetyError
        d={'fixed_mode':True,'fixed_started':True,'running':True,
            'rate_enabled':True,'rate_cpm':2.0,'sp':-12.1}
        self.assertIn('速率模式开启',require_step_setpoint_ack(d,15.,15.,
                    expected_rate_enabled=True,expected_rate_cpm=2.0))
        for bad in [{'rate_enabled':False},{'rate_enabled':None},{'rate_cpm':0.0}]:
            with self.subTest(bad=bad),self.assertRaises(ChamberSafetyError):
                require_step_setpoint_ack(dict(d,**bad),15.,15.,
                    expected_rate_enabled=True,expected_rate_cpm=2.0)

    def test_original_thermal_sp_ack_is_required_at_preparation(self):
        from chamber_auto_guard import require_step_setpoint_ack, ChamberSafetyError
        d={'fixed_mode':True,'fixed_started':True,'running':True,
           'rate_enabled':False,'rate_cpm':2.0,'sp':20.2}
        with self.assertRaisesRegex(ChamberSafetyError,'设定值回读不一致'):
            require_step_setpoint_ack(d,-15.,-15.,require_direct_sp_target=True)
        d['sp']=-15.
        self.assertIn('原温补逻辑',require_step_setpoint_ack(
            d,-15.,-15.,require_direct_sp_target=True))

    def test_preparation_ack_rejects_rate_on(self):
        from chamber_auto_guard import require_step_setpoint_ack, ChamberSafetyError
        d={'fixed_mode':True,'fixed_started':True,'running':True,
            'rate_enabled':True,'rate_cpm':2.0,'sp':15.}
        with self.assertRaisesRegex(ChamberSafetyError,'关闭'):
            require_step_setpoint_ack(d,-15.,-15.)

if __name__=='__main__':unittest.main()
