# -*- coding: utf-8 -*-
"""Run with: python -m unittest discover -s tests_post_thermal -v

100% synthetic experiment data, using a frozen model from an actual research
parameter file only to check its schema. Tests NEVER contact devices.
"""
import json
import math
import tempfile
import unittest
from pathlib import Path

import numpy as np

from post_thermal_qa import (ValidationError, _summary, evaluate_records, execute,
                              load_frozen, static_roll_pitch)
from production_cycle_analysis import forward_matrix
from production_cycle_protocol import generate_temperature_plan, PROTOCOL
from wk_r2_engine.wk_joint_offline_R2 import ref_acc, ref_gyro


class TestQA(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.m3 = [0.17626707796413937, 0.022767690605106992]
        # exact same mathematical structures as production; synthetic coefficient values
        # keep forward Jacobian nonsingular everywhere. Models must *not* be refitted.
        zero12 = [[0.] * 12 for _ in range(3)]
        for i in range(3):
            zero12[i][i] = 1.0
        zero16 = [[0.] * 16 for _ in range(3)]
        for i in range(3):
            zero16[i][i] = 1.0
        self.acc = dict(id='T0-D2', sensor='acc', coeff=zero12,
                        phase=False,input_id='T0', input_transform={'id':'T0','kind':'raw_chip'},
                        columns=[12]*3, center_c=22.5,scale_c=62.5,
                        temperature_domain_c=[-21.,19.],raw_units='g')
        self.gyro = dict(id='T0-SEG2_0',sensor='gyro',coeff=zero16,
                         phase=False,input_id='T0',input_transform={'id':'T0','kind':'raw_chip'},
                         columns=[16]*3, center_c=22.5,scale_c=62.5,
                         temperature_domain_c=[-21.,19.],raw_units='deg/s')
        self.parameters = self.root/'统一温补研究参数_未经生产批准.json'
        self.research = self.root/'全量研究结果_不得直接烧录.json'
        params = {'acc':self.acc,'gyro':self.gyro,'coordinate_frame':'software P'}
        result = {'device_sn':'DTS_DEMO_01','batch_id':'FIT_BATCH',
                  'models':{'acc':{'model':self.acc},'gyro':{'model':self.gyro}},
                  'geometry':{'selected':{'name':'M3','params_deg':self.m3}}}
        self.parameters.write_text(json.dumps(params),encoding='utf-8')
        self.research.write_text(json.dumps(result),encoding='utf-8')
        self.provenance=load_frozen(self.parameters,self.research)

    def tearDown(self):
        self.tmp.cleanup()

    def _make_data(self, name='FIT_BATCH', mismatch_sn=False, outside=False):
        plan_w = generate_temperature_plan('warming',-20,20,1)
        plan_c = generate_temperature_plan('cooling',-20,20,1)
        assert plan_w['temperature_setpoints_c'] and plan_c['temperature_setpoints_c']
        root=self.root/'raw'
        root.mkdir(exist_ok=True)
        for d,plan in [('warming',plan_w),('cooling',plan_c)]:
            rows=[]
            for sp in (-15.,-5.,5.,15.):
                if outside and sp == 15.: temp=24.0
                else: temp=sp
                for k,(outer,inner) in enumerate([(25.,0.),(-30.,90.),(45.,-60.)]):
                    r={'sensor':'acc','mode':'static','split':'validate',
                       'temperature_split':'validate','temperature_target_c':sp,
                       'temperature_mean_c':temp,'outer_actual_mean_deg':outer,
                       'inner_actual_mean_deg':inner,'step_id':f'ACC_{sp}_{k}'}
                    ref=ref_acc([r],*self.m3)[0]
                    F,b=forward_matrix(self.acc,{**r,'reference':ref.tolist(),'_direction':d})
                    r['acc_raw_mean_g']=(F@ref+b).tolist()
                    rows.append(r)
                    r={'sensor':'gyro','mode':'dynamic','split':'validate',
                       'temperature_split':'validate','temperature_target_c':sp,
                       'temperature_mean_c':temp,'outer_actual_mean_deg':outer,
                       'inner_actual_mean_deg':inner,'outer_rate_mean_dps':0.8,
                       'inner_rate_mean_dps':0.2,'step_id':f'GYRO_{sp}_{k}'}
                    phi=math.radians(inner)
                    nominal=[math.cos(phi)*0.8,-math.sin(phi)*0.8,0.2]
                    ref=ref_gyro([{**r,'reference':nominal}],self.m3[1])[0]
                    F,b=forward_matrix(self.gyro,{**r,'reference':ref.tolist(),'_direction':d})
                    r['gyro_raw_mean_dps']=(F@ref+b).tolist()
                    # For reference projection, ref_gyro uses the source baseline
                    r['reference']=nominal
                    rows.append(r)
            sub=root/('THERM_'+d)
            sub.mkdir()
            config={'production_scan_direction':d,'production_protocol':PROTOCOL,
                    'production_min_c':-20.0,'production_max_c':20.0,
                    'production_cycle_count':1,
                    'temperature_setpoints_c':plan['temperature_setpoints_c'],
                    'temperature_split':plan['temperature_split'],
                    'device_sn':'WRONG_SN' if mismatch_sn else 'DTS_DEMO_01',
                    'production_batch_id':name,'imu_sensor_config':{'fs':'test'}}
            (sub/'experiment_config.json').write_text(json.dumps(config),encoding='utf-8')
            (sub/'temperature_measurements.json').write_text(json.dumps({
                 'status':'COMPLETED','rows':rows,'imu_queue_drops':0,
                 'chamber_shutdown':{'confirmed':True,'manual_mode':False}}),encoding='utf-8')
        return root

    def test_models_matched_and_identity_recovery(self):
        root=self._make_data()
        dest, summary, manifest = execute(root,self.parameters,self.research,'01')
        self.assertTrue((dest/'报告.html').is_file())
        self.assertEqual(summary['counts']['acc']['used'],24)
        self.assertEqual(summary['counts']['gyro']['used'],24)
        self.assertLess(summary['acc_vector_mg']['rmse'],0.00001)
        self.assertLess(summary['gyro_vector_dps']['rmse'],1e-9)
        self.assertEqual(manifest['source']['source_kind'],'ORIGINAL_HOLDOUT')

    def test_02_reuses_same_static_postures(self):
        root=self._make_data()
        dest,s,m=execute(root,self.parameters,self.research,'02')
        self.assertEqual(s['pitch_deg']['count'],24)
        self.assertEqual(s['roll_deg']['count'],24)
        self.assertLess(s['roll_deg']['rmse'],1e-7)
        self.assertLess(s['pitch_deg']['rmse'],1e-7)
        self.assertNotIn('gyro',s['counts'])

    def test_new_batch_is_marked_as_new(self):
        root=self._make_data(name='NEW_BATCH')
        dest,s,m=execute(root,self.parameters,self.research,'01')
        self.assertEqual(m['source']['source_kind'],'NEW_BATCH_VALIDATION')

    def test_board_mismatch_fails_closed(self):
        root=self._make_data(mismatch_sn=True)
        with self.assertRaisesRegex(ValidationError,'PCB不一致'):
            execute(root,self.parameters,self.research,'01')

    def test_coefficients_crossfile_mismatch_fails(self):
        source=json.loads(self.parameters.read_text('utf-8'))
        source['acc']['coeff'][0][0] += .1
        self.parameters.write_text(json.dumps(source),encoding='utf-8')
        with self.assertRaisesRegex(ValidationError,'不一致'):
            load_frozen(self.parameters,self.research)

    def test_outside_over_ten_percent_fails(self):
        root=self._make_data(outside=True)
        with self.assertRaisesRegex(ValidationError,'超过10%'):
            execute(root,self.parameters,self.research,'02')

    def test_roll_singularity_is_not_scored(self):
        roll,pitch=static_roll_pitch([1.,0.,0.])
        self.assertIsNone(roll)
        self.assertAlmostEqual(pitch,-90.)

    def test_empty_summary(self):
        self.assertEqual(_summary([])['count'],0)
        self.assertIsNone(_summary([])['rmse'])


if __name__=='__main__':
    unittest.main()
