# -*- coding: utf-8 -*-
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
class TestUiSimplification(unittest.TestCase):
    def test_entry_open_04(self):
        main=(ROOT/'main.py').read_text('utf-8')
        self.assertIn('QStackedWidget(unified)',main)
        self.assertIn("addTab(unified,'温补后验收 01～06')",main)
        self.assertIn("select_post_thermal('04')",main)
        self.assertIn('stack.setCurrentWidget(form_post_ramp.page)',main)
        self.assertIn("('03','全温动态倾角精度'",main)
        self.assertIn("('05','六轴残余对齐'",main)
        self.assertIn("('06','温度循环重复性'",main)
    def test_04_autofill_and_advanced(self):
        form=(ROOT/'form/form_post_thermal_ramp.py').read_text('utf-8')
        self.assertIn('self._autofill_from_parameters()',form)
        self.assertIn("'全量研究结果_不得直接烧录.json'",form)
        self.assertIn("'04_连续变温验证记录'",form)
        self.assertIn('self.advanced_group.setVisible(False)',form)
        self.assertIn('self.sn.setText(sn)',form)
    def test_01_02_link(self):
        form=(ROOT/'form/form_post_thermal_qa.py').read_text('utf-8')
        self.assertIn('self._go_to_04',form)
        self.assertIn('self.advanced_group.setVisible(False)',form)
if __name__=='__main__': unittest.main()
