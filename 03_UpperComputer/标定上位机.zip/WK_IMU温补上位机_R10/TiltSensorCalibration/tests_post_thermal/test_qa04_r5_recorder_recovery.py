# -*- coding: utf-8 -*-
"""04 recorder regression: empty polls must not stop recording; root cause retained.

Executes the *production* recorder methods extracted from the Qt class, with
hardware/UI dependencies substituted. No PLC, IMU, or turntable is accessed.
"""
import ast
import datetime as dt
import math
from pathlib import Path
import sys
import threading
import time
import types
import unittest
from unittest.mock import patch

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
FORM=ROOT/'form/form_thermal_compensation.py'
FORM04=ROOT/'form/form_post_thermal_ramp.py'

def method(path,name,namespace):
    cls=next(n for n in ast.parse(path.read_text(encoding='utf-8')).body
             if isinstance(n,ast.ClassDef) and n.name in ('FormThermalCompensation','FormPostThermalRamp'))
    n=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name)
    exec(compile(ast.Module(body=[n],type_ignores=[]),str(path),'exec'),namespace)
    return namespace[name]

CLOCK=types.SimpleNamespace(t=100.)
FAKE_IMU=types.SimpleNamespace(data_lock=threading.Lock(),data_update_count=123,
    is_data_valid=False, temp_c=18.7,acc_g_arr=[[0.,0.,1.]]*16,
    gyr_dps_arr=[[.01,.02,.03]]*16)
G={'time':types.SimpleNamespace(monotonic=lambda:CLOCK.t,time=lambda:1777777777.),
   'np':np,'math':math,'tiltSensorRawData':FAKE_IMU,
   'QMessageBox':types.SimpleNamespace(critical=lambda *args: (_ for _ in ()).throw(AssertionError('unwanted modal popup')))}
TICK=method(FORM,'_r5_ramp_tick',G)
H={'time':types.SimpleNamespace(monotonic=lambda:CLOCK.t),
   'ValidationError':ValueError,'math':math,'dt':dt}
MONITOR=method(FORM04,'_monitor',H)

class Writer:
    def __init__(self,fail=False):self.rows=[];self.fail=fail
    def writerow(self,row):
        if self.fail:raise OSError('硬盘写入失败 TEST')
        self.rows.append(dict(row))

class R5:
    def __init__(self,fail_write=False):
        self.writer=Writer(fail_write)
        self.ramp_info=types.SimpleNamespace(setText=lambda _x:None)
        self.messages=[]
        self._r5_ramp_last_error=None
        self._r5_ramp_last_stop_reason=None
        self._r5_ramp={'count':0,'last_counter':122,'last_sample':0.,
            'last_new':CLOCK.t,'sn':'ABC','batch':'QA04','qa04_owned':True,
            'writer':self.writer,'last_plc_pv':19.8,'file':types.SimpleNamespace(flush=lambda:None)}
        self.failed=False
    def _valid_device(self):
        if self.failed:raise ValueError('IMU串口断线 TEST')
    def _stopped(self):return True
    def _require_plc(self,now):return {'pv':19.8,'running':True}
    def _stop_r5_ramp(self,reason):
        self._r5_ramp_last_stop_reason=reason
        self._r5_ramp=None
    def _log(self,txt):self.messages.append(txt)
    def tick(self):TICK(self)

class RecorderTests(unittest.TestCase):
    def setUp(self):
        CLOCK.t=100.
        FAKE_IMU.data_update_count=123
        FAKE_IMU.is_data_valid=False
        FAKE_IMU.acc_g_arr=[[0.,0.,1.]]*16
        FAKE_IMU.gyr_dps_arr=[[.01,.02,.03]]*16
    def test_transient_empty_poll_while_new_valid_frame_exists_is_recorded(self):
        r=R5()
        # The serial reader can set flag=False after it already committed
        # a genuinely new valid frame (counter=123).
        r.tick()
        self.assertIsNotNone(r._r5_ramp)
        self.assertEqual(len(r.writer.rows),1)
        self.assertEqual(r.writer.rows[0]['frame_count'],123)
    def test_empty_poll_with_no_new_valid_frame_does_not_duplicate_sample(self):
        r=R5();r.tick()
        CLOCK.t+=1.2
        FAKE_IMU.is_data_valid=False
        r.tick()
        self.assertEqual(len(r.writer.rows),1)
        self.assertIsNotNone(r._r5_ramp)
    def test_actual_imu_failure_stops_and_retains_exact_reason(self):
        r=R5();r.failed=True;r.tick()
        self.assertIsNone(r._r5_ramp)
        self.assertIn('IMU串口断线 TEST',r._r5_ramp_last_error)
        self.assertTrue(any('原始原因' in s for s in r.messages))
    def test_csv_write_failure_stops_with_io_error(self):
        r=R5(fail_write=True);r.tick()
        self.assertIsNone(r._r5_ramp)
        self.assertIn('硬盘写入失败 TEST',r._r5_ramp_last_error)
    def test_bad_six_axis_array_stops_instead_of_saving_bad_data(self):
        r=R5();FAKE_IMU.acc_g_arr=[];r.tick()
        self.assertIsNone(r._r5_ramp)
        self.assertIn('六轴数组结构异常',r._r5_ramp_last_error)
        self.assertFalse(r.writer.rows)

class QA04:
    def __init__(self,reason):
        self.fail=None
        self.thermal=types.SimpleNamespace(_valid_device=lambda:None,
            _stopped=lambda:True,_r5_ramp=None,
            _r5_ramp_last_error=reason,_r5_ramp_last_stop_reason='异常终止')
        self.live={'started':0.,'stage':'DOWN','stage_started':99.,
            'max_seconds':300000.,'auto_plc':True,
            'plan_low':-15.,'plan_high':15.,
            'imu_count':10,'last_imu_change':CLOCK.t,'model_lo':-20.,'model_hi':20.,
            'model_outside_observations':0,'model_outside_noted':False,
            'observed_chip_min_c':15.,'observed_chip_max_c':15.}
    def _read_chip(self):return 15.,10
    def _fail(self,reason):self.fail=str(reason)
    def _append(self,txt):pass

class ReasonPropagationTests(unittest.TestCase):
    def test_real_collector_reason_is_shown_by_04_not_generic_only(self):
        CLOCK.t=100.
        q=QA04('ValueError: IMU连续5秒没有新有效帧')
        m=types.ModuleType('chamber_fixed_control')
        m.require_chamber_ready=lambda now:{'pv':17.,'running':True}
        with patch.dict(sys.modules,{'chamber_fixed_control':m}):MONITOR(q)
        self.assertIn('IMU连续5秒没有新有效帧',q.fail)
        self.assertIn('R5采集器已停止',q.fail)

if __name__=='__main__':unittest.main()
