# -*- coding: utf-8 -*-
"""Fail-closed checks for the *existing, field-proven* Snap7 temperature controller.

No PLC I/O is performed here. Snapshot health is intentionally tested
independently of PySide6 or proprietary DLLs.
"""
import math


class ChamberSafetyError(ValueError):
    pass


def require_live_chamber(snapshot, now, *, maximum_age=15.0):
    """Reject stale temperatures/status, faults and a disconnected PLC.

    `snapshot` holds monotonic timestamps stamped after successful PLC reads.
    Do not infer freshness from successful TCP connection alone.
    """
    if not snapshot['connected'] or not snapshot['data_available'] or snapshot['pv_failed']:
        raise ChamberSafetyError('温箱PLC断线或PV读取失败')
    for field, timestamp in (
        ('PV',snapshot['pv_updated']), ('SP',snapshot['sp_updated']),
        ('报警',snapshot['alarm_updated']), ('故障',snapshot['fault_updated']),
        ('运行',snapshot['run_updated']), ('定值启动',snapshot['started_updated']),
        ('运行模式',snapshot['mode_updated'])):
        if not math.isfinite(float(timestamp)) or timestamp<=0 or now-timestamp>maximum_age or timestamp>now+1:
            raise ChamberSafetyError(f'温箱{field}反馈过期/无效（禁止使用缓存值）')
    pv, sp = snapshot['pv'], snapshot['sp']
    if not math.isfinite(float(pv)) or not -45<=pv<=110:
        raise ChamberSafetyError('温箱PV异常或超出核对范围')
    if not math.isfinite(float(sp)) or not -45<=sp<=110:
        raise ChamberSafetyError('温箱SP异常或超出核对范围')
    if bool(snapshot['fault']) or snapshot['alarm'] != 0:
        raise ChamberSafetyError(f'温箱故障/报警：{snapshot["alarm"]}')
    return True


def require_setpoint_ack(snapshot, target, *, tolerance=0.2):
    """Readback acknowledgement is mandatory before waiting for chamber PV."""
    if abs(float(snapshot['sp'])-float(target))>tolerance:
        raise ChamberSafetyError(f'温箱设定值回读不一致：目标{target:.2f}，回读{snapshot["sp"]:.2f}℃')
    if not snapshot['fixed_mode']:
        raise ChamberSafetyError('PLC尚未进入定值模式')
    if not snapshot['fixed_started'] or not snapshot['running']:
        raise ChamberSafetyError('温箱未确认进入运行状态')
    return True


def require_ramped_setpoint_ack(snapshot, target, sp_before, command_echo, *,
                                command_tolerance=0.11, process_tolerance=0.25,
                                min_progress=0.075):
    """QA04 only. Accept verified command + PLC running + directional SP ramp.

    VW2110 is the final commanded target; VW2106 is the intermediate process SP.
    VW2106 may take minutes to reach VW2110 under the PLC ramp-rate setting.
    This guard is deliberately not used by the existing steady-temperature R10
    workflow; it MUST NOT make the legacy fixed-SP acknowledgement lenient.

    The caller separately checks fresh post-command telemetry, PLC alarms and
    fault status and reads VW2110 live over the existing synchronized connection.
    """
    if command_echo is None or not math.isfinite(float(command_echo)):
        raise ChamberSafetyError('PLC目标命令字VW2110未成功回读；不能确认目标设温')
    target = float(target)
    if abs(float(command_echo)-target)>command_tolerance:
        raise ChamberSafetyError(
            f'PLC目标命令字未确认：目标{target:.2f}℃，VW2110回读{float(command_echo):.2f}℃')
    if not snapshot['fixed_mode']:
        raise ChamberSafetyError('PLC尚未进入定值模式')
    if not snapshot['fixed_started'] or not snapshot['running']:
        raise ChamberSafetyError('PLC尚未确认定值启动及设备运行')
    process = float(snapshot['sp'])
    if not math.isfinite(process):
        raise ChamberSafetyError('过程SP VW2106无效')
    if abs(process-target)<=process_tolerance:
        return '目标寄存器已确认；过程SP已经达到目标附近'
    if sp_before is None or not math.isfinite(float(sp_before)):
        raise ChamberSafetyError('缺少发令前的过程SP基准，无法核实斜坡方向')
    baseline=float(sp_before)
    delta=target-baseline
    if abs(delta)<=process_tolerance:
        # Command is unchanged but process SP has deviated: do not approve an
        # unrelated ramp as proof that the command was applied.
        raise ChamberSafetyError('目标虽与发令前过程SP接近，但新的过程SP已偏离目标')
    direction=1.0 if delta>0 else -1.0
    moved=direction*(process-baseline)
    if moved < min_progress:
        raise ChamberSafetyError(
            f'目标已写入，但过程SP尚未朝目标变化：发令前{baseline:.2f}℃，'
            f'当前{process:.2f}℃，目标{target:.2f}℃')
    if direction*(process-target)>process_tolerance:
        raise ChamberSafetyError('过程SP越过目标温度，需核查速率控制状态')
    return (f'目标寄存器已确认；过程SP正朝目标变化：'
            f'{baseline:.2f}→{process:.2f}→{target:.2f}℃')


def require_step_setpoint_ack(snapshot, target, command_echo, *, command_tolerance=0.11,
                              expected_rate_enabled=False, expected_rate_cpm=None,
                              require_direct_sp_target=False,
                              allow_zero_rate_readback=False):
    """QA04 endpoint target ACK, with stage-appropriate PLC rate-mode check.

    VW2110 is the final target; VW2106 is merely internal process SP, which
    may ramp smoothly while PLC rate mode is enabled.  Preparation requires
    rate OFF; measured legs require rate ON with the requested rate.  Endpoint
    reach is *only* determined by chamber PV in the caller's state machine.

    With preparation's ordinary fixed-SP mode, the original R10 temperature
    compensation requires SP(VW2106) itself to equal the requested target.
    Do not infer a successful preparation from the writable VW2110 echo alone.
    """
    if command_echo is None or not math.isfinite(float(command_echo)):
        raise ChamberSafetyError('PLC最终目标VW2110未成功回读')
    target=float(target)
    if abs(float(command_echo)-target)>command_tolerance:
        raise ChamberSafetyError(f'PLC最终目标回读不一致：目标{target:.2f}℃，VW2110={float(command_echo):.2f}℃')
    if not snapshot['fixed_mode']:
        raise ChamberSafetyError('PLC未进入定值模式')
    if not snapshot['fixed_started'] or not snapshot['running']:
        raise ChamberSafetyError('PLC未确认定值启动和设备运行')
    rate_enabled=snapshot.get('rate_enabled')
    if rate_enabled is not expected_rate_enabled:
        state='开启' if expected_rate_enabled else '关闭'
        raise ChamberSafetyError(f'定值速率开关尚未确认{state}：{rate_enabled!r}')
    zero_rate_echo_trial=False
    if expected_rate_enabled and expected_rate_cpm is not None:
        actual=snapshot.get('rate_cpm')
        rate_matched=(actual is not None and math.isfinite(float(actual)) and
            abs(float(actual)-float(expected_rate_cpm))<=0.051)
        zero_rate_echo_trial=(bool(allow_zero_rate_readback) and not rate_matched and
            actual is not None and math.isfinite(float(actual)) and
            abs(float(actual))<=0.001)
        if not (rate_matched or zero_rate_echo_trial):
            raise ChamberSafetyError(f'PLC速率回读未确认：目标{float(expected_rate_cpm):.1f}℃/min，回读{actual!r}')
    if require_direct_sp_target:
        if expected_rate_enabled:
            raise ChamberSafetyError('普通定值起点要求关闭定值速率')
        # Exactly the same SP/mode/start/run acceptance as normal R10.
        require_setpoint_ack(snapshot, target)
        return (f'VW2110目标已确认；VW2106过程SP已按原温补逻辑确认为'
                f'{float(snapshot["sp"]):.2f}℃；速率模式关闭；定值运行已确认')
    mode='开启' if expected_rate_enabled else '关闭'
    caveat=('；警告：速率回读0.0，已按现场试验豁免，'
            '不能据此认定设定速率生效' if zero_rate_echo_trial else '')
    return (f'VW2110固定目标已确认；速率模式{mode}；PLC正在运行{caveat}；'
            f'过程SP={float(snapshot["sp"]):.2f}℃（正式斜坡需另外验证变化方向）')


def require_pv_progress(baseline_pv, current_pv, target, tolerance, elapsed_s, *,
                        window_s=900.0, minimum_progress_c=0.3):
    """Detect a physical chamber PV that is unresponsive, not a mere write ACK.

    A full 15-minute rolling window is allowed (initial plant inertia and
    refrigeration/compressor startup).  Only a *far* endpoint is checked;
    within the configured arrival tolerance the endpoint gate takes over.
    """
    for val in (baseline_pv,current_pv,target,tolerance,elapsed_s):
        if not math.isfinite(float(val)):
            raise ChamberSafetyError('温箱PV响应监测收到无效数据')
    if abs(float(current_pv)-float(target))<=float(tolerance):
        return True
    if abs(float(baseline_pv)-float(target))<=max(3.,2.*float(tolerance)):
        return True
    if float(elapsed_s)<float(window_s):
        return True
    direction=1.0 if float(target)>float(baseline_pv) else -1.0
    progress=direction*(float(current_pv)-float(baseline_pv))
    if progress<minimum_progress_c:
        raise ChamberSafetyError(
            f'温箱实际PV连续{float(window_s)/60:.0f}分钟未朝目标有效变化：'
            f'基准PV={float(baseline_pv):.2f}℃，当前PV={float(current_pv):.2f}℃，'
            f'目标={float(target):.2f}℃，方向进展={progress:+.2f}℃。'
            '即使PLC命令字/运行位正确，也不能判定温箱已控温；'
            '请现场检查面板SP、制冷/加热、远程控制授权及故障状态')
    return True
