# ---------------------------------------------------------------------------
# 本机WMI异常保护：
# platform.system()/uname() 默认先走WMI查询(platform._wmi_query -> _wmi.exec_query)，
# 本机该查询会卡死(实测>15秒不返回)，凡是调用它的第三方库(如snap7)在导入时都会
# 一起卡住，导致主界面窗口出不来。这里把WMI查询置为"不支持"，等价于Python在
# 未安装_wmi模块时的行为，platform会自动回退到 sys.getwindowsversion()，
# 结果不变且不再依赖WMI。若本机WMI恢复正常，删掉这段保护也不影响功能。
# ---------------------------------------------------------------------------
import platform as _platform_guard
if hasattr(_platform_guard, '_wmi_query'):
    def _wmi_query_disabled(*args, **kwargs):
        raise OSError("not supported")
    _platform_guard._wmi_query = _wmi_query_disabled

from pathlib import Path
import os
import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QStackedWidget, QLabel, QGridLayout
from PySide6.QtUiTools import QUiLoader

# 保持历史模块使用的相对配置与 DLL 路径，同时支持从 IDE / 任意目录启动。
PROJECT_DIR = Path(__file__).resolve().parent
os.chdir(PROJECT_DIR)
for subdir in ("form", "tilt_sensor", "turntable", "temperature_chamber", "tilt_sensor_calibration", "debug", "ellipsoid", "lm", "acc_tdc"):
    path = str(PROJECT_DIR / subdir)
    if path not in sys.path:
        sys.path.insert(0, path)

from form_turntable_ctrl import FormTurntableCtrl
from form_tc import FormTc
from form_tilt_sensor_cal import FormTiltSensorCal
from form_imu_calibration import FormImuCalibration
from form_thermal_compensation import FormThermalCompensation
from form_post_thermal_qa import FormPostThermalQA
from form_post_thermal_ramp import FormPostThermalRamp


def _remove_page(tab_widget, page):
    """从导航中摘掉遗留页（不销毁 widget，旧模块仍可安全取到相应对象）。"""
    index = tab_widget.indexOf(page)
    if index >= 0:
        tab_widget.removeTab(index)


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setFont(QFont("Microsoft YaHei UI", 9))
    ui = QUiLoader().load(str(PROJECT_DIR / "ui" / "mainWindow.ui"))
    if ui is None:
        raise RuntimeError("无法加载 ui/mainWindow.ui")

    # 恢复原软件紧凑尺寸；不强制扩大为 1460x900。
    ui.setFixedSize(1144, 723)
    ui.setWindowFlags(ui.windowFlags() & ~Qt.WindowCloseButtonHint)

    # 初始化所有仍在使用的底层设备模块，保留原串口/转台/温箱通信能力。
    form_turntable_ctrl = FormTurntableCtrl(ui)
    form_tc = FormTc(ui)
    form_tilt_sensor_cal = FormTiltSensorCal(ui)
    form_imu_calibration = FormImuCalibration(ui, form_turntable_ctrl)
    form_thermal = FormThermalCompensation(ui, form_turntable_ctrl, form_imu_calibration)
    form_post_qa = FormPostThermalQA(ui)  # 01/02 冻结参数离线验收；不操作转台/温箱
    form_post_ramp = FormPostThermalRamp(ui, form_thermal, form_post_qa)  # 04 冻结模型静止斜坡；复用R5被动采集
    # Unified 01-06 acceptance workbench. 03/05/06 are clearly marked
    # non-operational placeholders, never hidden behind misleading buttons.
    unified = QWidget()
    unified.setObjectName('page_PostThermalUnified')
    u_layout=QVBoxLayout(unified)
    nav=QGridLayout()
    selectors={}
    for position,number,name in (
            (0,'01','冻结参数复验'),(1,'02','静态倾角复核'),
            (2,'03','动态倾角精度'),(3,'04','连续变温漂移'),
            (4,'05','六轴残余对齐'),(5,'06','温度循环重复性')):
        btn=QPushButton(f'{number}｜{name}'+('（待开发）' if number in ('03','05','06') else ''))
        btn.setObjectName(f'post_thermal_test_{number}')
        btn.setMinimumHeight(31)
        nav.addWidget(btn,position//3,position%3)
        selectors[number]=btn
    u_layout.addLayout(nav)
    stack=QStackedWidget(unified)
    stack.addWidget(form_post_qa.page)
    stack.addWidget(form_post_ramp.page)
    placeholders={}
    for number,name,reason in (
        ('03','全温动态倾角精度','尚未接入最终动态Roll/Pitch融合输出，不能把GYRO测量误差冒充动态倾角精度。'),
        ('05','六轴残余对齐','待开发残余旋转角辨识及独立运动数据验证；现有0.01337/s不能直接当轴间夹角。'),
        ('06','温度循环重复性','待把现有R8温度循环任务改为固定参数、不重新拟合的重复性验收流程。')):
        page=QWidget()
        page.setObjectName(f'page_post_thermal_{number}_planned')
        v=QVBoxLayout(page)
        label=QLabel(f'{number}｜{name}\n\n状态：待开发，当前按钮不会发送WK/PLC/IMU命令。\n\n{reason}')
        label.setWordWrap(True)
        label.setStyleSheet('font-size:14px; padding:28px;')
        v.addWidget(label)
        v.addStretch()
        stack.addWidget(page)
        placeholders[number]=page
    u_layout.addWidget(stack)
    def select_post_thermal(number):
        if number in ('01','02'):
            stack.setCurrentWidget(form_post_qa.page)
        elif number=='04':
            stack.setCurrentWidget(form_post_ramp.page)
        else:
            stack.setCurrentWidget(placeholders[number])
    for number,button in selectors.items():
        button.clicked.connect(lambda _checked=False,num=number:select_post_thermal(num))
    form_post_qa._open_04=lambda:select_post_thermal('04')
    form_post_qa._ramp=form_post_ramp
    # One selected calibration file is shared between 01/02 and 04.
    def share_to_ramp(path):
        if path and form_post_ramp.parameters.text()!=path:
            form_post_ramp.parameters.setText(path)
            form_post_ramp._autofill_from_parameters()
    def share_to_qa(path):
        if path and form_post_qa.parameter.text()!=path:
            form_post_qa.parameter.setText(path)
            form_post_qa._autofill_research()
    form_post_qa.parameter.textChanged.connect(share_to_ramp)
    form_post_ramp.parameters.textChanged.connect(share_to_qa)
    select_post_thermal('04')
    ui.tabWidget_CalMain.addTab(unified,'温补后验收 01～06')
    # MCU UID 只由原串口采集线程读取；界面收到 DTS 编号后自动填充两处 PCB 编号。
    # 任务进行期间不改写编号，避免本次标定/温补的记录关联到另一块PCB。
    form_tilt_sensor_cal.register_device_sn_field(
        form_imu_calibration.line_device_sn,
        lambda: bool(form_imu_calibration.recording or form_imu_calibration._auto_task is not None),
    )
    form_tilt_sensor_cal.register_device_sn_field(
        form_thermal.sn,
        lambda: form_thermal.task is not None,
    )

    # 六轴 IMU 工作区优先：不再向用户暴露柔性测斜仪阵列、FTP、温漂计算等历史入口。
    # 注意：旧控件并未销毁，避免历史业务代码访问已删除的 QObject。
    # 数据预览区只保留“实时数据”和“数据记录”两个页面；
    # 校准计算 / 温漂补偿 / FTP / 故障统计控件已从 .ui 中移除。
    _remove_page(ui.tabWidget_CalMain, ui.tab_18)  # 旧版柔性测斜仪自动校准入口

    tabbar = ui.tabWidget_CalMain.tabBar()
    imu_index = ui.tabWidget_CalMain.indexOf(form_imu_calibration.page)
    if imu_index >= 0:
        tabbar.moveTab(imu_index, 0)
    # One unified module: do not expose separate 01/02 or 04 top-level tabs.
    qa_index=ui.tabWidget_CalMain.indexOf(unified)
    if qa_index>=0:
        ui.tabWidget_CalMain.tabBar().moveTab(qa_index,1)
        ui.tabWidget_CalMain.setCurrentWidget(unified)
    else:
        ui.tabWidget_CalMain.setCurrentWidget(form_imu_calibration.page)
    ui.tabWidget_AccDataManual.setCurrentWidget(ui.tab_AccData)

    # 正常退出时务必关闭实验 CSV / 释放记录队列。
    app.aboutToQuit.connect(form_post_ramp.shutdown)
    app.aboutToQuit.connect(form_thermal.shutdown)
    app.aboutToQuit.connect(form_imu_calibration.shutdown)
    ui.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
