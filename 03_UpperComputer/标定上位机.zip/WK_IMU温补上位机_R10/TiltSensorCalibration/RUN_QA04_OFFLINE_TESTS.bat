@echo off
setlocal
cd /d "%~dp0"
py -3 -m unittest discover -s tests_post_thermal -v
if errorlevel 1 (
    echo [FAILED] QA01/02/04 offline tests failed.
    pause
    exit /b 1
)
echo [PASS] QA01/02/04 offline tests finished.
pause
