# -*- coding: utf-8 -*-
"""固定硬件的陀螺仪: 无界面选项、无启动提示；实际驱动统一换算。"""
import ast
from pathlib import Path
from threading import RLock
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
thermal = (ROOT/'form/form_thermal_compensation.py').read_text(encoding='utf-8')
ambient = (ROOT/'form/form_imu_calibration.py').read_text(encoding='utf-8')
assert 'self.expected_gyro_fs' not in thermal, '温补页面仍提供可选配置'
assert 'gyro_fs_note' not in thermal, '温补页面仍包含多余提示'
assert '量程未核验：允许试运行' not in ambient, '常温标定仍有旧提示'
ambient_tree = ast.parse(ambient)
ambient_class = next(x for x in ambient_tree.body if isinstance(x,ast.ClassDef) and x.name == 'FormImuCalibration')
start_method = next(x for x in ambient_class.body if isinstance(x,ast.FunctionDef) and x.name == '_start_auto_task')
assert 'QMessageBox.information' not in ast.get_source_segment(ambient,start_method), '标定启动仍会弹信息窗'
assert 'GYRO ±' not in ambient

source = ROOT/'tilt_sensor/tilt_sensor_asm330_data_get.py'
tree = ast.parse(source.read_text(encoding='utf-8-sig'))
fn_node = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == 'tilt_sensor_raw_data_process')
module = ast.Module(body=[fn_node], type_ignores=[])
ast.fix_missing_locations(module)
state = SimpleNamespace(
    data_lock=RLock(), acc_fs_ever_valid=False,gyro_fs_ever_valid=False,
    gyro_fs=250,acc_fs=8,data_update_count=0,is_data_valid=False)
seen=[]
ns={
    'tiltSensorRawData':state,'INC_SAMPLE_NUM':16,'GYRO_FS_DEFAULT':250,
    'ACC_FS_DEFAULT':8,'acc_fs_is_valid':lambda v:v in (2,4,8,16),
    'accel_raw_to_g':lambda raw,fs:raw * 0.000244,
    'gyro_raw_to_dps':lambda raw,fs:(seen.append(fs) or raw*0.00875),
    'temp_raw_to_celsius':lambda t:t/256+25,
}
exec(compile(module,str(source),'exec'),ns)
for reported in (250,2000,0):
    raw={
        **{n:[100]*16 for n in ('acc_x_raw_arr','acc_y_raw_arr','acc_z_raw_arr','gyr_x_raw_arr','gyr_y_raw_arr','gyr_z_raw_arr')},
        'acc_fs':8,'gyro_fs':reported,'temp_raw':0,'data_unread':0,'tick_ms':100,
        'data_odr':208,'fifo_state':0
    }
    assert ns['tilt_sensor_raw_data_process'](raw) is True
    assert state.gyro_fs==250
    assert all(abs(v-0.875)<1e-12 for v in state.gyr_dps_arr[0])
assert seen and all(v == 250 for v in seen),seen
print('PASS: no range selection/popup; fixed scaling for all incoming register values')
