# -*- coding: utf-8 -*-
"""单档硬件陀螺仪换算、采样元数据与生产放行保护。"""
import copy
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from production_calibration import (load_profile, verify_sensor_config,
    sensor_config_consistent, restrict_unverified_release, validate_profile)
p = load_profile(ROOT)
fallback = {'acc_fs':2,'gyro_fs':250,'acc_fs_ever_valid':False,
    'gyro_fs_ever_valid':False,'data_odr':0}
a = verify_sensor_config(p, fallback)
assert not a['verified_for_release']
assert (a['acc_fs_g'],a['gyro_fs_dps']) == (2,250)
# 不要求固定硬件陀螺仪上报确认；ACC与ODR正常即可确认本次采样配置。
confirmed = verify_sensor_config(p,dict(fallback,acc_fs_ever_valid=True,data_odr=208))
assert sensor_config_consistent(a,confirmed)
assert confirmed['verified_for_release']
assert not sensor_config_consistent(a,verify_sensor_config(p,dict(fallback,acc_fs=8)))
assert not sensor_config_consistent(confirmed,verify_sensor_config(p,dict(fallback,data_odr=416)))
for acc in (2,4,8,16):
    assert verify_sensor_config(p,dict(fallback,acc_fs=acc))['gyro_fs_dps'] == 250
for gyro in (125,500,1000,2000,4000,0,9999):
    try:verify_sensor_config(p,dict(fallback,gyro_fs=gyro))
    except ValueError:pass
    else:raise AssertionError('非当前固定硬件数据被误接受')
result = {'quality_gate':{'metric_pass':True,'verdict':'PASS','approved_for_production':True},
    'combined_calibration':{'release_verdict':'PASS'},'status':'PASS'}
restrict_unverified_release(result,a)
assert result['quality_gate']['verdict']=='PILOT_PASS_NOT_RELEASED'
assert not result['quality_gate']['approved_for_production']
assert result['status']=='PILOT_PASS_NOT_RELEASED'
released={'quality_gate':{'metric_pass':True,'verdict':'PASS','approved_for_production':True},'status':'PASS'}
restrict_unverified_release(released,confirmed)
assert released['status']=='PASS'
bad_p=copy.deepcopy(p)
bad_p['rates']['maximum_command_rate_dps']=100
try:validate_profile(bad_p)
except ValueError:pass
else:raise AssertionError('转台保守限速被绕过')
print('PASS: fixed gyro conversion, no user choice, configuration tracking, motion safety')
