# -*- coding: utf-8 -*-
"""Deterministic per-PCB JSON filenames for calibration artifacts.

The PCB serial is frozen at task start; the MCU UID-derived DTS number is the
source of truth whenever the connected firmware provides one.
"""
import re

_SN = re.compile(r"[A-Za-z0-9._-]{1,64}\Z")


def validate_device_sn(device_sn):
    sn = str(device_sn or "").strip()
    if not _SN.fullmatch(sn):
        raise ValueError("PCB编号不能为空，且只能是1至64位字母、数字、点、下划线或短横线")
    return sn


def device_json_name(device_sn, base_filename):
    """Example: DTS672516 + gyro_calibration.json => DTS672516_gyro_calibration.json."""
    sn = validate_device_sn(device_sn)
    if (not isinstance(base_filename, str) or not base_filename.endswith(".json")
            or "/" in base_filename or "\\" in base_filename or base_filename.startswith(".")):
        raise ValueError("无效的标定JSON基本文件名")
    return f"{sn}_{base_filename}"


def ensure_uid_sn_matches(record_sn, live_uid_sn):
    """A real connected UID takes precedence over editable UI text."""
    sn = validate_device_sn(record_sn)
    live = str(live_uid_sn or "").strip()
    if live and sn != live:
        raise ValueError(f"当前芯片UID对应设备编号为 {live}，但标定页填写的是 {sn}，禁止跨PCB混用")
    return sn


def verify_calibration_identity(result, device_sn):
    sn = validate_device_sn(device_sn)
    if not isinstance(result, dict) or result.get("device_serial") != sn:
        raise ValueError(f"标定JSON内部设备编号与文件名的设备编号 {sn} 不匹配，禁止使用")
    return result
