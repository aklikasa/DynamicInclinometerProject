# -*- coding: utf-8 -*-
"""Offline PCB UID -> JSON names, root isolation and content identity checks."""
import ast
import json
import os
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from device_json_naming import (device_json_name, ensure_uid_sn_matches,
                                verify_calibration_identity)
from model_comparison_report import save_selected_model
from thermal_compensation import save_models

assert device_json_name('DTS672516', 'gyro_calibration.json') == 'DTS672516_gyro_calibration.json'
assert ensure_uid_sn_matches('DTS672516', 'DTS672516') == 'DTS672516'
for candidate in ('../hack', 'DTS6/a', '', 'x'*65):
    try:
        device_json_name(candidate, 'gyro_calibration.json')
        raise AssertionError('Accepted invalid PCB serial: ' + repr(candidate))
    except ValueError:
        pass
try:
    ensure_uid_sn_matches('DTS000001', 'DTS000002')
    raise AssertionError('Mismatch not blocked')
except ValueError:
    pass

src = ROOT / 'form' / 'form_imu_calibration.py'
cls = next(x for x in ast.parse(src.read_text(encoding='utf-8')).body
           if isinstance(x, ast.ClassDef) and x.name == 'FormImuCalibration')
methods = [m for m in cls.body if isinstance(m, ast.FunctionDef)
           and m.name in ('_named_calibration_inputs','_save_calibration_result')]
node = ast.ClassDef(name='Form', bases=[], keywords=[], decorator_list=[], body=methods)
ns={'json':json, 'os':os, 'device_json_name':device_json_name,
    'verify_calibration_identity':verify_calibration_identity}
exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])),str(src),'exec'),ns)

with tempfile.TemporaryDirectory() as folder:
    root=Path(folder)
    f=ns['Form']()
    f.run_dir=str(root/'run1')
    Path(f.run_dir).mkdir()
    f.line_output_root=SimpleNamespace(text=lambda:folder)
    f._manifest={}
    for sn in ('DTS111111','DTS222222'):
        for kind, base in (('accel','accel_calibration.json'),('gyro','gyro_calibration.json')):
            task={'type':kind,'device_serial':sn,'axis_model':'outer_x_inner_z'}
            res={'device_serial':sn,'quality_gate':{'metric_pass':True},'sensor_configuration':{'acc_fs_g':8}}
            f._save_calibration_result(task,res)
            target=root/device_json_name(sn,base)
            assert target.exists(),target
            verify_calibration_identity(json.loads(target.read_text(encoding='utf-8')),sn)
    assert len(list(root.glob('DTS*_calibration.json'))) == 4
    assert not (root/'accel_calibration.json').exists()
    assert tuple(map(Path,f._named_calibration_inputs('DTS111111'))) == (
        root/'DTS111111_accel_calibration.json',root/'DTS111111_gyro_calibration.json')

    # A failed calibration is archived in the run and never overwrites valid root parameters.
    f.run_dir=str(root/'run2');Path(f.run_dir).mkdir()
    task={'type':'gyro','device_serial':'DTS111111','axis_model':'outer_x_inner_z'}
    failed={'device_serial':'DTS111111','quality_gate':{'metric_pass':False}}
    f._save_calibration_result(task,failed)
    assert json.loads((root/'DTS111111_gyro_calibration.json').read_text())['quality_gate']['metric_pass']
    assert (root/'run2'/'DTS111111_gyro_calibration.json').exists()

    # Truncated DTS hash collision guard: same DTS with different raw MCU UID cannot overwrite.
    collision_target=root/'DTS111111_gyro_calibration.json'
    existing=json.loads(collision_target.read_text(encoding='utf-8'))
    existing['device_uid_raw']='0123456789ABCDEF01234567'
    collision_target.write_text(json.dumps(existing),encoding='utf-8')
    try:
        f._save_calibration_result(task, {'device_serial':'DTS111111',
            'device_uid_raw':'FEDCBA9876543210FEDCBA98','quality_gate':{'metric_pass':True}})
        raise AssertionError('MCU UID hash collision allowed to overwrite existing results')
    except ValueError:
        pass

    try:
        f._save_calibration_result(task, {'device_serial':'DTS222222','quality_gate':{'metric_pass':True}})
        raise AssertionError('Mismatched JSON was saved')
    except ValueError:
        pass
    candidate={'device_serial':'DTS111111','model_id':'A'}
    fname=save_selected_model(str(root/'run2'),'acc','A',candidate,'DTS111111')
    assert Path(fname).name=='DTS111111_accel_model_A_candidate.json'

    # Missing thermal data produce named fit-status report; no generic JSON is written.
    therm=root/'therm'
    result=save_models(therm,[],('acc',),1,device_sn='DTS111111')
    assert result['device_serial']=='DTS111111'
    assert (therm/'DTS111111_thermal_fit_status.json').is_file()
    assert not (therm/'thermal_fit_status.json').exists()

print('[PASS] PCB UID SN-prefixed calibration, A/B candidates, thermal status, cross-device isolation')
