﻿param([string]$ProjectRoot = "")
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

Write-Host "CT-07 V1.0 | same-pose repeated automatic re-positioning" -ForegroundColor Cyan
Write-Host "Installer touches CT-07 files, its placeholder, and baseline self-test assertions if still hardcoded." -ForegroundColor Cyan
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Read-Host 'Enter the root folder of DTS_TestPlatform_NET10_V0.6.8 (contains DTS.TestPlatform.sln)'
}
$ProjectRoot = $ProjectRoot.Trim('"').Trim()
if (-not (Test-Path -LiteralPath $ProjectRoot -PathType Container)) {
    throw "Project folder does not exist: $ProjectRoot"
}
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$solution = Join-Path $ProjectRoot 'DTS.TestPlatform.sln'
$testProject = Join-Path $ProjectRoot 'src/Dts.Tests/Dts.Tests.csproj'
$wpfProject = Join-Path $ProjectRoot 'src/Dts.Wpf/Dts.Wpf.csproj'
if (-not (Test-Path -LiteralPath $solution -PathType Leaf) -or
    -not (Test-Path -LiteralPath $testProject -PathType Leaf) -or
    -not (Test-Path -LiteralPath $wpfProject -PathType Leaf)) {
    throw 'Wrong project root: required .sln / Dts.Tests / Dts.Wpf project files are absent.'
}
$srcTests = Join-Path $PSScriptRoot 'src/Dts.Tests/S1/CT07'
$srcWpf = Join-Path $PSScriptRoot 'src/Dts.Wpf/TestWindows/CT07'
if (-not (Test-Path -LiteralPath (Join-Path $srcTests 'CT_07_Test.cs')) -or
    -not (Test-Path -LiteralPath (Join-Path $srcWpf 'CT07Window.xaml'))) {
    throw 'The CT07_Module package is incomplete.'
}
# Validate source identity BEFORE touching an existing installation.
$incoming = Get-Content -LiteralPath (Join-Path $srcTests 'CT_07_Test.cs') -Raw -Encoding UTF8
if ($incoming -notmatch 'class\s+CT_07_Test\s*:\s*TestModuleBase' -or
    $incoming -match 'class\s+CT_03_Test\b' -or
    $incoming -match 'class\s+CT_04_Test\b' -or
    $incoming -notmatch 'public\s+override\s+string\s+TestId\s*=>\s*"CT-07"') {
    throw 'CT-07 package has mismatched C# class name or TestId. Aborting before copying files.'
}
$destTests = Join-Path $ProjectRoot 'src/Dts.Tests/S1/CT07'
$destWpf = Join-Path $ProjectRoot 'src/Dts.Wpf/TestWindows/CT07'
$old = Join-Path $ProjectRoot 'src/Dts.Tests/S1/CT_07_Test.cs'
$backup = Join-Path $ProjectRoot ('_CT07_install_backup_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null

# Do not delete a modified / real implementation accidentally.
if (Test-Path -LiteralPath $old -PathType Leaf) {
    $body = Get-Content -LiteralPath $old -Raw -Encoding UTF8
    if ($body -notmatch 'class\s+CT_07_Test\s*:\s*TestModuleBase' -or
        $body -notmatch 'public\s+override\s+string\s+TestId\s*=>\s*"CT-07"' -or
        $body -match 'IsExecutable\s*=>\s*true') {
        throw "Existing CT_07_Test.cs does not look like the original placeholder; stopping rather than overwriting: $old"
    }
    Copy-Item -LiteralPath $old -Destination (Join-Path $backup 'old_CT_07_Test.cs')
}
if (Test-Path -LiteralPath $destTests -PathType Container) {
    Copy-Item -LiteralPath $destTests -Destination (Join-Path $backup 'previous_CT07_Tests') -Recurse -Force
}
if (Test-Path -LiteralPath $destWpf -PathType Container) {
    Copy-Item -LiteralPath $destWpf -Destination (Join-Path $backup 'previous_CT07_Window') -Recurse -Force
}
# Existing V0.6.8 self-tests hardcode exactly five executable modules.
# Change those assertions ONCE into future-proof minimum/required-base checks.
# These are test harness corrections, NOT runtime/test/driver source changes.
$checkPath = Join-Path $ProjectRoot 'scripts/check_sources.py'
$selfPath = Join-Path $ProjectRoot 'src/Dts.SelfTest/Program.cs'
if (-not (Test-Path -LiteralPath $checkPath -PathType Leaf) -or
    -not (Test-Path -LiteralPath $selfPath -PathType Leaf)) {
    throw 'Required baseline self-test source files are absent; not changing project.'
}
$checkSource = Get-Content -LiteralPath $checkPath -Raw -Encoding UTF8
$readyOld = "assert ready=={'S0-04','CT-02','CT-05','CT-09','CT-12'},ready"
$readyNew = "assert {'S0-04','CT-02','CT-05','CT-09','CT-12'}.issubset(ready),ready"
if ($checkSource.Contains($readyOld)) {
    Copy-Item -LiteralPath $checkPath -Destination (Join-Path $backup 'check_sources.py')
    $checkSource = $checkSource.Replace($readyOld, $readyNew)
    $checkSource = $checkSource.Replace(
        "print('PASS: 84 IDs / 84 independent .cs files; 5 actual entry points; 79 blocked placeholders')",
        "print(f'PASS: 84 IDs / 84 independent .cs files; {len(ready)} executable entries; {84-len(ready)} placeholders')")
    [System.IO.File]::WriteAllText($checkPath, $checkSource, (New-Object System.Text.UTF8Encoding($false)))
} elseif (-not $checkSource.Contains($readyNew)) {
    throw 'Unknown check_sources.py version. Refusing to rewrite an unrecognized self-test.'
}
$selfSource = Get-Content -LiteralPath $selfPath -Raw -Encoding UTF8
$guardOld = 'Ensure(registry.Modules.Count(m => m.IsExecutable) == 5,'
$guardNew = 'Ensure(registry.Modules.Count(m => m.IsExecutable) >= 5,'
if ($selfSource.Contains($guardOld)) {
    Copy-Item -LiteralPath $selfPath -Destination (Join-Path $backup 'SelfTest_Program.cs')
    $selfSource = $selfSource.Replace($guardOld, $guardNew)
    $selfSource = [regex]::Replace($selfSource,
        '(?m)^Console\.WriteLine\("PASS: 84/84.*$',
        'Console.WriteLine($"PASS: 84/84 modules found; {registry.Modules.Count(m => m.IsExecutable)} executable modules");')
    [System.IO.File]::WriteAllText($selfPath, $selfSource, (New-Object System.Text.UTF8Encoding($false)))
} elseif (-not $selfSource.Contains($guardNew)) {
    throw 'Unknown Dts.SelfTest/Program.cs version. Refusing to rewrite an unrecognized self-test.'
}
New-Item -ItemType Directory -Path $destTests -Force | Out-Null
New-Item -ItemType Directory -Path $destWpf -Force | Out-Null
foreach ($f in (Get-ChildItem -LiteralPath $srcTests -File)) {
    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $destTests $f.Name) -Force
}
foreach ($f in (Get-ChildItem -LiteralPath $srcWpf -File)) {
    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $destWpf $f.Name) -Force
}
if (Test-Path -LiteralPath $old -PathType Leaf) {
    Remove-Item -LiteralPath $old -Force
}

$module = Join-Path $destTests 'CT_07_Test.cs'
$window = Join-Path $destWpf 'CT07Window.xaml.cs'
if (-not (Test-Path -LiteralPath $module) -or -not (Test-Path -LiteralPath $window) -or
    (Test-Path -LiteralPath $old)) {
    throw 'CT-07 module installation verification failed. Inspect the backup folder.'
}
# Cross-module duplicate-type guard after installation.
$allTestSources = Get-ChildItem -LiteralPath (Join-Path $ProjectRoot 'src/Dts.Tests') -Filter '*.cs' -File -Recurse |
    Where-Object { $_.FullName -notmatch '[\\/](obj|bin)[\\/]' }
foreach ($typeName in @('CT_03_Test', 'CT_04_Test', 'CT_06_Test', 'CT_07_Test')) {
    $definitions = @(
        $allTestSources | Where-Object {
            $text = Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8
            $text -match ('\bclass\s+' + $typeName + '\b')
        }
    )
    if ($definitions.Count -gt 1) {
        throw "Duplicate test class $typeName found in $($definitions.Count) files. See project sources before rebuilding."
    }
    if ($typeName -eq 'CT_07_Test' -and $definitions.Count -ne 1) {
        throw 'CT_07_Test class was not installed exactly once.'
    }
}
Write-Host "CT-07 installed successfully." -ForegroundColor Green
Write-Host "Tests:  $destTests"
Write-Host "Window: $destWpf"
Write-Host "Backup: $backup"
Write-Host 'Next: Open DTS.TestPlatform.sln in Visual Studio. Choose Build > Rebuild Solution.'
Write-Host 'No other test module, MainWindow, hardware driver or calibration file was changed.'
