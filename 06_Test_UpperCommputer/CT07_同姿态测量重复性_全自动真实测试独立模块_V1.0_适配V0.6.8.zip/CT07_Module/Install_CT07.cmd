@echo off
chcp 65001 >nul
setlocal
set "ROOT=%~1"
if not defined ROOT (
  echo ===================================================
  echo CT-07 V1.0 return-repeatability installer for DTS TestPlatform V0.6.8
  echo Provide the project folder containing DTS.TestPlatform.sln
  echo ===================================================
  set /p ROOT=Project root folder path: 
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install_CT07.ps1" -ProjectRoot "%ROOT%"
if errorlevel 1 (
  echo.
  echo Installation failed. See the error text above.
) else (
  echo.
  echo Installation done. Rebuild the solution in Visual Studio.
)
pause
