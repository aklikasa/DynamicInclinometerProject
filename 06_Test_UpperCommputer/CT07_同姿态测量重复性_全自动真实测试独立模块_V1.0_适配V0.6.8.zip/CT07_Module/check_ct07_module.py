"""CT-07 static preflight; NOT a substitute for Windows dotnet build / bench acceptance."""
from pathlib import Path
from collections import Counter
import re,sys,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent
cs=list((r/'src/Dts.Tests/S1/CT07').glob('*.cs'))
assert len(cs)==4,cs
win=r/'src/Dts.Wpf/TestWindows/CT07/CT07Window.xaml'
code=win.with_suffix('.xaml.cs')
assert code.exists()
xaml=win.read_text(encoding='utf-8')
root=ET.parse(win).getroot()
for el in root.iter():
    tag=el.tag.rsplit('}',1)[-1]
    if 'TextWrapping' in el.attrib: assert tag in ('TextBlock','TextBox'),(tag,el.attrib)
    if tag=='CheckBox':assert 'TextWrapping' not in el.attrib
for name in re.findall(r'x:Name="([A-Za-z_]\w*)"',xaml):
    assert xaml.count('x:Name="'+name+'"')==1,name
source=code.read_text(encoding='utf-8')
for handler in re.findall(r'\b(?:Click|Checked|Unchecked|TextChanged|Closing)="([A-Za-z_]\w*)"',xaml):
    assert handler+'(' in source,handler
for filename in [*cs,code]:
    t=filename.read_text(encoding='utf-8')
    assert not re.search(r'\b(?:CT_03_Test|CT_04_Test|CT_06_Test|Ct06Algorithm)\b',t),filename
    assert 'new List<object?[]> {\n    [' not in t,filename
entry=(r/'src/Dts.Tests/S1/CT07/CT_07_Test.cs').read_text(encoding='utf-8')
assert len(re.findall(r'\bclass\s+CT_07_Test\b',entry))==1
assert 'public override string TestId => "CT-07";' in entry
assert 'public override bool IsExecutable => true;' in entry
assert 'StopTwoTdBothAsync' in entry and 'CaptureStaticPointAsync' in entry
assert 'Ct07Report.ExportAsync' in entry
assert 'TestWindowFor("CT-07")' in source
assert 'public CT07Window(TestDefinition definition,ITestModule module,' in source
assert 'physical' in entry and 'corrected' in entry
print('PASS CT-07: independent 6 source files, WPF event/identity checks, report, motion stop')
