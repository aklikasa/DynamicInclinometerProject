using Dts.TestEngine;

namespace Dts.Tests.S2;

/// <summary>
/// S2-05 - GYRO 比例因子温度变化
/// 当前为安全占位；实现时仅修改本文件。不得在尚未校验实测结果时返回 PASS。
/// </summary>
public sealed class S2_05_Test : TestModuleBase
{
    public override string TestId => "S2-05";
}
